import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, CheckCircle2, ChevronDown, House, LoaderCircle, MessageCircle, Send, Sofa, Sparkles, X } from 'lucide-react';
import { generateFurnishedModel, getDefaultFurniture, validateDesignBrief } from './furnishing.mjs';
import { createAIPlanBrief, getAIPlanReview } from './ai-plan.mjs';
import type { DesignBrief, FurnitureKind, HouseModel, RoomUse } from './types';
import './design-assistant.css';

interface Props { model: HouseModel; aiConfigured: boolean; onApply: (model: HouseModel) => void; onClose: () => void }
const USES: { id: RoomUse; label: string }[] = [{ id:'living',label:'客厅' },{ id:'bedroom',label:'卧室' },{ id:'study',label:'书房' },{ id:'kitchen',label:'厨房' },{ id:'bathroom',label:'卫生间' },{ id:'entry',label:'玄关' },{ id:'dining',label:'餐厅' },{ id:'empty',label:'暂不安排' }];
const ITEMS: Record<FurnitureKind,string> = { sofa:'沙发',coffee_table:'茶几',tv_console:'电视柜',bed_double:'双人床',bed_single:'单人床',wardrobe:'衣柜',desk:'书桌',chair:'座椅',dining_table:'餐桌',kitchen_counter:'橱柜',sink_cabinet:'洗手台',toilet:'马桶',shoe_cabinet:'鞋柜' };
const NEEDS = [{ id:'work',label:'居家办公' },{ id:'storage',label:'更多收纳' },{ id:'dining',label:'在家用餐' },{ id:'children',label:'儿童空间' },{ id:'pet',label:'宠物活动' },{ id:'senior',label:'长辈同住' },{ id:'accessibility',label:'宽敞通行' },{ id:'relax',label:'休闲阅读' }];
const STYLES: {id:DesignBrief['style'];name:string;detail:string;colors:string[]}[] = [
  {id:'warm',name:'温暖现代',detail:'米白、浅木与柔和织物',colors:['#e8e0d0','#c6a47a','#879784']},
  {id:'minimal',name:'清爽极简',detail:'浅色石材与干净线条',colors:['#f0eee8','#d6d6cb','#7a8985']},
  {id:'natural',name:'自然原木',detail:'木纹与低饱和绿意',colors:['#d1b28a','#dce3d4','#647761']},
  {id:'industrial',name:'沉稳工业',detail:'深木、灰石与金属色',colors:['#76553c','#899191','#343b3b']},
];
const STEPS = ['确认空间','居住需求','设计偏好','生成方案'];
const QUESTIONS = ['先确认一下，每个空间准备怎么使用？','谁会住在这里，希望家里满足哪些需求？','你喜欢哪种空间氛围？','这是按你的选择安排的家具方案。'];
type Message = { role:'user'|'assistant'; content:string; source?:'qwen'|'local' };

export default function DesignAssistant({model,aiConfigured,onApply,onClose}:Props) {
  const [brief,setBrief] = useState<DesignBrief>(()=>createAIPlanBrief(model));
  const aiReview = getAIPlanReview(model);
  const [step,setStep] = useState(0), [expanded,setExpanded] = useState<string|null>(null);
  const [messages,setMessages] = useState<Message[]>([]), [input,setInput] = useState('');
  const [busy,setBusy] = useState(false), [error,setError] = useState(''), [notice,setNotice] = useState('');
  const dialog = useRef<HTMLElement>(null), main = useRef<HTMLDivElement>(null), request = useRef<AbortController|null>(null), chatEnd = useRef<HTMLDivElement>(null);
  const returnFocus = useRef(document.activeElement instanceof HTMLElement ? document.activeElement : null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const prepared = useMemo(()=>{
    if(step!==3)return null;
    try{return generateFurnishedModel(model,brief);}catch(e){return {model:null,warnings:[e instanceof Error?e.message:'请检查设计需求。']};}
  },[model,brief,step]);
  useEffect(()=>{
    const previous=returnFocus.current;
    dialog.current?.focus({preventScroll:true});
    function key(event:KeyboardEvent){
      if(event.key==='Escape'){event.preventDefault();closeRef.current();return;}
      if(event.key!=='Tab')return;
      const nodes=Array.from(dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]')??[]).filter(el=>el.getClientRects().length);
      const first=nodes[0],last=nodes[nodes.length-1];
      if(!first){event.preventDefault();dialog.current?.focus({preventScroll:true});return;}
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===dialog.current)){event.preventDefault();last?.focus();}
      else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===dialog.current)){event.preventDefault();first.focus();}
    }
    document.addEventListener('keydown',key);
    return()=>{document.removeEventListener('keydown',key);request.current?.abort();request.current=null;queueMicrotask(()=>{if(previous?.isConnected&&!previous.closest('[inert]'))previous.focus({preventScroll:true});});};
  },[]);
  useEffect(()=>{chatEnd.current?.scrollIntoView({block:'nearest'});},[messages]);
  useEffect(()=>{main.current?.scrollTo({top:0});},[step]);
  function updateRoom(roomId:string,patch:Partial<DesignBrief['rooms'][number]>){setBrief(b=>({...b,rooms:b.rooms.map(r=>r.roomId===roomId?{...r,...patch}:r)}));}
  function toggleItem(roomId:string,kind:FurnitureKind){const r=brief.rooms.find(r=>r.roomId===roomId)!;const items=r.items??getDefaultFurniture(r.use,brief.needs);updateRoom(roomId,{items:items.includes(kind)?items.filter(k=>k!==kind):[...items,kind]});}
  async function sendMessage(){
    const content=input.trim();if(!content||busy)return;
    const history=[...messages,{role:'user' as const,content}].slice(-20);
    setMessages(history);setInput('');setBusy(true);setError('');setNotice('');
    const controller=new AbortController();request.current=controller;
    const timeout=setTimeout(()=>controller.abort(),55000);
    try{
      const response=await fetch('/api/design-chat',{method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,body:JSON.stringify({model:{width:model.width,depth:model.depth,rooms:model.rooms.map(r=>({id:r.id,name:r.name,area:r.area}))},brief,messages:history.map(({role,content})=>({role,content}))})});
      const data=await response.json();if(!response.ok)throw new Error(typeof data.detail==='string'?data.detail:'需求分析失败，请稍后重试。');
      if(typeof data.reply!=='string'||!['qwen','local'].includes(data.source))throw new Error('需求分析未返回有效方案。');
      setBrief(validateDesignBrief(model,data.brief));
      setMessages([...history,{role:'assistant' as const,content:data.reply,source:data.source as 'qwen'|'local'}].slice(-20));
      const warningText=Array.isArray(data.warnings)?data.warnings.filter((w:unknown)=>typeof w==='string'&&!w.startsWith('未配置QWEN_API_KEY')).join('；'):'';
      setNotice((data.source==='local'?'需求已更新，请核对空间用途和家具清单。':'千问已更新你的需求，请核对空间用途和家具清单。')+(warningText?' '+warningText:''));
    }catch(e){if(!controller.signal.aborted||request.current===controller)setError(controller.signal.aborted?'问答请求超时，请重试或继续填写下面的选择。':e instanceof Error?e.message:'问答服务无法连接。');}
    finally{clearTimeout(timeout);if(request.current===controller){request.current=null;setBusy(false);}}
  }
  const furnishedRooms=brief.rooms.filter(r=>r.furnish&&r.use!=='empty').length;
  return <div className="assistant-backdrop"><section ref={dialog} tabIndex={-1} className="design-assistant" role="dialog" aria-modal="true" aria-label="问答生成家居方案">
    <header className="assistant-header"><div className="assistant-mark"><House size={22}/></div><div><h2>一起设计你的家</h2><p>{model.rooms.length}个空间，{model.rooms.reduce((s,r)=>s+r.area,0).toFixed(1)} m² · 从需求开始，生成家具与材质方案</p></div><span className={`assistant-provider ${aiConfigured?'connected':''}`}><span/>{aiConfigured?'千问密钥已配置':'本地需求引导'}</span><button className="assistant-close" onClick={onClose} aria-label="关闭设计问答"><X size={20}/></button></header>
    <div className="assistant-body"><aside className="assistant-context"><span className="assistant-eyebrow">你的户型</span><svg className="assistant-plan" viewBox={`-.5 -.5 ${model.width+1} ${model.depth+1}`} aria-label="已识别的房间轮廓">{model.rooms.map((room,index)=>{const selection=brief.rooms.find(r=>r.roomId===room.id);return <g key={room.id}><polygon points={room.polygon.map(p=>p.join(',')).join(' ')} fill={selection?.furnish?'#e5ede3':'#f2f3ef'} stroke="#728d79" strokeWidth=".05"/><text x={room.polygon.reduce((s,p)=>s+p[0],0)/room.polygon.length} y={room.polygon.reduce((s,p)=>s+p[1],0)/room.polygon.length} textAnchor="middle" dominantBaseline="middle" fontSize={Math.max(.2,model.width*.029)} fill="#345341">{index+1}</text></g>;})}</svg><p className="assistant-plan-note">编号对应右侧的空间清单。尺寸与墙体沿用户导入的户型保留。</p><nav aria-label="设计问答步骤">{STEPS.map((label,index)=><button key={label} aria-current={step===index?'step':undefined} disabled={busy} className={step===index?'current':step>index?'done':''} onClick={()=>setStep(index)}><span>{step>index?<Check size={12}/>:String(index+1).padStart(2,'0')}</span>{label}</button>)}</nav><div className="assistant-context-foot"><Sofa size={17}/><span>你来决定需求<br/>我们安排家具和材质</span></div></aside>
      <div ref={main} className="assistant-main"><div key={step} className="assistant-step-heading"><span>第 {step+1} / 4 步</span><h3>{QUESTIONS[step]}</h3><p>{step===0?'识别结果提供空间轮廓，建议用途需要你确认。':step===1?'这些选择会影响家具数量、收纳和通行空间。':step===2?'材质与家具颜色会一起搭配，生成后仍能继续编辑。':'先查看家具清单和摆放提示，再应用到三维模型。'}</p></div>
      {step===0&&aiReview&&['applied','reviewed'].includes(aiReview.status)&&<div className="assistant-ai-review"><strong><Sparkles size={15}/>{aiReview.geometryRebuilt?'已带入 AI 重建与规划初稿':'已带入 AI 图纸核对建议'}</strong><p>空间用途、家具清单与设计说明已经预填。请按你的实际需求调整；家具位置会检查墙距、门扇与通路。</p>{aiReview.layoutSuggestions.length>0&&<ul>{aiReview.layoutSuggestions.slice(0,4).map(s=><li key={s.roomId}>{model.rooms.find(r=>r.id===s.roomId)?.name}：{s.placement}</li>)}</ul>}</div>}
      {step===0&&<div className="assistant-rooms">{model.rooms.map((room,index)=>{const draft=brief.rooms.find(r=>r.roomId===room.id)!;const items=draft.items??getDefaultFurniture(draft.use,brief.needs);return <div key={room.id} className="assistant-room"><div className="assistant-room-line"><span className="assistant-room-number">{index+1}</span><div><strong>{room.name}</strong><small>{room.area.toFixed(1)} m²</small></div><select aria-label={`${room.name}用途`} value={draft.use} disabled={busy} onChange={e=>updateRoom(room.id,{use:e.target.value as RoomUse,furnish:e.target.value!=='empty',items:undefined})}>{USES.map(u=><option key={u.id} value={u.id}>{u.label}</option>)}</select></div><div className="assistant-room-actions"><label><input type="checkbox" checked={draft.furnish} disabled={busy||draft.use==='empty'} onChange={e=>updateRoom(room.id,{furnish:e.target.checked})}/>生成家具</label><button aria-expanded={expanded===room.id} disabled={busy||!draft.furnish} onClick={()=>setExpanded(expanded===room.id?null:room.id)}>选择家具<ChevronDown size={13}/></button></div>{expanded===room.id&&draft.furnish&&<div className="assistant-item-list">{(Object.keys(ITEMS) as FurnitureKind[]).map(kind=><button key={kind} disabled={busy} aria-pressed={items.includes(kind)} onClick={()=>toggleItem(room.id,kind)}>{items.includes(kind)&&<Check size={12}/>} {ITEMS[kind]}</button>)}</div>}</div>;})}</div>}
      {step===1&&<><div className="assistant-residents"><div><strong>居住人数</strong><p>主要考虑日常起居与床位需求</p></div><input aria-label="居住人数" type="number" min="1" max="12" value={brief.residents} disabled={busy} onChange={e=>setBrief(b=>({...b,residents:Math.max(1,Math.min(12,Math.trunc(Number(e.target.value))||1))}))}/><span>人</span></div><div className="assistant-need-grid">{NEEDS.map(n=><button key={n.id} disabled={busy} aria-pressed={brief.needs.includes(n.id)} className={brief.needs.includes(n.id)?'chosen':''} onClick={()=>setBrief(b=>({...b,needs:b.needs.includes(n.id)?b.needs.filter(id=>id!==n.id):[...b.needs,n.id]}))}><span>{brief.needs.includes(n.id)?<Check size={15}/>:<PlusMark/>}</span>{n.label}</button>)}</div></>}
      {step===2&&<><div className="assistant-styles">{STYLES.map(s=><button key={s.id} disabled={busy} aria-label={`设计风格${s.name}`} aria-pressed={brief.style===s.id} className={brief.style===s.id?'chosen':''} onClick={()=>setBrief(b=>({...b,style:s.id}))}><div className="assistant-style-sample">{s.colors.map(c=><i key={c} style={{backgroundColor:c}}/>)}{brief.style===s.id&&<span><Check size={14}/></span>}</div><strong>{s.name}</strong><small>{s.detail}</small></button>)}</div><label className="assistant-notes">其他想法<textarea aria-label="其他设计想法" maxLength={2000} value={brief.notes} disabled={busy} placeholder="比如：主卧留书桌、不需要电视柜。可在下方问答中提交，让助手整理为家具清单。" onChange={e=>setBrief(b=>({...b,notes:e.target.value}))}/><small>描述中的具体家具增减需通过下方问答或第一步的家具清单确认。</small></label></>}
      {step===3&&<><div className="assistant-summary"><div><span>空间氛围</span><strong>{STYLES.find(s=>s.id===brief.style)?.name}</strong></div><div><span>家具布局</span><strong>{prepared?.model?.furniture?.length??0}件 / {furnishedRooms}个空间</strong></div><div><span>居住需求</span><strong>{brief.residents}人 · {brief.needs.length}项需求</strong></div></div><div className="assistant-review">{brief.rooms.map(r=>{const room=model.rooms.find(m=>m.id===r.roomId)!;const placed=prepared?.model?.furniture?.filter(f=>f.roomId===r.roomId)??[];return <div key={r.roomId}><span>{room.name}<small>{USES.find(u=>u.id===r.use)?.label}</small></span><p>{placed.length?placed.map(f=>ITEMS[f.kind]).join('、'):'保留空房'}</p></div>;})}</div>{!!prepared?.warnings.length&&<div className="assistant-warnings"><strong>摆放提示</strong>{prepared.warnings.map((w,index)=><p key={index}>{w}</p>)}</div>}<p className="assistant-result-note"><CheckCircle2 size={15}/>家具按房间轮廓、墙体和门洞避让。放不下的家具会提示并跳过，应用后可进入房间查看。</p></>}
      <section className="assistant-chat" aria-label="设计需求问答"><div className="assistant-chat-title"><MessageCircle size={15}/><strong>还有具体想法，直接告诉{aiConfigured?' AI':'助手'}</strong></div>{messages.length>0&&<div className="assistant-messages" aria-live="polite">{messages.map((message,index)=><div key={index} className={`assistant-message ${message.role}`}><small>{message.role==='user'?'你':message.source==='qwen'?'千问设计助手':'本地需求助手'}</small><p>{message.content}</p></div>)}<div ref={chatEnd}/></div>}<p className="assistant-plan-note">提交问答会更新需求草稿；完成四步并点击“生成我的家”，家具才会进入三维模型。</p><form onSubmit={e=>{e.preventDefault();void sendMessage();}} className="assistant-chat-input"><input aria-label="向设计助手描述需求" maxLength={2000} value={input} onChange={e=>setInput(e.target.value)} placeholder="例如：两个人住，主卧放书桌，不要电视柜" disabled={busy}/><button type="submit" disabled={busy||!input.trim()} aria-label="提交设计需求">{busy?<LoaderCircle size={17} className="spin"/>:<Send size={17}/>}</button></form><p className="assistant-privacy">{aiConfigured?'本次设计问答仅发送房间名称、面积和需求对话。导入时的 AI 重建会单独发送图纸；现场照片通过巡检分析提交。':'尚未配置千问密钥，当前使用本地规则问答；用途、家具和风格选择仍可生成方案。'}</p>{notice&&<p className="assistant-notice" role="status">{notice}</p>}{error&&<p className="assistant-error" role="alert">{error}</p>}</section>
      </div></div><footer className="assistant-footer"><button className="button secondary" disabled={busy} onClick={()=>step===0?onClose():setStep(s=>s-1)}><ArrowLeft size={15}/>{step===0?'稍后设计':'上一步'}</button><span>{step===3?'应用后会替换当前家具与材质方案，施工记录保留。':'所有选择都可以返回修改。'}</span>{step<3?<button className="button primary" disabled={busy} onClick={()=>setStep(s=>s+1)}>下一步<ArrowRight size={15}/></button>:<button className="button primary" disabled={busy||!prepared?.model} onClick={()=>{if(prepared?.model)onApply(prepared.model);}}><Sparkles size={16}/>生成我的家</button>}</footer>
  </section></div>;
}
function PlusMark(){return <span className="assistant-plus">+</span>;}
