import type { HouseModel, Room } from './types';

export interface RoomQuote { floorUnitPrice: number | null; floorWastePercent: number; wallUnitPrice: number | null }
export interface BudgetQuote { id: string; name: string; rooms: Record<string, RoomQuote>; furniture: Record<string, number | null> }
export interface BudgetConfig { version: 1; selectedQuoteId: string; quotes: BudgetQuote[] }
export interface BudgetStaleReferences { roomIds: string[]; furnitureIds: string[] }
export interface EdgeQuantity {
  edgeIndex: number; length: number; grossArea: number; deductionArea: number; netArea: number;
  estimatedLength: number; wallIds: string[]; deductions: { openingId: string; type: 'door' | 'window'; area: number }[];
}
export interface RoomQuantities {
  roomId: string; floorArea: number; perimeter: number; wallGrossArea: number; openingDeductionArea: number;
  wallNetArea: number; estimatedBoundaryLength: number; edges: EdgeQuantity[];
}
export interface BudgetRow {
  id: string; category: 'floor' | 'wall' | 'furniture'; roomId: string; roomName: string; label: string;
  netQuantity: number; quantity: number; unit: 'm²' | '件'; wastePercent: number; unitPrice: number | null; amount: number | null;
}
export interface BudgetResult {
  quoteId: string; quoteName: string; rows: BudgetRow[]; roomQuantities: RoomQuantities[]; partialTotal: number;
  pendingCount: number; complete: boolean; total: number | null; stale: BudgetStaleReferences; measurementLabel: string;
}
export const FURNITURE_LABELS: Readonly<Record<string, string>>;
export function createBudgetConfig(): BudgetConfig;
export function validateBudgetConfig(raw: unknown, model?: HouseModel): BudgetConfig;
export function getBudgetConfig(model: HouseModel): BudgetConfig;
export function setBudgetConfig(model: HouseModel, config: BudgetConfig): HouseModel;
export function getRoomQuote(quote: BudgetQuote, roomId: string): RoomQuote;
export function createBudgetQuote(config: BudgetConfig, copyId?: string | null): BudgetConfig;
export function getStaleBudgetReferences(model: HouseModel, quote: BudgetQuote): BudgetStaleReferences;
export function cleanStaleBudgetReferences(model: HouseModel, config: BudgetConfig, quoteId: string): BudgetConfig;
export function parseBudgetInput(raw: string, kind?: 'price' | 'waste'): { value: number | null; error: string | null };
export function calculateLineAmount(quantity: number, unitPrice: number | null): number | null;
export function polygonFloorArea(polygon: Room['polygon']): number;
export function calculateRoomQuantities(model: HouseModel, room: Room): RoomQuantities;
export function getBudgetMeasurementLabel(model: HouseModel): string;
export function calculateBudget(model: HouseModel, quote: BudgetQuote): BudgetResult;
export function compareBudgets(model: HouseModel, config: BudgetConfig): { budgets: BudgetResult[]; complete: boolean; difference: number | null };
export function csvSafeCell(value: unknown): string;
export function exportBudgetCsv(model: HouseModel, config: BudgetConfig, quoteIds?: string[] | null): string;
