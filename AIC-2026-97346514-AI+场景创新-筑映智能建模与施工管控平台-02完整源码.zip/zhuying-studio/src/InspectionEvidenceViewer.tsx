import { useEffect, useRef, useState } from 'react';
import { X, Images, ArrowRight, ShieldCheck } from 'lucide-react';
import { WORK_TYPES, stageLabel } from './progress.mjs';
import { evidenceSource } from './ConstructionPanel';
import type { Evidence, Room } from './types';
import './evidence-viewer.css';

const photosOf = (evidence: Evidence) => evidence.photos ?? [{id:evidence.id,image:evidence.image,viewpoint:'历史照片'}];
export default function InspectionEvidenceViewer({ room, evidence, onClose }: {room: Room; evidence: Evidence; onClose: ()=>void}) {
  const candidates=(room.evidence??[]).filter(e=>e.confirmed&&e.id!==evidence.id&&e.workType===evidence.workType&&e.date<evidence.date).slice().reverse().sort((a,b)=>b.date.localeCompare(a.date));
  const [previousId,setPreviousId]=useState(evidence.comparison?.previousEvidenceId??candidates[0]?.id??'');
  const previous=candidates.find(e=>e.id===previousId);
  const [currentIndex,setCurrentIndex]=useState(0),[previousIndex,setPreviousIndex]=useState(0);
  const currentPhotos=photosOf(evidence),previousPhotos=previous?photosOf(previous):[];
  const recordedComparison=previous?.id===evidence.comparison?.previousEvidenceId?evidence.comparison:undefined;
  const dialog=useRef<HTMLElement>(null),returnFocus=useRef(document.activeElement instanceof HTMLElement?document.activeElement:null),closeRef=useRef(onClose);
  closeRef.current=onClose;
  useEffect(()=>{
    dialog.current?.focus({preventScroll:true});
    const key=(event:KeyboardEvent)=>{
      if(event.key==='Escape'){event.preventDefault();closeRef.current();return;}
      if(event.key!=='Tab')return;
      const nodes=Array.from(dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),select:not(:disabled)')??[]).filter(el=>el.getClientRects().length);
      const first=nodes[0],last=nodes[nodes.length-1];
      if(!first){event.preventDefault();return;}
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===dialog.current)){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===dialog.current)){event.preventDefault();first.focus();}
    };
    document.addEventListener('keydown',key);
    return()=>{document.removeEventListener('keydown',key);queueMicrotask(()=>{const previous=returnFocus.current;if(previous?.isConnected&&!previous.closest('[inert]'))previous.focus({preventScroll:true});});};
  },[]);
  return <div className="evidence-viewer-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><section className="evidence-viewer" role="dialog" aria-modal="true" aria-label="巡检照片与前后对比" ref={dialog} tabIndex={-1}>
    <header><div className="evidence-viewer-mark"><Images size={22}/></div><div><h2>{room.name} · 现场证据</h2><p>{WORK_TYPES.find(w=>w.id===evidence.workType)?.label} · 多角度巡检与前后对照</p></div><button className="icon-button" aria-label="关闭巡检对比" onClick={onClose}><X size={20}/></button></header>
    <div className="evidence-viewer-body">
      <div className="evidence-comparison-picker"><label>对照此前记录<select aria-label="选择对照巡检日期" value={previousId} onChange={e=>{setPreviousId(e.target.value);setPreviousIndex(0);}}><option value="">仅查看本次巡检</option>{candidates.map(e=><option key={e.id} value={e.id}>{e.date} · {stageLabel(e.stage)} · {photosOf(e).length}张照片</option>)}</select></label><span>照片来自同一房间、同一工序；不同拍摄视角可分别选择。</span></div>
      <div className={`evidence-photo-columns ${previous?'comparing':''}`}>
        {previous&&<div className="evidence-photo-column"><div className="evidence-photo-heading"><span>此前 · {previous.date}</span><strong className={`construction-stage ${previous.stage}`}>{stageLabel(previous.stage)}</strong></div><div className="evidence-photo-large"><img src={previousPhotos[previousIndex]?.image} alt={`${previous.date}对照照片${previousIndex+1}`}/></div><div className="evidence-photo-thumbnails">{previousPhotos.map((p,index)=><button key={p.id} aria-label={`查看此前照片${index+1}`} aria-pressed={previousIndex===index} onClick={()=>setPreviousIndex(index)}><img src={p.image} alt=""/><span>{p.viewpoint||`视角 ${index+1}`}</span></button>)}</div><p>{previous.summary}</p></div>}
        <div className="evidence-photo-column"><div className="evidence-photo-heading"><span>本次 · {evidence.date}</span><strong className={`construction-stage ${evidence.stage}`}>{stageLabel(evidence.stage)}</strong></div><div className="evidence-photo-large"><img src={currentPhotos[currentIndex]?.image} alt={`${evidence.date}本次照片${currentIndex+1}`}/></div><div className="evidence-photo-thumbnails">{currentPhotos.map((p,index)=><button key={p.id} aria-label={`查看本次照片${index+1}`} aria-pressed={currentIndex===index} onClick={()=>setCurrentIndex(index)}><img src={p.image} alt=""/><span>{p.viewpoint||`视角 ${index+1}`}</span></button>)}</div><p>{evidence.summary}</p>{evidence.observations?.find(o=>o.photoIndex===currentIndex)&&<p className="evidence-photo-observation">{evidence.source.startsWith('qwen/')?'AI对该照片的观察：':'照片复核提示：'}{evidence.observations.find(o=>o.photoIndex===currentIndex)?.summary}</p>}</div>
      </div>
      {previous&&<section className="evidence-comparison-conclusion"><div><ShieldCheck size={16}/><strong>已确认状态对照</strong><span>{stageLabel(previous.stage)}<ArrowRight size={12}/>{stageLabel(evidence.stage)}</span></div>{recordedComparison?<p><strong>{recordedComparison.source.startsWith('qwen/')?'AI影像对比：':'对比记录：'}</strong>{recordedComparison.summary}</p>:<p>这里对照的是两次人工确认的状态与现场照片。尚未保存针对这组照片的 AI 变化分析。</p>}</section>}
      {evidence.aiStage!==undefined&&evidence.aiStage!==evidence.stage&&<p className="evidence-human-override">{evidence.source.startsWith('qwen/')?'AI原建议':'原复核提示'}为“{stageLabel(evidence.aiStage)}”，巡检人已修正为“{stageLabel(evidence.stage)}”。最终状态以人工确认记录为准。</p>}
    </div>
    <footer><span>{evidenceSource(evidence)} · 外观完成不等于工程验收通过</span><button className="button secondary" onClick={onClose}>返回工作台</button></footer>
  </section></div>;
}
