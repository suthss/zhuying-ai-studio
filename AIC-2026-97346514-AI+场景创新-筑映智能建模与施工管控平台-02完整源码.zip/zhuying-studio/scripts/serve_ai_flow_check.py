"""Isolated UI replay server: no credentials and no outbound AI requests.

Run after the public-image live check has written ai-rebuild-verified.json.
All project writes go to the separate check database.
"""
import json
import os
from pathlib import Path

from fastapi import FastAPI, File, Form, UploadFile
from backend.project_library import router

ROOT = Path(__file__).resolve().parents[1]
os.environ['PROJECT_DATABASE_PATH'] = str(ROOT / 'artifacts/ai-flow-check.sqlite3')
app = FastAPI(title='筑映 · 隔离界面回放检查')
app.include_router(router)


@app.get('/api/health')
def health():
    return {'status':'ok', 'algorithm':'hybrid-floorplan-v2', 'visionConfigured':True,
            'designConfigured':False, 'planRecognition':{'available':True,'weightsPresent':True},
            'testReplay':True}


@app.post('/api/parse-plan')
async def parse(file:UploadFile=File(...), ai_mode:str=Form('local'), design_style:str=Form('warm')):
    await file.close()
    model=json.loads((ROOT / 'artifacts/ai-rebuild-verified.json').read_text(encoding='utf-8'))
    model['name']='公开图纸 · AI 重建验证'
    if ai_mode=='local':
        model['meta'].pop('aiReview',None)
    return model
