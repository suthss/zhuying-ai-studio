import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import ts from 'typescript';
import { chromium, expect } from '@playwright/test';
const url = 'http://127.0.0.1:5176';
assert.equal((await (await fetch(`${url}/api/health`)).json()).visionConfigured, false);
const code = ts.transpileModule(await fs.readFile('src/demo.ts', 'utf8'), { compilerOptions: { module: ts.ModuleKind.ESNext } }).outputText;
const { DEMO_MODEL } = await import(`data:text/javascript;base64,${Buffer.from(code).toString('base64')}`);
const fixture = structuredClone(DEMO_MODEL); fixture.source = 'manual'; fixture.meta = { demoData: false }; fixture.name = `保存恢复验收 ${Date.now()}`;
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 950 } });
await context.addInitScript(() => localStorage.setItem('zhuying-guide-seen-v1','1'));
const reports = [], errors = [];
const check = text => { reports.push(text); console.log(`PASS: ${text}`); };
async function api(path, method='GET', body) {
  const response = await context.request.fetch(`${url}/api/projects${path}`, { method, data: body });
  assert.ok(response.ok(), await response.text()); return response.json();
}
async function title(page, value) {
  await page.getByRole('button', { name:'项目设置', exact:true }).first().click();
  const dialog = page.getByRole('dialog', { name:'项目设置' });
  await dialog.getByLabel('项目名称').fill(value);
  await dialog.getByRole('button',{name:'保存设置',exact:true}).click();
}
async function open(page, name) {
  if (!await page.locator('.project-library').count()) await page.getByRole('button',{name:'项目库',exact:true}).click();
  await page.locator('article').filter({ has:page.getByRole('heading',{name,exact:true}) }).getByRole('button',{name:'打开项目',exact:true}).click();
  await expect(page.locator('.project-switcher>span').first()).toHaveText(name);
}
try {
  const saved = await api('', 'POST', { model:fixture,clientKey:crypto.randomUUID() });
  const page = await context.newPage(); page.on('pageerror',e=>errors.push(e.message));
  await page.goto(url); await page.getByRole('button',{name:'项目库',exact:true}).waitFor(); await open(page, fixture.name);
  const endpoint = `**/api/projects/${saved.id}`;
  let releaseSlow, sawSlow;
  const slowSeen = new Promise(resolve=>sawSlow=resolve);
  const slowGate = new Promise(resolve=>releaseSlow=resolve);
  let delayOnce = true;
  await page.route(endpoint, async route => {
    if (route.request().method()==='PUT' && delayOnce) { delayOnce=false; sawSlow(); await slowGate; }
    await route.continue();
  });
  await title(page, '慢保存第一版'); await slowSeen;
  await title(page, '慢保存最终版'); releaseSlow();
  await expect.poll(async()=>(await api(`/${saved.id}`)).name).toBe('慢保存最终版');
  await page.unroute(endpoint);
  check('慢保存期间的新修改按顺序保存，没有回退或丢失');

  const page2 = await context.newPage(); page2.on('pageerror',e=>errors.push(e.message));
  await page2.goto(url); await open(page2, '慢保存最终版');
  let releaseConflict, sawConflict;
  const conflictSeen = new Promise(resolve=>sawConflict=resolve);
  const conflictGate = new Promise(resolve=>releaseConflict=resolve);
  let conflictOnce=true;
  await page2.route(endpoint, async route=>{
    if(route.request().method()==='PUT'&&conflictOnce){conflictOnce=false;sawConflict();await conflictGate;}
    await route.continue();
  });
  await title(page2,'本地冲突草稿'); await conflictSeen;
  const remote = await api(`/${saved.id}`);
  await api(`/${saved.id}`, 'PUT', { revision:remote.revision,name:'远端最新模型' }); releaseConflict();
  await page2.locator('.library-workspace-notice[role=alert]').waitFor();
  assert.equal((await api(`/${saved.id}`)).name,'远端最新模型');
  await expect(page2.locator('.project-switcher>span').first()).toHaveText('本地冲突草稿');
  await page2.reload();
  await expect(page2.getByRole('button',{name:'项目库',exact:true})).toBeEnabled({timeout:20000});
  await expect(page2.locator('.project-switcher>span').first()).toHaveText('本地冲突草稿');
  await page2.locator('.library-workspace-notice[role=alert]').waitFor();
  assert.equal((await api(`/${saved.id}`)).name,'远端最新模型');
  await page2.getByRole('button',{name:'另存本地副本',exact:true}).click();
  await expect(page2.locator('.project-switcher>span').first()).toHaveText('本地冲突草稿 · 副本');
  assert.equal((await api(`/${saved.id}`)).name,'远端最新模型');
  check('旧版本冲突保留本地草稿，刷新后可恢复并另存，不覆盖远端');

  const key = await page2.evaluate(()=>sessionStorage.getItem('zhuying-workspace-session'));
  const duplicateTab = await context.newPage();
  await duplicateTab.addInitScript(key=>sessionStorage.setItem('zhuying-workspace-session',key),key);
  await duplicateTab.goto(url);
  await expect(duplicateTab.locator('.project-switcher>span').first()).toHaveText('本地冲突草稿 · 副本');
  assert.notEqual(await duplicateTab.evaluate(()=>sessionStorage.getItem('zhuying-workspace-session')),key);
  check('复制标签页分配独立草稿空间，避免覆盖另一窗口备份');

  const offline = await api('', 'POST', { model:{...fixture,name:'断网恢复验收'},clientKey:crypto.randomUUID() });
  await open(page2, '断网恢复验收');
  const offlineEndpoint=`**/api/projects/${offline.id}`;
  await page2.route(offlineEndpoint, route=>route.request().method()==='PUT'?route.abort('failed'):route.continue());
  await title(page2,'断网期间保留草稿');
  await page2.locator('.library-workspace-notice[role=alert]').waitFor();
  await page2.reload(); await expect(page2.getByRole('button',{name:'项目库',exact:true})).toBeEnabled({timeout:20000}); await expect(page2.locator('.project-switcher>span').first()).toHaveText('断网期间保留草稿');
  await page2.locator('.library-workspace-notice[role=alert]').waitFor();
  await page2.unroute(offlineEndpoint);
  await page2.getByRole('button',{name:'保存到项目库',exact:true}).click();
  await expect.poll(async()=>(await api(`/${offline.id}`)).name).toBe('断网期间保留草稿');
  check('断网未虚报保存，刷新恢复草稿，网络恢复后可重试入库');

  await page2.getByRole('button',{name:'项目库',exact:true}).click();
  const current=await api(`/${saved.id}`);
  await api(`/${saved.id}`,'PUT',{revision:current.revision,name:'轮询更新后的项目'});
  await page2.getByRole('heading',{name:'轮询更新后的项目',exact:true}).waitFor({timeout:8000});
  check('其他窗口提交后，总览自动刷新显示新摘要');
  assert.deepEqual(errors,[]);
} finally {
  await fs.writeFile('artifacts/library-recovery-check.json',JSON.stringify({checks:reports,errors},null,2));
  await browser.close();
}
