import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import ts from 'typescript';
import { chromium } from '@playwright/test';

// Run against the isolated 8011/5176 test services, never the user's database.
const url = 'http://127.0.0.1:5176';
const health = await (await fetch(`${url}/api/health`)).json();
assert.equal(health.visionConfigured, false, 'The isolated test backend must have no AI credentials');
const code = ts.transpileModule(await fs.readFile('src/demo.ts', 'utf8'), { compilerOptions: { module: ts.ModuleKind.ESNext } }).outputText;
const { DEMO_MODEL } = await import(`data:text/javascript;base64,${Buffer.from(code).toString('base64')}`);
const legacy = structuredClone(DEMO_MODEL);
legacy.name = `项目库验收 A ${Date.now()}`;
const bName = legacy.name.replace(' A ', ' B '); legacy.source = 'manual'; legacy.meta = { demoData: false };
for (const room of legacy.rooms) { room.evidence = []; room.tasks.floor.stage = 'unknown'; room.tasks.wall.stage = 'unknown'; room.tasks.floor.dueDate = ''; room.tasks.wall.dueDate = ''; room.progress = 0; }
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 950 } });
await context.addInitScript(model => { if (!localStorage.getItem('zhuying-model-v1')) localStorage.setItem('zhuying-model-v1', JSON.stringify(model)); localStorage.setItem('zhuying-guide-seen-v1','1'); }, legacy);
const page = await context.newPage();
const errors = []; page.on('pageerror', error => errors.push(error.message));
const reports = [];
const check = (name) => { reports.push(name); console.log(`PASS: ${name}`); };
async function api(path, method = 'GET', body) {
  const response = await context.request.fetch(`${url}/api/projects${path}`, { method, data: body });
  assert.ok(response.ok(), `API ${method} ${path}: ${await response.text()}`);
  return response.json();
}
try {
  await page.goto(url); await page.getByRole('button', { name: '保存到项目库', exact: true }).click();
  await page.getByText('已保存至项目库', { exact: true }).waitFor();
  let listing = await api('');
  const a = listing.projects.find(project => project.name === legacy.name); assert.ok(a);
  assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('zhuying-model-v1')).name), legacy.name);
  check('旧浏览器模型首次显式入库，旧存储备份仍保留');

  await page.getByRole('button', { name: '项目库', exact: true }).click();
  await page.getByRole('heading', { name: legacy.name, exact: true }).waitFor();
  await page.getByRole('button', { name: `复制 ${legacy.name} 为独立项目`, exact: true }).click();
  await page.getByRole('heading', { name: `${legacy.name} · 副本`, exact: true }).waitFor();
  listing = await api('');
  const b = listing.projects.find(project => project.name === `${legacy.name} · 副本`); assert.ok(b); assert.notEqual(a.id, b.id);
  check('相同模型创建独立副本，不覆盖原项目');
  await page.screenshot({ path: 'artifacts/library-desktop.png', fullPage: true });

  const bCard = page.locator('article').filter({ has: page.getByRole('heading', { name: `${legacy.name} · 副本`, exact: true }) });
  await bCard.getByRole('button', { name: '打开项目', exact: true }).click();
  await page.getByText('已保存至项目库', { exact: true }).waitFor();
  await page.getByRole('button', { name: '项目设置', exact: true }).first().click();
  const settings = page.getByRole('dialog', { name: '项目设置' });
  await settings.getByLabel('项目名称').fill(bName);
  await settings.getByRole('button', { name: '保存设置', exact: true }).click();
  await page.getByText('已保存至项目库', { exact: true }).waitFor();
  assert.equal((await api(`/${a.id}`)).name, legacy.name);
  assert.equal((await api(`/${b.id}`)).name, bName);
  check('副本更名自动保存，原项目名称独立');

  await page.getByRole('button', { name: '施工进度', exact: true }).click();
  await page.getByRole('button', { name: '添加巡检', exact: true }).first().click();
  const inspection = page.getByRole('dialog', { name: '让进展，有迹可循。', exact: true });
  const image = await fs.readFile('public/demo-plan.png');
  await inspection.locator('input[type=file]').setInputFiles({ name: 'test-only.png', mimeType: 'image/png', buffer: image });
  await inspection.locator('.inspection-photo').waitFor();
  await inspection.locator('.inspection-confirmation select').selectOption('in_progress');
  await inspection.getByRole('textbox', { name: '巡检说明', exact: true }).fill('项目库自动化测试资料，并非真实施工证据');
  await inspection.getByRole('button', { name: '确认巡检', exact: true }).click();
  await page.getByText('已保存至项目库', { exact: true }).waitFor();
  const bSaved = await api(`/${b.id}`);
  assert.equal(bSaved.model.rooms[0].evidence.length, 1);
  assert.equal((await api(`/${a.id}`)).model.rooms[0].evidence.length, 0);
  check('巡检照片与状态按项目独立保存');
  await page.reload(); await page.getByText('已保存至项目库', { exact: true }).waitFor();
  assert.equal(await page.locator('.project-switcher>span').first().textContent(), bName);
  check('刷新后恢复当前项目及数据库版本');

  await page.getByRole('button', { name: '项目库', exact: true }).click();
  const updatedCard = page.locator('article').filter({ has: page.getByRole('heading', { name: bName, exact: true }) });
  await updatedCard.getByRole('button', { name: `归档 ${bName}`, exact: true }).click();
  await updatedCard.getByRole('button', { name: '确认归档', exact: true }).click();
  await updatedCard.getByRole('button', { name: `恢复 ${bName}`, exact: true }).waitFor();
  assert.equal((await api(`/${b.id}`)).model.rooms[0].evidence.length, 1);
  await updatedCard.getByRole('button', { name: `恢复 ${bName}`, exact: true }).click();
  await updatedCard.getByRole('button', { name: `归档 ${bName}`, exact: true }).waitFor();
  check('归档与恢复保留照片及模型');

  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: 'artifacts/library-mobile.png', fullPage: true });
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  check('390px移动端项目库无横向溢出');
  await page.setViewportSize({ width: 1440, height: 950 });
  await page.getByRole('button', { name: '返回建模工作台', exact: true }).click();
  await page.getByRole('button', { name: '切换为深色外观', exact: true }).click();
  await page.getByRole('button', { name: '项目库', exact: true }).click();
  await page.screenshot({ path: 'artifacts/library-dark.png', fullPage: true });
  check('深色项目库与工作台主题保持一致');
  assert.deepEqual(errors, []); check('浏览器没有运行时异常');
} finally {
  await fs.writeFile('artifacts/library-ui-check.json', JSON.stringify({ checks: reports, errors }, null, 2));
  await browser.close();
}
