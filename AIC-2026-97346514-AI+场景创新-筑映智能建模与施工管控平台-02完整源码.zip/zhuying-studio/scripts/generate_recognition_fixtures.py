"""Create deterministic, self-drawn floor-plan stress cases, not a real dataset."""

from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
DESTINATION = ROOT / "tests" / "fixtures" / "plan-recognition"
ORIGIN = 80
SCALE = 100


def pixel(point):
    return tuple(round(ORIGIN + coordinate * SCALE) for coordinate in point)


def base_geometry(topology):
    walls = [
        {"id": "outer-top", "start": [0, 0], "end": [12, 0], "thickness": .14},
        {"id": "outer-bottom", "start": [0, 8], "end": [12, 8], "thickness": .14},
        {"id": "outer-left", "start": [0, 0], "end": [0, 8], "thickness": .14},
        {"id": "outer-right", "start": [12, 0], "end": [12, 8], "thickness": .14},
    ]
    if topology == "grid-six":
        walls += [
            {"id": "middle-left", "start": [4, 0], "end": [4, 8], "thickness": .12},
            {"id": "middle-right", "start": [8, 0], "end": [8, 8], "thickness": .12},
            {"id": "middle-horizontal", "start": [0, 4], "end": [12, 4], "thickness": .12},
        ]
        # Interior faces, rather than centreline cells, are the room targets.
        polygons = []
        for row in range(2):
            for column in range(3):
                left = column * 4 + (.07 if column == 0 else .06)
                right = (column + 1) * 4 - (.07 if column == 2 else .06)
                top = row * 4 + (.07 if row == 0 else .06)
                bottom = (row + 1) * 4 - (.07 if row == 1 else .06)
                polygons.append([[left, top], [right, top], [right, bottom], [left, bottom]])
    else:
        # A large L-shaped living room and three differently sized rooms.
        walls += [
            {"id": "upper-horizontal", "start": [0, 3], "end": [12, 3], "thickness": .12},
            {"id": "upper-vertical", "start": [5, 0], "end": [5, 3], "thickness": .12},
            {"id": "lower-vertical", "start": [8, 3], "end": [8, 6], "thickness": .12},
            {"id": "lower-horizontal", "start": [8, 6], "end": [12, 6], "thickness": .12},
        ]
        polygons = [
            [[.07, .07], [4.94, .07], [4.94, 2.94], [.07, 2.94]],
            [[5.06, .07], [11.93, .07], [11.93, 2.94], [5.06, 2.94]],
            [[.07, 3.06], [7.94, 3.06], [7.94, 6.06], [11.93, 6.06], [11.93, 7.93], [.07, 7.93]],
            [[8.06, 3.06], [11.93, 3.06], [11.93, 5.94], [8.06, 5.94]],
        ]
    return walls, [{"id": f"target-room-{index + 1}", "polygon": polygon}
                   for index, polygon in enumerate(polygons)]


def openings_for(topology):
    if topology == "grid-six":
        definitions = [
            ("middle-left", "door", 1.6, .9), ("middle-left", "door", 5.6, .9),
            ("middle-right", "door", 1.6, .9), ("middle-right", "door", 5.6, .9),
            ("middle-horizontal", "door", 1.6, .9),
            ("middle-horizontal", "door", 5.6, .9),
            ("middle-horizontal", "door", 9.6, .9),
            ("outer-bottom", "door", 1.7, .9),
            ("outer-top", "window", 1.1, 1.5),
            ("outer-top", "window", 5.1, 1.5),
            ("outer-top", "window", 9.1, 1.5),
        ]
    else:
        definitions = [
            ("upper-vertical", "door", 1.25, .85),
            ("upper-horizontal", "door", 2, .9),
            ("upper-horizontal", "door", 6, .9),
            ("lower-vertical", "door", 1.15, .85),
            ("outer-bottom", "door", 2, .9),
            ("outer-top", "window", 1.2, 1.6),
            ("outer-right", "window", 4.1, 1.3),
        ]
    return [{"id": f"opening-{index + 1}", "wallId": wall_id,
             "type": kind, "offset": offset, "width": width}
            for index, (wall_id, kind, offset, width) in enumerate(definitions)]


def draw_case(topology, with_openings=False, furniture=False, dimensions=False):
    walls, rooms = base_geometry(topology)
    openings = openings_for(topology) if with_openings else []
    image = Image.new("RGB", (1400, 1000), "white")
    draw = ImageDraw.Draw(image)
    for wall in walls:
        draw.line((pixel(wall["start"]), pixel(wall["end"])), fill="#202627",
                  width=round(wall["thickness"] * SCALE))
    by_id = {wall["id"]: wall for wall in walls}
    for opening in openings:
        wall = by_id[opening["wallId"]]
        start, end = wall["start"], wall["end"]
        horizontal = start[1] == end[1]
        x = start[0] + (opening["offset"] if horizontal else 0)
        y = start[1] + (0 if horizontal else opening["offset"])
        span = opening["width"]
        thickness = wall["thickness"] * SCALE
        if horizontal:
            bounds = (pixel([x, y])[0], pixel([x, y])[1] - thickness,
                      pixel([x + span, y])[0], pixel([x + span, y])[1] + thickness)
        else:
            bounds = (pixel([x, y])[0] - thickness, pixel([x, y])[1],
                      pixel([x, y + span])[0] + thickness, pixel([x, y + span])[1])
        draw.rectangle(bounds, fill="white")
        px, py = pixel([x, y])
        length = round(span * SCALE)
        if opening["type"] == "door":
            # Thin leaf and swing arc are intentionally unlike a thick wall.
            if horizontal:
                draw.line((px, py, px, py + length), fill="#323738", width=2)
                draw.arc((px - length, py - length, px + length, py + length), 0, 90,
                         fill="#616869", width=2)
            else:
                draw.line((px, py, px + length, py), fill="#323738", width=2)
                draw.arc((px - length, py - length, px + length, py + length), 0, 90,
                         fill="#616869", width=2)
        else:
            for shift in (-3, 3):
                if horizontal:
                    draw.line((px, py + shift, px + length, py + shift), fill="#298cb2", width=2)
                else:
                    draw.line((px + shift, py, px + shift, py + length), fill="#298cb2", width=2)
    if furniture:
        # Mix low-contrast fills, colourful fabrics, and dark thin outlines.
        boxes = [(1.0, .75, 2.7, 2.4, "#b9c5bf"), (5.2, .75, 7.2, 2.6, "#cfd0ce"),
                 (9.1, .7, 11.4, 2.5, "#d8bea1"), (.8, 5.1, 2.9, 6.2, "#9dafbc"),
                 (4.7, 5.2, 7.0, 6.5, "#b5a796"), (9.2, 5.0, 11.1, 6.7, "#d1d0c8")]
        if topology == "l-four":
            boxes[-1] = (9.2, 3.75, 11.1, 5.6, "#d1d0c8")
        for x1, y1, x2, y2, fill in boxes:
            draw.rounded_rectangle((*pixel([x1, y1]), *pixel([x2, y2])), radius=9,
                                   fill=fill, outline="#555b5d", width=2)
            draw.line((*pixel([x1, y1 + .35]), *pixel([x2, y1 + .35])), fill="#656a69", width=2)
        draw.ellipse((*pixel([9.6, 6.95]), *pixel([10.35, 7.55])), fill="#aebabf",
                     outline="#444c50", width=2)
    if dimensions:
        # Lines extending beyond the exterior expose naive min/max calibration.
        draw.line((35, 30, 1325, 30), fill="#43484a", width=2)
        draw.line((1345, 30, 1345, 925), fill="#43484a", width=2)
        for x in (ORIGIN, ORIGIN + 400, ORIGIN + 800, ORIGIN + 1200):
            draw.line((x, 20, x, 70), fill="#43484a", width=2)
            draw.line((x - 5, 35, x + 5, 25), fill="#43484a", width=2)
        for y in (ORIGIN, ORIGIN + 400, ORIGIN + 800):
            draw.line((1300, y, 1360, y), fill="#43484a", width=2)
        draw.text((640, 13), "12000 mm", fill="#43484a")
        draw.text((1301, 480), "8000", fill="#43484a")
        for index, room in enumerate(rooms):
            points = room["polygon"]
            x = sum(p[0] for p in points) / len(points)
            y = sum(p[1] for p in points) / len(points)
            draw.text(pixel([x - .35, y]), f"ROOM {index + 1}", fill="#5b6262")
    return image, {"width": 12.0, "depth": 8.0, "height": 2.8,
                   "walls": walls, "rooms": rooms, "openings": openings}


def main():
    DESTINATION.mkdir(parents=True, exist_ok=True)
    definitions = [
        ("closed-grid", "grid-six", False, False, False, 1.0, 0),
        ("doors-windows", "grid-six", True, False, False, 1.0, 0),
        ("furniture", "grid-six", False, True, False, 1.0, 0),
        ("dimension-lines", "grid-six", False, False, True, 1.0, 0),
        ("mixed-doors-furniture-dimensions", "grid-six", True, True, True, 1.0, 0),
        ("small-mixed", "grid-six", True, True, True, .4, 0),
        ("rotated-mixed", "grid-six", True, True, True, 1.0, 2.2),
        ("closed-l-room", "l-four", False, False, False, 1.0, 0),
        ("l-room-mixed", "l-four", True, True, True, 1.0, 0),
        ("l-room-rotated", "l-four", True, True, True, .65, -1.5),
    ]
    cases = []
    for name, topology, openings, furniture, dimensions, resize, rotation in definitions:
        image, target = draw_case(topology, openings, furniture, dimensions)
        if resize != 1:
            image = image.resize((round(image.width * resize), round(image.height * resize)),
                                 Image.Resampling.LANCZOS)
        if rotation:
            image = image.rotate(rotation, resample=Image.Resampling.BICUBIC,
                                 expand=True, fillcolor="white")
        image.save(DESTINATION / f"{name}.png")
        (DESTINATION / f"{name}.json").write_text(
            json.dumps(target, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        cases.append({"id": name, "image": f"{name}.png", "groundTruth": f"{name}.json",
                      "topology": topology, "hasOpenings": openings,
                      "furniture": furniture, "dimensions": dimensions,
                      "resize": resize, "rotationDegrees": rotation})
    manifest = {"version": 1, "provenance": "Self-drawn deterministic synthetic plans",
                "scope": "Algorithm regression and controlled stress tests; not real-plan generalization",
                "coordinateConvention": "Canonical de-skewed metres, exterior wall centrelines define width and depth",
                "cases": cases}
    (DESTINATION / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Created {len(cases)} self-drawn cases in {DESTINATION}")


if __name__ == "__main__":
    main()
