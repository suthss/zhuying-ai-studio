# 上游公开图纸 smoke

仅取 [Grebtsew/FloorplanToBlender3d](https://github.com/Grebtsew/FloorplanToBlender3d) 的 2 张公开示例原图，用于实际推理和图像覆盖观察。来源固定到 commit `2da4c9532e9866b025c67aee17f87ff7e0b8db98`；原始路径、URL、下载时间、像素数、SHA-256、作者标注见 `sources.json`。

原仓库采用 GPL-3.0，本目录保留完整 `LICENSE.upstream.txt` 及作者归属 `Grebtsew, COPYRIGHT 2021`。图片无修改，未复制该项目算法到生产代码。此处仅说明原仓库公开提供的许可；不将这些图片标为本项目自绘或 MIT 素材。

`floorplan-to-blender-example.png`：含门洞、门扇弧线、薄家具线、外窗、卫浴瓷砖网格、瑞典文标签及阳台。

`floorplan-to-blender-example2.png`：含复杂非矩形轮廓、尺寸线、多种门窗、家具、希伯来文标签、相邻公共楼梯与室外空间。图中公共区域是否应纳入建模必须先确定，不能从房间总数比较直接下结论。

这两张图片没有经过本项目独立人工标注，也没有可靠的外墙中心线总宽度真值，**不参与 `manifest.json` 的合成准确率评估**。推理时输入的总宽度只能作为预览假定；应查看原图和识别叠加，验证墙、门窗和房间是否合理，不计算或宣称精确尺度及泛化准确率。
