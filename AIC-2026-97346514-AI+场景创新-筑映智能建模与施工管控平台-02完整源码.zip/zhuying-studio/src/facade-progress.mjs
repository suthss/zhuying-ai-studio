/** Evidence-bounded visible facade unit counts. This is not whole-project progress. */
const DAY = 86_400_000;
const STATUSES = new Set(['installed', 'not_installed', 'unknown']);
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const fail = message => { throw new TypeError(`外立面样例无效：${message}`); };
const text = (value, label, limit = 2000) => {
  if (typeof value !== 'string' || !value.trim() || value.length > limit) fail(`${label}须为非空文字，最多 ${limit} 字。`);
  return value;
};
const identifier = (value, label) => {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,120}$/.test(value)) fail(`${label}须为字母、数字、下划线或连字符组成的编号。`);
  return value;
};
const finite = (value, low, high, label) => {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < low || value > high) fail(`${label}超出有效数值范围。`);
  return value;
};
function dateValue(value, label = '日期') {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || Number(value.slice(0, 4)) < 1) fail(`${label}须为有效的 YYYY-MM-DD 日历日期。`);
  const parsed = Date.parse(value + 'T00:00:00Z');
  if (!Number.isFinite(parsed) || new Date(parsed).toISOString().slice(0, 10) !== value) fail(`${label}须为有效的 YYYY-MM-DD 日历日期。`);
  return parsed;
}
function webUrl(value, label) {
  text(value, label, 2000);
  let url;
  try { url = new URL(value); } catch { fail(`${label}须为有效网页链接。`); }
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password) fail(`${label}须为不含账号信息的 HTTP(S) 网页链接。`);
  return value;
}
function imageUrl(value) {
  text(value, '影像路径', 2000);
  if (value.startsWith('/') && !value.startsWith('//') && !value.split(/[\\/]/).includes('..') && !/[\u0000-\u001f]/.test(value)) return value;
  return webUrl(value, '影像路径');
}
const cross = (a, b, c) => (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
const onSegment = (a, b, p) => Math.abs(cross(a,b,p)) < 1e-10 && p[0] >= Math.min(a[0],b[0])-1e-10 && p[0] <= Math.max(a[0],b[0])+1e-10 && p[1] >= Math.min(a[1],b[1])-1e-10 && p[1] <= Math.max(a[1],b[1])+1e-10;
function intersects(a,b,c,d) {
  return cross(a,b,c)*cross(a,b,d) < -1e-20 && cross(c,d,a)*cross(c,d,b) < -1e-20
    || onSegment(a,b,c) || onSegment(a,b,d) || onSegment(c,d,a) || onSegment(c,d,b);
}
function regionsOf(value) {
  if (!Array.isArray(value) || !value.length || value.length > 400) fail('每期观测须包含 1 至 400 个固定标定单元。');
  const ids = new Set();
  return value.map(region => {
    if (!record(region)) fail('标定单元格式无效。');
    const id = identifier(region.id, '单元编号');
    if (ids.has(id)) fail('同一期单元编号不能重复。');
    ids.add(id);
    if (!STATUSES.has(region.status)) fail('单元状态须为 installed、not_installed 或 unknown。');
    if (!Array.isArray(region.polygon) || region.polygon.length < 3 || region.polygon.length > 40) fail('单元轮廓须包含 3 至 40 个归一化顶点。');
    const polygon = region.polygon.map(point => {
      if (!Array.isArray(point) || point.length !== 2) fail('单元顶点须为 [x,y]。');
      return [finite(point[0], 0, 1, '单元 x 坐标'), finite(point[1], 0, 1, '单元 y 坐标')];
    });
    if (new Set(polygon.map(p=>p.join(','))).size !== polygon.length) fail('单元轮廓不能含重复顶点。');
    const area = Math.abs(polygon.reduce((sum,a,index)=>{const b=polygon[(index+1)%polygon.length];return sum+a[0]*b[1]-b[0]*a[1];},0))/2;
    if (area < 1e-8) fail('单元轮廓面积必须大于零。');
    for (let i=0;i<polygon.length;i++) for(let j=i+1;j<polygon.length;j++) {
      if (j===i+1 || i===0 && j===polygon.length-1) continue;
      if (intersects(polygon[i],polygon[(i+1)%polygon.length],polygon[j],polygon[(j+1)%polygon.length])) fail('单元轮廓不能自交。');
    }
    return {id,label:text(region.label,'单元名称',200),polygon,status:region.status,evidence:text(region.evidence,'单元证据',2000)};
  });
}
function validatePlan(raw) {
  if (!record(raw) || raw.simulated !== true) fail('计划必须明确标记 simulated:true，不能当作真实施工计划。');
  const start = dateValue(raw.startDate, '计划开始日期'), end = dateValue(raw.endDate, '计划完成日期');
  if (end <= start) fail('计划完成日期必须晚于开始日期。');
  if (!Number.isInteger(raw.inspectionGapDays) || raw.inspectionGapDays < 1 || raw.inspectionGapDays > 3650) fail('巡检间隔须为 1 至 3650 天的整数。');
  return {simulated:true,label:text(raw.label,'模拟计划标签',500),startDate:raw.startDate,endDate:raw.endDate,
    targetPercent:finite(raw.targetPercent,0,100,'目标安装率'),inspectionGapDays:raw.inspectionGapDays};
}

/** Validate untrusted imported data and return a separate, chronologically sorted copy. */
export function validateFacadeSample(raw) {
  if (!record(raw) || raw.schemaVersion !== 1) fail('schemaVersion 须为 1。');
  if (!record(raw.dataset)) fail('须提供影像数据来源。');
  if (typeof raw.datesAreCaptureDates !== 'boolean') fail('须声明日期是否为真实拍摄日期。');
  if (!record(raw.annotation) || raw.annotation.method !== 'manual') fail('该样例标注须明确为人工判读。');
  if (!Array.isArray(raw.observations) || !raw.observations.length || raw.observations.length > 500) fail('须提供 1 至 500 期观测。');
  const seen = new Set();
  let expectedUnits;
  const observations = raw.observations.map(observation => {
    if (!record(observation)) fail('观测格式无效。');
    const id = identifier(observation.id, '观测编号');
    if (seen.has(id)) fail('观测编号不能重复。');
    seen.add(id);
    dateValue(observation.date, '观测日期');
    if (!['raw','partial'].includes(observation.stage)) fail('样例阶段仅允许 raw 或 partial，不能伪造完工影像。');
    const regions = regionsOf(observation.regions), units = regions.map(region=>region.id).sort().join('|');
    if (expectedUnits !== undefined && units !== expectedUnits) fail('各期须使用相同固定标定单元编号，不能通过改变分母计算安装率。');
    expectedUnits = units;
    return {id,date:observation.date,dateLabel:text(observation.dateLabel,'观测日期标签',200),dateSource:text(observation.dateSource,'日期来源',2000),
      image:imageUrl(observation.image),sourceFile:text(observation.sourceFile,'来源文件',1000),
      frameSeconds:finite(observation.frameSeconds,0,604800,'原视频抽帧秒数'),stage:observation.stage,
      summary:text(observation.summary,'观测说明',4000),regions};
  }).sort((a,b)=>a.date.localeCompare(b.date));
  return {schemaVersion:1,id:identifier(raw.id,'样例编号'),title:text(raw.title,'样例标题',300),description:text(raw.description,'样例说明',4000),
    dataset:{title:text(raw.dataset.title,'数据集标题',500),url:webUrl(raw.dataset.url,'数据集链接'),creator:text(raw.dataset.creator,'数据作者',500),
      license:text(raw.dataset.license,'许可名称',500),licenseUrl:webUrl(raw.dataset.licenseUrl,'许可链接')},
    datesAreCaptureDates:raw.datesAreCaptureDates,observations,plan:validatePlan(raw.plan),
    annotation:{method:'manual',scope:text(raw.annotation.scope,'人工标注范围',2000),label:text(raw.annotation.label,'人工标注说明',2000)}};
}

/** Unit counts have equal weights; unknown units contribute only to the upper bound. */
export function summarizeFacade(observation) {
  if (!record(observation)) fail('须提供有效观测。');
  const regions = regionsOf(observation.regions);
  const installed = regions.filter(region=>region.status==='installed').length;
  const notInstalled = regions.filter(region=>region.status==='not_installed').length;
  const unknown = regions.length-installed-notInstalled, total = regions.length;
  return {total,installed,notInstalled,unknown,coverage:(installed+notInstalled)/total*100,lower:installed/total*100,upper:(installed+unknown)/total*100};
}

/** Linear cumulative target, clamped before/after the explicitly simulated schedule. */
export function planAtDate(rawPlan, date) {
  const plan = validatePlan(rawPlan), time = dateValue(date, '计划对照日期');
  const start = dateValue(plan.startDate), end = dateValue(plan.endDate);
  return Math.max(0, Math.min(1,(time-start)/(end-start))) * plan.targetPercent;
}

function evaluateValidated(sample, asOf, plan) {
  const asOfTime = dateValue(asOf, '监控截至日期');
  const historical = sample.observations.filter(observation=>observation.date<=asOf);
  // A later appended observation wins a same-date tie; ties are never extra days
  // or an extra rate sample. Dates after asOf are excluded from every computation.
  const byDate = new Map(historical.map(observation=>[observation.date,observation]));
  const dated = [...byDate.values()];
  const observation = dated.at(-1) ?? null;
  const actual = observation ? summarizeFacade(observation) : null;
  const planned = planAtDate(plan,asOf), gap = actual ? actual.lower-planned : null;
  const staleDays = observation ? (asOfTime-dateValue(observation.date))/DAY : null;
  const alerts = [];
  if (!observation) alerts.push({kind:'missing_evidence',message:'截至所选日期尚无观测证据，实际安装率未知，请补充取证后再对照模拟计划。'});
  else {
    if (gap < -1e-8) alerts.push({kind:'deviation',message:`已确认安装率下限低于模拟计划 ${(-gap).toFixed(1)} 个百分点；这是可见单元与演示计划的偏差，不能认定真实施工延期。`});
    if (staleDays > plan.inspectionGapDays) alerts.push({kind:'stale',message:`最近观测距截至日已 ${staleDays} 天，超过 ${plan.inspectionGapDays} 天巡检间隔；请补充影像，旧证据不能代表当前现场。`});
    if (actual.unknown) alerts.push({kind:'uncertain',message:`${actual.unknown} 个标定单元无法判断，安装率证据区间为 ${actual.lower.toFixed(1)}% 至 ${actual.upper.toFixed(1)}%，请补充清晰影像核对。`});
  }
  let scenario = null;
  // Only fully judged observations have comparable installed counts. An unknown
  // becoming visible must not be mistaken for newly completed installation.
  const effective = dated.filter(item=>summarizeFacade(item).unknown===0);
  const previous = effective.at(-2), latest = effective.at(-1);
  if (observation && actual.unknown===0 && latest?.id===observation.id && previous && staleDays<=plan.inspectionGapDays) {
    const current = summarizeFacade(latest), before = summarizeFacade(previous);
    const interval = (dateValue(latest.date)-dateValue(previous.date))/DAY;
    const advance = current.lower-before.lower;
    if (interval>0 && advance>0 && current.lower<plan.targetPercent) {
      const rate = advance/interval;
      const days = Math.ceil((plan.targetPercent-current.lower)/rate);
      const targetTime = dateValue(latest.date)+days*DAY;
      const estimate = new Date(targetTime);
      if (days>0 && targetTime>asOfTime && Number.isFinite(targetTime) && Number.isFinite(estimate.getTime()) && estimate.getUTCFullYear()<=9999) {
        const date = estimate.toISOString().slice(0,10);
        scenario = {date,days,rate,label:`仅作情景估计：若保持最近两期已核对观测的 ${rate.toFixed(2)} 个百分点/天变化，约在 ${date} 达到模拟目标 ${plan.targetPercent}%；${sample.datesAreCaptureDates?'这不是经过验证的真实完工日期或延期预测。':'观测日期为演示时间轴，这不是实际工期预测。'}`};
      }
    }
  }
  return {observation,actual,planned,gap,staleDays,alerts,scenario};
}

/** Compare the latest evidence available as of the date, never a future frame. */
export function evaluateFacade(raw, asOf, planOverride) {
  const sample = validateFacadeSample(raw), plan = planOverride===undefined ? sample.plan : validatePlan(planOverride);
  return evaluateValidated(sample,asOf,plan);
}

/** Export only evidence already available by asOf, with source and clear limitations. */
export function createFacadeReport(raw, asOf, planOverride) {
  const sample = validateFacadeSample(raw), plan = planOverride===undefined ? sample.plan : validatePlan(planOverride);
  const evaluation = evaluateValidated(sample,asOf,plan);
  return {schemaVersion:1,reportType:'visible_facade_monitoring_demo',sampleId:sample.id,title:sample.title,asOf,
    metric:{label:'固定可见标定单元完整安装率',unit:'percent',denominator:'各期相同的固定可见单元总数',unknownPolicy:'无法判断单元只计入安装率上限，并单独报告证据覆盖率。'},
    dataset:sample.dataset,datesAreCaptureDates:sample.datesAreCaptureDates,annotation:sample.annotation,plan,
    limitations:['该比例仅表示标定可见单元的安装状态，不表示整体建筑、工程量、造价或施工完成百分比。',
      '标注为人工判读，未知单元保留为未知；公开影像不提供安装量真值，未进行算法准确率评测。',
      '计划由演示用户设定，偏差与取证过期分别告警，不能等同于项目真实延期。',
      '情景估计仅在不同日期、可比且完全判明的观测呈正增量时计算；不是经过验证的工期预测。',
      sample.datesAreCaptureDates?'拍摄日期采用样例所列来源，仍须按来源复核。':'观测日期为演示时间轴，不能用于推断真实拍摄间隔或施工工期。'],
    observations:sample.observations.filter(observation=>observation.date<=asOf),evaluation};
}
