"""Convert semantic wall/door/window masks into reviewable pixel geometry.

The public input classes are 0=background, 1=wall, 2=door, 3=window.
This is an independent implementation of the segmentation -> centreline ->
host-wall opening pipeline. No upstream model or geometry source is vendored.
Coordinates and distances remain in pixels; the API owns metric calibration.
"""

import math

import cv2
import numpy as np

INDOOR_ROOM_CLASSES = frozenset({3, 4, 5, 6, 7, 9, 10, 11})


class VectorizationError(ValueError):
    """A mask does not contain enough trustworthy geometry for a house."""


def _validated_mask(value, name, classes=None):
    mask = np.asarray(value)
    if mask.ndim != 2 or min(mask.shape) < 12 or max(mask.shape) > 4096 or mask.size > 8_000_000:
        raise VectorizationError(f"{name} 必须为尺寸合理的二维语义标签图。")
    if not np.issubdtype(mask.dtype, np.integer) or mask.dtype == np.bool_:
        raise VectorizationError(f"{name} 必须为整数类别，不接受概率图或浮点标签。")
    if np.any(mask < 0) or np.any(mask > 255) or (classes is not None and not np.isin(mask, classes).all()):
        raise VectorizationError(f"{name} 含有未支持的语义类别。")
    return mask.astype(np.uint8, copy=True)


def _thin(mask):
    """Zhang-Suen thinning, expressed with NumPy neighbour arrays."""
    pixels = np.pad(mask > 0, 1).astype(np.uint8)
    # Each iteration removes at least one contour layer; the cap bounds work
    # on pathological filled semantic predictions rather than hanging an API.
    for _ in range(min(max(mask.shape), 512)):
        changed = False
        for phase in (0, 1):
            centre = pixels[1:-1, 1:-1]
            neighbours = [pixels[:-2, 1:-1], pixels[:-2, 2:], pixels[1:-1, 2:],
                          pixels[2:, 2:], pixels[2:, 1:-1], pixels[2:, :-2],
                          pixels[1:-1, :-2], pixels[:-2, :-2]]
            count = sum(neighbours)
            transitions = sum((neighbours[i] == 0) & (neighbours[(i + 1) % 8] == 1)
                              for i in range(8))
            north, east, south, west = neighbours[0], neighbours[2], neighbours[4], neighbours[6]
            first = north * east * (south if phase == 0 else west)
            second = (east if phase == 0 else north) * south * west
            remove = (centre == 1) & (count >= 2) & (count <= 6) & (transitions == 1) & (first == 0) & (second == 0)
            if remove.any():
                centre[remove] = 0
                changed = True
        if not changed:
            break
    return pixels[1:-1, 1:-1] * 255


def _components(mask, minimum=4):
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    return [(index, stats[index]) for index in range(1, count) if stats[index, cv2.CC_STAT_AREA] >= minimum], labels


def _line(start, end, thickness):
    start, end = np.asarray(start, dtype=float), np.asarray(end, dtype=float)
    # A deterministic orientation also makes offsets stable between runs.
    if (end[0], end[1]) < (start[0], start[1]):
        start, end = end, start
    vector = end - start
    length = float(np.linalg.norm(vector))
    return {"start": start, "end": end, "unit": vector / max(length, 1e-8),
            "length": length, "thickness": float(thickness)}


def _projection(line, points):
    delta = np.asarray(points, dtype=float) - line["start"]
    unit = line["unit"]
    return delta @ unit, np.abs(delta[:, 0] * unit[1] - delta[:, 1] * unit[0])


def _merge_lines(lines, openings, thickness):
    """Merge collinear runs, crossing a large gap only with opening evidence.

    Checking perpendicular separation prevents the two parallel sides of a
    narrow corridor from becoming one diagonal wall.
    """
    merged = []
    for candidate in sorted(lines, key=lambda item: -item["length"]):
        for index, previous in enumerate(merged):
            if abs(float(previous["unit"] @ candidate["unit"])) < math.cos(math.radians(4)):
                continue
            endpoints = np.stack((candidate["start"], candidate["end"]))
            along, distance = _projection(previous, endpoints)
            if max(distance) > max(1.5, min(previous["thickness"], candidate["thickness"]) * .35):
                continue
            low, high = float(min(along)), float(max(along))
            gap_low, gap_high = (previous["length"], low) if low > previous["length"] else (high, 0.)
            gap = max(0., gap_high - gap_low)
            supported = gap <= max(2.5, thickness * 1.35)
            if not supported:
                for opening in openings:
                    projected, perpendicular = _projection(previous, opening["points"])
                    near = projected[perpendicular <= max(2., previous["thickness"] * .85)]
                    # Thinning retracts blunt wall caps by roughly half their
                    # thickness; Hough endpoints can retract one layer more.
                    cap_allowance = max(3., thickness * 2)
                    if len(near) >= 3 and float(min(near)) <= gap_low + cap_allowance and float(max(near)) >= gap_high - cap_allowance:
                        supported = True
                        break
            if not supported:
                continue
            # Fit to both centreline samples, rather than averaging wall end
            # boxes (which biases long segments near short T-junction stubs).
            points = np.vstack((previous["samples"], candidate["samples"]))
            fitted = _fit_line(points, max(previous["thickness"], candidate["thickness"]))
            fitted["samples"] = points
            merged[index] = fitted
            break
        else:
            merged.append(candidate)
    return merged


def _fit_line(points, thickness):
    centre = points.mean(axis=0)
    _, _, vectors = np.linalg.svd(points - centre, full_matrices=False)
    unit = vectors[0]
    # Tiny stair-step raster errors should not introduce fake tilted walls.
    if abs(unit[1]) < math.sin(math.radians(.75)):
        unit = np.array([1., 0.])
    elif abs(unit[0]) < math.sin(math.radians(.75)):
        unit = np.array([0., 1.])
    along = (points - centre) @ unit
    return _line(centre + min(along) * unit, centre + max(along) * unit, thickness)


def _snap_junctions(lines):
    # A centreline skeleton rounds corners. Recover intersections only when
    # both finite segments reach them within a local wall-thickness radius.
    for left in range(len(lines)):
        for right in range(left + 1, len(lines)):
            a, b = lines[left], lines[right]
            if abs(float(a["unit"] @ b["unit"])) > math.cos(math.radians(12)):
                continue
            matrix = np.column_stack((a["unit"], -b["unit"]))
            try:
                ta, tb = np.linalg.solve(matrix, b["start"] - a["start"])
            except np.linalg.LinAlgError:
                continue
            radius = max(3., min(a["thickness"], b["thickness"]) * 1.7)
            if not (-radius <= ta <= a["length"] + radius and -radius <= tb <= b["length"] + radius):
                continue
            intersection = a["start"] + ta * a["unit"]
            for line, value in ((a, ta), (b, tb)):
                if abs(value) <= radius:
                    line["start"] = intersection.copy()
                elif abs(value - line["length"]) <= radius:
                    line["end"] = intersection.copy()
                else:
                    continue
                updated = _line(line["start"], line["end"], line["thickness"])
                line.update(updated)


def _opening_components(labels):
    result = []
    for class_id, kind in ((2, "door"), (3, "window")):
        # A one-pixel class interruption should not duplicate a single opening
        # or leave both fragments without supporting jambs. This only joins
        # nearby predictions of the same semantic kind.
        mask = cv2.morphologyEx(np.uint8(labels == class_id), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
        components, ids = _components(mask, minimum=3)
        for index, _ in components:
            rows, columns = np.where(ids == index)
            result.append({"type": kind, "points": np.column_stack((columns, rows)).astype(float)})
    return result


def _bridge_openings(wall, components):
    """Recover host centrelines through labelled holes, including short jambs.

    A Hough transform of only solid walls loses a wall whose remaining jamb is
    shorter than the minimum line length. Use the principal direction of a
    thin opening strip only when original wall pixels support *both* ends.
    Door swing arcs are not elongated strips and are left to the wall-based
    assignment path; no complete door-symbol polygon becomes a solid wall.
    """
    repaired = wall.copy()
    distance = cv2.distanceTransform(wall, cv2.DIST_L2, 5)
    positive = distance[wall > 0]
    thickness = max(2., float(np.percentile(positive, 80) * 2 - 1)) if len(positive) else 2.
    wall_y, wall_x = np.where(wall > 0)
    wall_points = np.column_stack((wall_x, wall_y)).astype(float)
    for component in components:
        points = component['points']
        centre = points.mean(axis=0)
        _, values, axes = np.linalg.svd(points - centre, full_matrices=False)
        elongation = 1.8 if component['type'] == 'window' else 2.5
        if len(values) < 2 or values[0] < max(2., values[1] * elongation):
            continue
        unit = axes[0]
        perpendicular = np.array([-unit[1], unit[0]])
        along = (points - centre) @ unit
        low, high = float(along.min()), float(along.max())
        projected = (wall_points - centre) @ unit
        offsets = (wall_points - centre) @ perpendicular
        caps = []
        for endpoint, sign in ((low, -1), (high, 1)):
            selected = (sign * (projected - endpoint) >= 0) & (sign * (projected - endpoint) <= thickness * 2)
            selected &= np.abs(offsets) <= thickness * 1.5
            samples = wall_points[selected]
            if len(samples) < max(4, thickness * .5):
                break
            caps.append(samples)
        if len(caps) != 2:
            continue
        first, second = [float(np.median((samples - centre) @ perpendicular)) for samples in caps]
        if abs(first - second) > thickness * .65:
            continue
        # A narrow temporary bridge establishes one centreline, while original
        # cap thickness later supplies the physical wall's thickness.
        cap_widths = [np.percentile((samples - centre) @ perpendicular, 85) -
                      np.percentile((samples - centre) @ perpendicular, 15) for samples in caps]
        # At a T/corner the perpendicular wall adds an asymmetric cloud to one
        # jamb. Weight the narrower (straight) cap more heavily so this cloud
        # cannot pull the recovered host centreline off its solid continuation.
        shift = float(np.average([first, second], weights=1 / np.maximum(cap_widths, 1.) ** 2))
        bridge_width = max(1, int(round(min(thickness, max(2., float(np.median(cap_widths)))))))
        start = centre + (low - 2) * unit + shift * perpendicular
        end = centre + (high + 2) * unit + shift * perpendicular
        cv2.line(repaired, tuple(np.rint(start).astype(int)), tuple(np.rint(end).astype(int)), 255, bridge_width)
    return repaired


def _remove_isolated_thin_lines(lines, thickness):
    """Suppress short disconnected raster strokes, not connected thin walls."""
    keep = []
    for index, line in enumerate(lines):
        if line['thickness'] >= thickness * .4 or line['length'] >= thickness * 4:
            keep.append(line)
            continue
        linked = False
        for other_index, other in enumerate(lines):
            if index == other_index:
                continue
            along, perpendicular = _projection(other, np.stack((line['start'], line['end'])))
            # An almost coincident, much thinner parallel stroke is commonly
            # the unfilled edge of a window band, not a second exterior wall.
            if (other['thickness'] > line['thickness'] * 2 and
                    abs(float(other['unit'] @ line['unit'])) > math.cos(math.radians(4)) and
                    np.all(perpendicular <= other['thickness'] * .7) and
                    np.all((along >= -2) & (along <= other['length'] + 2))):
                linked = False
                break
            radius = max(2., other['thickness'] * .3)
            if np.any((along >= -radius) & (along <= other['length'] + radius) & (perpendicular <= radius)):
                linked = True
                break
        if linked:
            keep.append(line)
    return keep, len(lines) - len(keep)


def _open_structural_holes(region, barrier):
    """Represent wall islands in the platform's single-ring floor polygons.

    A narrow, explicit slit from each structural island to the nearest outer
    boundary makes the raster contour a simple polygon, preserving the wall
    void rather than dropping an entire open-plan living room or filling its
    floor through an internal wall. This changes only floor geometry.
    """
    region = region.copy()
    for _ in range(50):
        contours, hierarchy = cv2.findContours(region, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
        if hierarchy is None:
            break
        structural = None
        for index, contour in enumerate(contours):
            parent = hierarchy[0, index, 3]
            if parent < 0:
                continue
            island = np.zeros_like(region)
            cv2.drawContours(island, contours, index, 255, cv2.FILLED)
            if np.count_nonzero((island > 0) & (barrier > 0)) >= 4:
                structural = (contours[parent][:, 0].astype(float), contour[:, 0].astype(float))
                break
        if structural is None:
            break
        outer, inner = structural
        # Bound the pairwise closest-edge calculation on noisy large masks.
        # The three-pixel cut also covers the subpixel approximation error.
        reduced = []
        for ring in (outer, inner):
            tolerance = .5
            ring = ring.astype(np.float32).reshape(-1, 1, 2)
            approximation = cv2.approxPolyDP(ring, tolerance, True)
            while len(approximation) > 1000:
                tolerance *= 1.5
                approximation = cv2.approxPolyDP(ring, tolerance, True)
            reduced.append(approximation[:, 0].astype(float))
        outer, inner = reduced
        # Closest point on an outer edge, not only its sparse corner vertices.
        first, second = outer, np.roll(outer, -1, axis=0)
        vectors = second - first
        length_squared = np.sum(vectors * vectors, axis=1)
        fractions = np.sum((inner[:, None] - first) * vectors, axis=2) / np.maximum(length_squared, 1e-8)
        projected = first + np.clip(fractions, 0, 1)[:, :, None] * vectors
        distances = np.sum((inner[:, None] - projected) ** 2, axis=2)
        hole_index, edge_index = np.unravel_index(np.argmin(distances), distances.shape)
        start, end = inner[hole_index], projected[hole_index, edge_index]
        # Three pixels keep the resulting contour from touching itself at the
        # slit, which could otherwise confuse triangle tessellation.
        cv2.line(region, tuple(np.rint(start).astype(int)), tuple(np.rint(end).astype(int)), 0, 3)
    return region


def _simple_polygon(points):
    """Reject crossings and nonadjacent touches before 3D tessellation."""
    if len(points) < 3 or len(points) > 200:
        return False
    a, b = points[:, None, :], np.roll(points, -1, axis=0)[:, None, :]
    c, d = points[None, :, :], np.roll(points, -1, axis=0)[None, :, :]

    def orientation(start, end, point):
        first, second = end - start, point - start
        return first[..., 0] * second[..., 1] - first[..., 1] * second[..., 0]

    one, two = orientation(a, b, c), orientation(a, b, d)
    three, four = orientation(c, d, a), orientation(c, d, b)
    crossings = (one * two < -1e-8) & (three * four < -1e-8)

    def on_segment(start, end, point, cross):
        return (np.abs(cross) < 1e-8) & np.all(point >= np.minimum(start, end) - 1e-8, axis=2) & np.all(point <= np.maximum(start, end) + 1e-8, axis=2)

    crossings |= on_segment(a, b, c, one) | on_segment(a, b, d, two)
    crossings |= on_segment(c, d, a, three) | on_segment(c, d, b, four)
    indices = np.arange(len(points))
    adjacent = (indices[:, None] == indices[None, :]) | ((indices[:, None] - indices[None, :]) % len(points) == 1) | ((indices[None, :] - indices[:, None]) % len(points) == 1)
    return not bool(np.any(crossings & ~adjacent))


def _extract_lines(wall, openings, original_wall=None):
    skeleton = _thin(wall)
    rows, columns = np.where(skeleton > 0)
    if len(rows) < 15:
        raise VectorizationError("墙体语义区域过少，无法提取稳定墙中心线。")
    distance = cv2.distanceTransform(wall if original_wall is None else original_wall, cv2.DIST_L2, 5)
    skeleton_distances = distance[rows, columns]
    thickness = float(max(1., np.median(skeleton_distances[skeleton_distances > 0] * 2 - 1)))
    minimum = max(8, int(max(wall.shape) / 45), int(thickness * 1.6))
    detected = cv2.HoughLinesP(skeleton, 1, np.pi / 360, threshold=max(6, int(minimum * .65)),
                               minLineLength=minimum, maxLineGap=max(2, int(thickness * .5)))
    if detected is None:
        raise VectorizationError("未识别到足够的直线墙段，请使用清晰户型图。")
    points = np.column_stack((columns, rows)).astype(float)
    lines = []
    for coordinates in detected[:1200, 0]:
        initial = _line(coordinates[:2], coordinates[2:], thickness)
        along, perpendicular = _projection(initial, points)
        selected = (along >= -2) & (along <= initial["length"] + 2) & (perpendicular <= 1.5)
        # Probabilistic Hough reports only part of some straight runs. Extend
        # to the connected collinear skeleton interval, stopping at real gaps
        # so an exterior entrance cannot disappear because a cap was truncated.
        near_indices = np.flatnonzero(perpendicular <= 1.5)
        order = near_indices[np.argsort(along[near_indices])]
        if len(order):
            split_at = np.flatnonzero(np.diff(along[order]) > 2.8) + 1
            for run in np.split(order, split_at):
                if len(run) and selected[run].any():
                    selected[run] = True
        samples = points[selected]
        if len(samples) < minimum * .6:
            continue
        distances = distance[samples[:, 1].astype(int), samples[:, 0].astype(int)]
        distances = distances[distances > 0]
        if not len(distances):
            continue
        fitted = _fit_line(samples, max(1., float(np.median(distances * 2 - 1))))
        fitted["samples"] = samples
        lines.append(fitted)
    lines = _merge_lines(lines, openings, thickness)
    # First-pass merging can join small stubs after a long wall was processed.
    lines = _merge_lines(lines, openings, thickness)
    lines = [line for line in lines if line["length"] >= minimum]
    if len(lines) < 3 or len(lines) > 500:
        raise VectorizationError("墙段数量或结构不合理，请核对墙体分割结果。")
    _snap_junctions(lines)
    return sorted(lines, key=lambda line: (round(float(line["start"][1]), 2), round(float(line["start"][0]), 2))), thickness


def _assign_openings(lines, components, wall):
    accepted, warnings = [], []
    # Floor boundaries must follow the very same recovered walls that the 3D
    # renderer receives. Retaining discarded raster strokes here would leave
    # holes through the floor under removed sofa/dimension-line false positives.
    # This temporary barrier closes host-wall openings for room flood filling.
    barrier = np.zeros_like(wall)
    for line in lines:
        cv2.line(barrier, tuple(np.rint(line['start']).astype(int)), tuple(np.rint(line['end']).astype(int)),
                 255, max(1, int(math.ceil(line['thickness']))))
    for component in components:
        candidates = []
        for index, line in enumerate(lines):
            along, perpendicular = _projection(line, component["points"])
            near = perpendicular <= max(2., line["thickness"] * .85)
            if np.count_nonzero(near) < 3:
                continue
            projected = along[near]
            low, high = max(0., float(min(projected)) - .5), min(line["length"], float(max(projected)) + .5)
            if high - low < max(3., line["thickness"] * .6):
                continue
            # Require real wall support around the inferred hole. An isolated
            # door symbol in a room must not be glued to the nearest wall.
            supported = []
            before, after = low, line['length'] - high
            for available, value in ((before, low - min(max(2., line['thickness']), before * .5)),
                                     (after, high + min(max(2., line['thickness']), after * .5))):
                if available < 1:
                    supported.append(False)
                    continue
                if value < 0 or value > line["length"]:
                    supported.append(False)
                    continue
                point = line["start"] + value * line["unit"]
                x, y = np.rint(point).astype(int)
                radius = max(1, int(line["thickness"] / 2))
                patch = wall[max(0, y-radius):min(wall.shape[0], y+radius+1),
                             max(0, x-radius):min(wall.shape[1], x+radius+1)]
                supported.append(bool(patch.size and patch.any()))
            if not all(supported):
                continue
            score = float(np.median(perpendicular[near])) + float(np.median(perpendicular)) * .15
            candidates.append((score, index, low, high))
        if not candidates:
            warnings.append(f"有一处{ '门' if component['type'] == 'door' else '窗'}无法可靠关联墙段，已保留为待人工复核。")
            continue
        _, index, low, high = min(candidates)
        overlapping = [item for item in accepted if item['wallIndex'] == index and
                       min(high, item['offset'] + item['width']) > max(low, item['offset']) - 2]
        if any(item['type'] != component['type'] for item in overlapping):
            warnings.append("门窗语义区域发生重叠，已跳过冲突开口，请人工复核。")
            continue
        if overlapping:
            low = min(low, *(item['offset'] for item in overlapping))
            high = max(high, *(item['offset'] + item['width'] for item in overlapping))
            accepted = [item for item in accepted if item not in overlapping]
        accepted.append({"wallIndex": index, "type": component["type"], "offset": round(low, 4),
                         "width": round(high - low, 4)})
        line = lines[index]
        start = line["start"] + max(0., low - 2) * line["unit"]
        end = line["start"] + min(line["length"], high + 2) * line["unit"]
        cv2.line(barrier, tuple(np.rint(start).astype(int)), tuple(np.rint(end).astype(int)),
                 255, max(1, int(math.ceil(line["thickness"])) + 2))
    return accepted, barrier, warnings


def _room_polygons(barrier, room_labels, bounds):
    available = barrier == 0
    has_semantics = room_labels is not None and np.isin(room_labels, tuple(INDOOR_ROOM_CLASSES)).any()
    if has_semantics:
        # CubiCasa's class 1 is outdoor, class 2 wall, and class 8 railing.
        # Its indoor floor prediction can isolate an interior region even if
        # a few exterior-wall pixels are missed; it never supplies new walls.
        available &= np.isin(room_labels, tuple(INDOOR_ROOM_CLASSES))
        # The API calibrates/clamps coordinates to this wall envelope. Crop
        # semantic floor pixels here, before extracting their contour, so that
        # an incomplete edge prediction cannot make the later metric clamp
        # collapse distinct vertices into a self-touching floor polygon.
        x0, y0, x1, y1 = bounds
        available[:max(0, int(math.ceil(y0))), :] = False
        available[min(available.shape[0], int(math.floor(y1)) + 1):, :] = False
        available[:, :max(0, int(math.ceil(x0)))] = False
        available[:, min(available.shape[1], int(math.floor(x1)) + 1):] = False
    free = np.pad(available.astype(np.uint8), 1, constant_values=1)
    count, ids, stats, centroids = cv2.connectedComponentsWithStats(free, connectivity=4)
    minimum = max(45, int((bounds[2] - bounds[0]) * (bounds[3] - bounds[1]) * .003))
    rooms = []
    for index in range(1, count):
        x, y, width, height, area = stats[index]
        # Every region touching the padded image edge is exterior, regardless
        # of its size; the largest-component shortcut fails on cropped plans.
        if x == 0 or y == 0 or x + width >= free.shape[1] or y + height >= free.shape[0] or area < minimum:
            continue
        region = np.uint8(ids[1:-1, 1:-1] == index) * 255
        region = _open_structural_holes(region, barrier)
        # One-pixel semantic branches can make OpenCV contours retrace an
        # edge. Remove those nonoccupiable spurs before making a floor ring.
        region = cv2.morphologyEx(region, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        contours, hierarchy = cv2.findContours(region, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            continue
        contour = max(contours, key=cv2.contourArea)
        perimeter = cv2.arcLength(contour, True)
        # Narrow voids between two unfilled wall-outline strokes are not
        # occupiable rooms. Their area/perimeter remains tiny even when long.
        if perimeter <= 0 or cv2.contourArea(contour) / perimeter < 2.5:
            continue
        # Keep thin notches around structural islands. A perimeter-proportional
        # tolerance alone can collapse a long narrow slit into a self-touching
        # outline and put the reconstructed floor through the island again.
        epsilon = min(1.25, max(.8, perimeter * .003))
        polygon = cv2.approxPolyDP(contour, epsilon, True)
        while len(polygon) > 200:
            epsilon *= 1.4
            polygon = cv2.approxPolyDP(contour, epsilon, True)
        polygon = polygon[:, 0].astype(float)
        if not _simple_polygon(polygon):
            # Keep actual narrow corners when a coarse simplification crosses
            # its own boundary; the unsimplified raster ring is often sound.
            for tolerance in (.5, .1):
                candidate = cv2.approxPolyDP(contour, tolerance, True)[:, 0].astype(float)
                if _simple_polygon(candidate):
                    polygon = candidate
                    break
            else:
                continue
        if len(polygon) < 3 or cv2.contourArea(polygon.astype(np.float32)) < minimum:
            continue
        # If a pathological contour still contains a structural hole, fail
        # closed for this region instead of drawing floors through the wall.
        contour_index = next(i for i, candidate in enumerate(contours) if candidate is contour)
        child = hierarchy[0, contour_index, 2] if hierarchy is not None else -1
        structural_hole = False
        while child >= 0:
            island = np.zeros_like(barrier)
            cv2.drawContours(island, contours, int(child), 255, cv2.FILLED)
            if np.count_nonzero((island > 0) & (barrier > 0)) >= 4:
                structural_hole = True
                break
            child = hierarchy[0, child, 0]
        if structural_hole:
            continue
        if has_semantics:
            # Room semantics without physical wall evidence could be an image
            # artefact. Require some real boundary support, without requiring
            # a completely closed shell that the neural mask may have missed.
            edge = np.zeros_like(barrier)
            cv2.drawContours(edge, [contour], -1, 255, 1)
            nearby_wall = cv2.dilate(barrier, np.ones((5, 5), np.uint8))
            if np.count_nonzero((edge > 0) & (nearby_wall > 0)) < max(8, np.count_nonzero(edge) * .05):
                continue
        semantic = 0
        if room_labels is not None:
            values, counts = np.unique(room_labels[region > 0], return_counts=True)
            positive = np.isin(values, tuple(INDOOR_ROOM_CLASSES))
            if positive.any():
                semantic = int(values[positive][np.argmax(counts[positive])])
        rooms.append({"polygon": polygon.tolist(), "area": round(float(cv2.contourArea(polygon.astype(np.float32))), 4),
                      "semantic": semantic, "_centre": centroids[index].tolist()})
    rooms.sort(key=lambda item: (round(item["_centre"][1] / 15), item["_centre"][0]))
    for room in rooms:
        del room["_centre"]
    return rooms


def vectorize_plan_labels(labels, room_labels=None):
    """Return walls, host-wall openings, inner room polygons and pixel bounds.

    ``room_labels`` uses CubiCasa's 12-class room head: indoor classes are
    3/4/5/6/7/9/10/11; background/outdoor/wall/railing are 0/1/2/8. When it
    contains no indoor predictions the enclosed-background fallback is used.
    ``bounds`` is the envelope of recovered wall centrelines. Openings are
    retained as holes in the resulting parametric walls; only the temporary
    room flood-fill barrier closes them. Unknown background cannot by itself
    become a room. Optional room labels name enclosed spaces, not invent walls.
    Raised errors must be surfaced to the user instead of replacing their plan.
    """
    labels = _validated_mask(labels, "结构分割", (0, 1, 2, 3))
    if room_labels is not None:
        room_labels = _validated_mask(room_labels, "房间分割", tuple(range(12)))
        if room_labels.shape != labels.shape:
            raise VectorizationError("房间与结构分割尺寸必须一致。")
    wall = np.uint8(labels == 1) * 255
    if np.count_nonzero(wall) > wall.size * .65:
        raise VectorizationError("墙体语义覆盖过多，分割结果无法作为可用户型结构，请核对输入图。")
    components, ids = _components(wall, minimum=4)
    wall = np.uint8(np.isin(ids, [index for index, _ in components])) * 255
    # Pinholes and 1 px segmentation interruptions can be repaired. Larger
    # gaps require an explicit door/window prediction rather than guessed walls.
    wall = cv2.morphologyEx(wall, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    openings = _opening_components(labels)
    lines, thickness = _extract_lines(_bridge_openings(wall, openings), openings, original_wall=wall)
    lines, discarded = _remove_isolated_thin_lines(lines, thickness)
    accepted, barrier, warnings = _assign_openings(lines, openings, wall)
    if discarded:
        warnings.append(f"已过滤 {discarded} 处短薄孤立线段，请检查是否有小隔墙需要手动补充。")
    points = np.vstack([np.stack((line["start"], line["end"])) for line in lines])
    bounds = [float(points[:, 0].min()), float(points[:, 1].min()),
              float(points[:, 0].max()), float(points[:, 1].max())]
    if min(bounds[2] - bounds[0], bounds[3] - bounds[1]) < 12:
        raise VectorizationError("墙中心线范围过小，无法标定建筑尺寸。")
    rooms = _room_polygons(barrier, room_labels, bounds)
    if not rooms:
        raise VectorizationError("墙体与已识别门窗未形成可用封闭房间；请核对外墙缺口和语义分割结果。")
    if len(rooms) > 100 or len(accepted) > 500:
        raise VectorizationError("房间或门窗数量超过项目上限。")
    if len(rooms) == 1 and not accepted and len(openings):
        warnings.append("检测到开口符号但无法可靠匹配墙体，房间可能仍有合并，请校正结构。")
    return {"walls": [{"start": [round(float(v), 4) for v in line["start"]],
                       "end": [round(float(v), 4) for v in line["end"]],
                       "thickness": round(line["thickness"], 4)} for line in lines],
            "openings": accepted, "rooms": rooms, "bounds": [round(value, 4) for value in bounds],
            "warnings": warnings[:100]}
