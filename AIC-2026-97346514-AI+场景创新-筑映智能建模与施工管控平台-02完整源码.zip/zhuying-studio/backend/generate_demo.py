"""Generate a controlled input fixture, not an AI reconstruction benchmark."""

from pathlib import Path

from PIL import Image, ImageDraw


def generate():
    image = Image.new("RGB", (1300, 900), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((50, 50, 1250, 850), outline="#181818", width=15)
    for x in (450, 850):
        draw.line((x, 50, x, 850), fill="#181818", width=11)
    draw.line((50, 450, 1250, 450), fill="#181818", width=11)
    path = Path(__file__).resolve().parents[1] / "public" / "demo-plan.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)
    print(path)


if __name__ == "__main__":
    generate()
