import test from 'node:test';
import assert from 'node:assert/strict';
import { FLOOR_FINISHES, WALL_COLORS, resolveRoomDesign, updateRoomDesign, resetRoomDesign, preserveRoomDesign } from '../src/design.mjs';
import { validateProject } from '../src/project.mjs';

const room = (id, material = 'wood') => ({
  id, name: id, polygon: [[0,0],[4,0],[4,4],[0,4]], area: 16, material, progress: 75,
  tasks: { floor: {stage:'complete',plannedStage:'complete',dueDate:'2026-10-04'},
           wall: {stage:'in_progress',plannedStage:'complete',dueDate:'2026-10-08'} },
  evidence: [{id:'e1',date:'2026-10-04',image:'data:image/png;base64,aA==',workType:'floor',
             stage:'complete',summary:'人工确认现场状态',confirmed:true,source:'manual'}]
});
const model = () => ({id:'test-design',name:'设计测试',width:8,depth:4,height:2.8,source:'demo',warnings:[],
  walls:[{id:'w1',start:[0,0],end:[8,0],thickness:.2}],openings:[],rooms:[room('r1'),room('r2','tile')],meta:{demo:true}});
const custom = () => ({floorFinish:'walnut',wallColor:'#c2d0bd',wallFinish:'plaster',floorDirection:90});

test('六种地面和六种墙色提供合法、唯一的完整预设', () => {
  assert.equal(FLOOR_FINISHES.length, 6);
  assert.equal(WALL_COLORS.length, 6);
  assert.deepEqual(new Set(FLOOR_FINISHES.map(f=>f.id)), new Set(['oak','walnut','light_tile','gray_stone','terrazzo','concrete']));
  assert.equal(new Set(WALL_COLORS.map(c=>c.id)).size, 6);
  for (const finish of FLOOR_FINISHES) assert.ok(finish.label && finish.description && /^#[0-9a-f]{6}$/i.test(finish.color));
  for (const color of WALL_COLORS) assert.ok(color.label && /^#[0-9a-f]{6}$/i.test(color.color));
});

test('未带design的旧房间按材质获得默认设计，不修改原房间', () => {
  for (const [material, finish] of [['wood','oak'],['tile','light_tile'],['stone','gray_stone'],['concrete','concrete'],['old-material','oak']]) {
    const r = room('r1', material), before = structuredClone(r);
    assert.deepEqual(resolveRoomDesign(r), {floorFinish:finish,wallColor:'#f4f0e8',wallFinish:'paint',floorDirection:0});
    assert.deepEqual(r,before);
  }
});

test('已有设计优先，并返回独立对象避免调用方修改已保存状态', () => {
  const r = {...room('r1'),design:custom()};
  const resolved = resolveRoomDesign(r);
  assert.deepEqual(resolved,custom());
  resolved.wallColor = '#000000';
  assert.equal(r.design.wallColor,'#c2d0bd');
});

test('设计变更仅影响目标房间且完整保留施工状态、证据、材料和项目来源', () => {
  const m = model(), before = structuredClone(m);
  const next = updateRoomDesign(m,'r1',{floorFinish:'walnut',wallColor:'#c2d0bd'});
  assert.notStrictEqual(next,m);
  assert.equal(next.rooms[0].design.floorFinish,'walnut');
  assert.equal(next.rooms[0].design.wallColor,'#c2d0bd');
  assert.equal(next.source,'demo');
  assert.deepEqual(next.meta,m.meta);
  assert.deepEqual(next.rooms[1],m.rooms[1]);
  const {design,...withoutDesign} = next.rooms[0];
  assert.deepEqual(withoutDesign,m.rooms[0]);
  assert.deepEqual(m,before);
});

test('对已有设计修改单个字段保留其它设计选择', () => {
  const m = model(); m.rooms[0].design = custom();
  const next = updateRoomDesign(m,'r1',{floorDirection:0});
  assert.deepEqual(next.rooms[0].design,{...custom(),floorDirection:0});
});

test('重置只删除目标design，恢复旧材质默认，不改变施工记录', () => {
  const m = model(); m.rooms[0].design = custom(); m.rooms[1].design = custom();
  const before = structuredClone(m);
  const next = resetRoomDesign(m,'r1');
  assert.ok(!Object.hasOwn(next.rooms[0],'design'));
  assert.equal(resolveRoomDesign(next.rooms[0]).floorFinish,'oak');
  assert.deepEqual(next.rooms[1],m.rooms[1]);
  assert.deepEqual(next.rooms[0],room('r1'));
  assert.equal(next.source,'demo');
  assert.deepEqual(m,before);
});

test('跨时间线按房间id保留设计，采用next工序与进度且不污染旧快照', () => {
  const previous = model(); previous.rooms[0].design = custom();
  const next = model(); next.rooms.reverse();
  const target = next.rooms.find(r=>r.id==='r1');
  target.tasks.floor.stage = 'not_started'; target.tasks.wall.stage = 'unknown'; target.progress=0;target.evidence=[];
  next.rooms.push(room('r3','concrete'));
  const beforeNext=structuredClone(next), beforePrevious=structuredClone(previous);
  const combined = preserveRoomDesign(previous,next);
  const preserved=combined.rooms.find(r=>r.id==='r1');
  assert.deepEqual(preserved.design,custom());
  assert.deepEqual(preserved.tasks,target.tasks);
  assert.equal(preserved.progress,0);
  assert.deepEqual(preserved.evidence,[]);
  assert.ok(!Object.hasOwn(combined.rooms.find(r=>r.id==='r2'),'design'));
  assert.ok(!Object.hasOwn(combined.rooms.find(r=>r.id==='r3'),'design'));
  preserved.design.wallColor='#000000';
  assert.deepEqual(previous,beforePrevious);
  assert.deepEqual(next,beforeNext);
});

test('非法设计值、未知房间和跨领域字段修改被明确拒绝', () => {
  const m = model();
  for (const patch of [{floorFinish:'carpet'},{wallColor:'red'},{wallColor:'#fff'},{wallColor:'#gg0000'},
                       {wallFinish:'wallpaper'},{floorDirection:45},{floorDirection:'90'},{progress:100}]) {
    assert.throws(()=>updateRoomDesign(m,'r1',patch));
  }
  assert.throws(()=>updateRoomDesign(m,'missing',{floorFinish:'oak'}));
  assert.throws(()=>resetRoomDesign(m,'missing'));
  assert.ok(!Object.hasOwn(m.rooms[0],'design'));
});

test('设计项目导出导入roundtrip保留全部设计、进度与证据，旧项目仍可读取', () => {
  const old = model(); assert.strictEqual(validateProject(old),old);
  const styled = updateRoomDesign(old,'r1',custom());
  const restored = validateProject(JSON.parse(JSON.stringify(styled)));
  assert.deepEqual(restored,styled);
  assert.deepEqual(resolveRoomDesign(restored.rooms[0]),custom());
});
