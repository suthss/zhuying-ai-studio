"""Download one official CC BY 4.0 demonstration video and extract real observations.

Run with .venv/Scripts/python.exe scripts/build_renovation_case.py.
The third source sequence is a different room and must never be presented as a
third observation of room 5-169. The original image annotations are preserved.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

import cv2


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "renovation-case"
DATASET_ID = "rskgn5f8y8"
VERSION = 2
FILE_ID = "b2ba26c9-1253-42f2-88cb-e5b0449fb585"
SOURCE_URL = f"https://data.mendeley.com/datasets/{DATASET_ID}/{VERSION}"
SNAPSHOT_URL = f"https://data.mendeley.com/public-api/datasets/{DATASET_ID}/snapshot/{VERSION}"
API_URL = (
    f"https://data.mendeley.com/public-api/datasets/{DATASET_ID}/files"
    "?folder_id=root&version=2&$start=0&$limit=1000"
)
VIDEO_URL = (
    f"https://data.mendeley.com/public-files/datasets/{DATASET_ID}"
    f"/files/{FILE_ID}/file_downloaded"
)
SHA256 = "6782458b7250ce57ed82003cf7c4e8092ef8296c14d13592e0524d966bc0d4e2"
BYTES = 28659205
CROP = [12, 143, 629, 490]  # x0, y0, x1, y1: source camera viewport.
AUTHORS = ["Christian Koch", "Markus König", "Christopher Kropp"]


def read_json(url: str):
    with urlopen(Request(url, headers={"User-Agent": "Renovation-case-provenance/1.0"})) as response:
        return json.load(response)


def frame(cap: cv2.VideoCapture, second: int):
    # Exact source frame index at 24 fps; no interpolation or image synthesis.
    cap.set(cv2.CAP_PROP_POS_FRAMES, second * 24)
    success, pixels = cap.read()
    if not success:
        raise RuntimeError(f"Could not decode source frame at {second}s")
    return pixels


def save_jpg(filename: str, pixels) -> str:
    target = OUT / filename
    success, encoded = cv2.imencode(".jpg", pixels, [cv2.IMWRITE_JPEG_QUALITY, 94])
    if not success:
        raise RuntimeError(f"Could not save {target}")
    # imwrite on Windows does not reliably handle a workspace containing Chinese.
    target.write_bytes(encoded.tobytes())
    return f"/renovation-case/{filename}"


def observation(cap, sequence, date, room, label, state, seconds, reference=False):
    prefix = f"reference-0{sequence}" if reference else f"stage-0{sequence}"
    photos = []
    for view, second in seconds:
        pixels = frame(cap, second)
        original = save_jpg(f"{prefix}-{view}-source-frame.jpg", pixels)
        x0, y0, x1, y1 = CROP
        image = save_jpg(f"{prefix}-{view}.jpg", pixels[y0:y1, x0:x1])
        photos.append({
            "id": f"{prefix}-{view}",
            "image": image,
            "url": image,
            "fullFrame": original,
            "alt": f"波鸿大学 IC 楼 {room} 房间，{date}，{label}，{view} 视角",
            "view": view,
            "sourceTimeSeconds": second,
            "sourceFrameIndex": second * 24,
            "cropPixels": CROP,
            "width": x1 - x0,
            "height": y1 - y0,
            "changes": "从原视频抽帧并裁切左上角真实相机画面；保留原视频已有彩色识别标注；JPEG编码，无补绘、增强或合成。",
        })
    title_second = {1: 20, 2: 50, 3: 115}[sequence]
    evidence = save_jpg(f"sequence-0{sequence}-date-room-evidence.jpg", frame(cap, title_second))
    return {
        "id": prefix,
        "sourceSequence": sequence,
        "label": label,
        "roomId": room,
        "comparisonGroup": f"ic-room-{room}",
        "isSameRoomTimeline": not reference,
        "role": "other-room-reference" if reference else "same-room-observation",
        "capturedAt": date,
        "capturedDate": date,
        "capturedTime": None,
        "captureTimezone": None,
        "dateSource": "原视频各序列片头直接标注；未将数据集发布日期或API文件记录日期当作拍摄日期。",
        "dateEvidence": {"image": evidence, "sourceTimeSeconds": title_second},
        "states": state,
        "image": photos[0]["image"],
        "images": photos,
        "evidenceScope": "施工活动阶段观察；不提供实际验收结论、缺陷判断或整改事件。",
    }


def build(keep_video=False):
    OUT.mkdir(parents=True, exist_ok=True)
    snapshot = read_json(SNAPSHOT_URL)
    if snapshot["licence"]["short_name"] != "CC BY 4.0":
        raise RuntimeError("Dataset license changed; review before redistributing")
    (OUT / "official-dataset-metadata.json").write_text(
        json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    metadata = read_json(API_URL)
    files = metadata if isinstance(metadata, list) else [metadata]
    record = next(item for item in files if item["id"] == FILE_ID)
    if record["size"] != BYTES:
        raise RuntimeError("Official file size changed; review before downloading")
    (OUT / "official-file-metadata.json").write_text(
        json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    video = OUT / "source-video.mp4"
    if not video.exists():
        request = Request(VIDEO_URL, headers={
            "User-Agent": "Mozilla/5.0", "Referer": SOURCE_URL,
        })
        with urlopen(request) as response, video.open("wb") as destination:
            copied = 0
            while chunk := response.read(1024 * 1024):
                copied += len(chunk)
                if copied > BYTES:
                    raise RuntimeError("Download exceeded verified file size")
                destination.write(chunk)
    if video.stat().st_size != BYTES or hashlib.sha256(video.read_bytes()).hexdigest() != SHA256:
        raise RuntimeError("Downloaded video does not match the official SHA-256")
    cap = cv2.VideoCapture(str(video))
    if cap.get(cv2.CAP_PROP_FPS) != 24.0:
        raise RuntimeError("Video fps changed; timestamp mapping must be reviewed")
    stages = [
        observation(cap, 1, "2012-11-27", "5-169", "石膏板已安装 · 散热器未出现",
                    {"drywall": "installed", "radiator": "not-present"}, [("window", 30), ("wall", 39)]),
        observation(cap, 2, "2012-12-20", "5-169", "石膏板已批灰 · 散热器未安装",
                    {"drywall": "plastered", "radiator": "not-present"}, [("window", 70), ("wall", 62)]),
    ]
    references = [
        observation(cap, 3, "2012-12-20", "2-169", "另一房间参考：墙面已涂漆 · 散热器已出现",
                    {"drywall": "painted", "radiator": "present"}, [("window", 120), ("wall", 130)], True)
    ]
    cap.release()
    data = {
        "schemaVersion": 1,
        "id": "rub-ic-renovation",
        "title": "波鸿大学 IC 楼真实室内翻修案例",
        "subtitle": "房间 5-169 两期真实观察；房间 2-169 单独作为同工地阶段参考",
        "source": {
            "title": "Data for: Interior construction state recognition with 4D BIM registered image sequences",
            "url": SOURCE_URL,
            "doi": "10.17632/rskgn5f8y8.2",
            "repository": "Mendeley Data",
            "metadataApi": SNAPSHOT_URL,
            "licenseEvidence": "/renovation-case/official-dataset-metadata.json",
            "version": VERSION,
            "authors": AUTHORS,
            "publishedAt": "2017-11-09",
            "file": {
                "name": record["filename"], "id": FILE_ID,
                "bytes": BYTES, "sha256": SHA256, "downloadUrl": VIDEO_URL,
                "metadataApi": API_URL,
                "repositoryFileCreatedAt": record["content_details"]["created_date"],
                "durationSeconds": 3797 / 24, "fps": 24, "width": 1920, "height": 1080,
            },
            "license": {"id": "CC-BY-4.0", "label": "CC BY 4.0", "url": "https://creativecommons.org/licenses/by/4.0/"},
            "attribution": "Koch, Christian; König, Markus; Kropp, Christopher (2017), Mendeley Data V2, doi:10.17632/rskgn5f8y8.2. CC BY 4.0. 本应用抽帧并裁切真实相机画面，保留原标注。",
            "checkedAt": "2026-10-06",
        },
        "project": {
            "name": "Ruhr-Universität Bochum, IC building renovation",
            "location": "Bochum, Germany",
            "primaryRoomId": "5-169",
            "measuredDimensions": None,
            "floorPlan": None,
            "bimFile": None,
            "actualPlan": None,
            "actualBudget": None,
            "actualAssignees": None,
            "actualDefects": None,
            "actualRemediationEvents": None,
        },
        "stages": stages,
        "referenceStages": references,
        "limits": [
            "主时序仅含房间5-169的两次真实采集，第三段房间2-169不得作为该房间的后续时序。",
            "拍摄日期来自原视频片头；精确时间、时区和EXIF未知。",
            "画面中的彩色边界与状态识别文字来自原作者视频，不是本应用新生成的检测结果。",
            "本素材没有公开尺寸、户型、原始BIM文件、预算、施工计划或责任人，不足以建立实景测绘模型。",
            "可展示真实施工阶段；素材不证明延期、不合格、缺陷或实际整改，相关任务须明确为演示模拟。",
        ],
    }
    (OUT / "data.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if not keep_video:
        video.unlink()
    print(json.dumps({"data": str(OUT / "data.json"), "sameRoomStages": len(stages),
                      "otherRoomReferences": len(references), "sourceSha256Verified": True,
                      "keptSourceVideo": keep_video}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--keep-video", action="store_true", help="Keep the 27.3 MiB source video locally")
    build(parser.parse_args().keep_video)
