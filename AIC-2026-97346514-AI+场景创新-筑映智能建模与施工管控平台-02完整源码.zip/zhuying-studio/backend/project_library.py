"""Local project library. Full models live in SQLite; list responses use small summaries."""

import base64
import binascii
import hashlib
import json
import math
import os
import re
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from starlette.concurrency import run_in_threadpool

from backend.practical import validate_practical_meta

router = APIRouter(prefix="/api/projects", tags=["project-library"])
MAX_PROJECT_BODY_BYTES = 50 * 1024 * 1024
STAGES = frozenset(("unknown", "not_started", "in_progress", "complete"))
WORK_TYPES = frozenset(("electrical", "waterproof", "masonry", "carpentry", "floor", "wall"))
FURNITURE_KINDS = frozenset(("sofa", "coffee_table", "tv_console", "bed_double", "bed_single",
                            "wardrobe", "desk", "chair", "dining_table", "kitchen_counter", "sink_cabinet", "toilet", "shoe_cabinet"))
ROOM_USES = frozenset(("living", "bedroom", "study", "kitchen", "bathroom", "entry", "dining", "empty"))
DESIGN_NEEDS = frozenset(("work", "storage", "dining", "children", "pet", "senior", "accessibility", "relax"))
SHANGHAI = timezone(timedelta(hours=8))
COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")
IMAGE = re.compile(r"^data:image/(?:png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$")


def library_today():
    """Calendar deadlines follow China time even on a differently configured host."""
    return datetime.now(SHANGHAI).date().isoformat()


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _invalid(message):
    raise HTTPException(422, detail=message)


def _text(value, maximum=160, empty=False):
    return isinstance(value, str) and len(value) <= maximum and (empty or bool(value.strip()))


def _number(value, low, high):
    try:
        return type(value) in (int, float) and math.isfinite(value) and low <= value <= high
    except OverflowError:
        return False


def _enum(value, choices):
    return isinstance(value, str) and value in choices


def _point(value):
    return isinstance(value, list) and len(value) == 2 and all(_number(item, 0, 100) for item in value)


def _date(value, empty=False):
    if empty and value == "":
        return True
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return False
    try:
        return date.fromisoformat(value).isoformat() == value
    except ValueError:
        return False


def _array(value, maximum, minimum=0):
    return isinstance(value, list) and minimum <= len(value) <= maximum


def _rows(value, maximum, minimum=0):
    if not _array(value, maximum, minimum) or any(not isinstance(row, dict) or not _text(row.get("id")) for row in value):
        return False
    return len({row["id"] for row in value}) == len(value)


def _polygon_area(polygon):
    return abs(sum(a[0] * polygon[(index + 1) % len(polygon)][1]
                   - polygon[(index + 1) % len(polygon)][0] * a[1]
                   for index, a in enumerate(polygon))) / 2


def _image_bytes(value):
    if not isinstance(value, str) or len(value) > 15 * 1024 * 1024:
        _invalid("巡检照片须为不超过 10 MB 的 PNG、JPEG 或 WebP 内嵌图片。")
    match = IMAGE.fullmatch(value)
    if not match or len(match[1]) % 4:
        _invalid("巡检照片编码无效，请重新导入原项目。")
    try:
        size = len(base64.b64decode(match[1], validate=True))
    except (ValueError, binascii.Error):
        _invalid("巡检照片编码无效，请重新导入原项目。")
    if size > 10 * 1024 * 1024:
        _invalid("单张巡检照片超过 10 MB，请先压缩照片。")
    return size


def _validate_evidence(records):
    if not _rows(records, 1000):
        _invalid("施工记录须为最多 1000 条、编号不重复的记录。")
    seen = {}
    for index, record in enumerate(records):
        if (not _date(record.get("date")) or not _enum(record.get("workType"), WORK_TYPES)
                or not _enum(record.get("stage"), STAGES) or ("aiStage" in record and not _enum(record["aiStage"], STAGES))
                or not _text(record.get("summary"), 12000, empty=True) or not _text(record.get("source"))
                or type(record.get("confirmed")) is not bool):
            _invalid("施工记录的日期、工序、阶段或确认状态无效。")
        size = _image_bytes(record.get("image"))
        count = 1
        if "photos" in record:
            if not _rows(record["photos"], 6, 1):
                _invalid("每条巡检须有 1–6 张编号不重复的照片。")
            count, size = len(record["photos"]), 0
            for photo in record["photos"]:
                if not _text(photo.get("viewpoint"), 240):
                    _invalid("巡检照片须填写视角名称。")
                size += _image_bytes(photo.get("image"))
            if record["image"] != record["photos"][0]["image"]:
                _invalid("巡检封面须与第一张照片一致。")
        if size > 30 * 1024 * 1024:
            _invalid("单条巡检照片合计超过 30 MB。")
        if "observations" in record:
            observations = record["observations"]
            if not _array(observations, count):
                _invalid("巡检逐图观察数量无效。")
            indexes = set()
            for observation in observations:
                if (not isinstance(observation, dict) or type(observation.get("photoIndex")) is not int
                        or not 0 <= observation["photoIndex"] < count or observation["photoIndex"] in indexes
                        or not _text(observation.get("summary"), 12000, empty=True)):
                    _invalid("巡检逐图观察须对应不同的有效照片编号。")
                indexes.add(observation["photoIndex"])
        if "comparison" in record:
            comparison = record["comparison"]
            if (not isinstance(comparison, dict) or not _text(comparison.get("previousEvidenceId"))
                    or not _date(comparison.get("previousDate"))
                    or not _text(comparison.get("summary"), 12000, empty=True)
                    or comparison.get("change") not in ("advanced", "unchanged", "regressed", "uncertain")
                    or not _text(comparison.get("source"))):
                _invalid("巡检历史对比格式无效。")
        seen[record["id"]] = (index, record)
    for index, record in enumerate(records):
        if "comparison" not in record:
            continue
        comparison = record["comparison"]
        previous = seen.get(comparison["previousEvidenceId"])
        if (not previous or not previous[1]["confirmed"] or previous[1]["workType"] != record["workType"]
                or previous[1]["date"] != comparison["previousDate"] or previous[1]["date"] > record["date"]
                or (previous[1]["date"] == record["date"] and previous[0] >= index)):
            _invalid("历史对比须引用同房间同工序、较早且已确认的巡检记录。")


def validate_model(model):
    """Validate basic editable geometry and stored evidence, preserving the full model."""
    if (not isinstance(model, dict) or not _text(model.get("id")) or not _text(model.get("name"))
            or not _number(model.get("width"), .1, 100) or not _number(model.get("depth"), .1, 100)
            or not _number(model.get("height"), 2, 6) or model.get("source") not in ("demo", "opencv", "manual")):
        _invalid("模型编号、名称、尺寸或来源无效，请使用筑映完整项目。")
    if "meta" in model and not isinstance(model["meta"], dict):
        _invalid("模型附加信息须为 JSON 对象。")
    if (not _rows(model.get("walls"), 500, 1) or not _rows(model.get("rooms"), 100, 1)
            or not _rows(model.get("openings"), 500) or not _array(model.get("warnings"), 100)
            or any(not _text(item, 12000, empty=True) for item in model["warnings"])):
        _invalid("墙体、房间或门窗列表无效，或编号存在重复。")
    walls = {wall["id"]: wall for wall in model["walls"]}
    for wall in walls.values():
        if (not _point(wall.get("start")) or not _point(wall.get("end"))
                or math.dist(wall["start"], wall["end"]) < .01 or not _number(wall.get("thickness"), .02, 2)
                or ("height" in wall and not _number(wall["height"], .1, model["height"]))):
            _invalid("墙体坐标、厚度或高度无效。")
    for opening in model["openings"]:
        wall_id = opening.get("wallId")
        wall = walls.get(wall_id) if isinstance(wall_id, str) else None
        if (not wall or opening.get("type") not in ("door", "window")
                or not _number(opening.get("offset"), 0, 150) or not _number(opening.get("width"), .1, 150)
                or not _number(opening.get("height"), .1, model["height"])
                or not _number(opening.get("sill", 0), 0, model["height"])
                or (opening["type"] == "door" and opening.get("sill", 0) != 0)
                or opening["offset"] + opening["width"] > math.dist(wall["start"], wall["end"]) + .00001
                or opening.get("sill", 0) + opening["height"] > wall.get("height", model["height"]) + .00001):
            _invalid("门窗须关联有效墙体，且开口不得超出墙长或墙高。")
        if "design" in opening:
            design = opening["design"]
            styles = ("flush", "panel", "glass") if opening["type"] == "door" else ("fixed", "casement", "sliding")
            if (not isinstance(design, dict) or design.get("style") not in styles
                    or not isinstance(design.get("color"), str) or not COLOR.fullmatch(design["color"])
                    or not _number(design.get("openAngle"), 0, 100 if opening["type"] == "door" else 60)
                    or (design["style"] in ("fixed", "sliding") and design["openAngle"] != 0)
                    or design.get("hinge") not in ("start", "end") or type(design.get("swing")) is not int
                    or design["swing"] not in (-1, 1) or design.get("glassTint") not in ("clear", "smoke")):
                _invalid("门窗款式、颜色或开启设置无效。")
    rooms = {room["id"]: room for room in model["rooms"]}
    for room in rooms.values():
        if (not _text(room.get("name")) or not _array(room.get("polygon"), 200, 3)
                or any(not _point(point) for point in room["polygon"]) or _polygon_area(room["polygon"]) < .001
                or not _number(room.get("area"), .001, 10000) or not _text(room.get("material"))
                or not _number(room.get("progress"), 0, 100)):
            _invalid("房间名称、轮廓、面积或阶段数据无效。")
        tasks = room.get("tasks")
        if not isinstance(tasks, dict) or "floor" not in tasks or "wall" not in tasks:
            _invalid("每个房间须包含地面和墙面工序。")
        for kind, task in tasks.items():
            if (kind not in WORK_TYPES or not isinstance(task, dict) or not _enum(task.get("stage"), STAGES)
                    or not _enum(task.get("plannedStage"), STAGES) or not _date(task.get("dueDate"), empty=True)
                    or ("enabled" in task and type(task["enabled"]) is not bool)
                    or ("note" in task and not _text(task["note"], 12000, empty=True))):
                _invalid("工序类型、阶段、计划日期或启用状态无效。")
        if "design" in room:
            design = room["design"]
            if (not isinstance(design, dict) or design.get("floorFinish") not in ("oak", "walnut", "light_tile", "gray_stone", "terrazzo", "concrete")
                    or not isinstance(design.get("wallColor"), str) or not COLOR.fullmatch(design["wallColor"])
                    or design.get("wallFinish") not in ("paint", "plaster") or type(design.get("floorDirection")) is not int
                    or design["floorDirection"] not in (0, 90)):
                _invalid("房间装修材质、墙色或地板方向无效。")
        if "evidence" in room:
            _validate_evidence(room["evidence"])
    if "furniture" in model:
        if not _rows(model["furniture"], 300):
            _invalid("家具列表无效或编号重复。")
        for item in model["furniture"]:
            if (not _enum(item.get("roomId"), rooms) or not _enum(item.get("kind"), FURNITURE_KINDS) or not _point(item.get("position"))
                    or not isinstance(item.get("size"), list) or len(item["size"]) != 3
                    or not _number(item["size"][0], .1, 6) or not _number(item["size"][2], .1, 6)
                    or not _number(item["size"][1], .1, min(4, model["height"] - .03))
                    or not _number(item.get("rotation"), -math.pi * 2 - .000001, math.pi * 2 + .000001)
                    or not isinstance(item.get("color"), str) or not COLOR.fullmatch(item["color"])):
                _invalid("家具关联房间、种类、尺寸、颜色或位置无效。")
    if "designBrief" in model:
        brief = model["designBrief"]
        if (not isinstance(brief, dict) or brief.get("style") not in ("warm", "minimal", "natural", "industrial")
                or type(brief.get("residents")) is not int or not 1 <= brief["residents"] <= 12
                or not _array(brief.get("needs"), 8) or any(not _enum(item, DESIGN_NEEDS) for item in brief["needs"])
                or not _text(brief.get("notes"), 2000, empty=True) or not _array(brief.get("rooms"), len(rooms))
                or len(brief["rooms"]) != len(rooms)):
            _invalid("装修需求问答格式无效。")
        seen = set()
        for room in brief["rooms"]:
            if (not isinstance(room, dict) or not _enum(room.get("roomId"), rooms) or room["roomId"] in seen
                    or not _enum(room.get("use"), ROOM_USES) or type(room.get("furnish")) is not bool
                    or ("items" in room and (not _array(room["items"], 30) or any(not _enum(item, FURNITURE_KINDS) for item in room["items"])))):
                _invalid("装修问答须为每个房间提供有效且不重复的用途。")
            seen.add(room["roomId"])
    if "meta" in model:
        validate_practical_meta(model["meta"], model)
    return model


def _summary(model):
    tasks = [task for room in model["rooms"] for task in room["tasks"].values() if task.get("enabled", True)]
    latest_dates = [record["date"] for room in model["rooms"] for record in room.get("evidence", [])]
    stats = {"roomCount": len(model["rooms"]), "area": round(sum(_polygon_area(room["polygon"]) for room in model["rooms"]), 2),
             "completed": sum(task["stage"] == "complete" for task in tasks),
             "known": sum(task["stage"] != "unknown" for task in tasks), "total": len(tasks),
             "unknown": sum(task["stage"] == "unknown" for task in tasks),
             "latestInspectionDate": max(latest_dates, default=None),
             "demo": model["source"] == "demo" or bool((model.get("meta") or {}).get("demoData"))}
    return {"stats": stats, "preview": {"width": model["width"], "depth": model["depth"],
            "rooms": [{key: room[key] for key in ("id", "name", "polygon")} for room in model["rooms"]],
            "walls": [{key: wall[key] for key in ("start", "end")} for wall in model["walls"]]},
            "schedule": [{"stage": task["stage"], "plannedStage": task["plannedStage"], "dueDate": task["dueDate"]} for task in tasks]}


def _json(value):
    try:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    except (ValueError, TypeError, RecursionError) as exc:
        raise HTTPException(422, detail="项目须为有效 JSON，不能包含无限值。") from exc


def _overdue(task, today):
    ranks = {"not_started": 0, "in_progress": 1, "complete": 2}
    planned = ranks.get(task.get("plannedStage", "complete"))
    actual = ranks.get(task["stage"])
    return (bool(task["dueDate"]) and task["dueDate"] < today and planned is not None
            and (actual is None or actual < planned))


def database_path():
    configured = os.environ.get("PROJECT_DATABASE_PATH", "").strip()
    return Path(configured).expanduser().resolve() if configured else Path(__file__).resolve().parent.parent / "data" / "zhuying.sqlite3"


@contextmanager
def _connection():
    path = database_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=10, isolation_level=None)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=10000")
        connection.executescript("""
          CREATE TABLE IF NOT EXISTS library_meta (singleton INTEGER PRIMARY KEY CHECK(singleton=1), change_version INTEGER NOT NULL);
          INSERT OR IGNORE INTO library_meta VALUES (1, 0);
          CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, location TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('active', 'archived')), revision INTEGER NOT NULL,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL, model_json TEXT NOT NULL, summary_json TEXT NOT NULL
          );
          CREATE INDEX IF NOT EXISTS projects_updated ON projects(updated_at DESC, id);
          CREATE TABLE IF NOT EXISTS project_creation_keys (
            client_key TEXT PRIMARY KEY, project_id TEXT NOT NULL, request_hash TEXT NOT NULL
          );
        """)
        yield connection
    finally:
        connection.close()


def _metadata(row):
    return {"id": row["id"], "name": row["name"], "location": row["location"], "status": row["status"],
            "revision": row["revision"], "createdAt": row["created_at"], "updatedAt": row["updated_at"]}


def _record(row):
    return {**_metadata(row), "model": json.loads(row["model_json"])}


def _required_row(connection, project_id):
    if not _text(project_id):
        _invalid("项目库编号无效。")
    row = connection.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
    if row is None:
        raise HTTPException(404, detail="项目库中找不到该项目，请刷新列表。")
    return row


def list_projects():
    today = library_today()
    with _connection() as connection:
        # Both values belong to the same read snapshot; no full photo JSON is selected.
        connection.execute("BEGIN")
        rows = connection.execute("SELECT id,name,location,status,revision,created_at,updated_at,summary_json FROM projects ORDER BY updated_at DESC,id").fetchall()
        version = connection.execute("SELECT change_version FROM library_meta WHERE singleton=1").fetchone()[0]
    projects = []
    for row in rows:
        summary = json.loads(row["summary_json"])
        summary["stats"]["overdue"] = sum(_overdue(task, today) for task in summary.pop("schedule"))
        projects.append({**_metadata(row), **summary})
    return {"projects": projects, "changeVersion": version, "serverTime": _now()}


def get_project(project_id):
    with _connection() as connection:
        return _record(_required_row(connection, project_id))


def create_project(payload):
    if not isinstance(payload, dict) or set(payload) - {"model", "location", "clientKey"}:
        _invalid("新建项目只接受 model、location 和可选 clientKey 字段。")
    model = validate_model(payload.get("model"))
    location = payload.get("location", "")
    if not _text(location, 240, empty=True):
        _invalid("项目位置须为不超过 240 字的文字。")
    client_key = payload.get("clientKey")
    if "clientKey" in payload and not _text(client_key):
        _invalid("clientKey 须为 1–160 字的非空文字。")
    # Retrying a creation after a lost response must not create a second model.
    # A different payload using the same key is rejected rather than discarded.
    model_json = _json(model)
    canonical = json.dumps({"model": json.loads(model_json), "location": location.strip()}, ensure_ascii=False,
                           sort_keys=True, separators=(",", ":"), allow_nan=False)
    request_hash = hashlib.sha256(canonical.encode()).hexdigest()
    project_id, now = str(uuid.uuid4()), _now()
    with _connection() as connection:
        connection.execute("BEGIN IMMEDIATE")
        if client_key is not None:
            previous = connection.execute("SELECT project_id,request_hash FROM project_creation_keys WHERE client_key=?", (client_key,)).fetchone()
            if previous is not None:
                if previous["request_hash"] != request_hash:
                    raise HTTPException(409, detail={"reason": "creation_conflict", "message": "该保存请求已有不同内容，请重新保存当前模型。"})
                return _record(_required_row(connection, previous["project_id"]))
        connection.execute("INSERT INTO projects VALUES (?,?,?,?,?,?,?,?,?)",
                           (project_id, model["name"], location.strip(), "active", 1, now, now, model_json, _json(_summary(model))))
        connection.execute("UPDATE library_meta SET change_version=change_version+1 WHERE singleton=1")
        if client_key is not None:
            connection.execute("INSERT INTO project_creation_keys VALUES (?,?,?)", (client_key, project_id, request_hash))
        row = _required_row(connection, project_id)
        connection.commit()
        return _record(row)


def update_project(project_id, payload):
    if (not isinstance(payload, dict) or set(payload) - {"revision", "model", "name", "location", "status"}
            or not set(payload).intersection(("model", "name", "location", "status"))):
        _invalid("更新项目须包含 model、name、location 或 status，以及当前 revision。")
    if type(payload.get("revision")) is not int or payload["revision"] < 1:
        _invalid("更新项目须提供有效的当前版本 revision。")
    if "model" in payload:
        validate_model(payload["model"])
    if "name" in payload and not _text(payload["name"]):
        _invalid("项目名称须为 1–160 字的文字。")
    if "location" in payload and not _text(payload["location"], 240, empty=True):
        _invalid("项目位置须为不超过 240 字的文字。")
    if "status" in payload and payload["status"] not in ("active", "archived"):
        _invalid("项目状态须为 active 或 archived。")
    with _connection() as connection:
        connection.execute("BEGIN IMMEDIATE")
        current = _required_row(connection, project_id)
        if current["revision"] != payload["revision"]:
            raise HTTPException(409, detail={"reason": "revision_conflict", "message": "该项目已有更新。请重新打开最新版本后保存，当前修改不会覆盖库中内容。", "currentRevision": current["revision"]})
        model = payload.get("model")
        if model is not None or "name" in payload:
            model = model if model is not None else json.loads(current["model_json"])
            if "name" in payload:
                model["name"] = payload["name"].strip()
            name, model_json, summary_json = model["name"], _json(model), _json(_summary(model))
        else:
            name, model_json, summary_json = current["name"], current["model_json"], current["summary_json"]
        connection.execute("UPDATE projects SET name=?,location=?,status=?,revision=revision+1,updated_at=?,model_json=?,summary_json=? WHERE id=?",
                           (name, payload.get("location", current["location"]).strip(), payload.get("status", current["status"]), _now(), model_json, summary_json, project_id))
        connection.execute("UPDATE library_meta SET change_version=change_version+1 WHERE singleton=1")
        row = _required_row(connection, project_id)
        connection.commit()
        return _record(row)


def _reject_constant(value):
    raise ValueError("Non-finite JSON number")


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


async def _payload(request):
    if request.headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/json":
        raise HTTPException(415, detail="项目库保存须使用 application/json。")
    length = request.headers.get("content-length")
    if length:
        try:
            if int(length) > MAX_PROJECT_BODY_BYTES:
                raise HTTPException(413, detail="项目超过 50 MB，请减少或压缩巡检照片后保存。")
        except ValueError as exc:
            raise HTTPException(422, detail="请求长度无效。") from exc
    chunks, size = [], 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > MAX_PROJECT_BODY_BYTES:
            raise HTTPException(413, detail="项目超过 50 MB，请减少或压缩巡检照片后保存。")
        chunks.append(chunk)
    try:
        value = json.loads(b"".join(chunks), parse_constant=_reject_constant, object_pairs_hook=_unique_object)
    except (ValueError, UnicodeDecodeError, RecursionError) as exc:
        raise HTTPException(422, detail="项目 JSON 无效、存在重复字段或非有限数值。") from exc
    if not isinstance(value, dict):
        _invalid("项目库请求须为 JSON 对象。")
    return value


async def _store_call(function, *args):
    try:
        return await run_in_threadpool(function, *args)
    except (sqlite3.Error, OSError) as exc:
        raise HTTPException(503, detail="本地项目库暂时不可用，请检查磁盘空间与目录写入权限后重试。") from exc


@router.get("")
async def projects_list():
    return await _store_call(list_projects)


@router.post("", status_code=201)
async def projects_create(request: Request):
    return await _store_call(create_project, await _payload(request))


@router.get("/{project_id}")
async def projects_get(project_id: str):
    return await _store_call(get_project, project_id)


@router.put("/{project_id}")
async def projects_update(project_id: str, request: Request):
    return await _store_call(update_project, project_id, await _payload(request))
