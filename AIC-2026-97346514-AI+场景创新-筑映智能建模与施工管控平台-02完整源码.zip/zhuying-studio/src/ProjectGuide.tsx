import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, BookOpen, Camera, CheckCircle2, ChevronRight, Download, FolderOpen, Layers3, MousePointer2, PencilRuler, ScanLine, ShieldCheck, Sofa, View, X } from 'lucide-react';
import { activeWorkTypes, WORK_TYPES } from './progress.mjs';
import type { HouseModel, Room } from './types';
import './project-guide.css';

export type GuideAction = 'import' | 'structure' | 'design' | 'interior' | 'progress' | 'inspection' | 'timeline' | 'library' | 'facade-demo' | 'tools' | 'case';
interface Props { model: HouseModel; room: Room; onAction: (action: GuideAction) => void; onClose: () => void }
const STEPS = [
  { name: '建立空间', description: '图纸、尺度与结构', icon: ScanLine },
  { name: '设计你的家', description: '需求、材质与环视', icon: Sofa },
  { name: '记录施工', description: '工序、计划与巡检', icon: Camera },
  { name: '看见变化', description: '对比、回放与保存', icon: Layers3 },
];

export default function ProjectGuide({ model, room, onAction, onClose }: Props) {
  const [step, setStep] = useState(0);
  const dialog = useRef<HTMLElement>(null);
  const content = useRef<HTMLDivElement>(null);
  const returnFocus = useRef(document.activeElement instanceof HTMLElement ? document.activeElement : null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const demo = model.source === 'demo' || model.meta?.demoData === true;
  const active = activeWorkTypes(room);
  const records = (room.evidence ?? []).filter(evidence => evidence.confirmed);
  const compared = records.filter(evidence => evidence.comparison).length;
  const hasDesign = !!model.designBrief || model.furniture !== undefined;
  const hints = [
    demo ? `当前为示例户型，${model.rooms.length} 个空间可先体验；导入你的图纸后再核对实际尺度。` : `已建立 ${model.rooms.length} 个空间、${model.walls.length} 段墙体。识别结构仍需核对，已有模型不等于完成测绘。`,
    hasDesign ? `已保存家具方案，共 ${model.furniture?.length ?? 0} 件家具。可继续调整 ${room.name} 的材质、门窗与空间氛围。` : '目前尚未保存问答生成的家具方案。先确认房间用途，再把居住需求告诉设计助手。',
    `${room.name} 已启用 ${active.length} 项工序，保存 ${records.length} 次已确认巡检。${demo ? '此处包含示例施工数据，请用真实照片建立你的记录。' : records.length ? '下一次巡检可选择同工序的更早记录做对比。' : '第一组现场照片，会成为后续对比的起点。'}`,
    compared ? `${room.name} 已保存 ${compared} 组前后对比。可以从巡检详情查看照片，或在时间线回放历史状态。` : `${room.name} 尚未保存前后影像分析。${records.length > 1 ? '有多次巡检时，选择同工序的更早日期作为参照。' : '先留下不同日期的同工序照片，再查看施工变化。'}`,
  ];
  useEffect(() => {
    dialog.current?.focus({ preventScroll: true });
    const key = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); closeRef.current(); return; }
      if (event.key !== 'Tab') return;
      const nodes = Array.from(dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]') ?? []).filter(element => element.getClientRects().length);
      const first = nodes[0], last = nodes[nodes.length - 1];
      if (!first) { event.preventDefault(); return; }
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog.current)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialog.current)) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('keydown', key);
      queueMicrotask(() => { const element = returnFocus.current; if (element?.isConnected && !element.closest('[inert]')) element.focus({ preventScroll: true }); });
    };
  }, []);
  useEffect(() => { content.current?.scrollTo({ top: 0, behavior: 'instant' }); }, [step]);
  const Icon = STEPS[step].icon;
  return <div className="project-guide-backdrop"><section className="project-guide" role="dialog" aria-modal="true" aria-labelledby="project-guide-title" ref={dialog} tabIndex={-1}>
    <header className="project-guide-header"><div className="project-guide-heading"><span className="project-guide-mark"><BookOpen size={23} aria-hidden="true" /></span><div><span className="project-guide-eyebrow">筑映 / 使用指南</span><h2 id="project-guide-title">从图纸到现场，四步开始。</h2><p>每一步都能直接进入对应功能，随时回来继续。</p></div></div><button className="project-guide-close" aria-label="关闭使用指南" onClick={onClose}><X size={20} /></button></header>
    <div className="project-guide-body"><aside className="project-guide-route"><nav aria-label="使用指南步骤"><ol>{STEPS.map((item, index) => { const StepIcon = item.icon; return <li key={item.name}><button className={step === index ? 'current' : ''} aria-current={step === index ? 'step' : undefined} onClick={() => setStep(index)}><span className="project-guide-step-number">{String(index + 1).padStart(2, '0')}</span><span className="project-guide-step-name"><strong>{item.name}</strong><small>{item.description}</small></span><StepIcon size={16} aria-hidden="true" /></button></li>; })}</ol></nav><div className="project-guide-project"><div><span>当前项目</span><strong>{model.name}</strong><small>{demo ? '含示例数据' : '你的本地项目'}</small></div><svg viewBox={`-.3 -.3 ${model.width + .6} ${model.depth + .6}`} role="img" aria-label={`当前户型共 ${model.rooms.length} 个空间`}><title>当前户型空间轮廓</title>{model.rooms.map(item => <polygon key={item.id} points={item.polygon.map(point => point.join(',')).join(' ')} fill={item.id === room.id ? 'var(--selected)' : 'var(--surface)'} stroke="var(--accent)" strokeWidth=".055" />)}</svg><p>当前空间 · {room.name}</p></div></aside>
      <div className="project-guide-content" ref={content}><article aria-labelledby="project-guide-step-title"><div className="project-guide-step-heading" key={step}><span><Icon size={17} aria-hidden="true" />第 {step + 1} / 4 步</span><h3 id="project-guide-step-title">{step === 0 ? '先把空间，建立准确。' : step === 1 ? '再把生活方式，放进房间。' : step === 2 ? '每一次进展，都留下依据。' : '把今天与昨天，放在一起看。'}</h3></div>
        {step === 0 && <><p className="project-guide-intro">导入清晰户型图并确认实际尺度。配置千问后默认使用 AI 自主重建，也可切换辅助校正或本地识别；先对照原图预览结构与家具初稿，再采用模型继续设计。</p><ol className="project-guide-instructions"><li><span>1</span><div><strong>导入图纸，输入真实尺度</strong><p>点击“导入户型”，选择 PNG、JPG 或 WEBP，填写外墙中心线总宽度与房屋层高。尺寸用于确定模型比例，请按真实测量填写。</p></div></li><li><span>2</span><div><strong>预览房间、墙体和门窗</strong><p>识别完成后，先检查原图与模型预览、AI 调整和待核对提示。“采用模型并设计”将初稿保存为新项目；原项目继续保留。采用后可用“校正结构”编辑墙段坐标、门窗与房间轮廓。</p></div></li><li><span>3</span><div><strong>先校正，再继续设计</strong><p>结构与家具布局有关。移动墙体后，核对相邻房间轮廓，必要时重新生成家具方案。</p></div></li></ol><div className="project-guide-actions"><button className="button primary" onClick={() => onAction('import')}><ScanLine size={15} />导入我的户型<ArrowRight size={14} /></button><button className="button secondary" onClick={() => onAction('structure')}><PencilRuler size={15} />核对当前结构</button></div></>}
        {step === 1 && <><p className="project-guide-intro">先表达需求，再调整细节。设计助手会根据空间用途、居住人数与风格选择安排家具，你仍能逐个空间修改方案。</p><ol className="project-guide-instructions"><li><span>1</span><div><strong>完成设计问答，生成家具</strong><p>确认每个房间的用途、需要的家具、居住需求与风格。问答建议需要你核对；配置千问后可用自然语言整理需求，未配置时仍可手动选择。</p></div></li><li><span>2</span><div><strong>单击房间，编辑材质和门窗</strong><p>选择三维模型中的房间或左侧空间列表，在右侧“材质设计”修改地板、墙面；“门窗编辑”调整样式、颜色与开启效果。</p></div></li><li><span>3</span><div><strong>双击房间，进入 360° 环视</strong><p>也可使用“进入房间环视”按钮。进入后拖动查看周围；聚焦模型后可用方向键环视，按 Esc 或“返回整屋”退出。</p></div></li></ol><div className="project-guide-interaction-note"><MousePointer2 size={16} aria-hidden="true" /><span>整屋：拖动旋转、滚轮缩放 · 室内：拖动或方向键环视</span></div><div className="project-guide-actions"><button className="button primary" onClick={() => onAction('design')}><Sofa size={15} />开始设计问答<ArrowRight size={14} /></button><button className="button secondary" onClick={() => onAction('interior')}><View size={15} />进入 {room.name} 环视</button></div></>}
        {step === 2 && <><p className="project-guide-intro">进入“施工记录”，按房间跟踪真实工序。状态来自人工确认的现场证据，而不是模型自动推测整间房的工程量。</p><div className="project-guide-trades" aria-label="可跟踪的六项工序">{WORK_TYPES.map(work => <span key={work.id}>{work.shortLabel}</span>)}</div><ol className="project-guide-instructions"><li><span>1</span><div><strong>启用工序，填写计划日期</strong><p>只开启这个房间实际需要跟踪的工序，再设置计划完成日期。尚未核对的状态会保留为“待复核”。</p></div></li><li><span>2</span><div><strong>每次巡检，拍摄 1–6 张照片</strong><p>同一房间、同一工序可记录全景、门口、窗侧与细节。填写真实巡检日期，补充视角标签；标签用于整理照片，不代表测量坐标。</p></div></li><li><span>3</span><div><strong>核对建议，由你确认状态</strong><p>点击“联合分析”才会提交照片；配置视觉模型后得到逐张观察与状态建议，无密钥时使用人工确认。检查照片覆盖情况后保存，“外观完成”不等于质量验收通过。</p></div></li></ol><div className="project-guide-actions"><button className="button primary" onClick={() => onAction('progress')}><Layers3 size={15} />设置工序与计划<ArrowRight size={14} /></button><button className="button secondary" onClick={() => onAction('inspection')}><Camera size={15} />记录一次巡检</button></div></>}
        {step === 3 && <><p className="project-guide-intro">从多次巡检中查看变化，及时处理计划偏差。照片、确认记录和设计方案共同保留在项目里。</p><ol className="project-guide-instructions"><li><span>1</span><div><strong>打开巡检详情，看前后照片</strong><p>在“施工记录”中点击巡检照片或“详情”，选择同房间、同工序的更早记录，分别切换拍摄角度。添加新巡检时，也可选择此前照片进行影像对比分析。</p></div></li><li><span>2</span><div><strong>打开时间线，回放历史状态</strong><p>选择一个历史日期，查看截至当天已确认的工序记录与空间状态。缺少照片的工序保持待核对，不把今天的状态倒填到过去。</p></div></li><li><span>3</span><div><strong>管理多个项目，保留施工记录</strong><p>点击顶部“项目库”，集中查看多套房子的工序完成情况、待核对状态与计划告警。每套模型、家具和巡检照片独立保存，可切换、复制或归档恢复。</p></div></li></ol><div className="project-guide-save-note"><Download size={17} aria-hidden="true" /><div><strong>自动保存之后，也留一份备份。</strong><p>先将当前模型保存到项目库，后续修改会自动保存，状态见顶部。导入新户型会新建独立项目。重要节点再用“导出项目”保留完整 JSON 备份。</p></div></div><div className="project-guide-actions"><button className="button primary" onClick={() => onAction('timeline')}><Layers3 size={15} />打开时间线回放<ArrowRight size={14} /></button><button className="button secondary" onClick={() => onAction('library')}><FolderOpen size={15} />打开项目库</button></div></>}
        <button className="project-guide-facade-entry button secondary" onClick={()=>onAction('facade-demo')}><Camera size={15}/>体验真实影像的施工监控样例<ArrowRight size={14}/></button>
        <button className="project-guide-facade-entry button secondary" onClick={()=>onAction('case')}><Camera size={15}/>没有现场项目？从真实室内案例开始<ArrowRight size={14}/></button>
        <button className="project-guide-facade-entry button secondary" onClick={()=>onAction('tools')}><PencilRuler size={15}/>整改、材料预算、尺寸复核与周报<ArrowRight size={14}/></button>
        <div className={`project-guide-current ${demo ? 'is-demo' : ''}`} role="status"><CheckCircle2 size={16} aria-hidden="true" /><div><strong>{demo ? '示例项目 · 可先体验操作' : '当前项目进展'}</strong><p>{hints[step]}</p></div></div>
      </article></div>
    </div>
    <footer className="project-guide-footer"><span><ShieldCheck size={13} aria-hidden="true" />可随时从左侧“使用指南”重新打开</span><div><button className="button secondary" disabled={step === 0} onClick={() => setStep(current => current - 1)}><ArrowLeft size={14} />上一步</button>{step < 3 ? <button className="button secondary" onClick={() => setStep(current => current + 1)}>下一步<ChevronRight size={15} /></button> : <button className="button primary" onClick={onClose}>明白了，开始使用<ArrowRight size={14} /></button>}</div></footer>
  </section></div>;
}
