import { Check, RotateCcw, ArrowRight, ArrowDown, CheckCircle2 } from 'lucide-react';
import { FLOOR_FINISHES, WALL_COLORS, resolveRoomDesign } from './design.mjs';
import type { Room, RoomDesign } from './types';
import './room-design.css';

interface Props {
  room: Room;
  onChange: (patch: Partial<RoomDesign>) => void;
  onReset: () => void;
}

export default function RoomDesignPanel({ room, onChange, onReset }: Props) {
  const design = resolveRoomDesign(room);
  const floor = FLOOR_FINISHES.find(f => f.id === design.floorFinish)!;
  const wall = WALL_COLORS.find(c => c.color.toLowerCase() === design.wallColor.toLowerCase());
  return <div className="room-design-panel">
    <section className="design-section">
      <div className="design-section-heading"><h3>地板材质</h3><span>{floor.label}</span></div>
      <div className="finish-grid" aria-label="地板材质">
        {FLOOR_FINISHES.map(f => <button key={f.id} className={`finish-option ${design.floorFinish === f.id ? 'chosen' : ''}`} title={f.description} aria-pressed={design.floorFinish === f.id} aria-label={`选择${f.label}地板`} onClick={() => onChange({ floorFinish: f.id })}>
          <span className={`finish-sample finish-${f.id}`} aria-hidden="true">{design.floorFinish === f.id && <span className="swatch-check"><Check size={12}/></span>}</span>
          <strong>{f.label}</strong>
        </button>)}
      </div>
      <div className="direction-row"><span>铺设方向</span><div className="direction-buttons"><button aria-label="横向铺设" aria-pressed={design.floorDirection === 0} className={design.floorDirection === 0 ? 'active' : ''} onClick={() => onChange({ floorDirection: 0 })}><ArrowRight size={13}/>横向</button><button aria-label="纵向铺设" aria-pressed={design.floorDirection === 90} className={design.floorDirection === 90 ? 'active' : ''} onClick={() => onChange({ floorDirection: 90 })}><ArrowDown size={13}/>纵向</button></div></div>
    </section>
    <section className="design-section">
      <div className="design-section-heading"><h3>墙面色彩</h3><span>{wall?.label ?? '自定义'}</span></div>
      <div className="wall-color-grid" aria-label="墙面色彩">
        {WALL_COLORS.map(c => <button key={c.id} className={`wall-color-option ${design.wallColor.toLowerCase() === c.color.toLowerCase() ? 'chosen' : ''}`} aria-label={`墙面颜色${c.label}`} aria-pressed={design.wallColor.toLowerCase() === c.color.toLowerCase()} onClick={() => onChange({ wallColor: c.color })}>
          <span style={{ background: c.color }} aria-hidden="true">{design.wallColor.toLowerCase() === c.color.toLowerCase() && <Check size={16}/>}</span><small>{c.label}</small>
        </button>)}
      </div>
      <label className="custom-color"><span>自定义颜色</span><span className="color-code">{design.wallColor.toUpperCase()}</span><input type="color" value={design.wallColor} aria-label="自定义墙面颜色" onChange={e => onChange({ wallColor: e.target.value })}/></label>
      <div className="direction-row"><span>墙面质感</span><div className="direction-buttons"><button aria-pressed={design.wallFinish === 'paint'} className={design.wallFinish === 'paint' ? 'active' : ''} onClick={() => onChange({ wallFinish: 'paint' })}>哑光乳胶漆</button><button aria-pressed={design.wallFinish === 'plaster'} className={design.wallFinish === 'plaster' ? 'active' : ''} onClick={() => onChange({ wallFinish: 'plaster' })}>细纹灰泥</button></div></div>
    </section>
    <div className="design-saved"><CheckCircle2 size={13}/><span>即时预览</span><button disabled={!room.design} onClick={onReset} title="恢复当前房间的默认材质"><RotateCcw size={12}/>恢复默认</button></div>
    <details className="design-help"><summary>设计与施工的区别</summary><p>材质调整只影响设计预览。真实进度请切换施工记录，添加巡检并确认。</p></details>
  </div>;
}
