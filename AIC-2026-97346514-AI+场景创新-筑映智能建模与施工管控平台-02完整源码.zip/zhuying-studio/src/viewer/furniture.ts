import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { makeFabricTexture, makeFloorTexture } from './finishes';
import type { FurnitureItem } from '../types';

const NAMES: Record<FurnitureItem['kind'], string> = {
  sofa: '沙发', coffee_table: '茶几', tv_console: '电视柜', bed_double: '双人床', bed_single: '单人床',
  wardrobe: '衣柜', desk: '书桌', chair: '座椅', dining_table: '餐桌', kitchen_counter: '厨房操作台',
  sink_cabinet: '洗手台', toilet: '坐便器', shoe_cabinet: '玄关柜',
};

/** Create real meshes in the item's local footprint; height includes the details. */
export function createFurniture(item: FurnitureItem) {
  const group = new THREE.Group(); group.name = `${NAMES[item.kind]} · ${item.id}`;
  group.position.set(item.position[0], 0.033, item.position[1]); group.rotation.y = item.rotation;
  const data = { furnitureId: item.id, roomId: item.roomId, kind: 'furniture', furnitureKind: item.kind };
  group.userData = { ...data, size: [...item.size], color: item.color };
  const [W, H, D] = item.size;
  const metal = new THREE.MeshStandardMaterial({ color: '#595f57', metalness: 0.58, roughness: 0.4 });
  const body = new THREE.MeshStandardMaterial({ color: item.color, roughness: 0.68 });
  let timber: THREE.MeshStandardMaterial | null = null;
  let textile: THREE.MeshStandardMaterial | null = null;
  let linen: THREE.MeshStandardMaterial | null = null;
  const wood = () => timber ??= new THREE.MeshStandardMaterial({ color: item.color, map: makeFloorTexture('oak', 0), roughness: 0.69 });
  const fabric = () => textile ??= new THREE.MeshStandardMaterial({ color: '#ffffff', map: makeFabricTexture(item.color), roughness: 0.98 });
  const white = () => linen ??= new THREE.MeshStandardMaterial({ color: '#fffaf0', map: makeFabricTexture('#eae8de'), roughness: 0.98 });
  const used = new Set<THREE.Material>();
  const add = (geometry: THREE.BufferGeometry, position: [number, number, number], material: THREE.Material, label: string) => {
    const mesh = new THREE.Mesh(geometry, material); mesh.position.set(...position);
    mesh.castShadow = true; mesh.receiveShadow = true; mesh.name = `${item.id} · ${label}`;
    mesh.userData = { ...data }; used.add(material); group.add(mesh); return mesh;
  };
  const box = (size: [number, number, number], position: [number, number, number], material: THREE.Material, label: string, rounded = false) => {
    const geometry = rounded ? new RoundedBoxGeometry(...size, 3, Math.min(...size) * 0.17) : new THREE.BoxGeometry(...size);
    return add(geometry, position, material, label);
  };
  const rod = (start: [number, number, number], end: [number, number, number], radius: number, material: THREE.Material, label: string) => {
    const a = new THREE.Vector3(...start), b = new THREE.Vector3(...end), direction = b.clone().sub(a);
    const mesh = add(new THREE.CylinderGeometry(radius, radius, direction.length(), 10), a.clone().add(b).multiplyScalar(0.5).toArray() as [number, number, number], material, label);
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize()); return mesh;
  };
  const legs = (top: number, radius = Math.min(W, H, D) * 0.026) => {
    for (const x of [-W * 0.37, W * 0.37]) for (const z of [-D * 0.34, D * 0.34]) rod([x, H * 0.03, z], [x * 0.9, top, z * 0.9], radius, metal, '细腿');
  };
  const doors = (height: number, bottom: number, count: number, material: THREE.Material) => {
    // The layout uses local +Z as the furniture's front, facing into the room.
    const width = W * 0.96 / count;
    for (let i = 0; i < count; i++) {
      const x = -W * 0.48 + width * (i + 0.5);
      box([width * 0.985, height, D * 0.019], [x, bottom + height / 2, D * 0.475], material, '柜门', true);
      box([Math.min(W * 0.012, width * 0.04), Math.min(height * 0.27, H * 0.2), D * 0.015], [x + width * 0.32, bottom + height * 0.57, D * 0.491], metal, '嵌入式拉手', true);
    }
  };
  switch (item.kind) {
    case 'sofa': {
      legs(H * 0.13, Math.min(W, H, D) * 0.022);
      box([W * 0.96, H * 0.22, D * 0.94], [0, H * 0.23, 0], body, '底座', true);
      box([W * 0.96, H * 0.62, D * 0.12], [0, H * 0.67, -D * 0.43], fabric(), '软包靠背', true);
      for (const side of [-1, 1]) box([W * 0.105, H * 0.56, D * 0.94], [side * W * 0.4375, H * 0.44, 0], fabric(), '软包扶手', true);
      const count = Math.max(2, Math.min(4, Math.round(W / 0.85))), span = W * 0.79 / count;
      for (let i = 0; i < count; i++) {
        const x = -W * 0.395 + span * (i + 0.5);
        box([span * 0.965, H * 0.14, D * 0.72], [x, H * 0.42, D * 0.01], fabric(), '独立坐垫', true);
        box([span * 0.96, H * 0.39, D * 0.14], [x, H * 0.69, -D * 0.335], fabric(), '独立背垫', true);
      }
      for (const side of [-1, 1]) box([W * 0.14, H * 0.25, D * 0.14], [side * W * 0.29, H * 0.64, -D * 0.18], white(), '靠枕', true);
      break;
    }
    case 'bed_double': case 'bed_single': {
      box([W * 0.96, H * 0.25, D * 0.95], [0, H * 0.19, 0], wood(), '床架', true);
      box([W * 0.91, H * 0.19, D * 0.89], [0, H * 0.44, D * 0.015], white(), '床垫', true);
      box([W * 0.96, H * 0.82, D * 0.055], [0, H * 0.59, -D * 0.4575], fabric(), '软包床头', true);
      const panels = item.kind === 'bed_single' ? 4 : 6;
      for (let i = 1; i < panels; i++) box([W * 0.006, H * 0.69, D * 0.004], [-W * 0.48 + W * 0.96 * i / panels, H * 0.60, -D * 0.427], white(), '床头缝线');
      box([W * 0.94, H * 0.12, D * 0.62], [0, H * 0.59, D * 0.12], fabric(), '被子', true);
      for (const side of [-1, 1]) box([W * 0.032, H * 0.25, D * 0.6], [side * W * 0.465, H * 0.465, D * 0.12], fabric(), '被沿垂边', true);
      box([W * 0.93, H * 0.045, D * 0.18], [0, H * 0.672, D * 0.31], white(), '床尾搭毯', true);
      const pillows = item.kind === 'bed_single' ? 1 : 2;
      for (let i = 0; i < pillows; i++) {
        const x = pillows === 1 ? 0 : (i === 0 ? -1 : 1) * W * 0.22;
        box([W * (pillows === 1 ? 0.68 : 0.38), H * 0.11, D * 0.2], [x, H * 0.62, -D * 0.28], white(), '枕头', true);
        box([W * (pillows === 1 ? 0.43 : 0.24), H * 0.09, D * 0.11], [x, H * 0.7, -D * 0.22], fabric(), '装饰枕', true);
      }
      break;
    }
    case 'coffee_table': case 'dining_table': case 'desk': {
      const top = item.kind === 'coffee_table' ? H * 0.9 : H * 0.955;
      legs(top - H * 0.045);
      box([W * 0.98, H * 0.09, D * 0.98], [0, top, 0], wood(), '圆角台面', true);
      if (item.kind === 'coffee_table') {
        box([W * 0.73, H * 0.055, D * 0.74], [0, H * 0.24, 0], body, '下层置物板', true);
        box([W * 0.23, H * 0.03, D * 0.35], [-W * 0.2, H * 0.96, 0], white(), '桌面书册', true);
        box([W * 0.18, H * 0.02, D * 0.3], [-W * 0.19, H * 0.985, D * 0.01], fabric(), '书册封面', true);
      }
      if (item.kind === 'desk') {
        box([W * 0.24, H * 0.62, D * 0.7], [W * 0.26, H * 0.59, 0], body, '抽屉柜', true);
        for (const y of [H * 0.42, H * 0.64, H * 0.82]) box([W * 0.15, H * 0.009, D * 0.008], [W * 0.26, y, D * 0.356], metal, '抽屉缝');
      }
      break;
    }
    case 'chair': {
      legs(H * 0.46);
      box([W * 0.9, H * 0.09, D * 0.86], [0, H * 0.49, D * 0.015], fabric(), '软包坐面', true);
      box([W * 0.92, H * 0.45, D * 0.10], [0, H * 0.76, -D * 0.438], fabric(), '圆角椅背', true);
      for (const x of [-W * 0.36, W * 0.36]) rod([x, H * 0.41, -D * 0.37], [x, H * 0.86, -D * 0.38], Math.min(W, H, D) * 0.019, metal, '椅背支撑');
      break;
    }
    case 'wardrobe': {
      box([W * 0.98, H * 0.96, D * 0.9], [0, H * 0.51, D * 0.02], body, '柜体');
      box([W * 0.94, H * 0.025, D * 0.86], [0, H * 0.028, D * 0.02], metal, '踢脚底座');
      doors(H * 0.9, H * 0.055, Math.max(2, Math.min(6, Math.ceil(W / 0.65))), wood());
      break;
    }
    case 'shoe_cabinet': case 'kitchen_counter': case 'sink_cabinet': {
      const sink = item.kind === 'sink_cabinet';
      const cabinetTop = sink ? H * 0.79 : H * 0.94;
      box([W * 0.96, cabinetTop - H * 0.08, D * 0.9], [0, (cabinetTop + H * 0.08) / 2, D * 0.01], body, '柜体');
      box([W * 0.93, H * 0.06, D * 0.82], [0, H * 0.04, D * 0.02], metal, '踢脚底座');
      doors(cabinetTop - H * 0.13, H * 0.1, Math.max(1, Math.min(5, Math.round(W / 0.55))), body);
      box([W * 0.995, H * 0.045, D * 0.995], [0, cabinetTop + H * 0.026, 0], item.kind === 'shoe_cabinet' ? wood() : white(), '台面', true);
      if (sink) {
        box([W * 0.5, H * 0.018, D * 0.56], [0, H * 0.822, -D * 0.035], metal, '盆内阴影', true);
        const basin = new THREE.MeshStandardMaterial({ color: '#f4f2e9', roughness: 0.32 });
        for (const side of [-1, 1]) box([W * 0.035, H * 0.025, D * 0.61], [side * W * 0.267, H * 0.83, -D * 0.035], basin, '盆边', true);
        for (const side of [-1, 1]) box([W * 0.565, H * 0.025, D * 0.025], [0, H * 0.83, -D * 0.035 + side * D * 0.297], basin, '盆边', true);
        rod([0, H * 0.82, -D * 0.32], [0, H * 0.972, -D * 0.32], Math.min(W, H, D) * 0.015, metal, '龙头');
        rod([0, H * 0.972, -D * 0.32], [0, H * 0.972, -D * 0.20], Math.min(W, H, D) * 0.015, metal, '出水口');
      }
      break;
    }
    case 'tv_console': {
      const tall = H >= 0.9, cabinetTop = tall ? H * 0.36 : H * 0.94;
      box([W * 0.97, cabinetTop - H * 0.08, D * 0.92], [0, (cabinetTop + H * 0.08) / 2, D * 0.01], wood(), '电视柜体', true);
      doors(cabinetTop - H * 0.11, H * 0.085, Math.max(2, Math.min(5, Math.round(W / 0.55))), body);
      for (const x of [-W * 0.38, W * 0.38]) box([W * 0.025, H * 0.085, D * 0.7], [x, H * 0.043, 0], metal, '柜脚');
      if (tall) {
        const screen = new THREE.MeshStandardMaterial({ color: '#25362d', metalness: 0.25, roughness: 0.27 });
        box([W * 0.8, H * 0.5, D * 0.07], [0, H * 0.735, D * 0.15], metal, '电视边框', true);
        box([W * 0.765, H * 0.464, D * 0.01], [0, H * 0.735, D * 0.191], screen, '屏幕', true);
        box([W * 0.025, H * 0.18, D * 0.075], [0, H * 0.43, D * 0.15], metal, '屏幕支架');
        box([W * 0.24, H * 0.019, D * 0.26], [0, H * 0.371, D * 0.15], metal, '屏幕底座', true);
      }
      break;
    }
    case 'toilet': {
      const porcelain = new THREE.MeshStandardMaterial({ color: item.color, roughness: 0.27 });
      box([W * 0.77, H * 0.62, D * 0.24], [0, H * 0.68, -D * 0.29], porcelain, '水箱', true);
      const bowl = add(new THREE.SphereGeometry(1, 28, 18), [0, H * 0.43, D * 0.11], porcelain, '坐便器盆');
      bowl.scale.set(W * 0.43, H * 0.2, D * 0.34);
      box([W * 0.48, H * 0.31, D * 0.52], [0, H * 0.2, D * 0.07], porcelain, '底座', true);
      const seat = add(new THREE.TorusGeometry(1, 0.11, 8, 32), [0, H * 0.615, D * 0.11], body, '坐圈');
      seat.rotation.x = Math.PI / 2; seat.scale.set(W * 0.31, D * 0.29, H * 0.025);
      box([W * 0.2, H * 0.014, D * 0.07], [0, H * 0.989, -D * 0.29], metal, '冲水按钮', true);
      break;
    }
  }
  for (const material of [metal, body, timber, textile, linen]) if (material && !used.has(material)) material.dispose();
  return group;
}

export function createFurnitureCollection(items: FurnitureItem[]) {
  const group = new THREE.Group(); group.name = '按户型配置的家具';
  for (const item of items) group.add(createFurniture(item));
  return group;
}
