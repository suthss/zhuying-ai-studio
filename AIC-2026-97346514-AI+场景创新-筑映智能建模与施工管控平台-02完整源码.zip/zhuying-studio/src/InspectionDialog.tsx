import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight, Camera, Check, CheckCircle2, ChevronDown, Clock3, Images, LoaderCircle, ScanLine, ShieldCheck, Trash2, Upload, X } from 'lucide-react';
import { WORK_TYPES, stageLabel } from './progress.mjs';
import type { Evidence, HouseModel, Room, Stage, WorkType } from './types';
import './inspection.css';

interface Props {
  model: HouseModel;
  room: Room;
  aiConfigured: boolean;
  today: string;
  onSave: (evidence: Evidence) => void;
  onClose: () => void;
}
type InspectionPhoto = { id: string; image: string; viewpoint: string };
type DraftPhoto = InspectionPhoto & { blob: Blob; originalBytes: number; fingerprint: string };
type Observation = { photoIndex: number; summary: string };
type ComparisonChange = 'advanced' | 'unchanged' | 'regressed' | 'uncertain';
type Suggestion = { stage: Stage; summary: string; source: string; observations: Observation[]; comparison?: { summary: string; change: ComparisonChange } };
const STAGES: Stage[] = ['unknown', 'not_started', 'in_progress', 'complete'];
const CHANGE_LABELS: Record<ComparisonChange, string> = { advanced: '可见进展', unchanged: '未见明显变化', regressed: '可见回退', uncertain: '暂无法比较' };
const FILE_BYTES = 10 * 1024 * 1024;
const TOTAL_BYTES = 30 * 1024 * 1024;

function validDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function validAnalysisText(value: unknown): value is string { return typeof value === 'string' && value.trim().length > 0 && value.length <= 2000; }
function imageData(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('照片读取失败，请重新选择完整图片。'));
    reader.readAsDataURL(blob);
  });
}
function imageBlob(image: string): Blob {
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(image);
  if (!match) throw new Error('此前巡检照片格式无效，请更换对比记录。');
  const bytes = Uint8Array.from(atob(match[2]), character => character.charCodeAt(0));
  return new Blob([bytes], { type: match[1] });
}
async function preparePhoto(file: File, fingerprint: string): Promise<DraftPhoto> {
  let bitmap: ImageBitmap;
  try { bitmap = await createImageBitmap(file); } catch { throw new Error(`无法读取「${file.name}」，请使用完整的 PNG、JPG 或 WEBP 图片。`); }
  try {
    if (!bitmap.width || !bitmap.height || bitmap.width * bitmap.height > 60_000_000) throw new Error(`「${file.name}」尺寸过大，请先缩小图片。`);
    const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext('2d');
    if (!context) throw new Error('浏览器无法处理照片，请重试。');
    context.fillStyle = '#fff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(value => value ? resolve(value) : reject(new Error('照片压缩失败，请重新选择。')), 'image/jpeg', .88));
    return { id: crypto.randomUUID(), image: await imageData(blob), viewpoint: '', blob, originalBytes: file.size, fingerprint };
  } finally { bitmap.close(); }
}
function evidencePhotos(evidence: Evidence): InspectionPhoto[] {
  return evidence.photos?.length ? evidence.photos : [{ id: evidence.id, image: evidence.image, viewpoint: '此前记录' }];
}

export default function InspectionDialog({ model, room, aiConfigured, today, onSave, onClose }: Props) {
  const enabledTypes = WORK_TYPES.filter(({ id }) => room.tasks[id] && room.tasks[id]?.enabled !== false).map(({ id }) => id);
  const [workType, setWorkType] = useState<WorkType>(() => enabledTypes[0] ?? 'floor');
  const [date, setDate] = useState(today);
  const [photos, setPhotos] = useState<DraftPhoto[]>([]);
  const [previousId, setPreviousId] = useState('');
  const [stage, setStage] = useState<Stage>('unknown');
  const [notes, setNotes] = useState('');
  const [coverageReviewed, setCoverageReviewed] = useState(false);
  const [suggestion, setSuggestion] = useState<Suggestion | null>(null);
  const [busy, setBusy] = useState<'photos' | 'analysis' | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const dialog = useRef<HTMLElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const returnFocus = useRef(document.activeElement instanceof HTMLElement ? document.activeElement : null);
  const mounted = useRef(false);
  const busyRef = useRef<typeof busy>(null);
  const closeRef = useRef(onClose);
  const request = useRef<AbortController | null>(null);
  const processing = useRef(false);
  closeRef.current = onClose;
  busyRef.current = busy;
  const earlier = useMemo(() => (room.evidence ?? []).filter(evidence => evidence.confirmed && evidence.workType === workType && validDate(evidence.date) && validDate(date) && evidence.date < date).slice().sort((a, b) => b.date.localeCompare(a.date)), [room.evidence, workType, date]);
  const previous = earlier.find(evidence => evidence.id === previousId);
  const dateError = !validDate(date) ? '请填写有效的巡检日期。' : date > today ? '巡检日期不能晚于今天。' : '';
  const canSave = photos.length > 0 && enabledTypes.includes(workType) && validDate(date) && date <= today && (stage !== 'complete' || coverageReviewed) && !busy;

  useEffect(() => {
    mounted.current = true;
    dialog.current?.focus({ preventScroll: true });
    const keyboard = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); if (!busyRef.current) closeRef.current(); return; }
      if (event.key !== 'Tab') return;
      const nodes = Array.from(dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled):not([type="file"]),select:not(:disabled),textarea:not(:disabled),[tabindex="0"]') ?? []).filter(element => element.getClientRects().length);
      const first = nodes[0], last = nodes[nodes.length - 1];
      if (!first) { event.preventDefault(); return; }
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog.current)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialog.current)) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', keyboard);
    return () => {
      mounted.current = false;
      request.current?.abort();
      document.removeEventListener('keydown', keyboard);
      queueMicrotask(() => { const element = returnFocus.current; if (element?.isConnected && !element.closest('[inert]')) element.focus({ preventScroll: true }); });
    };
  }, []);
  function invalidate() { setSuggestion(null); setStage('unknown'); setCoverageReviewed(false); setError(''); setNotice(''); }
  async function addPhotos(files: File[]) {
    if (!files.length || busyRef.current || processing.current) return;
    processing.current = true;
    setBusy('photos'); setError(''); setNotice('');
    try {
      if (files.some(file => !['image/png', 'image/jpeg', 'image/webp'].includes(file.type))) throw new Error('请选择 PNG、JPG 或 WEBP 照片。');
      if (files.some(file => file.size > FILE_BYTES)) throw new Error('单张照片不能超过 10 MB，请缩小后重新选择。');
      if (files.reduce((total, file) => total + file.size, 0) > TOTAL_BYTES) throw new Error('本批照片超过 30 MB，请减少照片或缩小图片。');
      const known = new Set(photos.map(photo => photo.fingerprint));
      const unique: { file: File; fingerprint: string }[] = [];
      let duplicates = 0;
      for (const file of files) {
        const fingerprint = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await file.arrayBuffer()))).map(value => value.toString(16).padStart(2, '0')).join('');
        if (known.has(fingerprint)) { duplicates++; continue; }
        known.add(fingerprint); unique.push({ file, fingerprint });
      }
      if (photos.length + unique.length > 6) throw new Error('一次巡检最多 6 张照片，请减少选择或先删除现有照片。');
      if (photos.reduce((total, photo) => total + photo.originalBytes, 0) + unique.reduce((total, item) => total + item.file.size, 0) > TOTAL_BYTES) throw new Error('本次巡检照片总量不能超过 30 MB，请减少照片或缩小图片。');
      const prepared: DraftPhoto[] = [];
      for (const item of unique) prepared.push(await preparePhoto(item.file, item.fingerprint));
      if (!mounted.current) return;
      if (prepared.length) { invalidate(); setPhotos(current => [...current, ...prepared]); }
      if (duplicates) setNotice(`已跳过 ${duplicates} 张重复照片。`);
    } catch (cause) { if (mounted.current) setError(cause instanceof Error ? cause.message : '照片处理失败，请重试。'); }
    finally { processing.current = false; if (mounted.current) setBusy(null); }
  }
  async function analyze() {
    if (!photos.length || busy || !enabledTypes.includes(workType)) return;
    if (!validDate(date) || date > today) { setError('请填写有效且不晚于今天的巡检日期。'); return; }
    setBusy('analysis'); setError(''); setNotice(''); setSuggestion(null); setStage('unknown'); setCoverageReviewed(false);
    const controller = new AbortController(); request.current = controller;
    const timeout = setTimeout(() => controller.abort(), 90_000);
    try {
      const form = new FormData();
      photos.forEach((photo, index) => form.append('files', photo.blob, `inspection-${index + 1}.jpg`));
      form.append('room_name', room.name); form.append('work_type', workType); form.append('date', date);
      let uploadBytes = photos.reduce((total, photo) => total + photo.blob.size, 0);
      if (previous) {
        const previousPhotos = evidencePhotos(previous).slice(0, 6);
        for (let index = 0; index < previousPhotos.length; index++) {
          const blob = imageBlob(previousPhotos[index].image);
          const prepared = await preparePhoto(new File([blob], `previous-${index + 1}.jpg`, { type: blob.type }), 'previous');
          if (!mounted.current || controller.signal.aborted) return;
          uploadBytes += prepared.blob.size;
          form.append('previous_files', prepared.blob, `previous-${index + 1}.jpg`);
        }
        form.append('previous_date', previous.date); form.append('previous_stage', previous.stage);
      }
      if (uploadBytes > TOTAL_BYTES) throw new Error('当前与此前照片合计超过 30 MB，请减少照片或更换对比记录。');
      const response = await fetch('/api/analyze-inspection', { method: 'POST', body: form, signal: controller.signal });
      const data = await response.json();
      if (!response.ok) throw new Error(typeof data?.detail === 'string' ? data.detail : '分析未完成，请重试或手动确认巡检。');
      if (!data || typeof data !== 'object' || Array.isArray(data) || !STAGES.includes(data.stage) || !validAnalysisText(data.summary) || data.needsReview !== true || typeof data.source !== 'string' || data.source.length > 160 || !(data.source === 'manual_review' || data.source === 'qwen' || data.source.startsWith('qwen/'))) throw new Error('分析返回的状态无效，可以重试或继续人工确认巡检。');
      const seen = new Set<number>();
      if (!Array.isArray(data.observations) || data.observations.length !== photos.length || !data.observations.every((item: unknown) => {
        if (!item || typeof item !== 'object' || Array.isArray(item)) return false;
        const observation = item as Observation;
        if (!Number.isInteger(observation.photoIndex) || observation.photoIndex < 0 || observation.photoIndex >= photos.length || seen.has(observation.photoIndex) || !validAnalysisText(observation.summary)) return false;
        seen.add(observation.photoIndex); return true;
      })) throw new Error('分析未完整对应每张当前照片，可以重试或继续人工确认巡检。');
      const observations = (data.observations as Observation[]).map(item => ({ photoIndex: item.photoIndex, summary: item.summary.trim() })).sort((a, b) => a.photoIndex - b.photoIndex);
      if (previous && (!data.comparison || typeof data.comparison !== 'object' || Array.isArray(data.comparison) || !validAnalysisText(data.comparison.summary) || !['advanced', 'unchanged', 'regressed', 'uncertain'].includes(data.comparison.change))) throw new Error('分析未返回有效的前后对比，可以重试或继续人工确认巡检。');
      const comparison = previous ? { summary: data.comparison.summary.trim(), change: data.comparison.change as ComparisonChange } : undefined;
      if (!mounted.current || controller.signal.aborted) return;
      setSuggestion({ stage: data.stage, summary: data.summary.trim(), source: data.source, observations, ...(comparison ? { comparison } : {}) });
      setStage(data.stage);
      if (data.source === 'manual_review') setNotice('当前使用人工确认模式，未进行 AI 视觉判断。请核对照片后选择可见状态。');
    } catch (cause) { if (mounted.current) setError(controller.signal.aborted ? '分析超时，请重试或手动确认巡检。' : cause instanceof Error ? cause.message : '分析服务无法连接，可以手动确认巡检。'); }
    finally { clearTimeout(timeout); if (request.current === controller) request.current = null; if (mounted.current) setBusy(null); }
  }
  function save() {
    if (!canSave) { setError('请至少添加一张照片，核对工序、日期与可见状态后保存。'); return; }
    const evidence: Evidence = {
      id: crypto.randomUUID(), date, image: photos[0].image,
      photos: photos.map(({ id, image, viewpoint }, index) => ({ id, image, viewpoint: viewpoint.trim() || `角度 ${index + 1}` })),
      workType, stage, summary: notes.trim() || suggestion?.summary || '人工核对多角度照片并记录可见施工状态。', confirmed: true,
      source: suggestion?.source ?? 'manual',
      ...(suggestion ? { aiStage: suggestion.stage, observations: suggestion.observations } : {}),
      ...(previous && suggestion?.comparison ? { comparison: { previousEvidenceId: previous.id, previousDate: previous.date, summary: suggestion.comparison.summary, change: suggestion.comparison.change, source: suggestion.source } } : {}),
    };
    try { onSave(evidence); onClose(); } catch (cause) { setError(cause instanceof Error ? cause.message : '巡检保存失败，请核对记录后重试。'); }
  }
  return <div className="inspection-overlay"><section className="inspection-dialog" ref={dialog} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="inspection-title" aria-busy={!!busy}>
    <header className="inspection-header"><div className="inspection-heading"><span className="inspection-mark"><Camera size={22} aria-hidden="true" /></span><div><span className="inspection-eyebrow">现场巡检 / {model.name}</span><h2 id="inspection-title">让进展，有迹可循。</h2><p>{room.name} · 多角度记录，逐工序确认</p></div></div><button className="inspection-close" aria-label="关闭巡检记录" disabled={!!busy} onClick={onClose}><X size={21} /></button></header>
    <div className="inspection-body">
      <div className="inspection-evidence-pane">
        <div className="inspection-section-heading"><div><span className="inspection-section-number">01</span><h3>这次看到了什么</h3></div><span>{photos.length} / 6 张</span></div>
        <div className={`inspection-dropzone ${photos.length ? 'has-photos' : ''}`} onDragOver={event => { event.preventDefault(); }} onDrop={event => { event.preventDefault(); if (!busy) void addPhotos(Array.from(event.dataTransfer.files)); }}>
          <Images size={28} aria-hidden="true" /><strong>{photos.length ? '补充一个角度，留下更多依据' : '拖入现场照片，或选择图片'}</strong><p>建议覆盖房间全景与施工细节。最多 6 张，单张 10 MB，总量 30 MB。</p><button className="button secondary" disabled={!!busy || photos.length >= 6} onClick={() => fileInput.current?.click()}><Upload size={15} />{busy === 'photos' ? '正在处理照片…' : photos.length ? '追加照片' : '选择现场照片'}</button><input ref={fileInput} type="file" accept="image/png,image/jpeg,image/webp" multiple disabled={!!busy} tabIndex={-1} onChange={event => { const files = Array.from(event.target.files ?? []); event.target.value = ''; void addPhotos(files); }} />
        </div>
        {!!photos.length && <div className="inspection-photo-grid">{photos.map((photo, index) => <figure key={photo.id} className="inspection-photo"><div className="inspection-photo-image"><img src={photo.image} alt={`${room.name}本次巡检照片 ${index + 1}${photo.viewpoint ? `，${photo.viewpoint}` : ''}`} width={320} height={210} /><span>{String(index + 1).padStart(2, '0')}</span><button aria-label={`删除巡检照片 ${index + 1}`} disabled={!!busy} onClick={() => { invalidate(); setPhotos(current => current.filter(item => item.id !== photo.id)); }}><Trash2 size={14} /></button></div><figcaption><label>拍摄角度<input aria-label={`巡检照片 ${index + 1} 拍摄角度`} value={photo.viewpoint} maxLength={60} placeholder="如：门口、窗侧、全景" disabled={!!busy} onChange={event => { invalidate(); setPhotos(current => current.map(item => item.id === photo.id ? { ...item, viewpoint: event.target.value } : item)); }} /></label></figcaption></figure>)}</div>}
        <p className="inspection-caption"><ShieldCheck size={13} aria-hidden="true" />照片先在本机缩小保存；“门口”“窗侧”等标签用于整理视角，不作为测量位置。</p>
        <div className="inspection-previous"><div className="inspection-section-heading"><div><span className="inspection-section-number">02</span><h3>与此前记录对照</h3></div><Clock3 size={16} aria-hidden="true" /></div><label className="inspection-field">此前已确认巡检<select value={previous?.id ?? ''} disabled={!!busy} onChange={event => { invalidate(); setPreviousId(event.target.value); }}><option value="">{earlier.length ? '本次不做历史对比' : '暂无同房间、同工序的更早记录'}</option>{earlier.map(evidence => <option key={evidence.id} value={evidence.id}>{evidence.date} · {stageLabel(evidence.stage)}</option>)}</select></label>{previous && <div className="inspection-previous-card"><div className="inspection-previous-meta"><strong>{previous.date}</strong><span>{stageLabel(previous.stage)}</span></div><div className="inspection-previous-photos">{evidencePhotos(previous).slice(0, 6).map((photo, index) => <img key={photo.id} src={photo.image} alt={`${room.name}此前 ${previous.date} 巡检照片 ${index + 1}`} width={110} height={80} />)}</div><p>{previous.summary}</p></div>}<p className="inspection-caption">只展示此房间、此工序且早于本次日期的已确认记录；同日照片不用于前后进展比较。</p></div>
      </div>
      <div className="inspection-review-pane">
        <div className="inspection-section-heading"><div><span className="inspection-section-number">03</span><h3>核对工序与日期</h3></div></div>
        <div className="inspection-field-row"><label className="inspection-field">施工工序<select value={workType} disabled={!!busy || !enabledTypes.length} onChange={event => { invalidate(); setPreviousId(''); setWorkType(event.target.value as WorkType); }}>{WORK_TYPES.map(type => <option key={type.id} value={type.id} disabled={!enabledTypes.includes(type.id)}>{type.label}{!enabledTypes.includes(type.id) ? '（未启用）' : ''}</option>)}</select></label><label className="inspection-field">巡检日期<input type="date" aria-label="巡检日期" aria-invalid={!!dateError} aria-describedby={dateError ? 'inspection-date-error' : undefined} value={date} max={today} disabled={!!busy} onChange={event => { invalidate(); setPreviousId(''); setDate(event.target.value); }} />{dateError && <small id="inspection-date-error" role="alert">{dateError}</small>}</label></div>
        <div className="inspection-analysis-card"><span className={`inspection-provider ${aiConfigured ? 'connected' : ''}`}><i />{aiConfigured ? '千问视觉已配置' : '本地人工确认'}</span><h3>把多个角度，合成一次判断。</h3><p>{aiConfigured ? `点击联合分析后，当前 ${photos.length} 张照片${previous ? `与 ${previous.date} 的此前照片` : ''}才会发送至已配置的千问视觉接口。` : '当前未配置视觉模型。可直接核对照片、选择可见状态并保存；不会生成未经分析的 AI 结论。'}</p><button className="button secondary" disabled={!photos.length || !!busy || !enabledTypes.includes(workType) || !validDate(date) || date > today} onClick={() => void analyze()}>{busy === 'analysis' ? <LoaderCircle className="spin" size={16} /> : <ScanLine size={16} />}{busy === 'analysis' ? '正在联合分析…' : previous ? '联合分析与前后对比' : '联合分析照片'}<ArrowRight size={14} /></button></div>
        {suggestion && <section className="inspection-analysis-result" aria-label="巡检分析建议"><div><ScanLine size={15} aria-hidden="true" /><strong>{suggestion.source === 'manual_review' ? '请人工核对' : 'AI 建议，待你确认'}</strong><span>{stageLabel(suggestion.stage)}</span></div><p>{suggestion.summary}</p>{suggestion.observations.length > 0 && <details><summary>逐张照片观察<ChevronDown size={13} /></summary>{suggestion.observations.map((observation, index) => <p key={index}><strong>照片 {observation.photoIndex + 1}</strong>{observation.summary}</p>)}</details>}{suggestion.comparison && <div className="inspection-comparison"><span>{CHANGE_LABELS[suggestion.comparison.change]}</span><p>{suggestion.comparison.summary}</p></div>}</section>}
        <div className="inspection-confirmation"><div className="inspection-section-heading"><div><span className="inspection-section-number">04</span><h3>你来确认可见状态</h3></div><CheckCircle2 size={16} aria-hidden="true" /></div><label className="inspection-field">确认状态<select value={stage} disabled={!!busy} onChange={event => { setStage(event.target.value as Stage); setCoverageReviewed(false); }}>{STAGES.map(value => <option key={value} value={value}>{stageLabel(value)}</option>)}</select></label>{stage === 'complete' && <label className="inspection-coverage-check"><input type="checkbox" checked={coverageReviewed} disabled={!!busy} onChange={event => setCoverageReviewed(event.target.checked)} /><span>已核对本工序在房间内的覆盖情况；“已完成”表示照片中的外观完成，不代表质量验收通过。</span></label>}<label className="inspection-field">巡检说明 <span className="inspection-optional">可选</span><textarea aria-label="巡检说明" value={notes} maxLength={1000} disabled={!!busy} placeholder="补充未拍到的区域、待处理问题或人工核对结果…" onChange={event => setNotes(event.target.value)} /><small>{notes.length} / 1000</small></label></div>
        {notice && <p className="inspection-notice" role="status">{notice}</p>}{error && <p className="inspection-error" role="alert">{error}</p>}
      </div>
    </div>
    <footer className="inspection-footer"><p><ShieldCheck size={14} aria-hidden="true" />{!enabledTypes.length ? '此房间未启用施工工序，请先在工序计划中启用。' : !photos.length ? '至少添加一张现场照片，再核对并保存本次巡检。' : stage === 'complete' && !coverageReviewed ? '请先勾选已核对本工序的覆盖情况，再确认巡检。' : '保存后作为此房间、此工序的确认记录，保留全部拍摄角度。'}</p><div><button className="button secondary" disabled={!!busy} onClick={onClose}>取消</button><button className="button primary" disabled={!canSave} onClick={save}><Check size={16} />确认巡检</button></div></footer>
  </section></div>;
}

