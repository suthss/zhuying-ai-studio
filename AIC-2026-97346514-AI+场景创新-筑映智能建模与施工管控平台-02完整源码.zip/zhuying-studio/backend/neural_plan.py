"""Local CubiCasa raster inference and metric geometry integration.

Weights are downloaded explicitly by scripts/download_plan_model.py. No API
request downloads code/weights or sends the user's floorplan to a provider.
"""
from functools import lru_cache
import importlib.util
import math
import os
import pickle
from pathlib import Path
import threading
import time
import uuid

import cv2
import numpy as np
from PIL import Image

from backend.algorithm import PlanError, decode_image, parse_floor_plan
from backend.plan_vectorization import VectorizationError, vectorize_plan_labels

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_WEIGHTS = ROOT / 'models/cubicasa5k/model_best_val_loss_var.pkl'
REPOSITORY = 'https://github.com/CubiCasa/CubiCasa5k'
ROOM_NAMES = {3: '厨房', 4: '客厅', 5: '卧室', 6: '卫生间', 7: '玄关', 9: '储物间', 10: '车库', 11: '区域'}
_inference_lock = threading.Lock()


def recognition_status():
    configured = os.environ.get('PLAN_MODEL_PATH', '').strip()
    weights = Path(configured).expanduser() if configured else DEFAULT_WEIGHTS
    runtime = importlib.util.find_spec('torch') is not None
    return {'engine': 'cubicasa5k', 'available': weights.is_file() and runtime,
            'weightsPresent': weights.is_file(), 'runtimePresent': runtime,
            'requiresReview': True}


@lru_cache(maxsize=1)
def _load_network(path, device_name):
    try:
        import torch
        from backend.vendor.cubicasa.hg_furukawa_original import hg_furukawa_original
    except (ImportError, OSError) as exc:
        raise PlanError('PyTorch 识别环境无法加载，请检查识别依赖或选择基础线条识别。') from exc
    if device_name not in {'auto', 'cpu', 'cuda'}:
        raise PlanError('PLAN_DEVICE 应为 auto、cpu 或 cuda。')
    if device_name == 'cuda' and not torch.cuda.is_available():
        raise PlanError('当前没有可用 CUDA 显卡，请将 PLAN_DEVICE 设置为 cpu 或 auto。')
    device = 'cuda' if device_name != 'cpu' and torch.cuda.is_available() else 'cpu'
    torch.set_num_threads(min(8, max(1, os.cpu_count() or 1)))
    # Only state tensors/basic data can be loaded; never execute checkpoint globals.
    try:
        checkpoint = torch.load(path, map_location='cpu', weights_only=True)
        state = checkpoint['model_state']
        network = hg_furukawa_original(44)
        network.load_state_dict(state, strict=True)
        network.eval().to(device)
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, EOFError, pickle.UnpicklingError) as exc:
        raise PlanError('户型模型权重无法安全加载，请重新下载官方权重并检查 PyTorch 环境。') from exc
    return network, device


def segment_floor_plan(image_bytes):
    """Return canonical structural/room labels and inference metadata."""
    image = decode_image(image_bytes)
    source_size = image.size
    status = recognition_status()
    if not status['available']:
        raise PlanError('神经户型识别未就绪，请安装识别依赖并运行 scripts/download_plan_model.py，或选择基础线条识别。')
    try:
        side = int(os.environ.get('PLAN_INPUT_SIDE', '768'))
    except ValueError as exc:
        raise PlanError('PLAN_INPUT_SIDE 应为 512 至 1024 的整数。') from exc
    if side < 512 or side > 1024:
        raise PlanError('PLAN_INPUT_SIDE 应为 512 至 1024 的整数。')
    image.thumbnail((side, side), Image.Resampling.LANCZOS)
    rgb = np.asarray(image)
    height, width = rgb.shape[:2]
    # Preserve image aspect ratio. Padding is only at the bottom/right and is
    # cropped from logits before geometric analysis; it has no metric extent.
    padded_h, padded_w = max(128, math.ceil(height / 64) * 64), max(128, math.ceil(width / 64) * 64)
    canvas = np.full((padded_h, padded_w, 3), 255, dtype=np.uint8)
    canvas[:height, :width] = rgb
    path = str(Path(os.environ.get('PLAN_MODEL_PATH', '').strip() or DEFAULT_WEIGHTS).resolve())
    start = time.perf_counter()
    with _inference_lock:
        network, device = _load_network(path, os.environ.get('PLAN_DEVICE', 'auto').strip())
        import torch
        import torch.nn.functional as functional
        tensor = torch.from_numpy(canvas.transpose(2, 0, 1).copy()).float().unsqueeze(0).to(device) / 127.5 - 1
        try:
            with torch.inference_mode():
                prediction = network(tensor)
                prediction = functional.interpolate(prediction[:, 21:44], size=(padded_h, padded_w), mode='bilinear', align_corners=True)
                room_probabilities = prediction[:, :12].softmax(1)[0, :, :height, :width].cpu().numpy()
                icon_probabilities = prediction[:, 12:].softmax(1)[0, :, :height, :width].cpu().numpy()
        except RuntimeError as exc:
            raise PlanError('户型模型推理失败或显存不足，可改用 CPU / 512 像素输入后重试。') from exc
    rooms = room_probabilities.argmax(0).astype(np.uint8)
    icons = icon_probabilities.argmax(0).astype(np.uint8)
    structures = np.zeros_like(rooms)
    structures[rooms == 2] = 1
    structures[(icons == 2) & (icon_probabilities[2] >= .35)] = 2
    structures[(icons == 1) & (icon_probabilities[1] >= .35)] = 3
    foreground = (structures != 0) | np.isin(rooms, list(ROOM_NAMES))
    confidence = float(np.mean(room_probabilities.max(0)[foreground])) if foreground.any() else 0.
    return {'labels': structures, 'roomLabels': rooms, 'image': image,
            'meta': {'device': device, 'inferenceSeconds': round(time.perf_counter() - start, 3),
                     'sourcePixels': list(source_size), 'processedPixels': [width, height],
                     'meanClassProbability': round(confidence, 4), 'needsReview': True,
                     'sourceRepository': REPOSITORY}}


def _validate_dimensions(real_width, height):
    if isinstance(real_width, bool) or not isinstance(real_width, (int, float)) or not math.isfinite(real_width) or not 1 <= real_width <= 100:
        raise PlanError('建筑总宽度应为 1 至 100 米的有限数值。')
    if isinstance(height, bool) or not isinstance(height, (int, float)) or not math.isfinite(height) or not 2 <= height <= 6:
        raise PlanError('层高应为 2 至 6 米的有限数值。')


def parse_neural_floor_plan(image_bytes, real_width=12.0, height=2.8):
    _validate_dimensions(real_width, height)
    segmented = segment_floor_plan(image_bytes)
    try:
        geometry = vectorize_plan_labels(segmented['labels'], segmented['roomLabels'])
    except VectorizationError as exc:
        raise PlanError(str(exc)) from exc
    x0, y0, x1, y1 = geometry['bounds']
    scale = float(real_width) / (x1 - x0)
    depth = (y1 - y0) * scale
    if not .1 <= depth <= 100:
        raise PlanError('识别的户型长宽比超出可用范围，请裁剪单层户型区域后重试。')

    def point(coordinates):
        return [round(float(np.clip(coordinates[0], x0, x1) - x0) * scale, 4),
                round(float(np.clip(coordinates[1], y0, y1) - y0) * scale, 4)]

    walls = [{'id': f'wall-{index + 1:03d}', 'start': point(wall['start']), 'end': point(wall['end']),
              'thickness': round(min(2., max(.02, wall['thickness'] * scale)), 4), 'height': float(height)}
             for index, wall in enumerate(geometry['walls'])]
    if not walls or any(math.dist(wall['start'], wall['end']) < .01 for wall in walls):
        raise PlanError('识别墙段过短，请增大图像尺度或核对原始户型。')
    openings, skipped = [], []
    for raw in geometry['openings']:
        wall = walls[raw['wallIndex']]
        length = math.dist(wall['start'], wall['end'])
        offset = round(max(0., raw['offset'] * scale), 4)
        # Quantise inward after the rounded endpoints/offset are known. Separate
        # nearest rounding can put a hole beyond a diagonal wall's true length.
        width = math.floor((min(raw['width'] * scale, length - offset) + 1e-10) * 10000) / 10000
        if width < .1 or width > 6 or offset >= length:
            skipped.append('少量门窗的识别尺寸超出可用范围，已跳过，请在结构校正中添加。')
            continue
        opening = {'id': f'opening-{len(openings) + 1:03d}', 'wallId': wall['id'], 'type': raw['type'],
                   'offset': offset, 'width': width,
                   'height': round(min(2.1 if raw['type'] == 'door' else 1.2, height - .05), 4)}
        if raw['type'] == 'window':
            opening['sill'] = round(min(.85, height - opening['height'] - .05), 4)
        bottom = opening.get('sill', 0.)
        if any(other['wallId'] == opening['wallId']
               and min(offset + width, other['offset'] + other['width']) - max(offset, other['offset']) > 1e-5
               and min(bottom + opening['height'], other.get('sill', 0.) + other['height']) - max(bottom, other.get('sill', 0.)) > 1e-5
               for other in openings):
            skipped.append('有门窗在实际尺寸中重叠，已跳过冲突开口，请在结构校正中核对。')
            continue
        openings.append(opening)
    room_models, names = [], {}
    for index, room in enumerate(geometry['rooms']):
        area = round(room['area'] * scale ** 2, 4)
        if area < .001:
            skipped.append('有区域面积低于可建模下限，已跳过，请核对建筑总宽度与图像尺度。')
            continue
        semantic = room.get('semantic', 11)
        base_name = ROOM_NAMES.get(semantic, '区域')
        names[base_name] = names.get(base_name, 0) + 1
        name = f'{base_name} {names[base_name]:02d}'
        task = {'stage': 'unknown', 'plannedStage': 'unknown', 'dueDate': '',
                'note': '请确认房间用途并填写施工计划；户型识别不能说明施工状态。'}
        room_models.append({'id': f'room-{index + 1:03d}', 'name': name, 'polygon': [point(p) for p in room['polygon']],
                            'area': area, 'material': 'concrete', 'progress': 0,
                            'tasks': {'floor': dict(task), 'wall': dict(task)}, 'evidence': []})
    if not room_models:
        raise PlanError('识别区域在当前尺度下过小，请核对建筑总宽度。')
    meta = segmented['meta']
    meta.update({'rooms': len(room_models), 'doors': sum(o['type'] == 'door' for o in openings),
                 'windows': sum(o['type'] == 'window' for o in openings)})
    return {'id': f'plan-{uuid.uuid4().hex[:12]}', 'name': '导入户型 · 智能识别结果',
            'width': float(real_width), 'depth': round(depth, 4), 'height': float(height),
            'walls': walls, 'openings': openings, 'rooms': room_models, 'source': 'opencv',
            'warnings': list(dict.fromkeys([
                '墙体、门窗与房间用途来自本地神经模型预测，请核对轮廓及漏检、误检。',
                '尺度按外墙中心线总宽度标定；门高、窗高与窗台高度为可编辑的初始值。',
                '此模型源于 CubiCasa5K；中国营销户型、异形墙和低清扫描仍可能识别不完整。'] + geometry['warnings'] + skipped))[:100],
            'meta': {'algorithm': 'cubicasa5k-hg-v1', 'engine': 'neural', 'recognition': meta,
                     'sourcePixels': meta['sourcePixels'], 'processedPixels': meta['processedPixels'],
                     'metresPerPixel': scale, 'boundsPixels': list(geometry['bounds']),
                     'scaleBasis': 'outer_wall_centrelines', 'geometryNeedsReview': True}}


def recognize_floor_plan(image_bytes, real_width=12.0, height=2.8, engine='auto'):
    _validate_dimensions(real_width, height)
    if engine not in {'auto', 'neural', 'classic'}:
        raise PlanError('识别方式应为 auto、neural 或 classic。')
    fallback = None
    classic = None
    if engine == 'auto':
        try:
            classic = parse_floor_plan(image_bytes, real_width, height)
        except PlanError:
            pass
        # A neural mask may omit junctions on abstract line-only diagrams.
        # Select deterministic geometry only when virtually all input ink is
        # explained by one connected orthogonal wall network, not room count.
        evidence = classic.get('meta', {}).get('classicStructure', {}) if classic else {}
        if evidence.get('inkCoverage', 0.) >= .99 and evidence.get('connectedWallShare', 0.) >= .99:
            result = _classic_result(classic)
            result['meta']['selectionReason'] = 'closed_orthogonal_structure'
            result['warnings'].insert(0, '图中墨迹主要为连续闭合正交墙线，自动采用基础几何识别以保留清晰房间边界。')
            return result
    if engine != 'classic':
        try:
            return parse_neural_floor_plan(image_bytes, real_width, height)
        except PlanError as exc:
            if engine == 'neural':
                raise
            fallback = str(exc)
    result = _classic_result(classic or parse_floor_plan(image_bytes, real_width, height))
    if fallback:
        result['warnings'].insert(0, f'智能识别未完成，已使用基础线条识别：{fallback}')
        result['meta']['fallbackReason'] = fallback
    return result


def _classic_result(result):
    result['meta']['engine'] = 'classic'
    result['meta']['recognition'] = {'engine': 'classic', 'rooms': len(result['rooms']), 'doors': 0,
                                     'windows': 0, 'needsReview': True}
    return result
