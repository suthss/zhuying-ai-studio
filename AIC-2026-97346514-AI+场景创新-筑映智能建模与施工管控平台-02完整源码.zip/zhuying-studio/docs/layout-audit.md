# 实测记录与实时布局复核

`LayoutAuditPanel` 为项目操作面板中的嵌入组件：

```tsx
<LayoutAuditPanel model={model} onChange={next => setModel(next)}
  onLocate={(roomId, openingId) => locateInModel(roomId, openingId)} />
```

面板不创建弹窗。输入家具的合法宽、深、高即时调用模型 setter；空值、非有限数与越界尺寸只保留为本地输入并显示错误。显示顺序为宽、深、高，模型的 `size` 顺序仍为 `[width, height, depth]`。尺寸修改设置 `meta.layoutReviewPending = true`，几何冲突不会阻止填写实物尺寸；模型仍是待复核工作状态。

## 实测持久化契约

`model.meta.measurements` 是可选记录数组，最多 1000 条：

```ts
interface MeasurementRecord {
  id: string;                 // 1–160 字符、不可重复
  wallId: string;             // 1–160 字符；允许关联已删除墙段
  lengthMeters: number;       // 有限数，> 0 且 <= 200 m
  date: string;               // YYYY-MM-DD，有效日历日期
  source: string;             // 1–500 字符，记录人员、量法、工具或来源
  note: string;               // 0–2000 字符
  confirmed: boolean;        // 人填写确认；不是算法验收结果
  wallSnapshot?: {
    start: [number, number];  // 原模型端点；有限坐标，0–100 m
    end: [number, number];
  };
}
```

`validateMeasurements(raw, model)` 对错误数据抛出中文错误，返回规范化、复制后的数组；`undefined` 返回空数组。未知附加字段不进入规范化结果。不存在的墙段编号不会被静默删除，也不会拒绝整份历史项目。

`recordWallMeasurement(model, record)` 追加记录，使用当前墙的端点写快照，保留其他元数据。UI 不自动勾选人工确认；长度、日期、来源、备注变化会清除本次确认。记录不自动修改墙体长度。

`getMeasurementReview(model)` 返回 `{ walls, orphaned, error, summary }`。每段当前墙采用日期最近的记录；同一天取数组后写的记录。每行包含当前模型长度、`deltaMeters = 模型长度 - 实测长度`、端点是否仍相同、原始记录与状态：

- `unmeasured`：没有记录或当前墙几何无效。
- `unconfirmed`：记录尚未经人工确认。
- `geometry_changed`：墙端点已改变，或历史记录没有端点快照。
- `difference`：人工确认且端点快照一致，但长度差超过 2 cm。
- `checked`：人工确认、端点快照一致、差值在 ±2 cm 内，仅表示录入记录已经对照。
- `orphaned`：原墙段已删除；历史值、日期与来源保留展示。

统计字段为 `totalWalls / measuredWalls / confirmedCurrentWalls / unmeasuredWalls / differenceWalls / geometryChangedWalls / orphanedRecords`。`differenceWalls` 与 `geometryChangedWalls` 可重叠。全项目墙长记录核对条件为 `!error && totalWalls > 0 && confirmedCurrentWalls === totalWalls`；这不证明模型面积、墙高、净空或实物尺寸精确。模型墙轴线与现场净空量法有差别，必须由填写者注明量法。

## 布局检查 API

```ts
auditLayout(model): {
  issues: {
    id: string; type: string;
    severity: 'conflict' | 'hint' | 'unknown';
    basis: 'geometry' | 'heuristic' | 'data';
    message: string; roomId?: string; openingId?: string; wallId?: string;
    furnitureIds: string[];
  }[];
  counts: { conflicts: number; hints: number; unknown: number };
  checked: { furniture: number; walls: number; doors: number; windows: number };
  measurementReview: ReturnType<typeof getMeasurementReview>;
}
```

函数只派生当前状态，不写检查结论，不缓存旧布局；结构、门窗、尺寸或元数据变动后可立即再次调用。房间和门的定位使用 `roomId / openingId`，无法关联房间的数据项不伪造定位。

几何冲突包含家具超出真实多边形房间、墙实体相交、跨房间家具占地相交、当前门叶相交与从闭合到当前角度的门扫掠相交。旋转家具按同一三维模型旋转约定计算占地，凸占地相交使用分离轴检验；边界恰好接触不算实体穿透。凹房间同时检查家具角、边中点与边界穿越，不能只凭四个角通过。

墙实体依照 `viewer/buildHouse.ts` 的沿墙区间与垂直开口规则切分；窗台、门窗洞高与家具高度共同决定是否穿墙。门叶姿态复用 `doorLeafPose`，房间归属与门口定位复用 `getRoomOpenings`，门窗参数复用 `getOpeningErrors`。无效尺寸、端点、房间或开口产生数据待核对项，不当作检验通过。

门扫掠采用不超过 2° 的内接扇形分段，当前门叶厚度单独检查；扫掠边缘的微小擦碰可能漏检。当前叶检验包含主门扇和面板边框厚度，不含把手、五金、门框套线及真实安装误差。

预留提示沿用布置器的房间边缘 6 cm、墙体外扩 2.5 cm、家具间距 2.5 cm、门宽外加 25 cm / 向内 85 cm 门口区，以及继续开至 90° 的备用门扫掠。它们是规划假设，具有 `basis: 'heuristic'`，不是法规宽度或通行验收。

窗口的参数有效性与墙洞实体参与本次复核。未检查窗扇扫掠、抽屉、电器散热、真实家具复杂形状、全屋路线连通、可达性或规范验收。零冲突仅表示当前检测范围没有发现问题；家具数据没有单独实测来源时仍是当前录入尺寸，面板始终提示人工核对。

## 验证

运行 `node --test tests/layout-audit.test.mjs`。覆盖实测日期与数值、人工确认、历史记录排序、删墙孤立记录、几何改变后的旧确认、旋转家具、凹形边界、跨房间相撞、墙移动、门角度/方向/位置改变、窗台改变、实时家具尺寸输入映射、待复核元数据以及实际 React 面板的静态渲染。

本子任务未调用 AI、浏览器或全量构建；UI 初始输出由 React 服务端渲染检查，实际交互与整体集成由主任务验证。
