"""Extract only selected public IITU videos from its 5 GB ZIP using HTTP Range.

No external repository code is executed. Download source metadata is retained.
"""
from __future__ import annotations

import argparse
import io
import json
import zipfile
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "artifacts" / "facade-demo"
WORK.mkdir(parents=True, exist_ok=True)
DATASET = "https://data.mendeley.com/datasets/ww7rt2rnk6/1"


class RemoteFile(io.RawIOBase):
    def __init__(self, url: str, size: int):
        self.url, self.size, self.position = url, size, 0
        self.session = requests.Session()
        self.bytes_received = 0

    def readable(self):
        return True

    def seekable(self):
        return True

    def seek(self, offset, whence=0):
        self.position = offset if whence == 0 else self.position + offset if whence == 1 else self.size + offset
        return self.position

    def tell(self):
        return self.position

    def read(self, size=-1):
        size = self.size - self.position if size < 0 else min(size, self.size - self.position)
        if size <= 0:
            return b""
        start, end = self.position, self.position + size - 1
        response = self.session.get(self.url, headers={"Range": f"bytes={start}-{end}"}, timeout=90)
        response.raise_for_status()
        if response.status_code != 206 or response.headers.get("Content-Range") != f"bytes {start}-{end}/{self.size}":
            raise ValueError("Server did not honour the exact byte range; refusing a full archive download")
        self.position += len(response.content)
        self.bytes_received += len(response.content)
        return response.content


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--extract", nargs="*", default=[])
    args = parser.parse_args()
    listing = requests.get(
        "https://data.mendeley.com/public-api/datasets/ww7rt2rnk6/files",
        params={"folder_id": "root", "version": "1"},
        headers={"Accept": "application/vnd.mendeley-public-dataset.1+json"}, timeout=30,
    ).json()
    (WORK / "file-list.json").write_text(json.dumps(listing, indent=2), encoding="utf-8")
    entry = listing[0]
    url = requests.get(entry["content_details"]["download_url"], headers={"Range": "bytes=0-0"}, stream=True, timeout=30)
    remote_url = url.url
    url.close()
    remote = RemoteFile(remote_url, entry["size"])
    with zipfile.ZipFile(remote) as archive:
        items = [{"name": i.filename, "compressedBytes": i.compress_size,
                  "bytes": i.file_size, "compression": i.compress_type,
                  "archiveModified": list(i.date_time)} for i in archive.infolist()]
        (WORK / "archive-files.json").write_text(json.dumps(items, indent=2, ensure_ascii=False), encoding="utf-8")
        if not args.extract:
            for item in items:
                if not item["name"].startswith("__MACOSX/") and item["bytes"]:
                    print(item["name"], round(item["bytes"] / 1e6, 2), "MB")
        for name in args.extract:
            info = archive.getinfo(name)
            target = WORK / Path(name).name
            if target.exists() and target.stat().st_size == info.file_size:
                print("already downloaded:", target.name)
                continue
            # extract member bytes directly, never trust an archive path as a filesystem target
            target.write_bytes(archive.read(info))
            print("downloaded:", target.name, target.stat().st_size, flush=True)
    print("received bytes:", remote.bytes_received)


if __name__ == "__main__":
    main()
