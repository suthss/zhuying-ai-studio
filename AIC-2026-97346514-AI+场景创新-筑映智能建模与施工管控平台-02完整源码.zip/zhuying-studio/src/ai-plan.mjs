import { createDesignBrief, validateDesignBrief } from './furnishing.mjs';

const STATUSES = new Set(['applied', 'reviewed', 'unavailable', 'failed']);
const MODES = new Set(['local', 'assist', 'rebuild']);
const USES = new Set(['living', 'bedroom', 'study', 'kitchen', 'bathroom', 'entry', 'dining', 'empty']);
const ITEMS = new Set(['sofa', 'coffee_table', 'tv_console', 'bed_double', 'bed_single', 'wardrobe', 'desk', 'chair', 'dining_table', 'kitchen_counter', 'sink_cabinet', 'toilet', 'shoe_cabinet']);
const STYLES = new Set(['warm', 'minimal', 'natural', 'industrial']);
const text = (value, limit = 500) => typeof value === 'string' ? value.slice(0, limit) : '';
const object = value => value && typeof value === 'object' && !Array.isArray(value);

/** Treat imported metadata as untrusted; only display the supported review contract. */
export function getAIPlanReview(model) {
  const raw = model?.meta?.aiReview;
  if (!object(raw) || !STATUSES.has(raw.status) || !MODES.has(raw.mode)) return null;
  const roomIds = new Set(model.rooms.map(room => room.id));
  return {
    status: raw.status, mode: raw.mode, source: text(raw.source, 100), summary: text(raw.summary, 1000),
    geometryRebuilt: raw.status === 'applied' && raw.mode === 'rebuild' && raw.geometryRebuilt === true,
    changes: (Array.isArray(raw.changes) ? raw.changes : []).filter(object).slice(0, 100).map(change => ({kind: text(change.kind, 60), targetId: text(change.targetId, 160), reason: text(change.reason)})),
    issues: (Array.isArray(raw.issues) ? raw.issues : []).filter(object).slice(0, 100).map(issue => ({targetId: text(issue.targetId, 160), severity: issue.severity === 'warning' ? 'warning' : 'info', message: text(issue.message)})).filter(issue => issue.message),
    roomSuggestions: (Array.isArray(raw.roomSuggestions) ? raw.roomSuggestions : []).filter(s => object(s) && roomIds.has(s.roomId) && USES.has(s.use) && (s.confidence === null && s.applied === true || typeof s.confidence === 'number' && Number.isFinite(s.confidence) && s.confidence >= 0 && s.confidence <= 1)).slice(0, 100).map(s => ({roomId: s.roomId, name: text(s.name, 100), use: s.use, confidence: s.confidence, evidence: text(s.evidence), applied: s.applied === true})),
    layoutSuggestions: (Array.isArray(raw.layoutSuggestions) ? raw.layoutSuggestions : []).filter(s => object(s) && roomIds.has(s.roomId)).slice(0, 100).map(s => ({roomId: s.roomId, placement: text(s.placement), ...(Array.isArray(s.items) ? {items:[...new Set(s.items.filter(item => ITEMS.has(item)))].slice(0, 30)} : {})})),
    originalCounts: object(raw.originalCounts) ? Object.fromEntries(['rooms','walls','doors','windows'].filter(key => Number.isInteger(raw.originalCounts[key]) && raw.originalCounts[key] >= 0).map(key => [key, raw.originalCounts[key]])) : {},
  };
}

/** Seed a reviewable design from image-based suggestions, without changing structure or progress. */
export function createAIPlanBrief(model, style) {
  const brief = model.designBrief ? validateDesignBrief(model, model.designBrief) : createDesignBrief(model);
  if (STYLES.has(style)) brief.style = style;
  if (model.designBrief) return brief;
  const review = getAIPlanReview(model);
  if (!review || !['applied', 'reviewed'].includes(review.status)) return brief;
  const suggestions = new Map(review.roomSuggestions.filter(s => s.applied || s.confidence !== null && s.confidence >= .75).map(s => [s.roomId, s]));
  const layouts = new Map(review.layoutSuggestions.map(s => [s.roomId, s]));
  brief.rooms = brief.rooms.map(room => {
    const suggestion = suggestions.get(room.roomId), layout = layouts.get(room.roomId);
    const use = suggestion?.use ?? room.use;
    return {...room, use, furnish: use !== 'empty', ...(layout?.items !== undefined ? {items: layout.items} : {})};
  });
  brief.notes = review.layoutSuggestions.filter(s => s.placement).map(s => `${model.rooms.find(room => room.id === s.roomId)?.name}：${s.placement}`).join('\n').slice(0, 2000);
  return validateDesignBrief(model, brief);
}
