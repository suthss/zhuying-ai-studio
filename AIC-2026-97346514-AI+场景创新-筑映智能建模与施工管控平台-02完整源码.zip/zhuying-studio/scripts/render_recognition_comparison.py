"""Render self-drawn regression geometry beside its source and baseline.

Panels use the fixture's explicitly annotated metric coordinates. A successful
parse does not imply accuracy; rejection is displayed rather than substituted.
This script draws diagnostic geometry, not a photographic house reconstruction.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PALETTE = ('#d8e6df', '#cdddea', '#eadbc8', '#dfd3e4', '#cfe2df', '#e6dfbd')


def font(size):
    for path in ('C:/Windows/Fonts/msyh.ttc', 'C:/Windows/Fonts/arial.ttf'):
        if Path(path).is_file():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def diagram(model, size=(720, 520), title=''):
    image = Image.new('RGB', size, '#f5f7f6')
    draw = ImageDraw.Draw(image)
    draw.text((20, 16), title, fill='#21493f', font=font(20))
    if model is None:
        draw.text((25, 200), '未形成可用几何 / 解析拒绝', fill='#9b5847', font=font(25))
        return image
    scale = min((size[0] - 65) / max(12, model['width']), (size[1] - 95) / max(8, model['depth']))
    def p(point):
        return (round(30 + point[0] * scale), round(65 + point[1] * scale))
    for i, room in enumerate(model['rooms']):
        polygon = [p(point) for point in room['polygon']]
        draw.polygon(polygon, fill=PALETTE[i % len(PALETTE)], outline='#729287', width=2)
        centre = tuple(sum(point[j] for point in polygon) / len(polygon) for j in range(2))
        draw.text(centre, str(i + 1), fill='#39574e', font=font(15), anchor='mm')
    for wall in model['walls']:
        draw.line((p(wall['start']), p(wall['end'])), fill='#263c38', width=max(3, round(wall['thickness'] * scale)))
    walls = {wall['id']: wall for wall in model['walls']}
    for opening in model.get('openings', []):
        wall = walls[opening['wallId']]
        ax, az = wall['start']
        bx, bz = wall['end']
        length = math.hypot(bx - ax, bz - az)
        if not length:
            continue
        unit = ((bx - ax) / length, (bz - az) / length)
        ends = [[ax + unit[0] * t, az + unit[1] * t] for t in
                (opening['offset'], opening['offset'] + opening['width'])]
        draw.line([p(point) for point in ends], fill='#da8441' if opening['type'] == 'door' else '#348bb9', width=7)
    draw.text((20, size[1] - 22), f"{len(model['rooms'])} 空间 · {len(model['walls'])} 墙段 · {len(model.get('openings', []))} 门窗",
              fill='#6a7c75', font=font(13))
    return image


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--models', type=Path, required=True)
    cli.add_argument('--baseline-models', type=Path, default=ROOT / 'artifacts/recognition-baseline-models')
    cli.add_argument('--output', type=Path, required=True)
    cli.add_argument('--cases', nargs='+', default=['doors-windows', 'mixed-doors-furniture-dimensions', 'closed-l-room', 'l-room-mixed'])
    args = cli.parse_args()
    fixtures = ROOT / 'tests/fixtures/plan-recognition'
    canvas = Image.new('RGB', (2160, 560 * len(args.cases) + 75), '#ffffff')
    draw = ImageDraw.Draw(canvas)
    draw.text((24, 18), '自绘户型回归对比：不是真实图纸精度评测', font=font(28), fill='#21493f')
    for row, case in enumerate(args.cases):
        source = Image.open(fixtures / (case + '.png')).convert('RGB')
        source.thumbnail((700, 470))
        panel = Image.new('RGB', (720, 520), '#f5f7f6')
        ImageDraw.Draw(panel).text((20, 16), case + ' · 原始图', font=font(18), fill='#21493f')
        panel.paste(source, ((720 - source.width) // 2, 55))
        canvas.paste(panel, (0, 75 + row * 560))
        for column, directory, label in ((1, args.baseline_models, '旧规则方法'), (2, args.models, '当前识别方法')):
            path = directory / (case + '.json')
            model = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else None
            canvas.paste(diagram(model, title=label), (720 * column, 75 + row * 560))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(args.output)


if __name__ == '__main__':
    main()
