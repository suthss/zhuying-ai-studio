import test from 'node:test';
import assert from 'node:assert/strict';
import { viewer, withCanvas } from './helpers/viewer-module.mjs';
const { THREE, buildHouse, disposeTree, DEMO_MODEL, findInteriorStandingPoint } = viewer;

test('主卧门两侧铰链、双向0/45/90/100度开启均不穿入电视柜与床头柜', () => {
  for (const hinge of ['start', 'end']) for (const swing of [1, -1]) for (const openAngle of [0, 45, 90, 100]) {
    const model = structuredClone(DEMO_MODEL);
    model.openings.find(o => o.id === 'd3').design = { color: '#c9b99b', style: 'panel', hinge, swing, openAngle, glassTint: 'clear' };
    const { group } = withCanvas(() => buildHouse(model, 'material', false, true));
    try {
      group.updateMatrixWorld(true);
      const leaf = group.getObjectByName('d3 · 门扇转轴');
      assert.ok(leaf, 'actual rendered door leaf must exist');
      const leafBounds = new THREE.Box3().setFromObject(leaf);
      for (const name of ['客厅 · 电视柜', '主卧 · 床头柜左', '主卧 · 床头柜右']) {
        const furniture = group.getObjectByName(name);
        assert.ok(furniture, `${name} must remain in the model`);
        assert.equal(leafBounds.intersectsBox(new THREE.Box3().setFromObject(furniture)), false, `${hinge}/${swing}/${openAngle}° intersects ${name}`);
      }
    } finally { disposeTree(group); }
  }
});

test('室内模型具有双面顶面和暖灯，真实主卧几何仍有安全站点', () => {
  const { group, selections, hovers } = withCanvas(() => buildHouse(DEMO_MODEL, 'material', false, true, 'master'));
  try {
    const ceiling = group.getObjectByName('主卧 · 室内顶面');
    assert.ok(ceiling instanceof THREE.Mesh);
    assert.equal(ceiling.material.side, THREE.DoubleSide);
    assert.ok(group.getObjectByName('主卧 · 暖光吊灯'));
    assert.equal(selections.size, 0); assert.equal(hovers.size, 0);
    const point = findInteriorStandingPoint(DEMO_MODEL, 'master', group);
    assert.ok(point); assert.equal(point.y, 1.55);
    assert.ok(point.x > 1 && point.x < 6 && point.z > -.5 && point.z < 4.5);
  } finally { disposeTree(group); }
});

test('实际门窗可选网格保留构件编号与相邻墙面元数据', () => {
  const { group } = withCanvas(() => buildHouse(DEMO_MODEL, 'material', false, true));
  try {
    const counts = new Map();
    group.traverse(object => {
      if (!(object instanceof THREE.Mesh) || !object.userData.openingId) return;
      const data = object.userData;
      counts.set(data.openingId, (counts.get(data.openingId) ?? 0) + 1);
      assert.ok(data.wallId); assert.ok(data.wallPlane); assert.ok(data.wallRooms);
    });
    for (const opening of DEMO_MODEL.openings) assert.ok(counts.get(opening.id) > 3, `${opening.id} lacks selectable frame/leaf details`);
  } finally { disposeTree(group); }
});
