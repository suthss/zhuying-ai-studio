"""Publish six visually reviewed IITU frames, provenance, and a contact sheet.

Images are authentic video frames. No generative edits, fabricated dates, or
construction completion percentages are introduced by this data preparation.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import cv2
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "artifacts" / "facade-demo"
PUBLIC = ROOT / "public" / "facade-demo"
PUBLIC.mkdir(parents=True, exist_ok=True)

SELECTED = [
    ("2025-06-25", "20250625142613793_3dc8f258b29647169733d85662cce9f4_FV8790840.mp4", "14:26:14", "裸露结构与幕墙框架", "楼板与柱清晰可见；前侧框架已安装，大片开口仍能看到室内；不能仅凭灰色区域断言已装玻璃。"),
    ("2025-08-31", "20250831115922442_3dc8f258b29647169733d85662cce9f4_FV8790840.mp4", "11:59:20", "玻璃开始形成连续区域", "右侧蓝色玻璃覆盖明显，前侧上部可见蓝色玻璃带；屋顶层与若干下层开口仍未封闭。"),
    ("2025-09-06", "20250906180703778_3dc8f258b29647169733d85662cce9f4_FV8790840.mp4", "18:07:03", "幕墙安装扩展", "蓝色玻璃带沿前侧弧形立面扩展，右侧已覆盖较大区域；前侧仍有开口、框架和遮挡。"),
    ("2025-10-21", "20251021101715729_3dc8f258b29647169733d85662cce9f4_FV8790840.mp4", "10:17:17", "主要可见玻璃覆盖", "前侧大部分立面为连续玻璃外观；屋顶层白色围护、裸露砌体和斜撑仍在；不是整体完工。"),
    ("2025-11-05", "20251105150141825_3dc8f258b29647169733d85662cce9f4_FV8790840.mp4", "15:01:41", "雨雪条件下的复核", "积雪、灰暗光照和玻璃反射改变外观；用于复核已装区域是否因天气被误判；顶层仍未封闭。"),
    ("2026-04-25", "20260425_667B541F-A5CB-4732-A291-63E86637119B.MP4", "16:29:08", "跨季节持续观察", "春季阳光下主体可见幕墙较完整，但顶层仍有裸露结构、临时构件和施工围挡；未覆盖竣工验收。"),
]

def main():
    font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 20)
    title_font = ImageFont.truetype("C:/Windows/Fonts/msyh.ttc", 24)
    sheet = Image.new("RGB", (1440, 3 * 465 + 85), "#edf0eb")
    draw = ImageDraw.Draw(sheet)
    draw.text((24, 16), "IITU 同一工地 · 6 张真实典型时序画面", font=title_font, fill="#143d35")
    draw.text((24, 52), "摄影日期来自画面摄像机时间；未提供官方施工阶段/完成率标注", font=font, fill="#5b6862")
    frames = []
    for i, (date, filename, camera_time, stage, description) in enumerate(SELECTED):
        video = WORK / filename
        capture = cv2.VideoCapture(str(video))
        capture.set(cv2.CAP_PROP_POS_MSEC, 1000)
        ok, frame = capture.read()
        capture.release()
        if not ok:
            raise RuntimeError(f"Cannot read frame at 1 second: {filename}")
        im = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        original_size = list(im.size)
        im.thumbnail((1600, 900), Image.Resampling.LANCZOS)
        target = PUBLIC / f"{date}.webp"
        im.save(target, "WEBP", quality=91, method=6)
        thumb = im.copy()
        thumb.thumbnail((704, 396))
        x, y = (i % 2) * 720 + 8, (i // 2) * 465 + 85
        sheet.paste(thumb, (x, y))
        draw.text((x + 8, y + 404), date + "   " + stage, font=font, fill="#143d35")
        frames.append({
            "id": f"iitu-{date}", "date": date, "cameraTimestamp": f"{date} {camera_time}",
            "dateSource": "画面左上摄像机时间（视觉核对），与源视频文件名前8位一致；时区未声明",
            "image": f"/facade-demo/{date}.webp", "sourceFile": "IITU_2025-05_to_2026-06_raw/" + filename,
            "sourceVideoBytes": video.stat().st_size,
            "sourceVideoSha256": hashlib.sha256(video.read_bytes()).hexdigest(),
            "sampleSeconds": 1.0, "originalResolution": original_size,
            "exportResolution": list(im.size), "title": stage, "description": description,
            "imageSha256": hashlib.sha256(target.read_bytes()).hexdigest(),
            "modifications": "从公开视频1.0秒处抽帧，缩小至1600×900，WebP压缩；无生成式修改、无裁剪，保留摄像机时间",
            "officialConstructionStage": None, "officialProgressPercent": None,
        })
    source = {
        "datasetTitle": "IITU Multi-Temporal Building Floor-Count Dataset: 12-Month Fixed-Viewpoint Construction Sequence",
        "datasetUrl": "https://data.mendeley.com/datasets/ww7rt2rnk6/1",
        "doi": "10.17632/ww7rt2rnk6.1", "version": 1,
        "author": "Arman Keresh", "publisher": "Mendeley Data", "published": "2026-06-01",
        "location": "International Information Technology University, Almaty, Kazakhstan",
        "license": "CC BY 4.0", "licenseUrl": "https://creativecommons.org/licenses/by/4.0/",
        "attribution": "视频及抽帧影像：Arman Keresh (2026), IITU Multi-Temporal Building Floor-Count Dataset, Mendeley Data, v1, DOI:10.17632/ww7rt2rnk6.1, CC BY 4.0。筑映选帧、缩放并压缩。",
        "archiveFile": "IITU_2025-05_to_2026-05.zip", "archiveBytes": 5098033632,
        "downloadUrl": "https://data.mendeley.com/public-files/datasets/ww7rt2rnk6/files/42649ce1-1b15-4523-b942-f45cf86f240d/file_downloaded",
        "retrieved": "2026-10-05", "method": "HTTP Range读取ZIP64中央目录与选定压缩成员；不下载全量5.1GB归档",
        "limitations": [
            "原始视频没有官方施工阶段、幕墙安装率或实际计划标签。界面若显示安装率，必须明确其为本项目推断/人工复核值，而非官方真值。",
            "官方页面称May 2025–April 2026，但归档名含May、内部目录名含June，内部视频实际最早June 2025且延续May 2026。本样例选画面时间可核对的2025-06-25至2026-04-25。",
            "页面称May–August为未安装玻璃阶段，但2025-08-31画面已有明显蓝色玻璃；阶段说明以所选画面实际可见证据为准。",
            "同一地点视角总体相近但存在缩放/构图变化，应按帧标定共同立面，不能直接相减像素区域或把反射、雪、树木变化当成施工变化。",
            "数据仅覆盖裸露/部分饰面施工；屋顶层持续未封闭，不能声称整体竣工或验收通过。",
            "本样例只有6个代表日期，不是训练集；需按日期留出评估，不能随机拆分相邻视频帧宣称泛化性能。",
        ], "frames": frames,
    }
    (PUBLIC / "sources.json").write_text(json.dumps(source, ensure_ascii=False, indent=2), encoding="utf-8")
    sheet.save(WORK / "selected-contact-sheet.jpg", quality=93)
    print(json.dumps({"frames": len(frames), "assetBytes": sum((PUBLIC / f"{f['date']}.webp").stat().st_size for f in frames)}, indent=2))

if __name__ == "__main__":
    main()
