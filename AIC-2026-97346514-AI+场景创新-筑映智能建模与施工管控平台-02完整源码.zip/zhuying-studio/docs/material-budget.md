# 材料工程量与报价方案

`BudgetPanel({ model, onChange })` 嵌入项目管理页，使用现有主题变量，不自行打开弹窗。每次更改单价、损耗、方案名称或选择均通过 `onChange(nextModel)` 保存；输入在失焦或 Enter 时提交。非法输入留在输入框并标示“未保存”，不修改已保存数值。价格留空为待报价，明确输入 0 才表示零元报价。

## 持久化与验证

```ts
model.meta.materialBudget = {
  version: 1,
  selectedQuoteId: 'quote-a',
  quotes: [{
    id: 'quote-a', name: '方案 A',
    rooms: {
      roomId: { floorUnitPrice: null, floorWastePercent: 0, wallUnitPrice: null }
    },
    furniture: { furnitureId: null }
  }]
}
```

最多两套独立报价，第二套可从空白创建或复制当前方案。默认地板、墙面与家具单价全部为 `null`，不猜测实时价格。单价范围 0–10000000 元，最多两位小数；地板损耗为 0–100%，最多两位小数。`validateBudgetConfig(raw, model)` 返回隔离拷贝，非法结构、非有限数、负数、超范围、小数位超限、未知字段和失效的选中方案均抛错。根项目验证器应在此 meta 字段存在时调用它。

房间或家具被删除时，其历史报价仍保留在各方案中；`getStaleBudgetReferences` 将它们显式列出，计算排除，界面可用 `cleanStaleBudgetReferences(model,config,quoteId)` 清理指定方案。另一方案不受清理影响。新增房间与家具默认待报价。几何或材质更改会保留单价并重新计算；用户需自行复核报价适用性。

## 几何与金额

- 地面使用房间多边形鞋带公式计算，支持凹多边形与反向顶点顺序，不读取 `room.area`。不以包围盒近似地面。
- 墙面以房间边界为一个内侧饰面，按关联墙段高度分段求面积；无法关联的边界按模型层高估算，并列出估算边界长度。匹配允许墙厚的一半加 1 cm 的边线偏移，方向差最多约 0.11°。
- 只扣除关联门窗在本房间边界内的横向交叠宽度和有效高度。长外墙上其他房间的洞口不扣除；共享墙对各房间分别计一个饰面。矩形联合面积避免重叠洞口重复扣除。房间的“计算依据”列出分边墙面及洞口扣减。
- 计算工程量保留 6 位小数，界面显示至 3 位小数。地板报价量 = 净面积 ×（1 + 损耗率），再保留 6 位小数；墙面和家具首版不增加损耗。
- 两位小数单价转为整数分，以 BigInt 与工程量的百万分之一单位相乘，各条目采用非负数四舍五入至分，然后累加整数分。金额须有限、非负且处于安全整数分范围。
- `calculateBudget` 返回 `partialTotal`、`pendingCount` 和 `total`。缺少任何单价时 `total=null`；界面和 CSV 明示“已报价部分合计”，不给出完整总价。两套均补全时才输出合计差额。
- 仅统计 `model.furniture` 中的保存构件，每件数量 1，不统计场景中的默认示意家具。

测量来源读取 `meta.measurements`，共用 `layout-audit.mjs` 的 `getMeasurementReview`，显示 X/Y 墙段已核对。仅当所有墙段的最新记录都有人工确认、长度差在 2 cm 内且端点快照对应当前几何时，标示墙长记录已逐段核对；仍明确面积与墙高为模型估算。部分墙段记录或快照过期不得宣称全房实测。

## 导出和API

`exportBudgetCsv(model,config,quoteIds?)` 默认导出两套已建立方案的工程量、单价、状态及来源，`quoteIds` 可选筛选。字段均按 CSV 规则引号转义，公式起始字符 `= + - @`（含前置空白控制符）以及起始 tab / CR / LF 添加单引号前缀。下载使用 UTF-8 BOM；同一内容可展开预览、复制，剪贴板失败时选中文字供手动复制。

其他导出：`createBudgetConfig`、`createBudgetQuote`、`getBudgetConfig`、`setBudgetConfig`、`getRoomQuote`、`parseBudgetInput`、`polygonFloorArea`、`calculateRoomQuantities`、`calculateLineAmount`、`calculateBudget`、`compareBudgets`、`getBudgetMeasurementLabel`、`csvSafeCell`，类型位于 `budget.d.mts`。

## 范围

本功能为模型方案估算，不代替测绘、施工图工程量或施工报价。墙边线可能是中心线，也可能是内侧线；面积不扣墙厚，房间重叠不自动修正。模型应先通过项目几何验证。未计吊顶、踢脚线、洞口侧壁、基层处理、水电、安装与运输等项目。单价是否包含人工、辅材、税费由用户决定；不自动附加任何市场价、税率或费用。

验证命令：`node --test tests/budget.test.mjs`。测试覆盖凹多边形、真实房间边界洞口、长外墙单侧与共享墙两侧、裁剪与反向墙起点、局部墙高、矩形联合扣除、待报价总计规则、损耗及分位舍入、两方案独立、几何变更、失效引用清理、非法数值、CSV注入与测量快照状态。
