import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, DoorOpen, Layers3, Plus, Ruler, Trash2, X } from 'lucide-react';
import type { HouseModel, Opening, Point, Room, Wall } from './types';
import { validateProject } from './project.mjs';
import { getOpeningErrors } from './openings.mjs';
import './structure-editor.css';

type Props = { model: HouseModel; onSave: (model: HouseModel) => void; onClose: () => void; initialWallId?:string; initialRoomId?:string };
const EPS = 0.00001;
const finitePoint = (point: Point) => point.every(Number.isFinite);
const validCoordinates = (point: Point) => finitePoint(point) && point.every(value => value >= 0 && value <= 100);
const wallLength = (wall: Wall) => Math.hypot(wall.end[0] - wall.start[0], wall.end[1] - wall.start[1]);
function polygonArea(points: Point[]) {
  return Math.abs(points.reduce((sum, point, index) => {
    const next = points[(index + 1) % points.length];
    return sum + point[0] * next[1] - next[0] * point[1];
  }, 0)) / 2;
}
function polygonCrosses(points: Point[]) {
  const cross = (a: Point, b: Point, c: Point) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  const onSegment = (a: Point, b: Point, c: Point) => Math.abs(cross(a, b, c)) < EPS && c[0] >= Math.min(a[0], b[0]) - EPS && c[0] <= Math.max(a[0], b[0]) + EPS && c[1] >= Math.min(a[1], b[1]) - EPS && c[1] <= Math.max(a[1], b[1]) + EPS;
  for (let i = 0; i < points.length; i++) for (let j = i + 1; j < points.length; j++) {
    if (j === i + 1 || (i === 0 && j === points.length - 1)) continue;
    const a = points[i], b = points[(i + 1) % points.length], c = points[j], d = points[(j + 1) % points.length];
    const c1 = cross(a, b, c), c2 = cross(a, b, d), c3 = cross(c, d, a), c4 = cross(c, d, b);
    if ((c1 * c2 < 0 && c3 * c4 < 0) || onSegment(a, b, c) || onSegment(a, b, d) || onSegment(c, d, a) || onSegment(c, d, b)) return true;
  }
  return false;
}
function validate(model: HouseModel): string[] {
  const errors: string[] = [];
  if (model.rooms.length > 100 || model.walls.length > 500) errors.push('单个项目最多支持 100 个房间、500 段墙体。');
  if (![model.width, model.depth, model.height].every(value => Number.isFinite(value) && value > 0) || model.height < 2 || model.height > 6) errors.push('房屋长、宽须为有限正数，层高需在2–6米范围内。');
  const wallIds = new Set<string>();
  for (const wall of model.walls) {
    if (!wall.id || wallIds.has(wall.id)) errors.push('墙体编号须唯一且不能为空。');
    wallIds.add(wall.id);
    if (!validCoordinates(wall.start) || !validCoordinates(wall.end)) errors.push(`${wall.id}：X、Z 坐标须为 0–100 米之间的有限数，不能使用负坐标。`);
    if (!Number.isFinite(wall.thickness) || wall.thickness <= 0 || wallLength(wall) < EPS) errors.push(`${wall.id}：墙厚须大于 0，墙段不能为零长度。`);
    if (wall.height !== undefined && (!Number.isFinite(wall.height) || wall.height <= 0 || wall.height > model.height)) errors.push(`${wall.id}：墙高须大于 0 且不超过房屋层高。`);
  }
  const openingIds = new Set<string>();
  for (const opening of model.openings) {
    const wall = model.walls.find(item => item.id === opening.wallId);
    if (!opening.id || openingIds.has(opening.id)) errors.push('门窗编号须唯一且不能为空。');
    openingIds.add(opening.id);
    if (!wall) { errors.push(`${opening.id}：关联墙体不存在。`); continue; }
    const sill = opening.type === 'window' ? opening.sill ?? 0 : 0;
    const ceiling = Math.min(wall.height ?? model.height, model.height);
    if (![opening.offset, opening.width, opening.height, sill].every(Number.isFinite) || opening.offset < 0 || opening.width <= 0 || opening.height <= 0 || sill < 0) errors.push(`${opening.id}：门窗参数须为有限数，宽高须大于 0，偏移及窗台高度不能为负数。`);
    else if (opening.offset + opening.width > wallLength(wall) + EPS || sill + opening.height > ceiling + EPS) errors.push(`${opening.id}：开口超出墙长或墙高，请调整偏移、宽高或窗台高度。`);
  }
  const roomIds = new Set<string>();
  for (const room of model.rooms) {
    if (!room.id || roomIds.has(room.id)) errors.push('房间编号须唯一且不能为空。');
    roomIds.add(room.id);
    if (room.polygon.length < 3 || !room.polygon.every(validCoordinates)) errors.push(`${room.name}：轮廓至少需要 3 个顶点，X、Z 坐标须为 0–100 米之间的有限数，不能使用负坐标。`);
    else if (polygonArea(room.polygon) < EPS || polygonCrosses(room.polygon)) errors.push(`${room.name}：轮廓须有有效面积且不能交叉，请核对顶点顺序。`);
  }
  model.openings.forEach(opening=>errors.push(...getOpeningErrors(model,opening)));
  return [...new Set(errors)];
}

function NumberField({ label, value, onChange, min, max }: { label: string; value: number; onChange: (value: number) => void; min?: number; max?: number }) {
  return <label className="se-field"><span>{label}</span><div className="se-input-wrap"><input type="number" step="0.01" min={min} max={max} value={Number.isFinite(value) ? value : ''} onChange={event => onChange(event.target.value === '' ? NaN : Number(event.target.value))} /><span>m</span></div></label>;
}

export default function StructureEditor({ model, onSave, onClose, initialWallId, initialRoomId }: Props) {
  const [draft, setDraft] = useState<HouseModel>(() => structuredClone(model));
  const [section, setSection] = useState<'wall' | 'room'>('wall');
  const [wallId, setWallId] = useState(initialWallId ?? model.walls[0]?.id ?? '');
  const [roomId, setRoomId] = useState(initialRoomId ?? model.rooms[0]?.id ?? '');
  const [notice, setNotice] = useState('');
  const dialogRef = useRef<HTMLDivElement>(null);
  const returnFocus = useRef(document.activeElement instanceof HTMLElement ? document.activeElement : null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const previous = returnFocus.current;
    dialogRef.current?.focus({ preventScroll: true });
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); closeRef.current(); return; }
      if (event.key !== 'Tab') return;
      const nodes = Array.from(dialogRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), select:not(:disabled), [tabindex="0"]') ?? []).filter(element => element.getClientRects().length);
      if (!nodes.length) { event.preventDefault(); dialogRef.current?.focus({ preventScroll: true }); return; }
      const first = nodes[0], last = nodes[nodes.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialogRef.current)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialogRef.current)) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', handleKey);
    return () => { document.removeEventListener('keydown', handleKey); queueMicrotask(() => { if (previous?.isConnected && !previous.closest('[inert]')) previous.focus({ preventScroll: true }); }); };
  }, []);
  const wall = draft.walls.find(item => item.id === wallId);
  const room = draft.rooms.find(item => item.id === roomId);
  const openings = draft.openings.filter(item => item.wallId === wallId);
  const errors = useMemo(() => validate(draft), [draft]);
  const bounds = useMemo(() => {
    const points = [...draft.walls.slice(0, 500).flatMap(item => [item.start, item.end]), ...draft.rooms.slice(0, 100).flatMap(item => item.polygon)].filter(finitePoint);
    const xs = points.map(point => point[0]), zs = points.map(point => point[1]);
    const minX = Math.min(0, ...xs), minZ = Math.min(0, ...zs), maxX = Math.max(1, ...xs), maxZ = Math.max(1, ...zs);
    const padding = Math.max(maxX - minX, maxZ - minZ) * .09;
    return { x: minX - padding, z: minZ - padding, width: maxX - minX + padding * 2, depth: maxZ - minZ + padding * 2 };
  }, [draft]);
  const patchWall = (patch: Partial<Wall>) => setDraft(current => ({ ...current, walls: current.walls.map(item => item.id === wallId ? { ...item, ...patch } : item) }));
  const patchRoom = (patch: Partial<Room>) => setDraft(current => ({ ...current, rooms: current.rooms.map(item => item.id === roomId ? { ...item, ...patch } : item) }));
  const patchOpening = (id: string, patch: Partial<Opening>) => setDraft(current => ({ ...current, openings: current.openings.map(item => item.id === id ? { ...item, ...patch } : item) }));
  function addOpening(type: 'door' | 'window') {
    if (!wall || !Number.isFinite(wallLength(wall)) || wallLength(wall) < .1 || !Number.isFinite(draft.height) || draft.height <= 0) { setNotice('先设置有效墙段与层高，再添加门窗。'); return; }
    const width = Math.min(type === 'door' ? .9 : 1.2, wallLength(wall));
    const ceiling = Math.min(wall.height ?? draft.height, draft.height);
    const height = Math.min(type === 'door' ? 2.1 : 1.2, ceiling);
    const opening: Opening = { id: `${type}-${crypto.randomUUID().slice(0, 8)}`, wallId, type, offset: (wallLength(wall) - width) / 2, width, height, ...(type === 'window' ? { sill: Math.max(0, Math.min(.9, ceiling - height)) } : {}) };
    setDraft(current => ({ ...current, openings: [...current.openings, opening] }));
    setNotice('已添加开口。请确认位置，多个开口不要重叠。');
  }
  function save() {
    if (errors.length) { setNotice('请先修正下方提示，再保存模型。'); return; }
    const next = structuredClone(draft);
    next.rooms = next.rooms.map(item => ({ ...item, area: Math.round(polygonArea(item.polygon) * 100) / 100 }));
    const allPoints = [...next.walls.flatMap(item => [item.start, item.end]), ...next.rooms.flatMap(item => item.polygon)];
    next.width = Math.max(next.width, ...allPoints.map(point => point[0]));
    next.depth = Math.max(next.depth, ...allPoints.map(point => point[1]));
    next.source = 'manual';
    try { validateProject(next); } catch (error) { setNotice(error instanceof Error ? error.message : '模型参数无效，请核对尺寸。'); return; }
    onSave(next);
    onClose();
  }
  const selectKey = (event: React.KeyboardEvent, action: () => void) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); action(); } };
  return <div className="se-overlay">
    <div className="se-dialog" role="dialog" aria-modal="true" aria-labelledby="se-title" ref={dialogRef} tabIndex={-1}>
      <header className="se-header"><div className="se-heading"><div className="se-heading-icon"><Layers3 size={21} /></div><div><h2 id="se-title">编辑房屋结构</h2><p>校正墙体、门窗与房间轮廓</p></div></div><button className="se-icon-button" onClick={onClose} aria-label="关闭结构编辑器"><X size={21} /></button></header>
      <div className="se-body">
        <section className="se-preview-pane" aria-label="二维结构预览">
          <div className="se-preview-title"><Ruler size={16} /><span>二维结构预览</span><small>坐标单位：米</small></div>
          <div className="se-plan-frame"><svg viewBox={`${bounds.x} ${bounds.z} ${bounds.width} ${bounds.depth}`} className="se-plan" aria-label="房屋结构预览，可点选图形或通过墙段、房间选择器编辑">
            <defs><pattern id="se-grid" patternUnits="userSpaceOnUse" width="1" height="1"><path d="M 1 0 L 0 0 0 1" fill="none" stroke="#dce3df" strokeWidth=".015" /></pattern></defs>
            <rect x={bounds.x} y={bounds.z} width={bounds.width} height={bounds.depth} fill="url(#se-grid)" />
            {draft.rooms.slice(0, 100).filter(item => item.polygon.length >= 3 && item.polygon.every(finitePoint)).map(item => <g key={item.id} role="button" tabIndex={-1} aria-label={`编辑${item.name}`} aria-pressed={section === 'room' && roomId === item.id} onClick={() => { setRoomId(item.id); setSection('room'); }} onKeyDown={event => selectKey(event, () => { setRoomId(item.id); setSection('room'); })} className="se-svg-target">
              <polygon points={item.polygon.map(point => point.join(',')).join(' ')} fill={section === 'room' && roomId === item.id ? '#c9e2d4' : '#eef2ee'} stroke="#c2cec6" strokeWidth=".035" />
              <text x={item.polygon.reduce((sum, point) => sum + point[0], 0) / item.polygon.length} y={item.polygon.reduce((sum, point) => sum + point[1], 0) / item.polygon.length} textAnchor="middle" dominantBaseline="middle" fontSize=".27" fill="#456054">{item.name}</text>
            </g>)}
            {draft.walls.slice(0, 500).filter(item => finitePoint(item.start) && finitePoint(item.end)).map(item => <g key={item.id} role="button" tabIndex={-1} aria-label={`编辑墙段${item.id}`} aria-pressed={section === 'wall' && wallId === item.id} onClick={() => { setWallId(item.id); setSection('wall'); }} onKeyDown={event => selectKey(event, () => { setWallId(item.id); setSection('wall'); })} className="se-svg-target">
              <line x1={item.start[0]} y1={item.start[1]} x2={item.end[0]} y2={item.end[1]} stroke={section === 'wall' && wallId === item.id ? '#176247' : '#667d6d'} strokeWidth={Number.isFinite(item.thickness) && item.thickness > 0 ? item.thickness : .12} strokeLinecap="square" />
              <line x1={item.start[0]} y1={item.start[1]} x2={item.end[0]} y2={item.end[1]} stroke="transparent" strokeWidth=".3" />
              {section === 'wall' && wallId === item.id && [item.start, item.end].map((point, index) => <circle key={index} cx={point[0]} cy={point[1]} r=".11" fill="white" stroke="#176247" strokeWidth=".045" />)}
            </g>)}
            {draft.openings.map(item => {
              const linked = draft.walls.find(candidate => candidate.id === item.wallId);
              if (!linked || !finitePoint(linked.start) || !finitePoint(linked.end) || wallLength(linked) < EPS || ![item.offset, item.width].every(Number.isFinite)) return null;
              const length = wallLength(linked), dx = (linked.end[0] - linked.start[0]) / length, dz = (linked.end[1] - linked.start[1]) / length;
              return <line key={item.id} x1={linked.start[0] + dx * item.offset} y1={linked.start[1] + dz * item.offset} x2={linked.start[0] + dx * (item.offset + item.width)} y2={linked.start[1] + dz * (item.offset + item.width)} stroke={item.type === 'window' ? '#59a0b0' : '#fff'} strokeWidth={(Number.isFinite(linked.thickness) ? linked.thickness : .12) + .025} pointerEvents="none" />;
            })}
          </svg></div>
          <div className="se-legend"><span><i className="se-wall-dot" />墙体</span><span><i className="se-door-dot" />门洞</span><span><i className="se-window-dot" />窗洞</span></div>
          <p className="se-help">X、Z 坐标范围为 0–100 米。点选图中的墙或房间。墙段与房间轮廓分别编辑，移动墙体后请核对相邻房间的顶点。</p>
        </section>
        <section className="se-controls">
          <div className="se-tabs" aria-label="编辑对象"><button className={section === 'wall' ? 'is-active' : ''} aria-pressed={section === 'wall'} onClick={() => setSection('wall')}>墙体与门窗</button><button className={section === 'room' ? 'is-active' : ''} aria-pressed={section === 'room'} onClick={() => setSection('room')}>房间轮廓</button></div>
          <div className="se-controls-scroll">
            <NumberField label="房屋层高" value={draft.height} min={2} max={6} onChange={height => setDraft(current => ({ ...current, height, walls: current.walls.map(item => ({ ...item, height })) }))} />
            {section === 'wall' ? <>
              <label className="se-field"><span>选择墙段</span><select aria-label="选择墙段" value={wallId} onChange={event => setWallId(event.target.value)}>{draft.walls.map(item => <option key={item.id} value={item.id}>{item.id}</option>)}</select></label>
              {wall ? <>
                <div className="se-section-title"><h3>墙段坐标</h3><span>长度 {Number.isFinite(wallLength(wall)) ? wallLength(wall).toFixed(2) : '—'} m</span></div>
                <div className="se-field-grid">{(['start', 'end'] as const).flatMap((edge, edgeIndex) => ([0, 1] as const).map(axis => <NumberField key={`${edge}-${axis}`} label={`${edgeIndex === 0 ? '起点' : '终点'} ${axis === 0 ? 'X' : 'Z'}`} value={wall[edge][axis]} min={0} max={100} onChange={value => { const point: Point = [...wall[edge]]; point[axis] = value; patchWall({ [edge]: point }); }} />))}<NumberField label="墙体厚度" value={wall.thickness} min={.02} max={2} onChange={thickness => patchWall({ thickness })} /></div>
                <div className="se-section-title"><h3>门窗开口</h3><span>{openings.length} 个</span></div>
                <div className="se-add-buttons"><button onClick={() => addOpening('door')}><Plus size={14} />添加门洞</button><button onClick={() => addOpening('window')}><Plus size={14} />添加窗洞</button></div>
                {!openings.length && <p className="se-empty"><DoorOpen size={22} />这段墙还没有门窗开口</p>}
                {openings.map((item, index) => <div className="se-opening" key={item.id}><div className="se-opening-heading"><strong>{item.type === 'door' ? '门洞' : '窗洞'} {index + 1}</strong><button className="se-icon-button" aria-label={`删除${item.type === 'door' ? '门洞' : '窗洞'}${index + 1}`} onClick={() => setDraft(current => ({ ...current, openings: current.openings.filter(candidate => candidate.id !== item.id) }))}><Trash2 size={15} /></button></div><div className="se-field-grid"><NumberField label="距墙起点" value={item.offset} min={0} onChange={offset => patchOpening(item.id, { offset })} /><NumberField label="开口宽度" value={item.width} min={.01} onChange={width => patchOpening(item.id, { width })} /><NumberField label="开口高度" value={item.height} min={.01} onChange={height => patchOpening(item.id, { height })} />{item.type === 'window' && <NumberField label="窗台高度" value={item.sill ?? 0} min={0} onChange={sill => patchOpening(item.id, { sill })} />}</div></div>)}
                <p className="se-help">偏移从所选墙段的起点量起，表示开口左边缘到起点的距离。</p>
              </> : <p className="se-empty">当前模型没有可编辑墙段。</p>}
            </> : <>
              <label className="se-field"><span>选择房间</span><select aria-label="选择房间" value={roomId} onChange={event => setRoomId(event.target.value)}>{draft.rooms.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
              {room ? <><label className="se-field"><span>房间名称</span><input value={room.name} maxLength={40} onChange={event => patchRoom({ name: event.target.value })} /></label><div className="se-section-title"><h3>轮廓顶点</h3><span>{Number.isFinite(polygonArea(room.polygon)) ? polygonArea(room.polygon).toFixed(2) : '—'} m²</span></div><p className="se-help">按轮廓顺序输入坐标，范围为 0–100 米，首尾自动闭合。面积随顶点变化重新计算。</p><div className="se-vertices">{room.polygon.map((point, index) => <div className="se-vertex" key={index}><span className="se-vertex-number">{index + 1}</span>{([0, 1] as const).map(axis => <NumberField key={axis} label={axis === 0 ? 'X' : 'Z'} value={point[axis]} min={0} max={100} onChange={value => { const polygon = room.polygon.map(candidate => [...candidate] as Point); polygon[index][axis] = value; patchRoom({ polygon, area: polygonArea(polygon) }); }} />)}</div>)}</div></> : <p className="se-empty">当前模型没有房间轮廓。</p>}
            </>}
            {notice && <p className="se-notice" role="status">{notice}</p>}
            {errors.length > 0 && <div className="se-errors" role="alert"><strong>请检查模型参数</strong><ul>{errors.slice(0, 8).map(error => <li key={error}>{error}</li>)}</ul>{errors.length > 8 && <p>还有 {errors.length - 8} 项，请逐项修正。</p>}</div>}
          </div>
        </section>
      </div>
      <footer className="se-footer"><span>保存前，修改只保留在当前编辑器中</span><div><button className="se-cancel" onClick={onClose}>取消</button><button className="se-save" onClick={save} disabled={errors.length > 0}><Check size={17} />保存模型</button></div></footer>
    </div>
  </div>;
}
