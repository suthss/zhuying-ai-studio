import test from 'node:test';
import assert from 'node:assert/strict';
import { viewer } from './helpers/viewer-module.mjs';
const { THREE, INTERIOR_EYE_HEIGHT, findInteriorStandingPoint, applyInteriorAngles } = viewer;

const close = (a,b,tolerance=1e-9) => assert.ok(Math.abs(a-b)<=tolerance, `${a} differs from ${b}`);
const task = () => ({stage:'unknown',plannedStage:'unknown',dueDate:''});

function fixture() {
  const model={id:'interior-test',name:'室内站点测试',width:8,depth:6,height:2.8,source:'manual',warnings:[],
    walls:[],openings:[],rooms:[{id:'room-main',name:'卧室',polygon:[[0,0],[8,0],[8,6],[0,6]],
      area:48,material:'wood',progress:0,tasks:{floor:task(),wall:task()},evidence:[]}]};
  const scene=new THREE.Scene();
  const house=new THREE.Group();scene.add(house);
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(8,6),new THREE.MeshBasicMaterial());
  floor.rotation.x=-Math.PI/2;
  floor.userData={kind:'floor',roomId:'room-main'};
  house.add(floor);
  const furniture=(size,position,kind='furniture')=>{
    const mesh=new THREE.Mesh(new THREE.BoxGeometry(...size),new THREE.MeshBasicMaterial());
    mesh.position.set(...position);
    mesh.userData={kind,roomId:'room-main'};
    house.add(mesh);
    return mesh;
  };
  return {model,scene,house,floor,furniture};
}

test('无遮挡房间找到真实地板上的站点，眼高固定为1.55米',()=>{
  const {model,house}=fixture();
  const position=findInteriorStandingPoint(model,'room-main',house);
  assert.ok(position instanceof THREE.Vector3);
  close(INTERIOR_EYE_HEIGHT,1.55);
  close(position.x,0);close(position.z,0);close(position.y,1.55);
});

test('床占据房间中心时选择床外站点，身体半径不能落在床占地内',()=>{
  const {model,house,furniture}=fixture();
  const bed=furniture([3,1,3],[0,.5,0],'bed');
  const preferred=new THREE.Vector3(0,1.55,0);
  const position=findInteriorStandingPoint(model,'room-main',house,preferred);
  assert.ok(position);
  const bounds=new THREE.Box3().setFromObject(bed);
  const clearOfBed=position.x<=bounds.min.x-.18 || position.x>=bounds.max.x+.18
    || position.z<=bounds.min.z-.18 || position.z>=bounds.max.z+.18;
  assert.ok(clearOfBed,'standing point must leave the entire bed footprint plus body radius');
  close(position.y,1.55);
  assert.deepEqual(preferred.toArray(),[0,1.55,0]);
});

test('靠近实际墙面的preferred站点被拒绝并保留墙边身体余量',()=>{
  const {model,house,furniture}=fixture();
  const wall=furniture([.2,2.8,6],[-4,1.4,0],'wall');
  wall.userData.wallId='west';
  const position=findInteriorStandingPoint(model,'room-main',house,new THREE.Vector3(-3.75,1.55,0));
  assert.ok(position);
  assert.ok(position.x+4>=.23 && 4-position.x>=.23);
  assert.ok(position.z+3>=.23 && 3-position.z>=.23);
  assert.ok(position.x>=new THREE.Box3().setFromObject(wall).max.x+.18);
});

test('已有安全站点优先保留其水平位置而非重新移动至中心，且不修改preferred',()=>{
  const {model,house}=fixture();
  const preferred=new THREE.Vector3(-2,99,1);
  const before=preferred.toArray();
  const position=findInteriorStandingPoint(model,'room-main',house,preferred);
  assert.ok(position);
  close(position.x,-2);close(position.z,1);close(position.y,1.55);
  assert.deepEqual(preferred.toArray(),before);
  assert.notStrictEqual(position,preferred);
});

test('房内没有可站地面时返回null，不能把视点放在家具内部',()=>{
  const {model,house,furniture}=fixture();
  furniture([8.2,2,6.2],[0,1,0],'full-room-obstacle');
  assert.equal(findInteriorStandingPoint(model,'room-main',house),null);
});

test('未知房间和实际地板外的房间轮廓均返回null',()=>{
  const {model,house}=fixture();
  assert.equal(findInteriorStandingPoint(model,'missing',house),null);
  model.rooms[0].polygon=[[10,10],[12,10],[12,12],[10,12]];
  assert.equal(findInteriorStandingPoint(model,'room-main',house),null);
});

test('房外preferred不能被沿用，仍可回退到有地板的安全室内位置',()=>{
  const {model,house}=fixture();
  const position=findInteriorStandingPoint(model,'room-main',house,new THREE.Vector3(30,1.55,30));
  assert.ok(position);
  assert.ok(position.x>-4 && position.x<4 && position.z>-3 && position.z<3);
  close(position.y,1.55);
});

test('缺失地板、高悬地板及无法容纳眼高的房间不产生虚构站点',()=>{
  let f=fixture();f.house.remove(f.floor);
  assert.equal(findInteriorStandingPoint(f.model,'room-main',f.house),null);
  f=fixture();f.floor.position.y=.2;
  assert.equal(findInteriorStandingPoint(f.model,'room-main',f.house),null);
  f=fixture();f.model.height=1.6;
  assert.equal(findInteriorStandingPoint(f.model,'room-main',f.house),null);
});

test('薄地毯和顶面不阻挡站点，隐藏家具不被当作实体障碍',()=>{
  const {model,house,furniture}=fixture();
  furniture([7,.02,5],[0,.03,0],'rug');
  furniture([8,.2,6],[0,1.5,0],'ceiling');
  const hidden=furniture([8,2,6],[0,1,0]);hidden.visible=false;
  const position=findInteriorStandingPoint(model,'room-main',house);
  assert.ok(position);close(position.x,0);close(position.z,0);close(position.y,1.55);
});

test('环视只改变朝向并限制俯仰至±80度，position始终保持不变',()=>{
  const camera=new THREE.PerspectiveCamera(65,1,.05,100);
  camera.position.set(1.2,1.55,-.7);
  const position=camera.position.toArray();
  applyInteriorAngles(camera,1.3,Math.PI);
  close(camera.rotation.x,Math.PI*4/9);
  close(camera.rotation.y,1.3);close(camera.rotation.z,0);
  assert.equal(camera.rotation.order,'YXZ');
  assert.deepEqual(camera.position.toArray(),position);
  applyInteriorAngles(camera,-.4,-Math.PI);
  close(camera.rotation.x,-Math.PI*4/9);close(camera.rotation.y,-.4);
  assert.deepEqual(camera.position.toArray(),position);
});

test('水平视角可完成360度环视，最终方向回到起点且站点不移动',()=>{
  const camera=new THREE.PerspectiveCamera();camera.position.set(0,1.55,0);
  const initialPosition=camera.position.toArray();
  applyInteriorAngles(camera,0,0);
  const initialDirection=camera.getWorldDirection(new THREE.Vector3());
  applyInteriorAngles(camera,Math.PI/2,0);
  const side=camera.getWorldDirection(new THREE.Vector3());
  close(side.x,-1);close(side.y,0);close(side.z,0);
  applyInteriorAngles(camera,Math.PI*2,0);
  assert.ok(camera.getWorldDirection(new THREE.Vector3()).distanceTo(initialDirection)<1e-9);
  assert.deepEqual(camera.position.toArray(),initialPosition);
});
