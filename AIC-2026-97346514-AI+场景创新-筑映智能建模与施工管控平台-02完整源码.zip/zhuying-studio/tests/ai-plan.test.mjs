import test from 'node:test';
import assert from 'node:assert/strict';
import {createAIPlanBrief, getAIPlanReview} from '../src/ai-plan.mjs';

const model = () => ({rooms:[{id:'a',name:'区域1',area:15},{id:'b',name:'区域2',area:4}],meta:{}});
const review = () => ({mode:'rebuild',status:'applied',geometryRebuilt:true,summary:'根据图纸重建',roomSuggestions:[{roomId:'a',name:'主卧',use:'bedroom',confidence:null,applied:true}],layoutSuggestions:[{roomId:'a',placement:'床头靠墙',items:['bed_double','wardrobe']}]});

test('AI 重建的未校准用途能带入初稿，不伪造置信度',()=>{
  const m=model();m.meta.aiReview=review();
  const r=getAIPlanReview(m),b=createAIPlanBrief(m,'natural');
  assert.equal(r.roomSuggestions[0].confidence,null);
  assert.equal(b.rooms[0].use,'bedroom');assert.deepEqual(b.rooms[0].items,['bed_double','wardrobe']);
  assert.equal(b.style,'natural');assert.match(b.notes,/床头靠墙/);assert.equal(m.rooms[0].name,'区域1');
});
test('失败结果不能被显示成已重建或用来覆盖用途',()=>{
  const m=model();m.meta.aiReview={...review(),status:'failed'};
  assert.equal(getAIPlanReview(m).geometryRebuilt,false);
  assert.equal(createAIPlanBrief(m).rooms[0].use,'living');
});
test('低置信度辅助建议不自动改用途',()=>{
  const m=model();m.meta.aiReview={...review(),mode:'assist',roomSuggestions:[{roomId:'a',name:'厨房',use:'kitchen',confidence:.3,applied:false}],layoutSuggestions:[]};
  assert.equal(createAIPlanBrief(m).rooms[0].use,'living');
});
test('拒绝未知房间、非法用途与非有限置信度',()=>{
  const m=model();m.meta.aiReview={...review(),roomSuggestions:[{roomId:'foreign',use:'bedroom',confidence:1},{roomId:'a',use:'unsupported',confidence:1},{roomId:'b',use:'kitchen',confidence:NaN}],layoutSuggestions:[{roomId:'foreign',items:['sofa']}]};
  assert.equal(getAIPlanReview(m).roomSuggestions.length,0);assert.equal(getAIPlanReview(m).layoutSuggestions.length,0);
});
test('过滤未知家具，保留明确空清单',()=>{
  const m=model();m.meta.aiReview={...review(),layoutSuggestions:[{roomId:'a',items:[]},{roomId:'b',items:['toilet','untrusted','toilet']}]};
  const b=createAIPlanBrief(m);assert.deepEqual(b.rooms[0].items,[]);assert.deepEqual(b.rooms[1].items,['toilet']);
});
test('已有用户问答方案优先，不被导入 metadata 重新覆盖',()=>{
  const m=model();m.meta.aiReview=review();m.designBrief={style:'minimal',residents:3,needs:['work'],notes:'用户需求',rooms:[{roomId:'a',use:'study',furnish:true,items:['desk']},{roomId:'b',use:'empty',furnish:false}]};
  assert.deepEqual(createAIPlanBrief(m),m.designBrief);
});
test('未知或损坏的导入 metadata 安全忽略',()=>{
  const m=model();m.meta.aiReview={status:'success',mode:'rebuild'};assert.equal(getAIPlanReview(m),null);
  m.meta.aiReview={...review(),issues:[null,{message:'需要核对'},{message:[]}]};assert.equal(getAIPlanReview(m).issues.length,1);
});
