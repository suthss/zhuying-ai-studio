"""Guard evaluation semantics so selective successful examples cannot inflate scores."""

import copy
import json
from pathlib import Path
import unittest

from scripts.evaluate_plan_recognition import (
    canvas_shape, evaluate_case, opening_metrics, room_metrics, summarize, wall_metrics,
)


FIXTURES = Path(__file__).resolve().parent / "fixtures" / "plan-recognition"


class RecognitionEvaluationTests(unittest.TestCase):
    def setUp(self):
        self.target = json.loads((FIXTURES / "doors-windows.json").read_text(encoding="utf-8"))
        self.case = {"id": "doors-windows", "image": "doors-windows.png",
                     "groundTruth": "doors-windows.json"}

    def test_oracle_geometry_scores_one_on_all_independent_metrics(self):
        shape = canvas_shape(self.target, self.target)
        self.assertEqual(room_metrics(self.target, self.target, shape)["targetRoomMeanIoU"], 1)
        self.assertEqual(room_metrics(self.target, self.target, shape)["roomF1AtIoU50"], 1)
        self.assertEqual(wall_metrics(self.target, self.target, shape)["wallF1"], 1)
        self.assertEqual(opening_metrics(self.target, self.target)["openingF1"], 1)

    def test_room_count_alone_cannot_hide_displaced_or_missing_rooms(self):
        shifted = copy.deepcopy(self.target)
        for room in shifted["rooms"]:
            room["polygon"] = [[x + 30, z] for x, z in room["polygon"]]
        shifted["width"] = 45
        result = room_metrics(self.target, shifted, canvas_shape(self.target, shifted))
        self.assertTrue(result["roomCountExact"])
        self.assertEqual(result["targetRoomMeanIoU"], 0)
        self.assertEqual(result["roomF1AtIoU50"], 0)
        missing = copy.deepcopy(self.target)
        missing["rooms"] = missing["rooms"][:3]
        result = room_metrics(self.target, missing, canvas_shape(self.target, missing))
        self.assertEqual(result["targetRoomMeanIoU"], .5)
        self.assertEqual(result["roomRecallAtIoU50"], .5)

    def test_opening_match_requires_correct_type_and_nearby_position(self):
        changed = copy.deepcopy(self.target)
        changed["openings"][0]["type"] = "window"
        changed["openings"][1]["offset"] += 1
        result = opening_metrics(self.target, changed)
        self.assertEqual(result["matchedOpenings"], len(self.target["openings"]) - 2)
        self.assertLess(result["openingF1"], 1)

    def test_rejections_earn_zero_in_suite_quality_metrics(self):
        def oracle(_image, **_kwargs):
            return copy.deepcopy(self.target)

        def rejected(_image, **_kwargs):
            raise ValueError("controlled rejection")

        summary = summarize([evaluate_case(oracle, FIXTURES, self.case),
                             evaluate_case(rejected, FIXTURES, self.case)])
        self.assertEqual(summary["parsedCases"], 1)
        self.assertEqual(summary["rejectedCases"], 1)
        self.assertEqual(summary["roomCountExactRateIncludingRejections"], .5)
        self.assertEqual(summary["targetRoomMeanIoUIncludingRejections"], .5)
        self.assertEqual(summary["meanOpeningF1IncludingRejections"], .5)


if __name__ == "__main__":
    unittest.main()
