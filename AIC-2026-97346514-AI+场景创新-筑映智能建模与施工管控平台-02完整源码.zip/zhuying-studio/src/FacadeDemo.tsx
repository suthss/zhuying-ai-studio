import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Camera, Check, ChevronLeft, ChevronRight, Download, ExternalLink, Eye, EyeOff, Image, Layers3, LoaderCircle, RotateCcw, ScanLine, Sparkles, X } from 'lucide-react';
import BrandMark from './BrandMark';
import { validateFacadeSample, summarizeFacade, planAtDate, evaluateFacade, createFacadeReport } from './facade-progress.mjs';
import type { FacadeSample, FacadeObservation, FacadePlan, FacadeStatus } from './facade-progress.mjs';
import './facade-demo.css';

const STEPS = ['影像回放', '安装核对', '计划对照', '报告导出'];
const STATUS_LABEL: Record<FacadeStatus, string> = { installed: '已安装', not_installed: '未安装', unknown: '无法判断' };
type AIReview = { source: string; summary: string; stage: 'raw'|'partial'|'unknown'; regions: { id: string; status: FacadeStatus; evidence: string }[]; needsReview: true };
const STORE = 'zhuying-facade-demo-v1';
function downloadReport(body: unknown) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(body, null, 2)], { type: 'application/json' }));
  const link = document.createElement('a'); link.href = url; link.download = '筑映-外立面监控样例.json'; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function EvidenceImage({ observation, overlay, active, onRegion }: { observation: FacadeObservation; overlay: boolean; active: string; onRegion: (id: string) => void }) {
  return <div className="facade-image-frame"><img src={observation.image} alt={`${observation.dateLabel}施工立面原始画面`} draggable={false}/>{overlay && <svg className="facade-image-overlay" viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-label="可见安装单元标注">{observation.regions.map(region => <polygon key={region.id} points={region.polygon.map(p => `${p[0]*1000},${p[1]*1000}`).join(' ')} className={`${region.status} ${active===region.id?'active':''}`} role="button" tabIndex={0} aria-label={`${region.label}，${STATUS_LABEL[region.status]}`} onClick={()=>onRegion(region.id)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onRegion(region.id)}}}><title>{region.label}：{STATUS_LABEL[region.status]}</title></polygon>)}</svg>}</div>;
}
function FacadeModel({ observation, active, onRegion }: { observation: FacadeObservation; active: string; onRegion: (id: string)=>void }) {
  const rows = Math.ceil(observation.regions.length/3);
  return <div className="facade-model"><svg viewBox="0 0 660 440" role="img" aria-label="可见安装单元的轴测示意，非测绘模型"><defs><pattern id="facade-model-grid" width="30" height="18" patternUnits="userSpaceOnUse"><path d="M 30 0 L 0 0 0 18" fill="none" stroke="#d8d2c7" strokeWidth=".6"/></pattern></defs><path d="M20 325L355 135 650 292 320 435Z" fill="url(#facade-model-grid)"/><path d="M151 310L460 379 565 291 257 222Z" fill="#c5beb0"/><path d="M460 379V100L565 35V291Z" fill="#aaa596"/><path d="M151 310V31L460 100V379Z" fill="#e7e2d7"/><path d="M151 31L260 2 565 35 460 100Z" fill="#fffdf8"/>{observation.regions.map((region,index)=>{
    const col=index%3,row=Math.floor(index/3), cellH=260/rows;
    const x=164+col*96,y=46+row*cellH+col*21.3;
    return <polygon key={region.id} points={`${x},${y} ${x+84},${y+18.7} ${x+84},${y+18.7+cellH-10} ${x},${y+cellH-10}`} className={`${region.status} ${active===region.id?'active':''}`} role="button" tabIndex={0} aria-label={`示意单元${region.label}，${STATUS_LABEL[region.status]}`} onClick={()=>onRegion(region.id)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onRegion(region.id)}}}/>;
  })}<path d="M151 310V31L460 100V379" fill="none" stroke="#7f7c71" strokeWidth="2"/><text x="342" y="422" textAnchor="middle">标定单元状态示意 · 非测绘模型</text></svg></div>;
}
function ProgressChart({ sample, plan, selected, onSelect }: { sample: FacadeSample; plan: FacadePlan; selected: string; onSelect: (id:string)=>void }) {
  const dates = sample.observations.map(o=>Date.parse(o.date+'T00:00:00Z'));
  const first = Math.min(...dates), last = Math.max(...dates), span = Math.max(86400000,last-first);
  const x = (date: string)=>46+(Date.parse(date+'T00:00:00Z')-first)/span*510;
  const y = (value: number)=>172-value*1.4;
  const actual=sample.observations.map(o=>({o,s:summarizeFacade(o)}));
  const points=actual.map(({o,s})=>`${x(o.date)},${y(s.lower)}`).join(' ');
  const range=[...actual.map(({o,s})=>`${x(o.date)},${y(s.upper)}`),...actual.slice().reverse().map(({o,s})=>`${x(o.date)},${y(s.lower)}`)].join(' ');
  const ticks=first===last?[first]:[first,(first+last)/2,last];
  return <svg className="facade-chart" viewBox="0 0 600 214" role="img" aria-label="可见单元安装率与模拟计划曲线"><title>已确认安装率与模拟计划，阴影为未知单元区间</title>{[0,25,50,75,100].map(value=><g key={value}><line x1="46" x2="556" y1={y(value)} y2={y(value)} stroke="var(--fd-line)"/><text x="32" y={y(value)+4} textAnchor="end">{value}%</text></g>)}<polygon points={range} fill="var(--fd-unknown-range)"/><polyline points={sample.observations.map(o=>`${x(o.date)},${y(planAtDate(plan,o.date))}`).join(' ')} fill="none" stroke="var(--fd-plan)" strokeWidth="2" strokeDasharray="6 5"/><polyline points={points} fill="none" stroke="var(--fd-installed)" strokeWidth="3"/>{actual.map(({o,s})=><g key={o.id} role="button" tabIndex={0} aria-label={`查看${o.dateLabel}安装率${s.lower.toFixed(0)}%`} onClick={()=>onSelect(o.id)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelect(o.id)}}}><circle cx={x(o.date)} cy={y(s.lower)} r={selected===o.id?6:4} fill="var(--fd-installed)" stroke="var(--fd-paper)" strokeWidth="2"/><title>{o.dateLabel}：已确认安装 {s.lower.toFixed(0)}%</title></g>)}{ticks.map(time=><text key={time} x={46+(time-first)/span*510} y="195" textAnchor="middle">{new Date(time).toISOString().slice(0,7)}</text>)}</svg>;
}

export default function FacadeDemo({ onClose }: { onClose: ()=>void }) {
  const [original,setOriginal]=useState<FacadeSample|null>(null),[error,setError]=useState('');
  const [step,setStep]=useState(0),[selected,setSelected]=useState(''),[active,setActive]=useState('');
  const [overlay,setOverlay]=useState(false),[view,setView]=useState<'photo'|'compare'|'model'>('photo');
  const [edits,setEdits]=useState<Record<string,FacadeStatus>>({}),[plan,setPlan]=useState<FacadePlan|null>(null),[asOf,setAsOf]=useState('');
  const [ai,setAI]=useState<Record<string,AIReview>>({}),[busy,setBusy]=useState(false),[aiError,setAIError]=useState(''),[configured,setConfigured]=useState(false),[toast,setToast]=useState('');
  const screen=useRef<HTMLElement>(null), previous=useRef(document.activeElement instanceof HTMLElement?document.activeElement:null),abort=useRef<AbortController|null>(null);
  useEffect(()=>{
    const controller=new AbortController();
    fetch('/facade-demo/sample.json',{signal:controller.signal}).then(r=>{if(!r.ok)throw new Error('样例资料暂未加载，请重试。');return r.json()}).then(raw=>{
      const value=validateFacadeSample(raw);setOriginal(value);setPlan(value.plan);
      const latest=value.observations.at(-1)!;setSelected(latest.id);setAsOf(latest.date);setActive(latest.regions[0]?.id??'');
      try {const stored=JSON.parse(localStorage.getItem(STORE)??'null');if(stored?.sampleId===value.id){
        const valid:Record<string,FacadeStatus>={};for(const o of value.observations)for(const r of o.regions){const state=stored.edits?.[o.id+'/'+r.id];if(typeof state==='string'&&Object.hasOwn(STATUS_LABEL,state))valid[o.id+'/'+r.id]=state as FacadeStatus;}setEdits(valid);
        if(stored.plan){validateFacadeSample({...value,plan:stored.plan});setPlan(stored.plan);}
      }}catch{/* Invalid local edits never replace the source sample. */}
    }).catch(e=>{if(e.name!=='AbortError')setError(e.message)});
    fetch('/api/health',{signal:controller.signal}).then(r=>r.json()).then(h=>setConfigured(!!h.visionConfigured)).catch(()=>{});
    screen.current?.focus();
    return()=>{controller.abort();abort.current?.abort();queueMicrotask(()=>{if(previous.current?.isConnected)previous.current.focus()})};
  },[]);
  useEffect(()=>{
    const handle=(event:KeyboardEvent)=>{
      if(event.key==='Escape'){event.preventDefault();onClose();return;}
      if(event.key!=='Tab')return;
      const nodes=Array.from(screen.current?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),summary,[tabindex="0"]')??[]).filter(el=>el.getClientRects().length);
      const first=nodes[0],last=nodes.at(-1);if(!first||!last)return;
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===screen.current)){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===screen.current)){event.preventDefault();first.focus();}
    };
    document.addEventListener('keydown',handle);return()=>document.removeEventListener('keydown',handle);
  },[onClose]);
  useEffect(()=>{if(original&&plan)try{validateFacadeSample({...original,plan});localStorage.setItem(STORE,JSON.stringify({sampleId:original.id,edits,plan}))}catch{}},[original,plan,edits]);
  useEffect(()=>{if(!toast)return;const timeout=setTimeout(()=>setToast(''),3500);return()=>clearTimeout(timeout)},[toast]);
  const sample=useMemo(()=>original?{...original,observations:original.observations.map(o=>({...o,regions:o.regions.map(r=>({...r,status:edits[o.id+'/'+r.id]??r.status,evidence:edits[o.id+'/'+r.id]?`原始样例依据：${r.evidence} 当前状态为本地演示人工修改，需另行核对依据。`:r.evidence}))}))}:null,[original,edits]);
  const index=sample?.observations.findIndex(o=>o.id===selected)??-1;
  const observation=sample?.observations[Math.max(0,index)],prior=sample?.observations[Math.max(0,index-1)];
  const region=observation?.regions.find(r=>r.id===active)??observation?.regions[0];
  const summary=observation?summarizeFacade(observation):null;
  let evaluation:ReturnType<typeof evaluateFacade>|null=null,planError='';
  if(sample&&plan)try{validateFacadeSample({...sample,plan});evaluation=evaluateFacade(sample,asOf,plan)}catch(e){planError=e instanceof Error?e.message:'计划日期无效。'}
  const metric=step>=2?evaluation?.actual??null:summary;
  const select=(id:string)=>{const o=sample?.observations.find(item=>item.id===id);if(!o)return;if(view==='compare'&&sample?.observations[0].id===id)setView('photo');setSelected(id);setAsOf(o.date);setActive(o.regions[0]?.id??'');setAIError('')};
  async function analyze() {
    if(!observation||busy)return;setBusy(true);setAIError('');const currentId=observation.id;
    const controller=new AbortController();abort.current=controller;const timeout=setTimeout(()=>controller.abort(),75000);
    try {const response=await fetch('/api/facade-demo/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({observationId:currentId}),signal:controller.signal});const body=await response.json();if(!response.ok)throw new Error(body.detail??'AI分析未成功，请保留人工核对。');if(body.source?.startsWith('qwen/')&&body.needsReview===true&&Array.isArray(body.regions))setAI(current=>({...current,[currentId]:body}));else throw new Error('模型未提供有效核对建议。');}
    catch(e){setAIError(e instanceof Error&&e.name==='AbortError'?'分析已取消或超时，原始标注仍保留。':e instanceof Error?e.message:'分析失败，请重试。')}
    finally{clearTimeout(timeout);setBusy(false);abort.current=null}
  }
  function currentReport(){
    if(!sample||!plan||!evaluation)return null;
    const report=createFacadeReport(sample,asOf,plan),allowed=new Set(report.observations.map(o=>o.id));
    return {...report,localReviewOverrides:Object.fromEntries(Object.entries(edits).filter(([id])=>allowed.has(id.split('/')[0]))),aiReviewSuggestions:Object.fromEntries(Object.entries(ai).filter(([id])=>allowed.has(id)))};
  }
  function exportJSON(){const report=currentReport();if(!report)return;downloadReport(report);setToast('报告已生成。若浏览器未下载，可展开报告内容复制 JSON。')}

  return <section className="facade-demo" ref={screen} role="dialog" aria-modal="true" tabIndex={-1} aria-label="外立面施工监控公开数据样例">
    <header className="facade-header">
      <div className="facade-brand"><BrandMark size={32}/><span>筑映<strong>施工观察室</strong></span></div>
      <div className="facade-header-tag"><span>真实影像</span><span>模拟计划</span></div>
      <button className="fd-button" onClick={onClose}><ArrowLeft size={16} aria-hidden="true"/>返回工作台</button>
    </header>
    {!sample||!observation||!summary||!plan ?
      <div className="facade-loading" role={error?'alert':'status'}>
        {error ? <><ScanLine size={28}/><h1>样例资料加载失败</h1><p>{error}</p><button className="fd-button" onClick={()=>window.location.reload()}>重新加载</button></> : <><LoaderCircle className="spin" size={28}/><p>正在整理时序影像与监控记录…</p></>}
      </div> : <>
      <div className="facade-heading">
        <div><h1>让施工变化，有迹可循。</h1><p>{sample.description}</p></div>
        <div className="facade-scope"><Camera size={20} aria-hidden="true"/><div><strong>{sample.title}</strong><span>固定可见立面 · 无整栋完工影像</span></div></div>
      </div>
      <nav className="facade-steps" aria-label="施工监控样例步骤">
        {STEPS.map((name,i)=><button key={name} className={step===i?'current':step>i?'passed':''} aria-current={step===i?'step':undefined} onClick={()=>{setStep(i);if(i===1)setOverlay(true)}}><span>{step>i?<Check size={15} aria-hidden="true"/>:i+1}</span>{name}<ChevronRight size={16} aria-hidden="true"/></button>)}
      </nav>
      <main className="facade-workspace">
        <section className="facade-evidence" aria-label="现场影像与日期回放">
          <div className="facade-view-tools">
            <div role="group" aria-label="影像展示方式">
              <button aria-pressed={view==='photo'} onClick={()=>setView('photo')}><Image size={16} aria-hidden="true"/>现场影像</button>
              <button aria-pressed={view==='compare'} onClick={()=>setView('compare')} disabled={index<1}><Layers3 size={16} aria-hidden="true"/>前后对照</button>
              <button aria-pressed={view==='model'} onClick={()=>setView('model')}><ScanLine size={16} aria-hidden="true"/>立面示意</button>
            </div>
            <label className="facade-date-select">日期<select aria-label="选择观察日期" value={selected} onChange={e=>select(e.target.value)}>{sample.observations.map(o=><option key={o.id} value={o.id}>{o.dateLabel}</option>)}</select></label>
            <button className="facade-overlay-toggle" aria-pressed={overlay} onClick={()=>setOverlay(value=>!value)}>{overlay?<Eye size={16} aria-hidden="true"/>:<EyeOff size={16} aria-hidden="true"/>}安装标注</button>
          </div>
          <div className={`facade-stage ${view}`}>
            {view==='photo' ? <EvidenceImage observation={observation} overlay={overlay} active={active} onRegion={setActive}/> : view==='model' ? <FacadeModel observation={observation} active={active} onRegion={setActive}/> : <>
              <div className="facade-compare-half"><EvidenceImage observation={prior!} overlay={overlay} active="" onRegion={()=>{}}/><span>前期 · {prior!.dateLabel}</span></div>
              <div className="facade-compare-half"><EvidenceImage observation={observation} overlay={overlay} active={active} onRegion={setActive}/><span>本期 · {observation.dateLabel}</span></div>
            </>}
            <span className="facade-photo-badge">{view==='model'?'状态映射 · 非测绘模型':observation.stage==='raw'?'裸框架阶段':'部分安装阶段'}</span>
          </div>
          <div className="facade-photo-caption">
            <div><strong>{observation.dateLabel}</strong><span>{observation.summary}</span></div>
            <div className="facade-image-arrows"><button aria-label="查看前一期影像" disabled={index<=0} onClick={()=>select(sample.observations[index-1].id)}><ChevronLeft size={20}/></button><button aria-label="查看后一期影像" disabled={index>=sample.observations.length-1} onClick={()=>select(sample.observations[index+1].id)}><ChevronRight size={20}/></button></div>
          </div>
          <div className="facade-filmstrip" aria-label="典型施工时序画面">{sample.observations.map(o=><button key={o.id} className={o.id===selected?'selected':''} aria-pressed={o.id===selected} onClick={()=>select(o.id)}><img src={o.image} alt="" loading="lazy"/><span>{o.dateLabel}<small>{o.stage==='raw'?'裸框架':'部分安装'}</small></span></button>)}</div>
          <details className="facade-date-note"><summary>本帧影像出处<ChevronRight size={15} aria-hidden="true"/></summary><p>{observation.dateSource} · 原始视频 {observation.sourceFile} · 抽帧 {observation.frameSeconds.toFixed(1)} 秒{view==='compare'?'；前后画面未进行几何配准。':''}</p></details>
        </section>
        <aside className="facade-inspector" aria-label={STEPS[step]}>
          <div className="facade-step-intro" key={step}>
            <h2>{['先选一个观察时点','核对每一个可见单元','对照模拟计划','保存这次观察'][step]}</h2>
            <p>{['选择日期，比较前后画面的变化。','点击画面标注或选择区域，逐项确认。','调整计划与截至日期，查看证据偏差。','保留来源、核对结果与计划，供后续复核。'][step]}</p>
          </div>
          <div className="facade-install-summary">
            {metric ? <>
              <div><span>{step>=2?'截至日期已确认安装':'本期已确认安装'}</span><strong>{metric.lower.toFixed(0)}<small>%</small></strong></div>
              <div><span>可判断单元</span><strong>{metric.total-metric.unknown}<small> / {metric.total}</small></strong></div>
              <div className="facade-install-track"><i style={{width:`${metric.lower}%`}}/><b style={{left:`${metric.lower}%`,width:`${metric.upper-metric.lower}%`}}/></div>
              <p>{metric.installed} 已安装 · {metric.notInstalled} 未安装 · {metric.unknown} 待核对{metric.unknown>0?<span className="facade-unknown-range">未知区间 {metric.lower.toFixed(0)}–{metric.upper.toFixed(0)}%</span>:null}</p>
              {index>0&&step<2&&summary.lower<summarizeFacade(prior!).lower&&<p>本期无法判断区域增加，已确认比例降低不代表施工倒退。</p>}
            </> : <p>截至日期尚无影像证据，安装率未知。当前样例帧不计入该日状态。</p>}
          </div>
          {step===0&&<div className="facade-observation-note">
            <h3>下一步，核对安装状态</h3><p>查看玻璃安装，遮挡或不清晰的区域保留“无法判断”。</p>
            <details className="facade-details"><summary>如何理解这组记录<ChevronRight size={15} aria-hidden="true"/></summary><ul><li>实拍画面提供外观变化依据。</li><li>标定单元等权计数，不换算真实工程量。</li><li>现有序列没有整栋建筑完工证据。</li></ul></details>
            <a href={sample.dataset.url} target="_blank" rel="noreferrer">查看原始数据集<ExternalLink size={15} aria-hidden="true"/></a>
          </div>}
          {step===1&&region&&<>
            <div className="facade-region-editor">
              <label>核对区域<select aria-label="选择标定安装单元" value={region.id} onChange={e=>setActive(e.target.value)}>{observation.regions.map(r=><option key={r.id} value={r.id}>{r.label}</option>)}</select></label>
              <div className="facade-region-evidence"><span className={`facade-dot ${region.status}`}/><strong>{STATUS_LABEL[region.status]}</strong><small>{edits[observation.id+'/'+region.id]?'本地演示修改':'样例人工标注'}</small></div>
              <details className="facade-details"><summary>查看标注依据<ChevronRight size={15} aria-hidden="true"/></summary><p>{region.evidence}</p></details>
              <div className="facade-status-choices">{(Object.keys(STATUS_LABEL) as FacadeStatus[]).map(status=><button key={status} className={status} aria-pressed={region.status===status} onClick={()=>setEdits(current=>({...current,[observation.id+'/'+region.id]:status}))}>{STATUS_LABEL[status]}</button>)}</div>
              <button className="facade-text-button" onClick={()=>setEdits(current=>{const next={...current};delete next[observation.id+'/'+region.id];return next})}><RotateCcw size={14} aria-hidden="true"/>恢复原始标注</button>
            </div>
            <div className="facade-ai">
              <h3><Sparkles size={17} aria-hidden="true"/>AI 独立复核</h3><p>点击后调用千问，建议仍需你确认。</p>
              <details className="facade-details"><summary>发送哪些影像<ChevronRight size={15} aria-hidden="true"/></summary><p>仅发送当前公开样例原图、编号图和区域裁切图至已配置千问。请对照实拍，逐项确认是否采用建议。</p></details>
              <button className="fd-button" disabled={!configured||busy} onClick={()=>void analyze()}>{busy?<LoaderCircle className="spin" size={16}/>:<Sparkles size={16} aria-hidden="true"/>}{busy?'正在分析当前影像…':configured?'请 AI 复核此帧':'连接视觉模型后可复核'}</button>
              {busy&&<button className="facade-text-button" onClick={()=>abort.current?.abort()}>取消等待</button>}
              {aiError&&<p className="facade-error" role="alert">{aiError}</p>}
              {ai[observation.id]&&<div className="facade-ai-result"><small>{ai[observation.id].source} · 待人工确认</small><p>{ai[observation.id].summary}</p>{ai[observation.id].regions.filter(r=>r.id===region.id).map(r=><div key={r.id}><strong>当前单元建议：{STATUS_LABEL[r.status]}</strong>{r.status!==region.status&&<span className="facade-ai-disagreement">与当前标注不同，请对照实拍再确认。</span>}<p>{r.evidence}</p><button className="facade-text-button" onClick={()=>setEdits(current=>({...current,[observation.id+'/'+r.id]:r.status}))}>确认采用该单元建议</button></div>)}</div>}
            </div>
          </>}
          {step===2&&<>
            <div className="facade-plan-fields">
              <strong>模拟计划 · 可调整</strong>
              <div><label>计划开始<input aria-label="模拟计划开始日期" type="date" value={plan.startDate} onChange={e=>setPlan({...plan,startDate:e.target.value})}/></label><label>计划完成<input aria-label="模拟计划完成日期" type="date" value={plan.endDate} onChange={e=>setPlan({...plan,endDate:e.target.value})}/></label></div>
              <label>目标安装率<input aria-label="模拟计划目标安装率" type="number" min="1" max="100" value={plan.targetPercent} onChange={e=>setPlan({...plan,targetPercent:Number(e.target.value)})}/><span>%</span></label>
              <label>监控截至<input aria-label="监控截至日期" type="date" value={asOf} onChange={e=>setAsOf(e.target.value)}/></label>
              <details className="facade-details"><summary>关于模拟计划<ChevronRight size={15} aria-hidden="true"/></summary><p>计划由样例人为设定。偏差只用于演示预警，不代表该工地真实延期；安装率不是整体施工进度。</p></details>
            </div>
            {planError?<p className="facade-error" role="alert">{planError}</p>:evaluation&&<div className="facade-alerts">
              <div className="facade-gap"><span>模拟计划要求</span><strong>{evaluation.planned.toFixed(0)}%</strong><span>已确认安装与计划相差</span><strong>{evaluation.gap===null?'暂无证据':`${evaluation.gap>0?'+':''}${evaluation.gap.toFixed(0)} 个百分点`}</strong></div>
              {evaluation.alerts.map((alert,i)=><p key={i} className={alert.kind==='stale'?'stale':'deviation'}>{alert.message}</p>)}
              {evaluation.alerts.length===0&&<p className="ontrack">当前证据未触发演示告警。</p>}
              {evaluation.scenario&&<p className="facade-scenario">{evaluation.scenario.label}</p>}
              <small>截至 {asOf} · 采用 {evaluation.observation?.dateLabel??'尚无'} 的证据</small>
            </div>}
          </>}
          {step===3&&<div className="facade-report">
            <label>报告截至日期<input aria-label="报告截至日期" type="date" value={asOf} onChange={e=>setAsOf(e.target.value)}/></label>
            {planError&&<p className="facade-error" role="alert">{planError}</p>}
            <button className="fd-button primary" onClick={exportJSON} disabled={!evaluation}><Download size={17} aria-hidden="true"/>导出本次监控报告</button>
            <p>JSON 格式 · 核对与计划自动保存在本机</p>
            <details className="facade-details"><summary>报告包含哪些信息<ChevronRight size={15} aria-hidden="true"/></summary><ol><li>真实影像、视频出处与抽帧位置</li><li>固定可见单元状态与未知区间</li><li>人工核对及 AI 参考建议</li><li>模拟计划、偏差告警与使用局限</li></ol><p>报告可复核数据与计算；下次进入可继续本地核对。</p></details>
            <details className="facade-report-preview"><summary>查看或复制 JSON<ChevronRight size={15} aria-hidden="true"/></summary><textarea readOnly aria-label="监控报告JSON" value={evaluation?JSON.stringify(currentReport(),null,2):'请先填写有效截至日期与计划。'} rows={12}/></details>
            <button className="facade-text-button" disabled={busy} title={busy?'请先取消 AI 等待，再重置记录':undefined} onClick={()=>{setEdits({});setPlan(original!.plan);setAI({});setAIError('');setToast('本地样例修改已恢复为原始记录。')}}><RotateCcw size={14} aria-hidden="true"/>重置演示记录</button>
          </div>}
          <footer className="facade-step-footer"><button className="fd-button" disabled={step===0} onClick={()=>setStep(value=>value-1)}><ArrowLeft size={16} aria-hidden="true"/>上一步</button>{step<3?<button className="fd-button primary" onClick={()=>{setStep(value=>value+1);if(step===0)setOverlay(true)}}>{STEPS[step+1]}<ArrowRight size={16} aria-hidden="true"/></button>:<button className="fd-button" onClick={onClose}>返回工作台</button>}</footer>
        </aside>
      </main>
      <section className="facade-trend"><div><h2>变化，沿着时间展开。</h2><p>告警与报告仅使用截至日期已有的证据。</p><div className="facade-legend"><span><i className="actual"/>已确认安装</span><span><i className="planned"/>模拟计划</span><span><i className="unknown"/>未知区间</span></div></div><ProgressChart sample={sample} plan={planError?original!.plan:plan} selected={selected} onSelect={select}/></section>
      <footer className="facade-sources"><details><summary>影像来源、许可与演示边界<ChevronRight size={16} aria-hidden="true"/></summary><p><a href={sample.dataset.url} target="_blank" rel="noreferrer">{sample.dataset.title}</a>，{sample.dataset.creator}，<a href={sample.dataset.licenseUrl} target="_blank" rel="noreferrer">{sample.dataset.license}</a>。{sample.annotation.label}</p><p>{sample.annotation.scope}原数据无安装量真值和真实施工计划；图上区域由本项目标定，未进行准确率评测。状态示意不是从照片恢复的精密建筑模型，模拟预警未验证真实延期预测效果。</p></details><span>本样例独立保存，不改动当前房屋项目。</span></footer>
    </>}
    {toast&&<div className="facade-toast" role="status"><Check size={17} aria-hidden="true"/>{toast}<button aria-label="关闭提示" onClick={()=>setToast('')}><X size={16}/></button></div>}
  </section>;
}
