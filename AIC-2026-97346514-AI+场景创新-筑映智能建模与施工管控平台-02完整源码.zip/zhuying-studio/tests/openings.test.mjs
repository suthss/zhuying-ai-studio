import test from 'node:test';
import assert from 'node:assert/strict';
import { doorStyles, windowStyles, resolveOpeningDesign, updateOpening, getOpeningErrors,
  getRoomOpenings, isOpeningDesign, doorLeafPose } from '../src/openings.mjs';

const task=()=>({stage:'in_progress',plannedStage:'complete',dueDate:'2026-10-04'});
const room=(id,polygon)=>({id,name:id,polygon,area:16,material:'wood',progress:50,
  tasks:{floor:task(),wall:task()},evidence:[]});
const door=(id='d1',patch={})=>({id,wallId:'partition',type:'door',offset:1,width:1,height:2.1,...patch});
const windowOpening=(id='w1',patch={})=>({id,wallId:'north',type:'window',offset:1,width:1.2,height:1.2,sill:.9,...patch});
const model=()=>({id:'opening-test',name:'测试',width:8,depth:4,height:2.8,source:'demo',warnings:[],
  walls:[{id:'north',start:[0,0],end:[8,0],thickness:.2},
         {id:'partition',start:[4,0],end:[4,4],thickness:.2}],
  openings:[door(),windowOpening()],rooms:[
    room('left',[[.1,.1],[3.9,.1],[3.9,3.9],[.1,3.9]]),
    room('right',[[4.1,.1],[7.9,.1],[7.9,3.9],[4.1,3.9]])],meta:{demoData:true}});
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-9,`${a} differs from ${b}`);

test('门窗预设按类型区分，旧开口默认闭合且不修改原数据',()=>{
  assert.deepEqual(doorStyles.map(s=>s.id),['flush','panel','glass']);
  assert.deepEqual(windowStyles.map(s=>s.id),['fixed','casement','sliding']);
  const d=door(),w=windowOpening(),before=structuredClone([d,w]);
  assert.deepEqual(resolveOpeningDesign(d),{color:'#c9b99b',style:'panel',openAngle:0,hinge:'start',swing:1,glassTint:'clear'});
  assert.deepEqual(resolveOpeningDesign(w),{color:'#596b63',style:'fixed',openAngle:0,hinge:'start',swing:1,glassTint:'clear'});
  assert.deepEqual([d,w],before);
});

test('设计校验限制门窗款式、颜色、开启角度与固定或推拉窗开启方式',()=>{
  const d=resolveOpeningDesign(door()),w=resolveOpeningDesign(windowOpening());
  assert.ok(isOpeningDesign({...d,openAngle:100},'door'));
  assert.ok(isOpeningDesign({...w,style:'casement',openAngle:60},'window'));
  for(const patch of [{style:'fixed'},{openAngle:101},{openAngle:-1},{openAngle:NaN},{openAngle:'60'},
    {color:'red'},{color:'#fff'},{hinge:'left'},{swing:0},{glassTint:'opaque'}]) {
    assert.equal(isOpeningDesign({...d,...patch},'door'),false);
  }
  for(const patch of [{style:'panel'},{openAngle:1},{style:'sliding',openAngle:1},
    {style:'casement',openAngle:61}]) assert.equal(isOpeningDesign({...w,...patch},'window'),false);
  assert.equal(isOpeningDesign(null,'door'),false);
});

test('门窗编辑只修改目标开口，工序、来源、房间设计与证据保持不变',()=>{
  const m=model(),before=structuredClone(m);
  const next=updateOpening(m,'d1',{width:1.1,offset:.8,design:{...resolveOpeningDesign(m.openings[0]),color:'#aabbcc'}});
  assert.equal(next.openings[0].width,1.1);
  assert.equal(next.openings[0].design.color,'#aabbcc');
  assert.deepEqual(next.openings[1],m.openings[1]);
  assert.deepEqual(next.rooms,m.rooms);
  assert.equal(next.source,'demo');
  assert.deepEqual(next.meta,m.meta);
  assert.deepEqual(m,before);
});

test('参数边界与墙体有效高度被校验，错误编辑不能改变原模型',()=>{
  const m=model(),before=structuredClone(m);
  for(const patch of [{width:-1},{width:.08},{width:Infinity},{offset:-.1},{offset:3.5},
    {height:3},{wallId:'missing'},{sill:.2}]) assert.throws(()=>updateOpening(m,'d1',patch));
  for(const patch of [{sill:-.1},{sill:2},{height:NaN}]) assert.throws(()=>updateOpening(m,'w1',patch));
  m.walls[0].height=1.5;
  assert.ok(getOpeningErrors(m,m.openings[1]).some(message=>message.includes('墙高')));
  const short=updateOpening(m,'w1',{height:.5,sill:1});
  assert.equal(getOpeningErrors(short,short.openings[1]).length,0);
  assert.deepEqual({...m,walls:before.walls},before);
  assert.throws(()=>updateOpening(m,'missing',{width:1}));
});

test('同一墙面横向且高度区间都相交的开口被阻止，边界接触合法',()=>{
  const m=model();m.openings.push(door('d2',{offset:1.5}));
  assert.ok(getOpeningErrors(m,m.openings[0]).some(error=>error.includes('重叠')));
  assert.throws(()=>updateOpening(m,'d2',{offset:1.2}));
  const separate=updateOpening(m,'d2',{offset:2});
  assert.equal(getOpeningErrors(separate,separate.openings[0]).length,0);
  assert.equal(getOpeningErrors(separate,separate.openings[2]).length,0);
});

test('上下分离的窗洞允许横向重合，重叠校验与所在墙无关项隔离',()=>{
  const m=model();m.openings=[windowOpening('low',{height:.6,sill:.2}),windowOpening('high',{height:.6,sill:.8})];
  assert.equal(getOpeningErrors(m,m.openings[0]).length,0);
  assert.equal(getOpeningErrors(m,m.openings[1]).length,0);
  const conflict={...m.openings[1],sill:.7};
  assert.ok(getOpeningErrors(m,conflict).some(error=>error.includes('重叠')));
  const otherWall={...conflict,wallId:'partition'};
  assert.equal(getOpeningErrors(m,otherWall).length,0);
});

test('开口按墙边距离与沿墙区间归属相邻房间，共用门属于两侧房间',()=>{
  const m=model();
  assert.deepEqual(getRoomOpenings(m,'left').map(o=>o.id),['d1','w1']);
  assert.deepEqual(getRoomOpenings(m,'right').map(o=>o.id),['d1']);
  assert.deepEqual(getRoomOpenings(m,'missing'),[]);
  m.openings[1].offset=5;
  assert.deepEqual(getRoomOpenings(m,'left').map(o=>o.id),['d1']);
  assert.deepEqual(getRoomOpenings(m,'right').map(o=>o.id),['d1','w1']);
});

test('相邻判定支持反向和斜向墙，且远处平行墙不误分给房间',()=>{
  const m=model();m.walls[0]={id:'north',start:[8,0],end:[0,0],thickness:.2};
  assert.deepEqual(getRoomOpenings(m,'right').map(o=>o.id),['d1','w1']);
  assert.deepEqual(getRoomOpenings(m,'left').map(o=>o.id),['d1']);
  m.walls=[{id:'diag',start:[0,0],end:[4,4],thickness:.1},
           {id:'far',start:[0,6],end:[4,10],thickness:.1}];
  m.openings=[door('near',{wallId:'diag'}),door('far',{wallId:'far'})];
  m.rooms=[room('triangle',[[0,0],[4,4],[4,0]])];
  assert.deepEqual(getRoomOpenings(m,'triangle').map(o=>o.id),['near']);
});

test('两种铰链闭合门叶端点都在框内，门叶中心与墙局部坐标一致',()=>{
  for(const hinge of ['start','end']) {
    const d=door('d1',{offset:1.2,width:1.1,design:{...resolveOpeningDesign(door()),hinge}});
    const p=doorLeafPose(d);
    close(p.leafWidth,1.1-.09);
    close(p.pivotZ,0);
    close(p.centerX,1.2+1.1/2);
    close(p.centerZ,0);
    const freeX=p.pivotX+Math.cos(p.rotation)*p.leafWidth;
    close(Math.min(p.pivotX,freeX),1.2+.045);
    close(Math.max(p.pivotX,freeX),1.2+1.1-.045);
    close(hinge==='start'?p.rotation:p.rotation-Math.PI,0);
  }
});

test('起止铰链均遵循swing方向开门，90度门叶法向正确且不重复旋转中心',()=>{
  for(const hinge of ['start','end']) for(const swing of [-1,1]) {
    const d=door('d1',{design:{...resolveOpeningDesign(door()),hinge,swing,openAngle:90}});
    const p=doorLeafPose(d);
    close(p.centerX,p.pivotX);
    close(p.centerZ,swing*p.leafWidth/2);
    const freeZ=p.pivotZ-Math.sin(p.rotation)*p.leafWidth;
    close(freeZ,swing*p.leafWidth);
  }
  assert.throws(()=>doorLeafPose(windowOpening()));
});
