import type { HouseModel, Point } from './types';

export interface ProjectMetadata {
  id: string; name: string; location: string; status: 'active' | 'archived';
  revision: number; createdAt: string; updatedAt: string;
}
export interface ProjectSummary extends ProjectMetadata {
  stats: { roomCount: number; area: number; completed: number; known: number; total: number;
    unknown: number; overdue: number; latestInspectionDate: string | null; demo: boolean };
  preview: { width: number; depth: number; rooms: { id: string; name: string; polygon: Point[] }[];
    walls: { start: Point; end: Point }[] };
}
export interface ProjectRecord extends ProjectMetadata { model: HouseModel }
export class LibraryError extends Error {
  constructor(message: string, public status = 0) { super(message); }
}
async function request<T>(path: string, method = 'GET', body?: unknown): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`/api/projects${path}`, { method, headers: body ? { 'Content-Type': 'application/json' } : {},
      body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20000) });
  } catch { throw new LibraryError('项目库连接失败，草稿已留在本机。请恢复服务后重试，或导出项目。'); }
  let data;
  try { data = await response.json(); }
  catch { throw new LibraryError('项目库返回异常，请确认后端已更新并重新启动。', response.status); }
  if (!response.ok) {
    const message = typeof data.detail === 'string' ? data.detail : data.detail?.message;
    throw new LibraryError(message || '项目库操作失败，请重试。', response.status);
  }
  return data;
}
export const listProjects = () => request<{ projects: ProjectSummary[]; changeVersion: number; serverTime: string }>('');
export const getProject = (id: string) => request<ProjectRecord>(`/${encodeURIComponent(id)}`);
export const createProject = (model: HouseModel, clientKey: string, location = '') => request<ProjectRecord>('', 'POST', { model, clientKey, location });
export const updateProject = (id: string, revision: number, patch: { model?: HouseModel; name?: string; location?: string; status?: 'active' | 'archived' }) =>
  request<ProjectRecord>(`/${encodeURIComponent(id)}`, 'PUT', { revision, ...patch });

export interface WorkspaceDraft {
  model: HouseModel; record: ProjectMetadata | null; baseline: string | null; clientKey: string;
}
let databasePromise: Promise<IDBDatabase> | null = null;
function workspaceDatabase() {
  databasePromise ??= new Promise<IDBDatabase>((resolve, reject) => {
    const opening = indexedDB.open('zhuying-workspaces-v1', 1);
    opening.onupgradeneeded = () => { opening.result.createObjectStore('sessions'); };
    opening.onsuccess = () => resolve(opening.result);
    opening.onerror = () => { databasePromise = null; reject(opening.error); };
    opening.onblocked = () => { databasePromise = null; reject(new Error('本机草稿库被其他窗口占用。')); };
  });
  return databasePromise;
}
export function workspaceSessionKey() {
  try {
    let key = sessionStorage.getItem('zhuying-workspace-session');
    if (!key) { key = crypto.randomUUID(); sessionStorage.setItem('zhuying-workspace-session', key); }
    return key;
  } catch { return 'current'; }
}
let sessionClaim: Promise<{ key: string; restoreKey: string }> | null = null;
export function acquireWorkspaceSession() {
  sessionClaim ??= new Promise(resolve => {
    const original = workspaceSessionKey();
    const finish = (owned: boolean) => {
      const key = owned ? original : crypto.randomUUID();
      try { sessionStorage.setItem('zhuying-workspace-session', key); } catch { /* Draft still lives in IndexedDB. */ }
      resolve({ key, restoreKey: original });
    };
    if (!navigator.locks) { finish(true); return; }
    // A duplicated tab inherits sessionStorage. Claiming the workspace prevents its
    // independent edits from overwriting the first tab's offline draft.
    void navigator.locks.request(`zhuying-workspace:${original}`, { ifAvailable: true }, lock => {
      if (!lock) { finish(false); return; }
      finish(true);
      return new Promise<void>(release => window.addEventListener('pagehide', () => release(), { once: true }));
    }).catch(() => finish(true));
  });
  return sessionClaim;
}
export async function readWorkspace(key: string): Promise<WorkspaceDraft | undefined> {
  const database = await workspaceDatabase();
  return new Promise((resolve, reject) => {
    const reading = database.transaction('sessions', 'readonly').objectStore('sessions').get(key);
    reading.onsuccess = () => resolve(reading.result);
    reading.onerror = () => reject(reading.error);
  });
}
export async function writeWorkspace(key: string, draft: WorkspaceDraft) {
  const database = await workspaceDatabase();
  return new Promise<void>((resolve, reject) => {
    const transaction = database.transaction('sessions', 'readwrite');
    transaction.objectStore('sessions').put(draft, key);
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error);
    transaction.onerror = () => reject(transaction.error);
  });
}
