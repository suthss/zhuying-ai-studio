import unittest

import cv2
import numpy as np

from backend.plan_vectorization import VectorizationError, vectorize_plan_labels, _simple_polygon


def plan_mask(thickness=7, opening=True):
    mask = np.zeros((220, 320), dtype=np.uint8)
    cv2.rectangle(mask, (20, 20), (300, 200), 1, thickness)
    cv2.line(mask, (160, 20), (160, 200), 1, thickness)
    if opening:
        mask[90:120, 156:165] = 2
        mask[16:25, 60:110] = 3
    return mask


class PlanVectorizationTests(unittest.TestCase):
    def test_closed_wall_mask_has_two_rooms_not_external_background(self):
        geometry = vectorize_plan_labels(plan_mask(opening=False))
        self.assertEqual(len(geometry["rooms"]), 2)
        self.assertGreaterEqual(len(geometry["walls"]), 5)
        self.assertEqual(geometry["openings"], [])
        self.assertAlmostEqual(geometry["bounds"][0], 20, delta=2)
        self.assertAlmostEqual(geometry["bounds"][2], 300, delta=2)
        for room in geometry["rooms"]:
            self.assertEqual(room["semantic"], 0)
            self.assertGreater(room["area"], 20_000)
            self.assertLessEqual(len(room["polygon"]), 200)

    def test_openings_rejoin_host_walls_and_keep_rooms_separate(self):
        geometry = vectorize_plan_labels(plan_mask())
        self.assertEqual(len(geometry["rooms"]), 2)
        self.assertEqual({item["type"] for item in geometry["openings"]}, {"door", "window"})
        self.assertEqual(len(geometry["openings"]), 2)
        for opening in geometry["openings"]:
            wall = geometry["walls"][opening["wallIndex"]]
            length = np.linalg.norm(np.array(wall["end"]) - wall["start"])
            self.assertGreater(opening["width"], 25)
            self.assertGreaterEqual(opening["offset"], 0)
            self.assertLessEqual(opening["offset"] + opening["width"], length + .001)
        door = next(item for item in geometry["openings"] if item["type"] == "door")
        wall = geometry["walls"][door["wallIndex"]]
        self.assertAlmostEqual(wall["start"][0], 160, delta=2)
        self.assertAlmostEqual(wall["end"][0], 160, delta=2)

    def test_door_swing_symbol_does_not_become_a_big_block_in_room(self):
        mask = plan_mask()
        # Semantics can include the whole swing sector, not just the thin hole.
        cv2.ellipse(mask, (160, 90), (30, 30), 0, 0, 90, 2, 2)
        cv2.line(mask, (160, 90), (190, 90), 2, 2)
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry["rooms"]), 2)
        door = next(item for item in geometry["openings"] if item["type"] == "door")
        self.assertLess(door["width"], 40)
        self.assertGreater(min(room["area"] for room in geometry["rooms"]), 20_000)

    def test_room_semantics_are_majority_vote_inside_existing_enclosed_rooms(self):
        mask = plan_mask()
        rooms = np.zeros_like(mask)
        rooms[25:196, 25:156] = 4
        rooms[25:196, 165:296] = 7
        geometry = vectorize_plan_labels(mask, rooms)
        self.assertEqual({room["semantic"] for room in geometry["rooms"]}, {4, 7})

    def test_indoor_semantics_recover_missing_shell_without_adding_fake_walls(self):
        mask = plan_mask(opening=False)
        mask[60:170, 10:30] = 0
        semantic = np.ones_like(mask)
        semantic[25:196, 25:156] = 5
        semantic[25:196, 165:296] = 4
        geometry = vectorize_plan_labels(mask, semantic)
        self.assertEqual(len(geometry["rooms"]), 2)
        self.assertEqual({room["semantic"] for room in geometry["rooms"]}, {4, 5})
        left_walls = [wall for wall in geometry["walls"] if abs(wall["start"][0] - 20) < 3
                      and abs(wall["end"][0] - 20) < 3]
        self.assertEqual(len(left_walls), 2)
        self.assertTrue(all(np.linalg.norm(np.array(wall["end"]) - wall["start"]) < 70 for wall in left_walls))

    def test_outdoor_and_railing_semantics_are_not_rooms(self):
        mask = plan_mask(opening=False)
        semantic = np.ones_like(mask)
        semantic[25:196, 25:156] = 8
        semantic[25:196, 165:296] = 4
        geometry = vectorize_plan_labels(mask, semantic)
        self.assertEqual(len(geometry["rooms"]), 1)
        self.assertEqual(geometry["rooms"][0]["semantic"], 4)

    def test_semantics_alone_cannot_fabricate_a_house(self):
        mask = np.zeros((100, 100), np.uint8)
        with self.assertRaises(VectorizationError):
            vectorize_plan_labels(mask, np.full_like(mask, 4))

    def test_one_pixel_walls_still_form_an_enclosed_plan(self):
        mask = plan_mask(thickness=1, opening=False)
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry["rooms"]), 2)
        self.assertTrue(all(1 <= wall["thickness"] <= 3 for wall in geometry["walls"]))

    def test_thin_void_inside_wall_outline_is_not_a_spurious_room(self):
        mask = plan_mask(thickness=1, opening=False)
        cv2.line(mask, (165, 20), (165, 200), 1, 1)
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry["rooms"]), 2)
        self.assertTrue(all(room["area"] > 20_000 for room in geometry["rooms"]))

    def test_solid_wall_prediction_is_rejected_before_expensive_thinning(self):
        with self.assertRaisesRegex(VectorizationError, "覆盖过多"):
            vectorize_plan_labels(np.ones((512, 512), np.uint8))

    def test_an_unlabelled_exterior_gap_is_not_guessed_closed(self):
        mask = plan_mask(opening=False)
        mask[50:180, 10:30] = 0
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry["rooms"]), 1)
        self.assertTrue(all(point[0] > 160 for point in geometry["rooms"][0]["polygon"]))

    def test_missing_exterior_boundaries_return_actionable_error(self):
        mask = np.zeros((100, 100), np.uint8)
        cv2.line(mask, (10, 10), (80, 10), 1, 5)
        cv2.line(mask, (10, 10), (10, 80), 1, 5)
        cv2.line(mask, (40, 10), (40, 80), 1, 5)
        with self.assertRaisesRegex(VectorizationError, "封闭"):
            vectorize_plan_labels(mask)

    def test_rotated_plan_preserves_slanted_lines_and_metric_envelope(self):
        mask = plan_mask(opening=False)
        rotation = cv2.getRotationMatrix2D((160, 110), 8, 1)
        rotated = cv2.warpAffine(mask, rotation, (320, 220), flags=cv2.INTER_NEAREST)
        geometry = vectorize_plan_labels(rotated)
        self.assertEqual(len(geometry["rooms"]), 2)
        slanted = [wall for wall in geometry["walls"] if abs(wall["end"][0] - wall["start"][0]) > 15
                   and abs(wall["end"][1] - wall["start"][1]) > 15]
        self.assertGreaterEqual(len(slanted), 3)

    def test_concave_room_keeps_its_reentrant_corner(self):
        mask = np.zeros((220, 320), np.uint8)
        outline = np.array([[20, 20], [280, 20], [280, 90], [150, 90], [150, 200], [20, 200]])
        cv2.polylines(mask, [outline], True, 1, 7)
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry["rooms"]), 1)
        room = geometry["rooms"][0]
        self.assertGreaterEqual(len(room["polygon"]), 6)
        polygon = np.asarray(room["polygon"], dtype=np.float32)
        self.assertEqual(cv2.pointPolygonTest(polygon, (240, 150), False), -1)
        self.assertEqual(cv2.pointPolygonTest(polygon, (100, 150), False), 1)

    def test_exterior_entrance_door_closes_room_flood_fill_only(self):
        mask = plan_mask(opening=False)
        mask[90:135, 16:25] = 2
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry["rooms"]), 2)
        self.assertEqual(len(geometry["openings"]), 1)
        door = geometry["openings"][0]
        self.assertEqual(door["type"], "door")
        self.assertAlmostEqual(door["width"], 45, delta=2)

    def test_isolated_door_symbol_is_reported_instead_of_moving_it_to_a_wall(self):
        mask = plan_mask(opening=False)
        mask[70:95, 60:65] = 2
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(geometry["openings"], [])
        self.assertTrue(geometry["warnings"])
        self.assertEqual(len(geometry["rooms"]), 2)

    def test_parallel_corridor_walls_do_not_merge_into_diagonal_wall(self):
        mask = np.zeros((220, 320), np.uint8)
        cv2.rectangle(mask, (20, 20), (300, 200), 1, 5)
        cv2.line(mask, (145, 20), (145, 200), 1, 5)
        cv2.line(mask, (175, 20), (175, 200), 1, 5)
        mask[80:115, 141:150] = 2
        mask[130:160, 171:180] = 2
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry["rooms"]), 3)
        self.assertEqual(len(geometry["openings"]), 2)
        self.assertNotEqual(geometry["openings"][0]["wallIndex"], geometry["openings"][1]["wallIndex"])

    def test_rejects_float_unknown_labels_shape_mismatch_and_huge_array(self):
        for value in (np.zeros((100, 100), dtype=float), np.full((100, 100), 99, np.uint8),
                      np.zeros((2, 2), np.uint8), np.zeros((4097, 12), np.uint8)):
            with self.subTest(shape=value.shape, dtype=value.dtype), self.assertRaises(VectorizationError):
                vectorize_plan_labels(value)
        with self.assertRaises(VectorizationError):
            vectorize_plan_labels(plan_mask(), np.zeros((100, 100), np.uint8))

    def test_does_not_mutate_input_masks(self):
        mask = plan_mask()
        original = mask.copy()
        vectorize_plan_labels(mask)
        np.testing.assert_array_equal(mask, original)

    def test_window_with_short_jamb_near_corner_recovers_whole_host(self):
        mask = plan_mask(opening=False)
        mask[16:25, 26:86] = 3
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry['rooms']), 2)
        self.assertEqual(len(geometry['openings']), 1)
        opening = geometry['openings'][0]
        self.assertEqual(opening['type'], 'window')
        self.assertAlmostEqual(opening['width'], 60, delta=2)
        wall = geometry['walls'][opening['wallIndex']]
        self.assertAlmostEqual(wall['start'][0], 20, delta=2)
        self.assertAlmostEqual(wall['end'][0], 300, delta=2)

    def test_door_next_to_t_junction_keeps_short_first_jamb(self):
        mask = plan_mask(opening=False)
        mask[26:81, 156:165] = 2
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry['rooms']), 2)
        self.assertEqual(len(geometry['openings']), 1)
        opening = geometry['openings'][0]
        self.assertEqual(opening['type'], 'door')
        self.assertAlmostEqual(opening['width'], 55, delta=2)
        self.assertLess(opening['offset'], 8)

    def test_open_plan_floor_with_wall_island_is_not_discarded_or_filled_through(self):
        mask = plan_mask(opening=False)
        cv2.line(mask, (55, 105), (125, 105), 1, 7)
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry['rooms']), 2)
        left = next(room for room in geometry['rooms'] if np.mean(np.array(room['polygon'])[:, 0]) < 160)
        polygon = np.asarray(left['polygon'], np.float32)
        self.assertGreater(left['area'], 20_000)
        self.assertTrue(_simple_polygon(polygon))
        self.assertEqual(cv2.pointPolygonTest(polygon, (85, 105), False), -1)
        for point in ((85, 70), (85, 140), (140, 90)):
            self.assertEqual(cv2.pointPolygonTest(polygon, point, False), 1)
        floor = np.zeros_like(mask)
        cv2.fillPoly(floor, [polygon.astype(np.int32)], 1)
        self.assertEqual(int(floor[102:109, 55:126].sum()), 0)

    def test_discarded_isolated_furniture_stroke_does_not_leave_floor_void(self):
        mask = plan_mask(opening=False)
        cv2.line(mask, (65, 80), (65, 95), 1, 1)
        geometry = vectorize_plan_labels(mask)
        self.assertTrue(any('孤立' in warning for warning in geometry['warnings']))
        left = next(room for room in geometry['rooms'] if np.mean(np.array(room['polygon'])[:, 0]) < 160)
        self.assertEqual(cv2.pointPolygonTest(np.array(left['polygon'], np.float32), (65, 88), False), 1)
        self.assertFalse(any(abs(w['start'][0] - 65) < 1 and abs(w['end'][0] - 65) < 1 for w in geometry['walls']))

    def test_one_window_split_by_label_noise_is_not_duplicated(self):
        mask = plan_mask(opening=False)
        mask[16:25, 60:85] = 3
        mask[16:25, 86:110] = 3
        geometry = vectorize_plan_labels(mask)
        self.assertEqual(len(geometry['openings']), 1)
        opening = geometry['openings'][0]
        self.assertEqual(opening['type'], 'window')
        self.assertAlmostEqual(opening['width'], 50, delta=2)

    def test_floor_polygon_topology_rejects_crossings_and_nonadjacent_touch(self):
        self.assertFalse(_simple_polygon(np.array([[0, 0], [5, 5], [0, 5], [5, 0]], float)))
        self.assertFalse(_simple_polygon(np.array([[0, 0], [6, 0], [6, 6], [3, 3], [0, 6], [3, 3]], float)))
        self.assertTrue(_simple_polygon(np.array([[0, 0], [6, 0], [6, 6], [3, 6], [3, 3], [0, 3]], float)))

    def test_semantic_floor_beyond_missing_wall_does_not_collapse_on_metric_clamp(self):
        mask = plan_mask(opening=False)
        mask[196:206, 215:296] = 0
        semantic = np.ones_like(mask)
        semantic[25:196, 25:156] = 5
        semantic[25:206, 165:296] = 4
        geometry = vectorize_plan_labels(mask, semantic)
        self.assertEqual(len(geometry['rooms']), 2)
        x0, y0, x1, y1 = geometry['bounds']
        for room in geometry['rooms']:
            polygon = np.array(room['polygon'])
            self.assertGreaterEqual(polygon[:, 0].min(), x0)
            self.assertGreaterEqual(polygon[:, 1].min(), y0)
            self.assertLessEqual(polygon[:, 0].max(), x1)
            self.assertLessEqual(polygon[:, 1].max(), y1)
            metric = np.round((polygon - [x0, y0]) * 12 / (x1 - x0), 4)
            self.assertTrue(_simple_polygon(metric))

    def test_unknown_room_head_class_is_rejected(self):
        with self.assertRaisesRegex(VectorizationError, '类别'):
            vectorize_plan_labels(plan_mask(), np.full((220, 320), 255, np.uint8))


if __name__ == "__main__":
    unittest.main()
