/** Opening geometry uses metres; visual changes never alter construction data. */
export const doorStyles = Object.freeze([
  { id: 'flush', label: '极简平板门' },
  { id: 'panel', label: '分格木门' },
  { id: 'glass', label: '玻璃门' },
].map(Object.freeze));
export const windowStyles = Object.freeze([
  { id: 'fixed', label: '固定窗' },
  { id: 'casement', label: '平开窗' },
  { id: 'sliding', label: '推拉窗' },
].map(Object.freeze));

const EPS = 0.00001;
const FRAME = 0.045;
const finite = value => typeof value === 'number' && Number.isFinite(value);
const point = value => Array.isArray(value) && value.length === 2 && value.every(finite);
const styles = { door: new Set(doorStyles.map(style => style.id)),
                 window: new Set(windowStyles.map(style => style.id)) };
const editableKeys = new Set(['id', 'wallId', 'type', 'offset', 'width', 'height', 'sill', 'design']);

export function isOpeningDesign(value, type) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || !Object.hasOwn(styles,type)) return false;
  if (!styles[type].has(value.style) || typeof value.color !== 'string' || !/^#[0-9a-f]{6}$/i.test(value.color)) return false;
  if (!finite(value.openAngle) || value.openAngle < 0 || value.openAngle > (type === 'door' ? 100 : 60)) return false;
  if ((value.style === 'fixed' || value.style === 'sliding') && value.openAngle !== 0) return false;
  return (value.hinge === 'start' || value.hinge === 'end')
    && (value.swing === 1 || value.swing === -1)
    && (value.glassTint === 'clear' || value.glassTint === 'smoke');
}

export function resolveOpeningDesign(opening) {
  if (!Object.hasOwn(styles,opening.type)) throw new Error('开口类型必须为门或窗。');
  if (opening.design === undefined) return {
    color: opening.type === 'door' ? '#c9b99b' : '#596b63',
    style: opening.type === 'door' ? 'panel' : 'fixed',
    openAngle: 0, hinge: 'start', swing: 1, glassTint: 'clear',
  };
  if (!isOpeningDesign(opening.design, opening.type)) throw new Error('门窗设计无效，请核对款式、六位墙色、铰链和开启角度。');
  const {color,style,openAngle,hinge,swing,glassTint}=opening.design;
  return {color,style,openAngle,hinge,swing,glassTint};
}

function verticalInterval(opening) {
  const bottom=opening.type==='window' ? opening.sill??0 : 0;
  return [bottom,bottom+opening.height];
}

export function getOpeningErrors(model, opening) {
  const errors=[];
  if (!opening || typeof opening !== 'object') return ['开口数据无效。'];
  if (typeof opening.id!=='string' || !opening.id.trim()) errors.push('门窗编号不能为空。');
  if (opening.type!=='door' && opening.type!=='window') errors.push('开口类型必须为门或窗。');
  const wall=model.walls.find(item=>item.id===opening.wallId);
  if (!wall) return [...errors,'关联墙体不存在，请重新选择墙段。'];
  if (!point(wall.start)||!point(wall.end)||!finite(model.height)||model.height<=0
      || (wall.height!==undefined&&(!finite(wall.height)||wall.height<=0))) {
    return [...errors,'关联墙体坐标或墙高无效，请先校正墙体。'];
  }
  const length=Math.hypot(wall.end[0]-wall.start[0],wall.end[1]-wall.start[1]);
  const effectiveHeight=Math.min(wall.height??model.height,model.height);
  if (!finite(opening.offset)||opening.offset<0) errors.push('距墙起点的偏移须为不小于 0 的有限数。');
  if (!finite(opening.width)||opening.width<.1) errors.push('开口宽度须为至少 0.10 米的有限数，以容纳两侧门窗框。');
  if (!finite(opening.height)||opening.height<.1) errors.push('开口高度须为至少 0.10 米的有限数。');
  if (finite(opening.offset)&&finite(opening.width)&&opening.offset+opening.width>length+EPS) errors.push('开口超出墙长，请减小偏移或宽度。');
  const sill=opening.sill??0;
  if (!finite(sill)||sill<0) errors.push('窗台高度须为不小于 0 的有限数。');
  if (opening.type==='door'&&sill!==0) errors.push('门洞从地面起算，窗台高度须为 0。');
  const [bottom,top]=verticalInterval(opening);
  if (finite(bottom)&&finite(top)&&top>effectiveHeight+EPS) errors.push('开口超出墙高，请减小开口高度或窗台高度。');
  if (opening.design!==undefined&&!isOpeningDesign(opening.design,opening.type)) errors.push('门窗设计无效：款式须匹配门窗类型，颜色须为六位十六进制，开启角度须在允许范围内。');
  if (finite(opening.offset)&&finite(opening.width)&&opening.width>0&&finite(bottom)&&finite(top)) {
    for (const other of model.openings) {
      if (other.id===opening.id||other.wallId!==opening.wallId) continue;
      if (!finite(other.offset)||!finite(other.width)||!finite(other.height)) continue;
      const [otherBottom,otherTop]=verticalInterval(other);
      const xIntersection=Math.min(opening.offset+opening.width,other.offset+other.width)-Math.max(opening.offset,other.offset);
      const yIntersection=Math.min(top,otherTop)-Math.max(bottom,otherBottom);
      if (xIntersection>EPS&&yIntersection>EPS) errors.push(`开口与 ${other.id} 重叠，请调整位置、宽高或窗台高度。`);
    }
  }
  return [...new Set(errors)];
}

export function updateOpening(model, id, patch) {
  const opening=model.openings.find(item=>item.id===id);
  if (!opening) throw new Error('找不到待编辑的门窗，请重新选择开口。');
  if (!patch||typeof patch!=='object'||Array.isArray(patch)||Object.keys(patch).some(key=>!editableKeys.has(key))) {
    throw new Error('门窗修改只能包含开口参数与门窗设计。');
  }
  if (patch.id!==undefined&&patch.id!==id) throw new Error('编辑门窗时不能更改构件编号。');
  const updated={...opening,...patch};
  const errors=getOpeningErrors(model,updated);
  if (errors.length) throw new Error(errors.join(' '));
  if (updated.design!==undefined) updated.design=resolveOpeningDesign(updated);
  return {...model,openings:model.openings.map(item=>item.id===id?updated:item)};
}

export function getRoomOpenings(model, roomId) {
  const room=model.rooms.find(item=>item.id===roomId);
  if (!room||!Array.isArray(room.polygon)||room.polygon.length<3||!room.polygon.every(point)) return [];
  return model.openings.filter(opening=>{
    const wall=model.walls.find(item=>item.id===opening.wallId);
    if (!wall||!point(wall.start)||!point(wall.end)||!finite(opening.offset)||!finite(opening.width)) return false;
    const dx=wall.end[0]-wall.start[0], dz=wall.end[1]-wall.start[1], length=Math.hypot(dx,dz);
    if (length<EPS) return false;
    const ux=dx/length, uz=dz/length;
    const tolerance=Math.max(.06,(finite(wall.thickness)?wall.thickness/2:0)+.06);
    for (let index=0;index<room.polygon.length;index++) {
      const a=room.polygon[index],b=room.polygon[(index+1)%room.polygon.length];
      const ex=b[0]-a[0],ez=b[1]-a[1], edgeLength=Math.hypot(ex,ez);
      if (edgeLength<EPS||Math.abs(ex*uz-ez*ux)/edgeLength>.08) continue;
      const distance=p=>Math.abs((p[0]-wall.start[0])*uz-(p[1]-wall.start[1])*ux);
      if (distance(a)>tolerance||distance(b)>tolerance) continue;
      const project=p=>(p[0]-wall.start[0])*ux+(p[1]-wall.start[1])*uz;
      const low=Math.min(project(a),project(b)),high=Math.max(project(a),project(b));
      if (Math.min(high,opening.offset+opening.width)-Math.max(low,opening.offset)>EPS) return true;
    }
    return false;
  });
}

/**
 * Wall-local x runs from wall.start to wall.end; +z is the positive swing side.
 * The leaf mesh is authored along its own +x with a hinge at x=0. Start hinges
 * close at rotation 0; end hinges close at rotation PI (the leaf points to -x).
 * All returned coordinates are absolute in the wall group's local x/z space.
 */
export function doorLeafPose(opening) {
  if (opening.type!=='door') throw new Error('门叶姿态只能用于门洞。');
  if (!finite(opening.offset)||opening.offset<0||!finite(opening.width)||opening.width<.1) throw new Error('门洞宽度或偏移无效。');
  const design=resolveOpeningDesign(opening);
  const start=design.hinge==='start';
  const leafWidth=opening.width-FRAME*2;
  const pivotX=start?opening.offset+FRAME:opening.offset+opening.width-FRAME;
  const pivotZ=0;
  const rotation=(start?0:Math.PI)-design.swing*(design.openAngle*Math.PI/180)*(start?1:-1);
  return {pivotX,pivotZ,rotation,leafWidth,centerX:pivotX+Math.cos(rotation)*leafWidth/2,
          centerZ:pivotZ-Math.sin(rotation)*leafWidth/2};
}
