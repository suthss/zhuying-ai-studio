# 真实室内翻修案例的来源与边界

案例为德国 Ruhr-Universität Bochum（波鸿大学）IC building 的翻修现场。来源作者是 Christian Koch、Markus König、Christopher Kropp。采用作者公开在 Mendeley Data 的 V2 数据集，**真实房间 5-169 的两次采集可用于同室时序对比**。第三段是房间 2-169，只是同工地的另一个房间参考。

## 原始来源与许可

- [数据集原始页面](https://data.mendeley.com/datasets/rskgn5f8y8/2)：*Data for: Interior construction state recognition with 4D BIM registered image sequences*。
- DOI：[10.17632/rskgn5f8y8.2](https://doi.org/10.17632/rskgn5f8y8.2)。公开发布日期为 **2017-11-09**。
- 原始页面的 Licence 明确为 **CC BY 4.0**，可以复制、再分发和修改，需署名、链接许可并注明修改：[Creative Commons 官方许可说明](https://creativecommons.org/licenses/by/4.0/)。
- [官方数据集快照 API](https://data.mendeley.com/public-api/datasets/rskgn5f8y8/snapshot/2) 同时保存作者、许可、描述和公开发布日期；原始元数据副本为 `public/renovation-case/official-dataset-metadata.json`，可直接核查 `licence.short_name` 和 `publish_date`。
- 原始页面说明三个视频段来自上述楼宇翻修现场，分别展现石膏板安装、批灰、涂漆和散热器状态；页面本身没有声明三个视频段属于同一房间。
- [官方文件列表 API](https://data.mendeley.com/public-api/datasets/rskgn5f8y8/files?folder_id=root&version=2&%24start=0&%24limit=1000)。元数据副本保存在 `public/renovation-case/official-file-metadata.json`。
- [官方单文件下载](https://data.mendeley.com/public-files/datasets/rskgn5f8y8/files/b2ba26c9-1253-42f2-88cb-e5b0449fb585/file_downloaded)。文件名为 `Automatic activity state recognition with BIM-registered videos.mp4`，大小 28,659,205 字节，约 27.3 MiB；未下载任何大包。
- SHA-256：`6782458b7250ce57ed82003cf7c4e8092ef8296c14d13592e0524d966bc0d4e2`，下载后已与官方 API 值匹配。
- 文件记录 `created_date=2017-09-12T00:00:00Z`，它是仓库文件元数据，**不能代替拍摄日期**。

## 画面逐项核对

原视频 1920×1080，24 fps，3797 帧，约 158.208 秒。日期和房间信息来自各段片头；未推测 EXIF 或拍摄时间。

| 视频段 | 片头证据时间 | 原片头拍摄日期 | 原片头房间 | 状态 | 抽帧时间 |
|---|---:|---|---|---|---|
| Sequence #1 | 20 s | November 27, 2012 | 5-169 | 石膏板已安装，散热器未出现 | 窗侧 30 s；左墙 39 s |
| Sequence #2 | 50 s | December 20, 2012 | 5-169 | 石膏板已批灰，散热器未安装 | 窗侧 70 s；左墙 62 s |
| Sequence #3 | 115 s | December 20, 2012 | **2-169** | 墙面已涂漆，散热器已出现 | 窗侧 120 s；左墙 130 s |

三个片头的完整证据帧为 `sequence-01-date-room-evidence.jpg`、`sequence-02-date-room-evidence.jpg`、`sequence-03-date-room-evidence.jpg`。Sequence #1 和 #2 的位置、窗、左侧隔墙、窗下区域及盘绕红色软管等相符，结合片头相同房间编号，可作为两期同室记录。Sequence #3 的房间编号不同，界面必须单列为另一房间的参考，不能给它建立房间 5-169 的第三期进度。

本应用保存了每张选中照片对应的完整视频帧（`*-source-frame.jpg`），方便查看原作者的阶段识别文字。阶段标签取自数据集说明和原视频，不是本应用新运行算法的结论。每张用于界面的图从完整帧左上角相机视口裁切，像素框为 `[12, 143, 629, 490]`，输出 617×347；保留原视频已有的紫色、黄色及青色边界标注。仅有抽帧、裁切和 JPEG 编码，未补绘、调亮、增强或合成。已实际查看片头、各期完整帧和典型裁切图。

## 应用接入

`public/renovation-case/data.json` 的 `stages` 仅包含房间 5-169 的两个时序观察，`referenceStages` 包含房间 2-169 的一个参考。每条带真实日期、房间编号、照片 URL、视频秒数、原始完整帧、日期证据；`comparisonGroup` 可防止跨房间对比。

建议在图片或来源区显示如下署名：

> Koch, Christian; König, Markus; Kropp, Christopher (2017), Mendeley Data V2, doi:10.17632/rskgn5f8y8.2. CC BY 4.0. 本应用抽帧并裁切真实相机画面，保留原标注。

引用 CC BY 4.0 时应链接上述许可页，来源名称应链接原始数据集。原作者的识别边界需标明为“源视频已有标注”。

精确拍摄时间、时区和 EXIF 未知。公开数据没有尺寸、户型、原始 BIM 文件、预算、施工计划、责任人、实际缺陷或整改记录，对应字段为 `null`。不能从这些素材声称实景测绘、延期、不合格或真实整改。任何示意房间、预算、责任人或任务都需由应用另行明确标识为演示模拟。

## 可复现抽帧

```powershell
& '.venv/Scripts/python.exe' 'scripts/build_renovation_case.py'
```

脚本只下载该一个官方 MP4，验证字节数和 SHA-256，按确定秒数/帧号抽帧，重建图片、文件元数据和 `data.json`；默认完成后删除视频以避免将 27.3 MiB 视频打包进网站。要保留视频以供人工核对，可加 `--keep-video`。文件元数据、片头日期与房间识别核验于 **2026-10-06**。
