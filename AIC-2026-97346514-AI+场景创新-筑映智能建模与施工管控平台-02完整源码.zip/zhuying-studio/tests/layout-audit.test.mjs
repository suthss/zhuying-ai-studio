import test from 'node:test';
import assert from 'node:assert/strict';
import { auditLayout, getMeasurementReview, validateMeasurements, recordWallMeasurement,
  getFurnitureDimensionErrors, parseFurnitureDimensions, updateFurnitureDimensions } from '../src/layout-audit.mjs';
import { resolveOpeningDesign, updateOpening } from '../src/openings.mjs';
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

const house = () => ({ id: 'audit-house', name: '核对户型', width: 8, depth: 6, height: 2.8, source: 'manual', warnings: [],
  walls: [
    { id: 'north', start: [0, 0], end: [8, 0], thickness: .2 },
    { id: 'east', start: [8, 0], end: [8, 6], thickness: .2 },
    { id: 'south', start: [8, 6], end: [0, 6], thickness: .2 },
    { id: 'west', start: [0, 6], end: [0, 0], thickness: .2 },
  ], openings: [], rooms: [{ id: 'room', name: '客厅', polygon: [[0, 0], [8, 0], [8, 6], [0, 6]], area: 48 }], furniture: [] });
const chair = (patch = {}) => ({ id: 'chair', roomId: 'room', kind: 'chair', position: [3, 3], size: [.5, .8, .5], rotation: 0, color: '#b79770', ...patch });
const record = (patch = {}) => ({ id: 'measure-1', wallId: 'north', lengthMeters: 8, date: '2026-10-05', source: '张工 / 激光测距 / 墙轴线', note: '', confirmed: true, ...patch });
const door = (patch = {}) => ({ id: 'door', wallId: 'north', type: 'door', offset: 1, width: 1, height: 2.1, ...patch });
const ofType = (model, type) => auditLayout(model).issues.filter(issue => issue.type === type);

test('实测记录规范化、克隆且默认未知，不会修改模型或自动确认', () => {
  const model = house(), before = structuredClone(model);
  assert.deepEqual(validateMeasurements(undefined, model), []);
  const review = getMeasurementReview(model);
  assert.equal(review.summary.unmeasuredWalls, 4);
  assert.ok(review.walls.every(wall => wall.status === 'unmeasured' && wall.record === null));
  const next = recordWallMeasurement(model, record({ confirmed: false, source: '  卷尺 / 净空  ' }));
  assert.deepEqual(model, before);
  assert.equal(next.meta.measurements[0].source, '卷尺 / 净空');
  assert.deepEqual(next.meta.measurements[0].wallSnapshot, { start: [0, 0], end: [8, 0] });
  assert.equal(getMeasurementReview(next).walls[0].status, 'unconfirmed');
  assert.equal(getMeasurementReview(next).summary.confirmedCurrentWalls, 0);
});

test('实测长度拒绝零负NaN无穷数，日期必须真实，来源/人工确认有明确类型', () => {
  const model = house();
  for (const lengthMeters of [0, -1, NaN, Infinity, '8', 201]) assert.throws(() => validateMeasurements([record({ lengthMeters })], model), /实测墙长/);
  for (const date of ['2026-02-29', '2026-13-01', '2026-10-00', '2026-10-5', '', '2026-10-05T12:00:00Z']) assert.throws(() => validateMeasurements([record({ date })], model), /日期/);
  assert.equal(validateMeasurements([record({ date: '2024-02-29' })], model).length, 1);
  for (const patch of [{ source: '' }, { source: ' '.repeat(3) }, { confirmed: 'true' }, { note: null }, { wallSnapshot: { start: [NaN, 0], end: [8, 0] } }, { wallSnapshot: { start: [0, 0], end: [0, 0] } }]) assert.throws(() => validateMeasurements([record(patch)], model));
  assert.throws(() => validateMeasurements([record(), record()], model), /不能重复/);
});

test('实测比对跟随墙长变化，同长度平移也要求重新核对，不复用旧确认', () => {
  const original = recordWallMeasurement(house(), record());
  assert.equal(getMeasurementReview(original).walls[0].status, 'checked');
  const stretched = { ...original, walls: original.walls.map(wall => wall.id === 'north' ? { ...wall, end: [7.5, 0] } : wall) };
  const review = getMeasurementReview(stretched);
  assert.equal(review.walls[0].deltaMeters, -.5);
  assert.equal(review.walls[0].status, 'geometry_changed');
  assert.equal(review.summary.confirmedCurrentWalls, 0);
  const shifted = { ...original, walls: original.walls.map(wall => wall.id === 'north' ? { ...wall, start: [0, .4], end: [8, .4] } : wall) };
  assert.equal(getMeasurementReview(shifted).walls[0].deltaMeters, 0);
  assert.equal(getMeasurementReview(shifted).walls[0].status, 'geometry_changed');
});

test('±2cm仅是对照容差，明显差异被列出，缺端点快照仍待核对', () => {
  assert.equal(getMeasurementReview(recordWallMeasurement(house(), record({ lengthMeters: 7.99 }))).walls[0].status, 'checked');
  const review = getMeasurementReview(recordWallMeasurement(house(), record({ lengthMeters: 7.8 })));
  assert.equal(review.walls[0].status, 'difference');
  assert.equal(review.summary.differenceWalls, 1);
  const legacy = { ...house(), meta: { measurements: [record()] } };
  assert.equal(getMeasurementReview(legacy).walls[0].status, 'geometry_changed');
  assert.equal(getMeasurementReview(legacy).summary.confirmedCurrentWalls, 0);
});

test('按量测日期选择最近记录，同日取后写；删墙保留历史与孤立标识', () => {
  let model = recordWallMeasurement(house(), record());
  model = recordWallMeasurement(model, record({ id: 'older-entry', date: '2026-10-01', lengthMeters: 7 }));
  assert.equal(getMeasurementReview(model).walls[0].record.id, 'measure-1');
  model = recordWallMeasurement(model, record({ id: 'same-day-later', lengthMeters: 8.3 }));
  assert.equal(getMeasurementReview(model).walls[0].record.id, 'same-day-later');
  const deleted = { ...model, walls: model.walls.filter(wall => wall.id !== 'north') };
  assert.equal(validateMeasurements(deleted.meta.measurements, deleted).length, 3);
  const review = getMeasurementReview(deleted);
  assert.equal(review.summary.orphanedRecords, 3);
  assert.ok(review.orphaned.every(row => row.status === 'orphaned' && row.modelLength === null));
  assert.throws(() => recordWallMeasurement(deleted, record({ id: 'new' })), /不存在/);
});

test('无效保存实测metadata产生待核对项，不能静默显示全墙确认', () => {
  const model = { ...house(), meta: { measurements: [record({ lengthMeters: NaN })] } };
  const result = auditLayout(model);
  assert.equal(result.counts.unknown, 1);
  assert.equal(result.measurementReview.summary.confirmedCurrentWalls, 0);
  assert.equal(result.issues[0].type, 'measurement_data');
});

test('调整墙位置后现有家具被实时识别穿墙，不缓存旧检验', () => {
  const model = house(); model.furniture = [chair()];
  assert.equal(auditLayout(model).counts.conflicts, 0);
  const moved = { ...model, walls: model.walls.map(wall => wall.id === 'north' ? { ...wall, start: [0, 3], end: [8, 3] } : wall) };
  assert.equal(ofType(moved, 'wall_collision').length, 1);
  assert.equal(ofType(moved, 'wall_collision')[0].furnitureIds[0], 'chair');
  assert.equal(auditLayout(model).counts.conflicts, 0);
});

test('旋转家具使用真实占地，旋转后越界、贴近不等于几何相撞', () => {
  const model = house(); model.furniture = [chair({ position: [1.3, 2], size: [2, .8, .6] })];
  assert.equal(ofType(model, 'outside_room').length, 0);
  const rotated = { ...model, furniture: [chair({ position: [.6, 2], size: [2, .8, .6], rotation: Math.PI / 4 })] };
  assert.equal(ofType(rotated, 'outside_room').length, 1);
  const touch = { ...model, furniture: [chair({ position: [3, 3], size: [1, .8, 1] }), chair({ id: 'second', position: [4, 3], size: [1, .8, 1] })] };
  assert.equal(ofType(touch, 'furniture_collision').length, 0);
  assert.equal(ofType(touch, 'furniture_spacing').length, 1);
});

test('凹房间跨缺口不能因为四个角在内而通过，斜墙房间也支持', () => {
  const model = house(); model.walls = []; model.rooms[0].polygon = [[0, 0], [6, 0], [6, 6], [4, 6], [4, 2], [2, 2], [2, 6], [0, 6]];
  model.furniture = [chair({ position: [3, 3], size: [5, .75, 1] })];
  assert.equal(ofType(model, 'outside_room').length, 1);
  const diamond = house(); diamond.rooms[0].polygon = [[4, 0], [8, 3], [4, 6], [0, 3]]; diamond.walls = []; diamond.furniture = [chair({ rotation: Math.PI / 4 })];
  assert.equal(ofType(diamond, 'outside_room').length, 0);
});

test('所有房间家具检查相撞，包括错误重叠的房间轮廓', () => {
  const model = house(); model.rooms.push({ ...structuredClone(model.rooms[0]), id: 'another', name: '第二间' });
  model.furniture = [chair({ rotation: Math.PI / 4 }), chair({ id: 'second', roomId: 'another', position: [3.45, 3] })];
  assert.equal(ofType(model, 'furniture_collision').length, 1);
  assert.deepEqual(ofType(model, 'furniture_collision')[0].furnitureIds, ['chair', 'second']);
});

test('门角度和开启方向编辑后出现当前门叶/扫掠新冲突，90度预留是提示', () => {
  const model = house(), opening = door();
  model.openings = [{ ...opening, design: { ...resolveOpeningDesign(opening), swing: -1, openAngle: 0 } }];
  model.furniture = [chair({ position: [1.05, .75], size: [.3, .8, .3] })];
  assert.equal(ofType(model, 'door_leaf').length, 0);
  assert.equal(ofType(model, 'door_sweep').length, 0);
  const changed = updateOpening(model, 'door', { design: { ...model.openings[0].design, swing: 1, openAngle: 90 } });
  assert.equal(ofType(changed, 'door_leaf').length, 1);
  assert.equal(ofType(changed, 'door_sweep').length, 1);
  assert.equal(ofType(changed, 'door_leaf')[0].openingId, 'door');
  const closed = updateOpening(changed, 'door', { design: { ...changed.openings[0].design, openAngle: 0 } });
  assert.equal(ofType(closed, 'door_sweep').length, 0);
  assert.equal(ofType(closed, 'door_reserved_sweep').length, 1);
  assert.equal(ofType(closed, 'door_reserved_sweep')[0].severity, 'hint');
});

test('门口预留通路被家具挡住显示heuristic提示，改变门位置会重新判定', () => {
  const model = house(); model.openings = [door({ offset: 5 })];
  model.furniture = [chair({ position: [2.5, .6], size: [.5, .8, .5] })];
  assert.equal(ofType(model, 'door_approach').length, 0);
  const changed = updateOpening(model, 'door', { offset: 2 });
  assert.equal(ofType(changed, 'door_approach').length, 1);
  assert.equal(ofType(changed, 'door_approach')[0].basis, 'heuristic');
});

test('墙实体扣除真实开口，窗台高度变化与家具高度共同产生新穿墙冲突', () => {
  const model = house(); model.walls.push({ id: 'inner', start: [0, 3], end: [8, 3], thickness: .2 });
  model.openings = [{ id: 'low-window', wallId: 'inner', type: 'window', offset: 2, width: 2, height: 1.5, sill: 0 }];
  model.furniture = [chair({ position: [3, 3], size: [.5, .8, .5] })];
  assert.equal(ofType(model, 'wall_collision').length, 0);
  const changed = updateOpening(model, 'low-window', { sill: .9 });
  assert.equal(ofType(changed, 'wall_collision').length, 1);
});

test('家具宽深高输入即时采用正确定义顺序，实测增大后保留冲突草稿与原值', () => {
  const model = house(); model.meta = { keep: 'source metadata' }; model.furniture = [chair({ position: [.7, 3] })];
  const input = parseFurnitureDimensions({ width: '2', depth: '0.4', height: '1.2' });
  const next = updateFurnitureDimensions(model, 'chair', input);
  assert.deepEqual(next.furniture[0].size, [2, 1.2, .4]);
  assert.equal(next.meta.layoutReviewPending, true);
  assert.equal(next.meta.keep, 'source metadata');
  assert.deepEqual(model.furniture[0].size, [.5, .8, .5]);
  assert.equal(ofType(next, 'outside_room').length, 1);
  const smaller = updateFurnitureDimensions(next, 'chair', parseFurnitureDimensions({ width: '.5', depth: '.4', height: '1.2' }));
  assert.equal(ofType(smaller, 'outside_room').length, 0);
});

test('空输入/零负NaN家具尺寸不更新模型，未知位置/尺寸不计作检验通过', () => {
  const model = house(); model.furniture = [chair()];
  for (const raw of [{ width: '', depth: '.5', height: '.8' }, { width: '-.5', depth: '.5', height: '.8' }, { width: '0', depth: '.5', height: '.8' }, { width: 'NaN', depth: '.5', height: '.8' }, { width: '.5', depth: 'Infinity', height: '.8' }, { width: '.5', depth: '.5', height: '3' }]) {
    const dimensions = parseFurnitureDimensions(raw);
    assert.ok(getFurnitureDimensionErrors(model, dimensions).length);
    assert.throws(() => updateFurnitureDimensions(model, 'chair', dimensions));
  }
  const bad = { ...model, furniture: [chair({ size: [NaN, .8, .5] })] };
  assert.equal(auditLayout(bad).counts.unknown, 1);
  assert.equal(auditLayout(bad).checked.furniture, 0);
  assert.equal(auditLayout({ ...model, furniture: [chair({ size: [.5, .8, .5, 1] })] }).checked.furniture, 0);
  assert.equal(auditLayout({ ...model, furniture: [chair({ kind: 'unknown' })] }).counts.unknown, 1);
  assert.throws(() => updateFurnitureDimensions(model, 'missing', { width: .5, depth: .5, height: .8 }));
});

test('复核完全派生，不改模型，输出包含检测范围、可定位房间与门', () => {
  const model = house(); model.openings = [door()]; model.furniture = [chair({ position: [1.5, .6] })];
  const before = structuredClone(model), first = auditLayout(model);
  assert.deepEqual(auditLayout(model), first);
  assert.deepEqual(model, before);
  assert.deepEqual(first.checked, { furniture: 1, walls: 4, doors: 1, windows: 0 });
  assert.ok(first.issues.some(issue => issue.roomId === 'room' && issue.openingId === 'door'));
  assert.equal(first.measurementReview.summary.confirmedCurrentWalls, 0);
});

test('实际React面板初始渲染显示正确宽深高、人工未确认与检测局限', async () => {
  const compiled = await build({
    entryPoints: [fileURLToPath(new URL('../src/LayoutAuditPanel.tsx', import.meta.url))], bundle: true,
    format: 'esm', platform: 'node', write: false, loader: { '.css': 'empty' },
    plugins: [{ name: 'shared-react', setup(builder) {
      builder.onResolve({ filter: /^react(?:\/|$)/ }, args => ({ path: import.meta.resolve(args.path), external: true }));
    } }],
  });
  const { default: Panel } = await import(`data:text/javascript;base64,${Buffer.from(compiled.outputFiles[0].text).toString('base64')}`);
  const model = house(); model.furniture = [chair({ size: [1.1, .8, .45] })];
  const html = renderToStaticMarkup(createElement(Panel, { model, onChange: () => {}, onLocate: () => {} }));
  const numbers = [...html.matchAll(/<input[^>]+type="number"[^>]+value="([^"]*)"/g)].map(match => match[1]);
  assert.deepEqual(numbers, ['', '1.1', '0.45', '0.8']);
  assert.match(html, /实测待核对/);
  assert.match(html, /布局待复核/);
  assert.match(html, /未检查窗扇扫掠/);
  assert.match(html, /不能代替现场量测和通行验收/);
  assert.doesNotMatch(html, /type="checkbox"[^>]*checked/);
});
