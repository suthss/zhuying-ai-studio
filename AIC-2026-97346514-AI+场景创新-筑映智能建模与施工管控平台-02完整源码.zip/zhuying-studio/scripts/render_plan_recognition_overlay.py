"""Overlay saved HouseModel geometry on original public raster examples.

Uses explicit processed-pixel bounds and metric scale. The original classic
parser did not store its origin, so only that origin is recomputed from its
unchanged morphological preprocessing. No geometry is fabricated on rejection.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import sys

import cv2
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.render_recognition_comparison import PALETTE, font
from backend.algorithm import _axis_walls, decode_image


def bounds(model, source_bytes):
    explicit = model.get('meta', {}).get('boundsPixels')
    if explicit:
        return explicit
    if model['meta']['algorithm'] != 'orthogonal-morphology-v1':
        raise ValueError('Saved neural model must include meta.boundsPixels for a faithful source overlay.')
    image = decode_image(source_bytes)
    image.thumbnail((1800, 1800), Image.Resampling.LANCZOS)
    gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
    _, ink = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    h = cv2.morphologyEx(ink, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(30, image.width // 18), 1)))
    v = cv2.morphologyEx(ink, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(30, image.height // 18))))
    hs, vs = _axis_walls(h, True), _axis_walls(v, False)
    return [min(w[0] for w in vs), min(w[1] for w in hs), max(w[0] for w in vs), max(w[1] for w in hs)]


def overlay(source, source_bytes, model):
    if model is None:
        image = source.copy()
        draw = ImageDraw.Draw(image)
        draw.rectangle((0, 0, image.width, 70), fill='#faeee7')
        draw.text((20, 20), '解析拒绝 · 未替换成示例几何', fill='#9b5847', font=font(23))
        return image
    x0, y0, _, _ = bounds(model, source_bytes)
    width, height = model['meta']['processedPixels']
    metres_per_pixel = model['meta']['metresPerPixel']
    def point(value):
        return (round((x0 + value[0] / metres_per_pixel) * source.width / width),
                round((y0 + value[1] / metres_per_pixel) * source.height / height))
    image = source.convert('RGBA')
    filled = Image.new('RGBA', source.size)
    draw = ImageDraw.Draw(filled)
    for i, room in enumerate(model['rooms']):
        color = PALETTE[i % len(PALETTE)]
        rgb = tuple(int(color[j:j+2], 16) for j in (1, 3, 5))
        draw.polygon([point(p) for p in room['polygon']], fill=(*rgb, 112))
    image = Image.alpha_composite(image, filled).convert('RGB')
    draw = ImageDraw.Draw(image)
    for wall in model['walls']:
        draw.line((point(wall['start']), point(wall['end'])), fill='#184c40', width=4)
    walls = {wall['id']: wall for wall in model['walls']}
    for opening in model.get('openings', []):
        wall = walls[opening['wallId']]
        ax, ay = wall['start']
        bx, by = wall['end']
        distance = math.hypot(bx-ax, by-ay)
        unit = ((bx-ax)/distance, (by-ay)/distance)
        ends = [(ax+unit[0]*t, ay+unit[1]*t) for t in (opening['offset'], opening['offset']+opening['width'])]
        draw.line([point(p) for p in ends], fill='#e18e39' if opening['type'] == 'door' else '#268cbf', width=8)
    return image


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--source', type=Path, required=True)
    cli.add_argument('--before-models', type=Path, required=True)
    cli.add_argument('--after-models', type=Path, required=True)
    cli.add_argument('--output', type=Path, required=True)
    args = cli.parse_args()
    source_bytes = args.source.read_bytes()
    source = decode_image(source_bytes)
    source.thumbnail((768, 768), Image.Resampling.LANCZOS)
    panel_width, panel_height = source.width + 40, source.height + 105
    canvas = Image.new('RGB', (panel_width*3, panel_height+55), '#ffffff')
    for column, title, directory in ((0, '原始户型图', None), (1, '原基础线条方法', args.before_models), (2, '当前识别方法', args.after_models)):
        model = None
        if directory:
            path = directory / (args.source.stem + '.json')
            model = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else None
        panel = source if column == 0 else overlay(source, source_bytes, model)
        canvas.paste(panel, (column*panel_width + 20, 62))
        draw = ImageDraw.Draw(canvas)
        draw.text((column*panel_width+20, 16), title, fill='#21493f', font=font(23))
        if model:
            draw.text((column*panel_width+20, panel_height-25), f"{len(model['rooms'])} 空间 · {len(model['walls'])} 墙段 · {len(model.get('openings', []))} 门窗",
                      fill='#5b7068', font=font(17))
    ImageDraw.Draw(canvas).text((20, panel_height+15), '墨绿：墙中心线  橙：门  蓝：窗 · 公开例无完整几何真值，不用于报告准确率；尺度为预览假设',
                               fill='#5b7068', font=font(17))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(args.output)


if __name__ == '__main__':
    main()
