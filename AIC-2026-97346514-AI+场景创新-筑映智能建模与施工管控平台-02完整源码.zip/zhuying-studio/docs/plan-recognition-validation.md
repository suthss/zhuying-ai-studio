# 户型识别本机验证

日期：2026-10-05。使用真实官方 CubiCasa5K checkpoint，未用模拟模型输出替代推理。结果描述本机运行和固定控制样本，不代表中国真实户型图的泛化准确率。

## 环境与来源

- Python 3.12.7、PyTorch 2.7.1+cu118、OpenCV 4.12.0、NumPy 2.2.6。
- 自动设备为 NVIDIA GeForce RTX 4060 Laptop GPU；最长边768，保留长宽比后补边再裁回。
- 官方权重208,651,193 bytes；SHA256 `dd20b4e1bf1d670f2125107b079df06958b1ccd36e49a464ab739aeb00b8e7a2`。来源与非商业研究许可见 [第三方声明](THIRD_PARTY_NOTICES.md)。
- 完整环境：[recognition-environment.json](../artifacts/recognition-environment.json)。

## 自绘十图：旧方法、神经方法、自动方式

样本由项目自绘，含两个布局拓扑、门窗、彩色家具、尺寸线、缩小与微旋转。它们有明确米制真值，适合控制变量回归；只有十个样本，不能外推真实图纸总体性能。拒识样本在主要平均指标中计0。

| 指标 | 原基础线条 | 显式神经模型 | 默认自动选择 |
|---|---:|---:|---:|
| 解析成功 | 4 / 10 | 10 / 10 | 10 / 10 |
| 房间数量完全一致 | 4 / 10 | 5 / 10 | 7 / 10 |
| 目标房间平均 IoU | 0.375 | 0.699 | 0.847 |
| 房间 F1（IoU≥0.5） | 0.400 | 0.715 | 0.862 |
| 墙中心线 F1（0.12米容差） | 0.326 | 0.717 | 0.782 |
| 含门窗案例开口 F1 | 0.000 | 0.782 | 0.782 |

自动方式有8图使用神经方法，2图因几乎全部墨迹属于连通的封闭正交墙结构而保留基础几何；这2图不是模型失败回退，本次自动方式没有回退案例。显式神经模型在抽象纯墙线图上仍会漏分区，自动选择保留旧方法适用优势。

门窗 F1 要求类别一致、中心偏差≤0.30米、宽度偏差≤0.35米；仅含门窗真值的案例参与平均。墙线指标不评估墙厚，也不能证明门洞识别正确；房间数量一致也不能替代轮廓 IoU。详见 [回归集与指标说明](../tests/fixtures/plan-recognition/README.md)。

原始记录：[旧基线](../artifacts/recognition-baseline.json)、[最终神经模型](../artifacts/recognition-neural-final.json)、[最终自动方式](../artifacts/recognition-improved.json)。模型JSON分别存 `artifacts/recognition-models/` 与 `artifacts/recognition-neural-models-final/`。

### 明确保留的失败与退化

- `furniture`：原基础线条得到6/6房间、IoU1.000；神经／自动方式只得到3/6、IoU0.234、墙线F1为0.375。这类没有门洞的彩色家具图在本版存在退化，界面可手动改选基础线条并核对。
- `small-mixed`：得到5/6房间，IoU0.615、墙线F1为0.324；低分辨率仍会丢细节。
- `l-room-mixed`：得到5/4房间，IoU0.957，保留主要L形空间，但存在额外小区域。
- 微旋转图房间匹配改善，墙线容差 F1仍分别只有0.540／0.617；本版没有独立去倾斜校正，不能宣称旋转几何已精确恢复。

四个案例的原图／旧几何／当前几何对比：

![自绘控制样本对比](../artifacts/recognition-comparison.png)

## 两张公开原图：只检查运行与可视结果

两图来自 Grebtsew / FloorplanToBlender3d 固定版本示例，来源、哈希与许可记录在 [public-smoke](../tests/fixtures/plan-recognition/public-smoke/README.md)。没有独立几何标注或测量总宽，12米是预览假设，不能计算真实准确率或尺度误差。

| 输入 | 原方法实际结果 | 新自动／神经方法实际结果 |
|---|---|---|
| `example.png` | 12空间、75墙段、0门窗，目视存在家具／地砖误当墙 | 4空间、13墙段、12门窗（5门7窗），客餐厨主空间恢复 |
| `example2.png` | 拒识：未形成封闭房间 | 14空间、44墙段、26门窗；复杂楼梯／边界仍需核对，部分门窗关联失败有提示 |

本次公开图自动和显式神经路径得到相同几何。第一张的阳台未生成单独空间；第二张外部阳台、较小功能区域与门窗仍有漏识别／误识别风险。没有人工完整真值，以上数量是模型输出，不能写成真实房间数量已全部识别。

覆盖图使用实际 `meta.boundsPixels` 与 `metresPerPixel` 将三维输入几何叠回原始图；原方法未保存原点时只复算原形态学预处理原点，不改变保存的几何。橙色为门、蓝色为窗、墨绿为墙中心线。失败时显示拒识，不换成演示户型。

![公开例一的原图与识别覆盖](../artifacts/recognition-public-example-comparison.png)

![公开例二的原图与识别覆盖](../artifacts/recognition-public-example2-comparison.png)

记录：[公开旧方法](../artifacts/recognition-public-baseline-rechecked.json)、[公开自动方式](../artifacts/recognition-public-improved.json)、[公开神经方法](../artifacts/recognition-public-neural-final.json)。

## 前后端与CPU验证

最终保存的24份模型（两种方式各10张控制图和2张公开例）均通过实际 `src/project.mjs` 的 `validateProject`；随后执行真实 `createDesignBrief → generateFurnishedModel → validateProject`，24份家具结果也通过输入契约及几何约束校验。记录：[recognition-frontend-validation.json](../artifacts/recognition-frontend-validation.json)。这证明模型能进入现有问答与家具流程，不能证明识别出的墙和房间与真实图纸一致。

另在独立新进程强制纯CPU运行公开例一：包含模块导入的冷启动端到端5.584秒；解析器含权重加载及矢量化5.182秒；网络阶段含权重加载4.600秒。输出4空间、12墙、5门7窗，实际前端校验通过。完整记录：[recognition-cpu-smoke.json](../artifacts/recognition-cpu-smoke.json)。GPU结果为13墙，CPU为12墙，说明浮点计算和阈值后处理可能带来小差异；这些是本机单例耗时，不是CPU速度或跨设备完全一致的保证。

浏览器在 `localhost:5174` 实际上传公开例一，默认自动方式经本地GPU得到4空间、13墙、5门7窗；四步设计问答生成7件家具。双击卧室可进入实时三维环视，识别出的窗户可编辑为平开窗／暖白，并在刷新后保留模型与家具。截图：[实际工作台](../artifacts/recognition-public-platform.jpg)。后端最终重启后实际 multipart 请求返回HTTP200，响应 [recognition-api-model.json](../artifacts/recognition-api-model.json) 也通过真实前端校验。根任务已执行92项Python测试、72项Node测试与生产构建，全部通过；这些检查证明功能闭环与契约，仍不替代图纸识别准确率评测。

## 复跑

```powershell
.\.venv\Scripts\python.exe scripts/evaluate_plan_recognition.py --parser backend.neural_plan:recognize_floor_plan --output artifacts/recognition-improved.json --save-models artifacts/recognition-models
.\.venv\Scripts\python.exe scripts/evaluate_plan_recognition.py --parser backend.neural_plan:parse_neural_floor_plan --output artifacts/recognition-neural-final.json --save-models artifacts/recognition-neural-models-final
.\.venv\Scripts\python.exe scripts/evaluate_public_plan_recognition.py --output artifacts/recognition-public-improved.json --save-models artifacts/recognition-public-models
.\.venv\Scripts\python.exe scripts/render_recognition_comparison.py --models artifacts/recognition-models --output artifacts/recognition-comparison.png
.\.venv\Scripts\python.exe scripts/render_plan_recognition_overlay.py --source tests/fixtures/plan-recognition/public-smoke/floorplan-to-blender-example.png --before-models artifacts/recognition-public-baseline-models --after-models artifacts/recognition-public-models --output artifacts/recognition-public-example-comparison.png
```

模型首次加载计入其第一个案例耗时；GPU／CPU、是否已加载、图像尺寸和并行负载都会影响时间，不能将两种解析方式的单次均值当成稳定性能结论。下一轮需要经授权、按房屋划分的真实中国户型标注测试集，重点量化漏墙、房间合并／多分区、门窗错配及尺寸误差。
