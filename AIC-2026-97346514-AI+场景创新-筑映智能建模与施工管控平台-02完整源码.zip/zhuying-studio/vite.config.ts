import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, strictPort: true, proxy: { '/api': process.env.ZHUYING_API_PROXY_TARGET || 'http://127.0.0.1:8000' } },
  build: { chunkSizeWarningLimit: 1000 }
});
