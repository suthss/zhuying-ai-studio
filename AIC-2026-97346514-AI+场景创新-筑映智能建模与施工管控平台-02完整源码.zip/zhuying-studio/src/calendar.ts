/** User-facing calendar dates follow the workspace's Shanghai timezone. */
export const localToday = () => new Intl.DateTimeFormat('sv-SE', {timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
