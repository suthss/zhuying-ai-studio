import { useCallback, useEffect, useRef, useState } from 'react';
import type { Dispatch, SetStateAction } from 'react';
import { validateProject } from './project.mjs';
import { acquireWorkspaceSession, createProject, getProject, listProjects, readWorkspace, updateProject, writeWorkspace } from './project-library';
import type { ProjectMetadata, ProjectRecord, ProjectSummary, WorkspaceDraft } from './project-library';
import type { HouseModel } from './types';
import { DEMO_MODEL } from './demo';

export function useProjectLibrary(model: HouseModel, setModel: Dispatch<SetStateAction<HouseModel>>, onActivated: (model: HouseModel) => void, editing = false) {
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [record, setRecord] = useState<ProjectMetadata | null>(null);
  const [ready, setReady] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [listError, setListError] = useState<string | null>(null);
  const [backupError, setBackupError] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [version, setVersion] = useState(0);
  const modelRef = useRef(model); modelRef.current = model;
  const activateRef = useRef(onActivated); activateRef.current = onActivated;
  const editingRef = useRef(editing); editingRef.current = editing;
  const sessionKey = useRef('');
  const current = useRef<{ record: ProjectMetadata | null; baseline: string | null; clientKey: string }>({ record: null, baseline: null, clientKey: crypto.randomUUID() });
  const flight = useRef<Promise<void> | null>(null);
  const blocked = useRef(false);
  const refreshSequence = useRef(0);
  const remoteFlight = useRef(false);
  const creationKeys = useRef(new Map<string,string>());
  const mounted = useRef(true);

  const persist = useCallback(async () => {
    const draft: WorkspaceDraft = { model: modelRef.current, ...current.current };
    try { await writeWorkspace(sessionKey.current, draft); if (mounted.current) setBackupError(false); }
    catch { if (mounted.current) setBackupError(true); }
  }, []);
  const adopt = useCallback((next: ProjectRecord, replaceModel = true) => {
    validateProject(next.model);
    if (current.current.record?.id === next.id && current.current.record.revision > next.revision) return false;
    const { model: savedModel, ...metadata } = next;
    current.current.record = metadata;
    current.current.baseline = JSON.stringify(savedModel);
    setRecord(metadata); setVersion(value => value + 1);
    if (replaceModel) { modelRef.current = savedModel; setModel(savedModel); activateRef.current(savedModel); }
    void persist();
    return true;
  }, [persist, setModel]);

  const refresh = useCallback(async () => {
    const sequence = ++refreshSequence.current;
    try {
      const result = await listProjects();
      if (!mounted.current || sequence !== refreshSequence.current) return;
      setProjects(result.projects); setListError(null); setLoading(false);
      const active = current.current.record;
      const remote = result.projects.find(project => project.id === active?.id);
      if (!active || !remote || remote.revision <= active.revision || flight.current || remoteFlight.current || editingRef.current) return;
      if (JSON.stringify(modelRef.current) !== current.current.baseline) {
        blocked.current = true;
        setError('另一窗口已更新这个项目。本地修改已保留，请另存副本或导出；重新载入会放弃当前草稿。');
        return;
      }
      remoteFlight.current = true;
      try {
        const latest = await getProject(active.id);
        if (current.current.record?.id === active.id && !flight.current && !editingRef.current && JSON.stringify(modelRef.current) === current.current.baseline) adopt(latest);
      } finally { remoteFlight.current = false; }
    } catch (failure) {
      if (mounted.current && sequence === refreshSequence.current) { setListError(failure instanceof Error ? failure.message : '项目库加载失败'); setLoading(false); }
    }
  }, [adopt]);

  useEffect(() => {
    mounted.current = true;
    let cancelled = false;
    acquireWorkspaceSession().then(session => { sessionKey.current = session.key; return readWorkspace(session.restoreKey); }).then(draft => {
      if (cancelled || !draft) return;
      const restored = validateProject(draft.model);
      current.current = { record: draft.record, baseline: draft.baseline, clientKey: draft.clientKey };
      modelRef.current = restored; setModel(restored); setRecord(draft.record); activateRef.current(restored);
    }).catch(failure => { if (!cancelled) { setBackupError(true); setError('本机草稿暂时无法恢复，请从项目库重新打开已保存的模型。'); console.warn('Workspace restore failed', failure); } }).finally(() => {
      if (!cancelled) { setReady(true); void refresh(); }
    });
    return () => { cancelled = true; mounted.current = false; };
  }, [refresh, setModel]);

  const flush = useCallback(async () => {
    if (flight.current) { await flight.current; return; }
    if (blocked.current) throw new Error('当前草稿与项目库版本冲突，请另存副本、导出或重新载入。');
    const savingOperation = async () => {
      setSaving(true); setError(null);
      try {
        // Serial saves keep edits made during a slow request attached to the same project.
        do {
          const snapshot = JSON.stringify(modelRef.current);
          const active = current.current.record;
          if (active && snapshot === current.current.baseline) break;
          const next = active
            ? await updateProject(active.id, active.revision, { model: JSON.parse(snapshot) })
            : await createProject(JSON.parse(snapshot), current.current.clientKey);
          const unchanged = JSON.stringify(modelRef.current) === snapshot;
          adopt(next, false);
          if (unchanged) { modelRef.current = next.model; setModel(next.model); }
          await persist();
        } while (JSON.stringify(modelRef.current) !== current.current.baseline);
        setDirty(false);
      } catch (failure) {
        if (failure && typeof failure === 'object' && 'status' in failure && failure.status === 409) blocked.current = true;
        setError(failure instanceof Error ? failure.message : '保存失败，当前草稿已保留。');
        await persist();
        throw failure;
      } finally { setSaving(false); }
    };
    const operation = savingOperation();
    flight.current = operation;
    try { await operation; } finally { flight.current = null; void refresh(); }
  }, [adopt, persist, refresh, setModel]);

  useEffect(() => {
    if (!ready) return;
    const changed = current.current.baseline !== null && JSON.stringify(model) !== current.current.baseline;
    setDirty(changed);
    void persist();
    if (!changed || !current.current.record || blocked.current) return;
    const timer = setTimeout(() => { void flush().catch(() => {}); }, 900);
    return () => clearTimeout(timer);
  }, [model, ready, version, flush, persist]);
  useEffect(() => {
    if (!ready) return;
    const timer = setInterval(() => { if (document.visibilityState === 'visible') void refresh(); }, 5000);
    const visible = () => { if (document.visibilityState === 'visible') void refresh(); };
    document.addEventListener('visibilitychange', visible);
    return () => { clearInterval(timer); document.removeEventListener('visibilitychange', visible); };
  }, [ready, refresh]);

  const protectCurrent = useCallback(async () => {
    // The untouched demo is a starting example; importing should not create fake jobs.
    if (!current.current.record && JSON.stringify(modelRef.current) === JSON.stringify(DEMO_MODEL)) return;
    await flush();
  }, [flush]);
  const open = useCallback(async (id: string) => {
    await protectCurrent();
    const next = await getProject(id);
    blocked.current = false; setError(null); adopt(next);
  }, [adopt, protectCurrent]);
  const create = useCallback(async (next: HouseModel) => {
    await protectCurrent();
    const identity = `create:${JSON.stringify(next)}`;
    const newKey = creationKeys.current.get(identity) ?? crypto.randomUUID();
    creationKeys.current.set(identity, newKey);
    const saved = await createProject(validateProject(next), newKey);
    creationKeys.current.delete(identity);
    current.current.clientKey = newKey;
    blocked.current = false; setError(null); adopt(saved); await refresh();
  }, [adopt, protectCurrent, refresh]);
  const saveCopy = useCallback(async () => {
    if (flight.current) { try { await flight.current; } catch { /* The existing draft is copied below. */ } }
    const next = { ...modelRef.current, name: `${modelRef.current.name} · 副本`.slice(0, 160) };
    const identity = `copy:${JSON.stringify(next)}`;
    const newKey = creationKeys.current.get(identity) ?? crypto.randomUUID();
    creationKeys.current.set(identity, newKey);
    const saved = await createProject(next, newKey, current.current.record?.location ?? '');
    creationKeys.current.delete(identity);
    blocked.current = false; setError(null); adopt(saved); await refresh();
  }, [adopt, refresh]);
  const duplicate = useCallback(async (id: string) => {
    if (current.current.record?.id === id) await flush();
    const next = await getProject(id);
    const identity = `duplicate:${id}:${next.revision}`;
    const newKey = creationKeys.current.get(identity) ?? crypto.randomUUID();
    creationKeys.current.set(identity, newKey);
    await createProject({ ...next.model, name: `${next.name} · 副本`.slice(0, 160) }, newKey, next.location);
    creationKeys.current.delete(identity);
    await refresh();
  }, [flush, refresh]);
  const metadata = useCallback(async (id: string, patch: { name?: string; location?: string; status?: 'active' | 'archived' }) => {
    if (current.current.record?.id === id) await flush();
    const snapshot = JSON.stringify(modelRef.current);
    const next = await getProject(id);
    const saved = await updateProject(id, next.revision, patch);
    if (current.current.record?.id === id) {
      const editedDuringRequest = JSON.stringify(modelRef.current) !== snapshot;
      if (adopt(saved, false)) {
        const merged = editedDuringRequest ? { ...modelRef.current, ...(patch.name !== undefined ? { name: saved.name } : {}) } : saved.model;
        modelRef.current = merged; setModel(merged);
        await persist();
      }
    }
    await refresh();
  }, [adopt, flush, persist, refresh, setModel]);
  const reload = useCallback(async () => {
    if (flight.current) { try { await flight.current; } catch { /* Explicitly reload after retaining the draft. */ } }
    if (!current.current.record) return;
    const next = await getProject(current.current.record.id);
    blocked.current = false; setError(null); adopt(next); await refresh();
  }, [adopt, refresh]);
  return { projects, record, ready, loading, saving, dirty, backupError, error: error ?? listError,
    flush, open, create, saveCopy, duplicate, metadata, reload, refresh };
}
