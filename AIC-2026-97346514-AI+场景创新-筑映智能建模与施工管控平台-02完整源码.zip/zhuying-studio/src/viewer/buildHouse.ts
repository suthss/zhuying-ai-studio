import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { resolveRoomDesign } from '../design.mjs';
import { confirmedProgress } from '../progress.mjs';
import { makeFloorTexture, makePlasterBump, makeFabricTexture } from './finishes';
import { openingAssembly } from './openings';
import { createFurnitureCollection } from './furniture';
import { getRoomRug } from '../furnishing.mjs';
import { createAIPlanBrief } from '../ai-plan.mjs';
import type { HouseModel, Point, Room, ViewerProps } from '../types';

export function roomCenter(polygon: Point[]): Point {
  let area = 0, x = 0, z = 0;
  polygon.forEach((point, index) => {
    const next = polygon[(index + 1) % polygon.length];
    const cross = point[0] * next[1] - next[0] * point[1];
    area += cross;
    x += (point[0] + next[0]) * cross;
    z += (point[1] + next[1]) * cross;
  });
  if (Math.abs(area) > 1e-6) return [x / (3 * area), z / (3 * area)];
  return [polygon.reduce((sum, point) => sum + point[0], 0) / Math.max(polygon.length, 1), polygon.reduce((sum, point) => sum + point[1], 0) / Math.max(polygon.length, 1)];
}

function random(seed: number) {
  let n = seed;
  return () => { n = (n * 1664525 + 1013904223) >>> 0; return n / 4294967296; };
}

function floorTexture(tile: boolean) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 512;
  const context = canvas.getContext('2d')!;
  const next = random(tile ? 719 : 521);
  if (tile) {
    context.fillStyle = '#a8afa9';
    context.fillRect(0, 0, 512, 512);
    for (let x = 0; x < 512; x += 128) for (let y = 0; y < 512; y += 128) {
      const shade = 197 + Math.floor(next() * 11);
      context.fillStyle = `rgb(${shade + 6},${shade + 7},${shade + 3})`;
      context.fillRect(x + 1.5, y + 1.5, 125, 125);
      for (let j = 0; j < 50; j++) {
        context.strokeStyle = `rgba(127,135,125,${next() * 0.04})`;
        context.beginPath(); context.moveTo(x + next() * 128, y + next() * 128);
        context.lineTo(x + next() * 128, y + next() * 128); context.stroke();
      }
    }
  } else {
    context.fillStyle = '#ba9468'; context.fillRect(0, 0, 512, 512);
    for (let row = 0; row < 8; row++) {
      const shade = next() * 20;
      context.fillStyle = `rgb(${195 + shade},${160 + shade},${111 + shade})`;
      context.fillRect(0, row * 64 + 1, 512, 62);
      const offset = row % 2 ? 145 : 360;
      context.fillStyle = '#ac895e'; context.fillRect(offset, row * 64, 1.5, 64);
      for (let line = 0; line < 85; line++) {
        const y = row * 64 + next() * 64;
        context.strokeStyle = `rgba(110,76,35,${next() * 0.12})`;
        context.lineWidth = next() * 1.3 + 0.2;
        context.beginPath(); context.moveTo(0, y);
        context.bezierCurveTo(170, y + next() * 3, 350, y - next() * 3, 512, y); context.stroke();
      }
    }
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(tile ? 0.5 : 0.32, tile ? 0.5 : 0.32);
  texture.anisotropy = 8;
  return texture;
}

function material(color: string, extra?: THREE.MeshStandardMaterialParameters) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.78, ...extra });
}

function box(group: THREE.Group, dimensions: [number, number, number], position: [number, number, number], mat: THREE.Material | THREE.Material[], rounded = false) {
  const geometry = rounded ? new RoundedBoxGeometry(...dimensions, 3, Math.min(...dimensions) * 0.16) : new THREE.BoxGeometry(...dimensions);
  const mesh = new THREE.Mesh(geometry, mat);
  mesh.position.set(...position); mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh);
  return mesh;
}

function rod(group: THREE.Group, a: THREE.Vector3, b: THREE.Vector3, radius: number, mat: THREE.Material) {
  const direction = b.clone().sub(a);
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, direction.length(), 8), mat);
  mesh.position.copy(a).add(b).multiplyScalar(0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize());
  group.add(mesh); return mesh;
}

function textSprite(text: string, color = '#64796d', size = 0.34) {
  const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 80;
  const context = canvas.getContext('2d')!;
  context.font = '500 38px Arial'; context.textAlign = 'center'; context.textBaseline = 'middle'; context.fillStyle = color;
  context.fillText(text, 128, 40);
  const texture = new THREE.CanvasTexture(canvas);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false, opacity: 0.8 }));
  sprite.scale.set(size * 3.2, size, 1); return sprite;
}

function fixtures(group: THREE.Group, model: HouseModel) {
  const furniture = new THREE.Group(); furniture.name = '示例软装 · 仅示例户型'; group.add(furniture);
  const cream = material('#ede8dd');
  const sofa = material('#ffffff', { map: makeFabricTexture('#c4c8ba'), roughness: 0.97 });
  const textile = material('#ffffff', { map: makeFabricTexture('#a4aea1'), roughness: 1 });
  const dark = material('#4d5750');
  const oak = material('#ae8860', { map: floorTexture(false) });
  const white = material('#f5f3ec', { roughness: 0.5 });
  const demoPolygons: Record<string, Point[]> = {
    living: [[0, 4], [7, 4], [7, 9], [0, 9]], master: [[7, 4], [12, 4], [12, 9], [7, 9]],
    kitchen: [[0, 0], [4, 0], [4, 4], [0, 4]], bathroom: [[4, 0], [7, 0], [7, 2.1], [4, 2.1]],
    entry: [[4, 2.1], [7, 2.1], [7, 4], [4, 4]], study: [[7, 0], [12, 0], [12, 4], [7, 4]],
  };
  const room = (id: string, callback: (g: THREE.Group) => void) => {
    const actual = model.rooms.find(item => item.id === id), expected = demoPolygons[id];
    if (!actual || !expected || actual.polygon.length !== expected.length || !actual.polygon.every(point => expected.some(match => Math.hypot(point[0] - match[0], point[1] - match[1]) < 0.01))) return;
    const g = new THREE.Group(); g.name = id; g.userData.roomId = id; furniture.add(g);
    callback(g); g.traverse(item => { item.userData.roomId = id; item.userData.kind = 'furniture'; });
  };
  room('living', g => {
    box(g, [3.4, 0.25, 1.05], [2.8, 0.29, 7.65], dark, true);
    box(g, [3.35, 0.43, 0.24], [2.8, 0.74, 8.02], sofa, true);
    box(g, [0.24, 0.58, 1.05], [1.2, 0.61, 7.65], sofa, true);
    box(g, [0.24, 0.58, 1.05], [4.4, 0.61, 7.65], sofa, true);
    for (let i = 0; i < 3; i++) box(g, [0.93, 0.2, 0.75], [1.84 + i * 0.96, 0.52, 7.56], sofa, true);
    for (let i = 0; i < 3; i++) box(g, [0.92, 0.37, 0.18], [1.84 + i * 0.96, 0.81, 7.95], sofa, true).rotation.x = -0.13;
    for (const x of [1.35, 4.25]) for (const z of [7.27, 8.02]) box(g, [0.055, 0.12, 0.055], [x, 0.13, z], oak);
    box(g, [0.44, 0.4, 0.15], [1.7, 0.82, 7.85], textile, true).rotation.z = -0.18;
    box(g, [0.44, 0.4, 0.15], [3.95, 0.82, 7.85], cream, true).rotation.z = 0.16;
    box(g, [3.35, 0.022, 2.7], [2.8, 0.055, 6.6], material('#ffffff', { map: makeFabricTexture('#ddd8c9', true), roughness: 1 }), true);
    box(g, [1.65, 0.12, 0.82], [2.8, 0.52, 6.1], oak, true);
    for (const x of [2.16, 3.44]) for (const z of [5.85, 6.35]) box(g, [0.06, 0.43, 0.06], [x, 0.29, z], dark);
    box(g, [0.35, 0.035, 0.25], [2.45, 0.602, 6.1], textile);
    // Spine door occupies z=5.0..5.95; all cabinet parts now start beyond z=6.675.
    box(g, [0.42, 0.42, 1.65], [6.61, 0.3, 7.5], oak, true).name = '客厅 · 电视柜';
    for (const z of [7.1, 7.66]) box(g, [0.016, 0.3, 0.006], [6.386, 0.31, z], dark);
    box(g, [0.045, 0.85, 1.3], [6.68, 1.01, 7.5], dark, true);
    box(g, [0.009, 0.75, 1.17], [6.65, 1.01, 7.5], material('#26372f', { roughness: 0.3, metalness: 0.18 }), true);
    box(g, [0.11, 0.08, 0.38], [6.63, 0.59, 7.5], dark, true);
    plant(g, 0.78, 4.75);
  });
  room('master', g => {
    box(g, [2.18, 0.32, 2.55], [9.65, 0.24, 6.28], oak, true);
    box(g, [2.02, 0.26, 2.34], [9.65, 0.53, 6.27], white, true);
    box(g, [2.18, 1.02, 0.16], [9.65, 0.61, 5.08], sofa, true);
    box(g, [2.08, 0.13, 1.62], [9.65, 0.73, 6.63], textile, true);
    box(g, [2.11, 0.065, 0.42], [9.65, 0.82, 7.1], material('#ffffff', { map: makeFabricTexture('#c5b595'), roughness: 1 }), true);
    for (const x of [8.68, 10.62]) box(g, [0.055, 0.26, 1.58], [x, 0.59, 6.55], textile, true);
    box(g, [0.76, 0.16, 0.46], [9.14, 0.75, 5.45], white, true);
    box(g, [0.76, 0.16, 0.46], [10.16, 0.75, 5.45], white, true);
    box(g, [0.47, 0.13, 0.32], [9.18, 0.88, 5.6], textile, true);
    box(g, [0.47, 0.13, 0.32], [10.12, 0.88, 5.6], textile, true);
    for (const x of [8.25, 11.1]) {
      box(g, [0.5, 0.43, 0.48], [x, 0.3, 5.47], oak, true).name = `主卧 · 床头柜${x < 9 ? '左' : '右'}`;
      box(g, [0.38, 0.012, 0.006], [x, 0.37, 5.718], dark);
      const lamp = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.21, 0.24, 18), cream);
      lamp.position.set(x, 0.82, 5.47); lamp.castShadow = true; g.add(lamp);
      rod(g, new THREE.Vector3(x, 0.55, 5.47), new THREE.Vector3(x, 0.72, 5.47), 0.018, dark);
    }
    // Solid south wall has no bedroom window; keep the east window entirely free.
    box(g, [2.9, 2.25, 0.5], [10.2, 1.19, 8.56], cream).name = '主卧 · 南墙衣柜';
    for (const x of [9.25, 10.2, 11.15]) {
      box(g, [0.005, 2.12, 0.006], [x + 0.45, 1.2, 8.303], dark);
      box(g, [0.012, 0.26, 0.032], [x + 0.32, 1.23, 8.285], oak);
    }
  });
  room('kitchen', g => {
    box(g, [3.4, 0.76, 0.65], [2.0, 0.46, 0.48], textile);
    box(g, [3.48, 0.09, 0.72], [2, 0.9, 0.48], cream);
    box(g, [0.65, 0.76, 2.35], [0.48, 0.46, 1.92], textile);
    box(g, [0.72, 0.09, 2.43], [0.48, 0.9, 1.92], cream);
    for (let x = 0.5; x < 3.6; x += 0.56) box(g, [0.015, 0.65, 0.012], [x, 0.48, 0.815], dark);
    box(g, [0.66, 0.025, 0.46], [2.9, 0.963, 0.49], dark, true);
    for (const x of [2.73, 3.07]) for (const z of [0.38, 0.62]) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.073, 0.006, 6, 24), material('#949b91'));
      ring.rotation.x = Math.PI / 2; ring.position.set(x, 0.981, z); g.add(ring);
    }
    box(g, [0.48, 0.035, 0.39], [0.48, 0.958, 1.83], material('#879792', { metalness: 0.6 }), true);
    rod(g, new THREE.Vector3(0.48, 0.98, 2.03), new THREE.Vector3(0.48, 1.19, 2.03), 0.018, dark);
    box(g, [0.79, 1.28, 0.77], [3.36, 0.7, 2.06], cream, true);
  });
  room('bathroom', g => {
    box(g, [0.83, 0.76, 0.48], [4.7, 0.46, 0.42], oak, true);
    box(g, [0.87, 0.07, 0.52], [4.7, 0.88, 0.42], white);
    const basin = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.2, 0.12, 28), white);
    basin.scale.z = 0.68; basin.position.set(4.7, 0.98, 0.42); g.add(basin);
    box(g, [0.38, 0.66, 0.2], [6.36, 0.42, 0.31], white, true);
    const toilet = new THREE.Mesh(new THREE.SphereGeometry(0.27, 24, 18), white);
    toilet.scale.set(0.88, 0.65, 1.25); toilet.position.set(6.36, 0.36, 0.68); toilet.castShadow = true; g.add(toilet);
    box(g, [0.27, 0.25, 0.33], [6.36, 0.2, 0.62], white, true);
  });
  room('study', g => {
    box(g, [2.07, 0.1, 0.78], [9.4, 0.86, 0.74], oak, true);
    for (const x of [8.48, 10.32]) for (const z of [0.48, 0.98]) rod(g, new THREE.Vector3(x, 0.1, z), new THREE.Vector3(x, 0.81, z), 0.025, dark);
    box(g, [0.65, 0.38, 0.05], [9.37, 1.15, 0.58], dark, true);
    box(g, [0.035, 0.14, 0.06], [9.37, 0.98, 0.58], dark);
    box(g, [0.58, 0.025, 0.17], [9.37, 0.93, 0.91], cream);
    box(g, [0.62, 0.12, 0.58], [9.4, 0.51, 1.7], textile, true);
    box(g, [0.62, 0.56, 0.13], [9.4, 0.8, 1.94], textile, true);
    rod(g, new THREE.Vector3(9.4, 0.13, 1.7), new THREE.Vector3(9.4, 0.48, 1.7), 0.06, dark);
    for (let i = 0; i < 5; i++) {
      const angle = i * Math.PI * 2 / 5;
      rod(g, new THREE.Vector3(9.4, 0.12, 1.7), new THREE.Vector3(9.4 + Math.sin(angle) * 0.32, 0.1, 1.7 + Math.cos(angle) * 0.32), 0.016, dark);
    }
    box(g, [0.49, 1.1, 2.4], [11.58, 0.62, 2.11], oak);
    for (let z = 1.08; z < 3.2; z += 0.18) box(g, [0.31, 0.28 + (z % 0.2), 0.1], [11.56, 0.8, z], z < 2 ? textile : cream);
    plant(g, 7.8, 0.8);
  });
  room('entry', g => {
    box(g, [1.5, 0.76, 0.38], [5.56, 0.44, 2.39], cream, true);
    box(g, [1.5, 0.07, 0.4], [5.56, 0.86, 2.39], oak);
  });
}

function plant(group: THREE.Group, x: number, z: number) {
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.15, 0.38, 24), material('#b7a88e'));
  pot.position.set(x, 0.25, z); pot.castShadow = true; group.add(pot);
  const leaves = material('#6e8566', { roughness: 1 });
  for (let i = 0; i < 9; i++) {
    const angle = i * Math.PI * 2 / 9;
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 8), leaves);
    leaf.scale.set(0.7, 2.6, 0.5);
    leaf.position.set(x + Math.sin(angle) * 0.17, 0.66 + i % 3 * 0.06, z + Math.cos(angle) * 0.17);
    leaf.rotation.z = Math.sin(angle) * 0.44; leaf.rotation.x = Math.cos(angle) * 0.44;
    leaf.castShadow = true; group.add(leaf);
  }
}

function progressColor(room: Room) {
  const summary = confirmedProgress(room);
  if (summary.known === 0) return '#d4d7cf';
  if (summary.total > 0 && summary.completed === summary.total) return '#9dc5b4';
  if ((summary.percent ?? 0) > 0) return '#dfc58f';
  return '#bdc8d0';
}

function containsPoint(polygon: Point[], point: Point) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const a = polygon[i], b = polygon[j];
    if ((a[1] > point[1]) !== (b[1] > point[1]) && point[0] < (b[0] - a[0]) * (point[1] - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
  }
  return inside;
}

function roomBoundaries(model: HouseModel, start: Point, dx: number, dz: number, length: number, thickness: number) {
  const offsets: number[] = [];
  const tolerance = thickness / 2 + 0.035;
  for (const room of model.rooms) room.polygon.forEach((a, index) => {
    const b = room.polygon[(index + 1) % room.polygon.length];
    const normalA = -(a[0] - start[0]) * dz + (a[1] - start[1]) * dx;
    const normalB = -(b[0] - start[0]) * dz + (b[1] - start[1]) * dx;
    const along = (p: Point) => (p[0] - start[0]) * dx + (p[1] - start[1]) * dz;
    if (Math.abs(normalA) <= tolerance) offsets.push(along(a));
    if (Math.abs(normalB) <= tolerance) offsets.push(along(b));
    if (normalA * normalB < 0) {
      const ratio = normalA / (normalA - normalB);
      offsets.push(along([a[0] + (b[0] - a[0]) * ratio, a[1] + (b[1] - a[1]) * ratio]));
    }
  });
  return offsets.filter(value => value > 0.001 && value < length - 0.001);
}

export function buildHouse(model: HouseModel, mode: ViewerProps['viewMode'], cutaway: boolean, showFurniture: boolean, interiorRoom: string | null = null) {
  const group = new THREE.Group(); group.name = `${model.name} · 筑映建筑模型`;
  group.userData = { modelId: model.id, modelName: model.name, source: model.source, units: 'metres', width: model.width, depth: model.depth, height: model.height, displayMode: mode, cutaway, interiorRoom };
  const architecture = new THREE.Group(); architecture.position.set(-model.width / 2, 0, -model.depth / 2); group.add(architecture);
  const selections = new Map<string, THREE.Group>();
  const hovers = new Map<string, THREE.Group>();
  const foundation = new THREE.Group(); foundation.name = '随户型轮廓的薄基础';
  foundation.userData = { kind: 'foundation' }; architecture.add(foundation);
  const foundationMaterial = material('#c5cbc3');
  const foundationCap = material('#e4e8e0');
  // Room polygons keep recessed exterior areas empty. Shared open-zone edges
  // are not expanded, so adjacent zones never produce overlapping top faces.
  // A narrow wall support provides the wall's half-thickness allowance only
  // where a real wall exists; its top stays below the room slab to avoid z-fighting.
  for (const wall of model.walls) {
    const length = Math.hypot(wall.end[0] - wall.start[0], wall.end[1] - wall.start[1]);
    if (length < 0.02) continue;
    const support = box(foundation, [length + 0.04, 0.23, Math.max(wall.thickness, 0.02) + 0.04],
      [(wall.start[0] + wall.end[0]) / 2, -0.125, (wall.start[1] + wall.end[1]) / 2], foundationMaterial);
    support.rotation.y = -Math.atan2(wall.end[1] - wall.start[1], wall.end[0] - wall.start[0]);
    support.name = `${wall.id} · 窄墙托底`; support.userData.kind = 'foundation';
  }
  const floorMaps = new Map<string, THREE.CanvasTexture>();
  const outlineMaterial = new THREE.MeshBasicMaterial({ color: '#26795b', depthTest: true });
  const outlineBacking = new THREE.MeshBasicMaterial({ color: '#f7fff9', depthTest: true });
  const hoverMaterial = new THREE.MeshBasicMaterial({ color: '#6eab91', transparent: true, opacity: 0.75 });
  const designs = new Map(model.rooms.map(room => [room.id, resolveRoomDesign(room)]));
  const roomUses = new Map(createAIPlanBrief(model).rooms.map(room => [room.roomId, room.use]));
  group.userData.roomDesigns = model.rooms.map(room => ({ roomId: room.id, roomName: room.name, design: designs.get(room.id) }));
  model.rooms.forEach(room => {
    if (room.polygon.length < 3) return;
    const shape = new THREE.Shape();
    room.polygon.forEach((point, i) => i === 0 ? shape.moveTo(point[0], -point[1]) : shape.lineTo(point[0], -point[1]));
    shape.closePath();
    for (const layer of [{ depth: 0.2, bottom: -0.24, mat: foundationMaterial }, { depth: 0.04, bottom: -0.04, mat: foundationCap }]) {
      const slab = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: layer.depth, bevelEnabled: false, steps: 1 }), layer.mat);
      slab.rotation.x = -Math.PI / 2; slab.position.y = layer.bottom;
      slab.castShadow = true; slab.receiveShadow = true;
      slab.name = `${room.name} · 轮廓基础`; slab.userData = { kind: 'foundation' };
      foundation.add(slab);
    }
    const design = designs.get(room.id)!;
    const textureKey = `${design.floorFinish}:${design.floorDirection}`;
    let texture: THREE.CanvasTexture | null = null;
    if (mode === 'material') {
      texture = floorMaps.get(textureKey) ?? makeFloorTexture(design.floorFinish, design.floorDirection);
      floorMaps.set(textureKey, texture);
    }
    const roughness = design.floorFinish === 'concrete' ? 0.98 : ['light_tile', 'gray_stone', 'terrazzo'].includes(design.floorFinish) ? 0.56 : 0.75;
    const floorMaterial = mode === 'progress' ? material(progressColor(room), { roughness: 0.86 }) : material('#ffffff', { map: texture, roughness });
    const floor = new THREE.Mesh(new THREE.ShapeGeometry(shape), floorMaterial);
    floor.rotation.x = -Math.PI / 2; floor.position.y = 0.022; floor.receiveShadow = true;
    floor.userData = { roomId: room.id, roomName: room.name, kind: 'floor', area: room.area, progressIndex: confirmedProgress(room).percent, tasks: structuredClone(room.tasks), design: { ...design } };
    floor.name = room.name; architecture.add(floor);
    if (room.id === interiorRoom) {
      const ceiling = new THREE.Mesh(new THREE.ShapeGeometry(shape), material('#f4f0e7', { roughness: 0.95, side: THREE.DoubleSide }));
      ceiling.rotation.x = -Math.PI / 2; ceiling.position.y = model.height + 0.045; ceiling.receiveShadow = true;
      ceiling.name = `${room.name} · 室内顶面`; ceiling.userData = { roomId: room.id, kind: 'ceiling' }; architecture.add(ceiling);
      const center = roomCenter(room.polygon);
      const lightFixture = new THREE.Group(); lightFixture.name = `${room.name} · 暖光吊灯`; lightFixture.userData = { roomId: room.id, kind: 'light' }; architecture.add(lightFixture);
      const brass = material('#9c917a', { metalness: 0.45, roughness: 0.35 });
      rod(lightFixture, new THREE.Vector3(center[0], model.height - 0.04, center[1]), new THREE.Vector3(center[0], model.height - 0.38, center[1]), 0.012, brass);
      const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.44, 0.16, 36), brass);
      shade.position.set(center[0], model.height - 0.43, center[1]); lightFixture.add(shade);
      const diffuser = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.017, 36), material('#fff2d1', { emissive: '#ffcb87', emissiveIntensity: 1.2, roughness: 0.8 }));
      diffuser.position.set(center[0], model.height - 0.516, center[1]); lightFixture.add(diffuser);
      lightFixture.traverse(item => { item.userData.roomId = room.id; item.userData.kind = 'light'; });
      const glow = new THREE.PointLight('#ffe4b4', 5, 9, 2); glow.position.set(center[0], model.height - 0.62, center[1]); architecture.add(glow);
    }
    if (interiorRoom) return;
    const outline = new THREE.Group(); outline.name = `${room.name}选中边界`; outline.visible = false;
    outline.userData.ignorePick = true;
    const hover = new THREE.Group(); hover.name = `${room.name}悬停边界`; hover.visible = false; hover.userData.ignorePick = true;
    const center = roomCenter(room.polygon);
    const inset = room.polygon.map(point => {
      const dx = center[0] - point[0], dz = center[1] - point[1];
      const length = Math.max(Math.hypot(dx, dz), 0.01);
      return [point[0] + dx / length * 0.21, point[1] + dz / length * 0.21] as Point;
    });
    inset.forEach((point, index) => {
      const next = inset[(index + 1) % inset.length];
      rod(outline, new THREE.Vector3(point[0], 0.067, point[1]), new THREE.Vector3(next[0], 0.067, next[1]), 0.055, outlineBacking);
      rod(outline, new THREE.Vector3(point[0], 0.10, point[1]), new THREE.Vector3(next[0], 0.10, next[1]), 0.028, outlineMaterial);
      rod(hover, new THREE.Vector3(point[0], 0.065, point[1]), new THREE.Vector3(next[0], 0.065, next[1]), 0.019, hoverMaterial);
    });
    architecture.add(outline); selections.set(room.id, outline);
    architecture.add(hover); hovers.set(room.id, hover);
  });
  if (interiorRoom) { outlineMaterial.dispose(); outlineBacking.dispose(); hoverMaterial.dispose(); }
  const wallMaterial = material('#f2eee5', { roughness: 0.92, side: THREE.DoubleSide });
  const capMaterial = material('#d7d2c5', { roughness: 0.73 });
  const trimMaterial = material('#e8e2d5');
  const interiorMaterials = new Map<string, THREE.MeshStandardMaterial>();
  let plaster: THREE.CanvasTexture | null = null;
  const interior = (room: Room | undefined) => {
    if (!room || mode === 'progress') return wallMaterial;
    const design = designs.get(room.id)!;
    const key = `${design.wallColor}:${design.wallFinish}`;
    let mat = interiorMaterials.get(key);
    if (!mat) {
      if (design.wallFinish === 'plaster') plaster ??= makePlasterBump();
      mat = material(design.wallColor, { roughness: design.wallFinish === 'plaster' ? 0.98 : 0.78, bumpMap: design.wallFinish === 'plaster' ? plaster : null, bumpScale: 0.008, side: THREE.DoubleSide });
      interiorMaterials.set(key, mat);
    }
    return mat;
  };
  model.walls.forEach(wall => {
    const length = Math.hypot(wall.end[0] - wall.start[0], wall.end[1] - wall.start[1]);
    if (length < 0.02) return;
    const fullHeight = wall.height || model.height;
    const farExterior = Math.max(wall.start[0], wall.end[0]) < 0.15 || Math.max(wall.start[1], wall.end[1]) < 0.15;
    const nearExterior = Math.min(wall.start[0], wall.end[0]) > model.width - 0.15 || Math.min(wall.start[1], wall.end[1]) > model.depth - 0.15;
    const height = cutaway && !interiorRoom ? Math.min(fullHeight, farExterior ? fullHeight : nearExterior ? 1.08 : 1.5) : fullHeight;
    const thickness = Math.max(wall.thickness, 0.02);
    const dx = (wall.end[0] - wall.start[0]) / length, dz = (wall.end[1] - wall.start[1]) / length;
    const neighbors = (offset: number) => {
      const x = wall.start[0] + dx * offset, z = wall.start[1] + dz * offset;
      const distance = thickness / 2 + 0.045;
      return {
        positive: model.rooms.find(room => containsPoint(room.polygon, [x - dz * distance, z + dx * distance])),
        negative: model.rooms.find(room => containsPoint(room.polygon, [x + dz * distance, z - dx * distance])),
      };
    };
    const assignFaces = (mesh: THREE.Mesh, left: number, right: number, side?: 1 | -1) => {
      const adjacent = neighbors((left + right) / 2);
      mesh.userData.wallId = wall.id;
      mesh.userData.kind = 'wall';
      mesh.userData.faceRooms = [adjacent.positive?.id ?? adjacent.negative?.id ?? null, adjacent.negative?.id ?? adjacent.positive?.id ?? null, null, null, adjacent.positive?.id ?? null, adjacent.negative?.id ?? null];
      mesh.userData.wallRooms = { positive: adjacent.positive?.id ?? null, negative: adjacent.negative?.id ?? null };
      mesh.userData.wallPlane = { x: wall.start[0] - model.width / 2, z: wall.start[1] - model.depth / 2, nx: -dz, nz: dx };
      if (side) mesh.userData.roomId = side === 1 ? adjacent.positive?.id : adjacent.negative?.id;
      return adjacent;
    };
    const g = new THREE.Group();
    g.name = wall.id;
    g.position.set(wall.start[0], 0.045, wall.start[1]);
    g.rotation.y = -Math.atan2(wall.end[1] - wall.start[1], wall.end[0] - wall.start[0]);
    architecture.add(g);
    const openings = model.openings.filter(opening => opening.wallId === wall.id).map(opening => ({ ...opening, left: Math.max(0, opening.offset), right: Math.min(length, opening.offset + opening.width) })).filter(opening => opening.right > opening.left).sort((a, b) => a.left - b.left);
    const breaks = [...new Set([0, length, ...openings.flatMap(opening => [opening.left, opening.right]), ...roomBoundaries(model, wall.start, dx, dz, length, thickness)].map(value => Math.round(value * 10000) / 10000))].sort((a, b) => a - b);
    const segment = (left: number, right: number, bottom: number, top: number) => {
      if (right - left < 0.015 || top - bottom < 0.015) return;
      const adjacent = neighbors((left + right) / 2);
      const surface = box(g, [right - left, top - bottom, thickness], [(left + right) / 2, (top + bottom) / 2, 0], [wallMaterial, wallMaterial, capMaterial, capMaterial, interior(adjacent.positive), interior(adjacent.negative)]);
      assignFaces(surface, left, right);
      if (Math.abs(top - height) < 0.01) assignFaces(box(g, [right - left, 0.035, thickness + 0.015], [(left + right) / 2, height + 0.01, 0], capMaterial), left, right);
      if (bottom <= 0.01) for (const side of [-1, 1] as const) assignFaces(box(g, [right - left, 0.09, 0.02], [(left + right) / 2, 0.05, side * (thickness / 2 + 0.012)], trimMaterial), left, right, side);
      if (!cutaway && Math.abs(top - fullHeight) < 0.01) for (const side of [-1, 1] as const) assignFaces(box(g, [right - left, 0.055, 0.04], [(left + right) / 2, height - 0.045, side * (thickness / 2 + 0.023)], trimMaterial), left, right, side);
    };
    for (let i = 0; i < breaks.length - 1; i++) {
      const a = breaks[i], b = breaks[i + 1], middle = (a + b) / 2;
      const crossing = openings.filter(opening => opening.left < middle && opening.right > middle);
      if (!crossing.length) { segment(a, b, 0, height); continue; }
      const voids = crossing.map(opening => ({ bottom: opening.type === 'window' ? Math.max(0, opening.sill ?? 0) : 0, top: Math.min(height, (opening.type === 'window' ? opening.sill ?? 0 : 0) + opening.height) })).sort((u, v) => u.bottom - v.bottom);
      let cursor = 0;
      for (const opening of voids) {
        segment(a, b, cursor, Math.min(opening.bottom, height));
        cursor = Math.max(cursor, opening.top);
      }
      segment(a, b, cursor, height);
    }
    openings.forEach(opening => {
      const adjacent = neighbors((opening.left + opening.right) / 2);
      const curtainRoom = [adjacent.positive, adjacent.negative].find(room => room && ['living', 'bedroom', 'study'].includes(roomUses.get(room.id) ?? 'empty'));
      const curtainSide: 1 | -1 | undefined = curtainRoom && (interiorRoom === curtainRoom.id || !cutaway || farExterior)
        ? curtainRoom.id === adjacent.positive?.id ? 1 : -1 : undefined;
      const assembly = openingAssembly(opening, {
        thickness, wallHeight: height, fullHeight,
        metadata: {
          wallId: wall.id,
          roomIds: [adjacent.positive?.id, adjacent.negative?.id].filter(Boolean),
          wallRooms: { positive: adjacent.positive?.id ?? null, negative: adjacent.negative?.id ?? null },
          wallPlane: { x: wall.start[0] - model.width / 2, z: wall.start[1] - model.depth / 2, nx: -dz, nz: dx },
        }, curtainSide,
      });
      g.add(assembly);
    });
  });
  if (showFurniture && mode === 'material') {
    if (model.furniture !== undefined) {
      for (const room of model.rooms) {
        const rug = getRoomRug(model, room.id);
        if (!rug) continue;
        const mesh = box(architecture, rug.size, [rug.position[0], 0.03, rug.position[1]], material('#ffffff', { map: makeFabricTexture(rug.color, true), roughness: 1 }), true);
        mesh.rotation.y = rug.rotation; mesh.castShadow = false;
        mesh.name = `${room.name} · 编织地毯`;
        // It is a floor finish, so it does not become a furniture obstruction
        // or intercept room entry in the interactive model.
        mesh.userData = { roomId: room.id, kind: 'floor', decoration: 'rug', ignorePick: true };
      }
      architecture.add(createFurnitureCollection(model.furniture));
    }
    else if ((model.source === 'demo' || model.meta?.demoData === true) && model.width === 12 && model.depth === 9) fixtures(architecture, model);
  }
  const ruler = new THREE.Group(); ruler.name = '米制比例标尺'; ruler.userData.ignorePick = true; group.add(ruler);
  ruler.visible = !interiorRoom;
  const rulerMat = material('#a6b4a9');
  const halfW = model.width / 2, halfD = model.depth / 2;
  rod(ruler, new THREE.Vector3(-halfW, -0.265, halfD + 0.6), new THREE.Vector3(halfW, -0.265, halfD + 0.6), 0.006, rulerMat);
  rod(ruler, new THREE.Vector3(-halfW - 0.6, -0.265, -halfD), new THREE.Vector3(-halfW - 0.6, -0.265, halfD), 0.006, rulerMat);
  const increment = Math.max(1, Math.ceil(Math.max(model.width, model.depth) / 24));
  for (let meter = 0; meter <= model.width; meter += increment) {
    const x = meter - halfW;
    rod(ruler, new THREE.Vector3(x, -0.265, halfD + 0.48), new THREE.Vector3(x, -0.265, halfD + 0.72), 0.006, rulerMat);
    if (meter % (increment * 2) === 0) { const label = textSprite(`${meter}`); label.position.set(x, -0.18, halfD + 0.9); ruler.add(label); }
  }
  for (let meter = 0; meter <= model.depth; meter += increment) {
    const z = meter - halfD;
    rod(ruler, new THREE.Vector3(-halfW - 0.48, -0.265, z), new THREE.Vector3(-halfW - 0.72, -0.265, z), 0.006, rulerMat);
    if (meter % (increment * 2) === 0) { const label = textSprite(`${meter}`); label.position.set(-halfW - 0.96, -0.18, z); ruler.add(label); }
  }
  const unit = textSprite('METRES', '#728376', 0.25); unit.position.set(0, -0.1, halfD + 1.3); ruler.add(unit);
  const north = textSprite('N ↑', '#607867', 0.43); north.position.set(halfW + 0.78, 0.08, -halfD + 0.15); ruler.add(north);
  return { group, selections, hovers };
}

export function disposeTree(root: THREE.Object3D) {
  const textures = new Set<THREE.Texture>();
  const materials = new Set<THREE.Material>();
  const geometries = new Set<THREE.BufferGeometry>();
  root.traverse(object => {
    if (object instanceof THREE.Mesh || object instanceof THREE.Sprite || object instanceof THREE.Line) {
      if ('geometry' in object && object.geometry instanceof THREE.BufferGeometry) geometries.add(object.geometry);
      const list = Array.isArray(object.material) ? object.material : [object.material];
      list.forEach(mat => {
        materials.add(mat);
        Object.values(mat).forEach(value => { if (value instanceof THREE.Texture) textures.add(value); });
      });
    }
  });
  geometries.forEach(geometry => geometry.dispose());
  materials.forEach(mat => mat.dispose());
  textures.forEach(texture => texture.dispose());
}
