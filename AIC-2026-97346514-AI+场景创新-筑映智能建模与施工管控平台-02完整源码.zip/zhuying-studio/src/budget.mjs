import { FLOOR_FINISHES, resolveRoomDesign } from './design.mjs';
import { getMeasurementReview } from './layout-audit.mjs';

const EPS = 1e-7;
const QUANTITY_SCALE = 1_000_000;
const MAX_PRICE = 10_000_000;
const object = value => !!value && typeof value === 'object' && !Array.isArray(value);
const finite = value => typeof value === 'number' && Number.isFinite(value);
const text = value => typeof value === 'string' && value.trim().length > 0 && value.length <= 160;
const point = value => Array.isArray(value) && value.length === 2 && value.every(finite);
const exactKeys = (value, keys) => object(value) && Object.keys(value).every(key => keys.includes(key));
const fail = message => { throw new Error(`材料预算配置无效：${message}`); };
const decimal = (value, maximum) => finite(value) && value >= 0 && value <= maximum
  && Number(value.toFixed(2)) === value;
const validPrice = value => value === null || decimal(value, MAX_PRICE);
const quantity = value => {
  if (!finite(value) || value < 0 || value * QUANTITY_SCALE > Number.MAX_SAFE_INTEGER) throw new Error('工程量超出可计算范围，请核对模型几何。');
  return Math.round(value * QUANTITY_SCALE) / QUANTITY_SCALE;
};

export const FURNITURE_LABELS = Object.freeze({ sofa: '沙发', coffee_table: '茶几', tv_console: '电视柜', bed_double: '双人床',
  bed_single: '单人床', wardrobe: '衣柜', desk: '书桌', chair: '椅子', dining_table: '餐桌', kitchen_counter: '厨房台面',
  sink_cabinet: '水槽柜', toilet: '坐便器', shoe_cabinet: '鞋柜' });

/** Empty prices mean unquoted; zero is accepted only as an explicit user quote. */
export function createBudgetConfig() {
  return { version: 1, selectedQuoteId: 'quote-a', quotes: [{ id: 'quote-a', name: '方案 A', rooms: {}, furniture: {} }] };
}

/** Returns an isolated copy. Orphaned references are preserved for explicit review/cleanup. */
export function validateBudgetConfig(raw, model) {
  if (!exactKeys(raw, ['version', 'selectedQuoteId', 'quotes']) || raw.version !== 1 || !text(raw.selectedQuoteId)
      || !Array.isArray(raw.quotes) || raw.quotes.length < 1 || raw.quotes.length > 2) fail('需包含 1–2 套报价及有效的当前方案。');
  const quotes = raw.quotes.map(quote => {
    if (!exactKeys(quote, ['id', 'name', 'rooms', 'furniture']) || !text(quote.id) || !text(quote.name)
        || !object(quote.rooms) || !object(quote.furniture)) fail('方案名称、编号或报价清单无效。');
    if (Object.keys(quote.rooms).length > 200 || Object.keys(quote.furniture).length > 600) fail('报价条目过多，请清理已删除构件的报价。');
    const rooms = Object.fromEntries(Object.entries(quote.rooms).map(([id, row]) => {
      if (!text(id) || !exactKeys(row, ['floorUnitPrice', 'floorWastePercent', 'wallUnitPrice'])
          || !validPrice(row.floorUnitPrice) || !validPrice(row.wallUnitPrice) || !decimal(row.floorWastePercent, 100)) {
        fail('单价需留空或输入 0–10000000 元的两位小数；地板损耗率需为 0–100%。');
      }
      return [id, { floorUnitPrice: row.floorUnitPrice, floorWastePercent: row.floorWastePercent, wallUnitPrice: row.wallUnitPrice }];
    }));
    const furniture = Object.fromEntries(Object.entries(quote.furniture).map(([id, price]) => {
      if (!text(id) || !validPrice(price)) fail('家具按件单价无效。');
      return [id, price];
    }));
    return { id: quote.id, name: quote.name, rooms, furniture };
  });
  if (new Set(quotes.map(quote => quote.id)).size !== quotes.length || !quotes.some(quote => quote.id === raw.selectedQuoteId)) fail('方案编号重复或当前方案不存在。');
  if (model !== undefined && (!object(model) || !Array.isArray(model.rooms) || !Array.isArray(model.walls))) fail('关联项目无效。');
  return { version: 1, selectedQuoteId: raw.selectedQuoteId, quotes };
}

export function getBudgetConfig(model) {
  return model.meta?.materialBudget === undefined ? createBudgetConfig() : validateBudgetConfig(model.meta.materialBudget, model);
}

export function setBudgetConfig(model, config) {
  return { ...model, meta: { ...model.meta, materialBudget: validateBudgetConfig(config, model) } };
}

export function getRoomQuote(quote, roomId) {
  return Object.hasOwn(quote.rooms, roomId) ? { ...quote.rooms[roomId] }
    : { floorUnitPrice: null, floorWastePercent: 0, wallUnitPrice: null };
}

export function createBudgetQuote(config, copyId = null) {
  const next = validateBudgetConfig(config);
  if (next.quotes.length >= 2) throw new Error('最多保留两套报价方案。');
  const source = copyId === null ? null : next.quotes.find(quote => quote.id === copyId);
  if (copyId !== null && !source) throw new Error('待复制的报价方案不存在。');
  const id = next.quotes.some(quote => quote.id === 'quote-b') ? 'quote-a' : 'quote-b';
  next.quotes.push({ id, name: source ? `${source.name.slice(0, 150)} · 副本` : '方案 B',
    rooms: source ? structuredClone(source.rooms) : {}, furniture: source ? { ...source.furniture } : {} });
  next.selectedQuoteId = id;
  return next;
}

export function getStaleBudgetReferences(model, quote) {
  const rooms = new Set(model.rooms.map(room => room.id));
  const furniture = new Set((model.furniture ?? []).map(item => item.id));
  return { roomIds: Object.keys(quote.rooms).filter(id => !rooms.has(id)),
    furnitureIds: Object.keys(quote.furniture).filter(id => !furniture.has(id)) };
}

export function cleanStaleBudgetReferences(model, config, quoteId) {
  const next = validateBudgetConfig(config, model);
  const quote = next.quotes.find(item => item.id === quoteId);
  if (!quote) throw new Error('报价方案不存在。');
  const stale = getStaleBudgetReferences(model, quote);
  stale.roomIds.forEach(id => { delete quote.rooms[id]; });
  stale.furnitureIds.forEach(id => { delete quote.furniture[id]; });
  return next;
}

export function parseBudgetInput(raw, kind = 'price') {
  const input = String(raw).trim();
  if (input === '') return { value: null, error: null };
  if (!/^\d+(?:\.\d{1,2})?$/.test(input)) return { value: null, error: '请输入非负数，最多保留两位小数。' };
  const value = Number(input);
  const maximum = kind === 'waste' ? 100 : MAX_PRICE;
  if (!decimal(value, maximum)) return { value: null, error: kind === 'waste' ? '损耗率需在 0–100% 之间。' : '单价需在 0–10000000 元之间。' };
  return { value, error: null };
}

/** Geometry quantities round to 6 decimals; each line rounds half-up to integer cents. */
export function calculateLineAmount(amountQuantity, unitPrice) {
  const normalizedQuantity = quantity(amountQuantity);
  if (unitPrice === null) return null;
  if (!validPrice(unitPrice)) throw new Error('单价无效。');
  const units = BigInt(Math.round(normalizedQuantity * QUANTITY_SCALE));
  const cents = units * BigInt(Math.round(unitPrice * 100));
  const roundedCents = (cents + BigInt(QUANTITY_SCALE / 2)) / BigInt(QUANTITY_SCALE);
  if (roundedCents > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('金额超出可计算范围。');
  return Number(roundedCents) / 100;
}

export function polygonFloorArea(polygon) {
  if (!Array.isArray(polygon) || polygon.length < 3 || !polygon.every(point)) throw new Error('房间轮廓无效，无法计算工程量。');
  return quantity(Math.abs(polygon.reduce((sum, p, i) => {
    const q = polygon[(i + 1) % polygon.length];
    return sum + p[0] * q[1] - q[0] * p[1];
  }, 0)) / 2);
}

// Rectangles share one edge coordinate system. The sweep prevents duplicate deductions.
function rectangleUnionArea(rectangles) {
  const xs = [...new Set(rectangles.flatMap(rect => [rect.left, rect.right]))].sort((a, b) => a - b);
  let area = 0;
  for (let i = 1; i < xs.length; i++) {
    const left = xs[i - 1], right = xs[i];
    const spans = rectangles.filter(rect => rect.left < right - EPS && rect.right > left + EPS)
      .map(rect => [rect.bottom, rect.top]).sort((a, b) => a[0] - b[0]);
    let high = -Infinity, covered = 0;
    for (const [bottom, top] of spans) { covered += Math.max(0, top - Math.max(bottom, high)); high = Math.max(high, top); }
    area += (right - left) * covered;
  }
  return area;
}

/** Each room is one finish face; only openings overlapping that room boundary are deducted. */
export function calculateRoomQuantities(model, room) {
  const floorArea = polygonFloorArea(room.polygon);
  if (!finite(model.height) || model.height <= 0) throw new Error('模型层高无效。');
  const edgeDetails = [];
  for (let index = 0; index < room.polygon.length; index++) {
    const a = room.polygon[index], b = room.polygon[(index + 1) % room.polygon.length];
    const dx = b[0] - a[0], dz = b[1] - a[1], length = Math.hypot(dx, dz);
    if (length < EPS) continue;
    const ux = dx / length, uz = dz / length;
    const project = p => (p[0] - a[0]) * ux + (p[1] - a[1]) * uz;
    const candidates = model.walls.flatMap(wall => {
      if (!point(wall.start) || !point(wall.end)) return [];
      const wx = wall.end[0] - wall.start[0], wz = wall.end[1] - wall.start[1], wallLength = Math.hypot(wx, wz);
      if (wallLength < EPS || Math.abs(wx * uz - wz * ux) / wallLength > .002) return [];
      const distance = p => Math.abs((p[0] - wall.start[0]) * wz - (p[1] - wall.start[1]) * wx) / wallLength;
      const tolerance = (finite(wall.thickness) ? wall.thickness / 2 : 0) + .01;
      if (distance(a) > tolerance + EPS || distance(b) > tolerance + EPS) return [];
      const p0 = project(wall.start), p1 = project(wall.end);
      const left = Math.max(0, Math.min(p0, p1)), right = Math.min(length, Math.max(p0, p1));
      const height = Math.min(wall.height ?? model.height, model.height);
      if (right - left <= EPS || !finite(height) || height <= 0) return [];
      return [{ wall, left, right, height, wallLength, wx, wz, distance: (distance(a) + distance(b)) / 2 }];
    }).sort((first, second) => first.distance - second.distance || first.wall.id.localeCompare(second.wall.id));
    const stops = [...new Set([0, length, ...candidates.flatMap(wall => [wall.left, wall.right])])].sort((first, second) => first - second);
    let grossArea = 0, estimatedLength = 0;
    const rectangles = [], wallIds = new Set();
    for (let part = 1; part < stops.length; part++) {
      const left = stops[part - 1], right = stops[part], midpoint = (left + right) / 2;
      const match = candidates.find(candidate => candidate.left <= midpoint + EPS && candidate.right >= midpoint - EPS);
      const height = match?.height ?? model.height;
      grossArea += (right - left) * height;
      if (!match) { estimatedLength += right - left; continue; }
      wallIds.add(match.wall.id);
      for (const opening of model.openings.filter(item => item.wallId === match.wall.id)) {
        if (!finite(opening.offset) || !finite(opening.width) || !finite(opening.height) || opening.width <= 0 || opening.height <= 0) continue;
        const at = offset => project([match.wall.start[0] + match.wx / match.wallLength * offset,
          match.wall.start[1] + match.wz / match.wallLength * offset]);
        const start = at(opening.offset), end = at(opening.offset + opening.width);
        const low = Math.max(left, Math.min(start, end)), high = Math.min(right, Math.max(start, end));
        const bottom = Math.max(0, opening.type === 'window' ? opening.sill ?? 0 : 0);
        const top = Math.min(height, bottom + opening.height);
        if (high - low > EPS && finite(bottom) && top > bottom) rectangles.push({ left: low, right: high, bottom, top, openingId: opening.id, type: opening.type });
      }
    }
    const openingIds = [...new Set(rectangles.map(rectangle => rectangle.openingId))];
    const deductions = openingIds.map(openingId => {
      const parts = rectangles.filter(rectangle => rectangle.openingId === openingId);
      return { openingId, type: parts[0].type, area: quantity(rectangleUnionArea(parts)) };
    });
    const deductionArea = Math.min(grossArea, rectangleUnionArea(rectangles));
    edgeDetails.push({ edgeIndex: index, length: quantity(length), grossArea: quantity(grossArea),
      deductionArea: quantity(deductionArea), netArea: quantity(Math.max(0, grossArea - deductionArea)),
      estimatedLength: quantity(estimatedLength), wallIds: [...wallIds], deductions });
  }
  const sum = key => quantity(edgeDetails.reduce((total, edge) => total + edge[key], 0));
  return { roomId: room.id, floorArea, perimeter: sum('length'), wallGrossArea: sum('grossArea'),
    openingDeductionArea: sum('deductionArea'), wallNetArea: sum('netArea'), estimatedBoundaryLength: sum('estimatedLength'), edges: edgeDetails };
}

/** Conservative provenance label; recording a single wall never certifies the whole model. */
export function getBudgetMeasurementLabel(model) {
  const review = getMeasurementReview(model), summary = review.summary;
  if (review.error) return '实测记录待核对；工程量为模型估算';
  const checked = `${summary.confirmedCurrentWalls}/${summary.totalWalls} 墙段已核对`;
  return summary.totalWalls > 0 && summary.confirmedCurrentWalls === summary.totalWalls
    ? `${checked}；面积与墙高仍为模型估算` : `${checked}；尺寸未全部实测核对，工程量为模型估算`;
}

export function calculateBudget(model, quote) {
  const checked = validateBudgetConfig({ version: 1, selectedQuoteId: quote.id, quotes: [quote] }, model).quotes[0];
  const rows = [], roomQuantities = model.rooms.map(room => calculateRoomQuantities(model, room));
  for (let index = 0; index < model.rooms.length; index++) {
    const room = model.rooms[index], amounts = roomQuantities[index], prices = getRoomQuote(checked, room.id), design = resolveRoomDesign(room);
    const floorLabel = FLOOR_FINISHES.find(finish => finish.id === design.floorFinish)?.label ?? room.material;
    const floorQuantity = quantity(amounts.floorArea * (1 + prices.floorWastePercent / 100));
    rows.push({ id: `floor:${room.id}`, category: 'floor', roomId: room.id, roomName: room.name, label: floorLabel,
      netQuantity: amounts.floorArea, quantity: floorQuantity, unit: 'm²', wastePercent: prices.floorWastePercent,
      unitPrice: prices.floorUnitPrice, amount: calculateLineAmount(floorQuantity, prices.floorUnitPrice) });
    rows.push({ id: `wall:${room.id}`, category: 'wall', roomId: room.id, roomName: room.name, label: design.wallFinish === 'plaster' ? '石膏饰面' : '墙面涂饰',
      netQuantity: amounts.wallNetArea, quantity: amounts.wallNetArea, unit: 'm²', wastePercent: 0,
      unitPrice: prices.wallUnitPrice, amount: calculateLineAmount(amounts.wallNetArea, prices.wallUnitPrice) });
  }
  for (const item of model.furniture ?? []) {
    const price = Object.hasOwn(checked.furniture, item.id) ? checked.furniture[item.id] : null;
    rows.push({ id: `furniture:${item.id}`, category: 'furniture', roomId: item.roomId,
      roomName: model.rooms.find(room => room.id === item.roomId)?.name ?? '已删除空间', label: FURNITURE_LABELS[item.kind] ?? item.kind,
      netQuantity: 1, quantity: 1, unit: '件', wastePercent: 0, unitPrice: price, amount: calculateLineAmount(1, price) });
  }
  const partialCents = rows.reduce((total, row) => total + (row.amount === null ? 0 : Math.round(row.amount * 100)), 0);
  if (!Number.isSafeInteger(partialCents) || partialCents < 0) throw new Error('预算合计超出可计算范围。');
  const pendingCount = rows.filter(row => row.amount === null).length;
  return { quoteId: checked.id, quoteName: checked.name, rows, roomQuantities, partialTotal: partialCents / 100,
    pendingCount, complete: pendingCount === 0, total: pendingCount === 0 ? partialCents / 100 : null,
    stale: getStaleBudgetReferences(model, checked), measurementLabel: getBudgetMeasurementLabel(model) };
}

export function compareBudgets(model, config) {
  const checked = validateBudgetConfig(config, model);
  const budgets = checked.quotes.map(quote => calculateBudget(model, quote));
  return { budgets, complete: budgets.length === 2 && budgets.every(budget => budget.complete),
    difference: budgets.length === 2 && budgets.every(budget => budget.complete)
      ? (Math.round(budgets[1].partialTotal * 100) - Math.round(budgets[0].partialTotal * 100)) / 100 : null };
}

export function csvSafeCell(value) {
  let string = String(value ?? '');
  if (/^[\s\u0000-\u001f]*[=+\-@]/u.test(string) || /^[\t\r\n]/u.test(string)) string = `'${string}`;
  return `"${string.replaceAll('"', '""')}"`;
}

export function exportBudgetCsv(model, config, quoteIds = null) {
  const checked = validateBudgetConfig(config, model);
  const quotes = quoteIds === null ? checked.quotes : checked.quotes.filter(quote => quoteIds.includes(quote.id));
  const header = ['方案', '类别', '空间', '项目或材质', '模型净工程量', '单位', '地板损耗率%', '报价工程量', '单价元', '金额元', '报价状态', '测量依据'];
  const records = [header];
  for (const quote of quotes) {
    const budget = calculateBudget(model, quote);
    for (const row of budget.rows) records.push([quote.name, { floor: '地板', wall: '墙面', furniture: '家具' }[row.category], row.roomName,
      row.label, row.netQuantity.toFixed(6), row.unit, row.wastePercent.toFixed(2), row.quantity.toFixed(6),
      row.unitPrice === null ? '' : row.unitPrice.toFixed(2), row.amount === null ? '' : row.amount.toFixed(2),
      row.amount === null ? '待报价' : '已报价', budget.measurementLabel]);
    records.push([quote.name, budget.complete ? '报价合计' : '已报价部分合计', '', '', '', '', '', '', '', budget.partialTotal.toFixed(2),
      budget.complete ? '全部已报价（模型估算）' : `尚有 ${budget.pendingCount} 项待报价，非完整总价`, budget.measurementLabel]);
  }
  return records.map(row => row.map(csvSafeCell).join(',')).join('\r\n');
}
