import base64
import copy
import io
import json
import os
import unittest
import urllib.error
from unittest.mock import patch

from fastapi.testclient import TestClient
from PIL import Image

from backend import algorithm
from backend.algorithm import MAX_IMAGE_BYTES, ModelServiceError, PlanError, analyze_photo
from backend.app import app


def photo(color="white"):
    buffer = io.BytesIO()
    Image.new("RGB", (40, 30), color).save(buffer, "PNG")
    return buffer.getvalue()


def provider_response(observation):
    return io.BytesIO(json.dumps({"choices": [{"message": {"content": json.dumps(observation, ensure_ascii=False)}}]}).encode())


def valid_observation(count=2, compare=False):
    result = {"stage": "in_progress", "summary": "可见墙面局部涂刷，其他区域需补拍。",
              "observations": [{"photoIndex": index, "summary": f"当前照片{index + 1}可见局部施工迹象。"} for index in range(count)]}
    if compare:
        result["comparison"] = {"summary": "可比视角出现新涂刷区域，完整覆盖仍待核对。", "change": "advanced"}
    return result


def inspection(images=None, previous=None, **kwargs):
    return algorithm.analyze_inspection(
        images if images is not None else [photo()], "客厅", kwargs.pop("work_type", "wall"),
        kwargs.pop("date", "2026-10-05"), previous_files=previous, **kwargs)


class InspectionTests(unittest.TestCase):
    def test_without_key_validates_both_groups_and_does_not_invent_progress(self):
        with patch.dict(os.environ, {}, clear=True), patch("urllib.request.urlopen") as network:
            result = inspection([photo("red"), photo("blue")], [photo("green")],
                                previous_date="2026-10-01", previous_stage="not_started")
        self.assertEqual(result["stage"], "unknown")
        self.assertEqual(result["source"], "manual_review")
        self.assertTrue(result["needsReview"])
        self.assertEqual([o["photoIndex"] for o in result["observations"]], [0, 1])
        self.assertTrue(all("人工" in o["summary"] for o in result["observations"]))
        self.assertEqual(result["comparison"]["change"], "uncertain")
        network.assert_not_called()

    def test_six_work_types_and_no_unpictured_previous_comparison(self):
        with patch.dict(os.environ, {}, clear=True):
            for work in ("electrical", "waterproof", "masonry", "carpentry", "floor", "wall"):
                with self.subTest(work=work):
                    result = inspection(work_type=work, previous_date="2026-10-01", previous_stage="complete")
                    self.assertNotIn("comparison", result)
                    self.assertEqual(result["stage"], "unknown")

    def test_one_provider_request_preserves_previous_current_order_and_metadata(self):
        expected = valid_observation(compare=True)
        expected["observations"].reverse()
        with patch.dict(os.environ, {"QWEN_API_KEY": "private-test-key", "QWEN_MODEL": "qwen-vl-plus"}, clear=True), \
                patch("urllib.request.urlopen", return_value=provider_response(expected)) as network:
            result = inspection([photo("red"), photo("blue")], [photo("green")],
                                previous_date="2026-10-01", previous_stage="not_started", work_type="electrical")
        self.assertEqual(network.call_count, 1)
        self.assertEqual(result["source"], "qwen/qwen-vl-plus")
        self.assertTrue(result["needsReview"])
        self.assertEqual([o["photoIndex"] for o in result["observations"]], [0, 1])
        self.assertNotIn("private-test-key", json.dumps(result))
        sent = json.loads(network.call_args.args[0].data)
        self.assertEqual(network.call_args.args[0].full_url, "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions")
        self.assertNotIn("enable_thinking", sent)
        self.assertNotIn("response_format", sent)
        system = sent["messages"][0]["content"]
        self.assertIn("隐蔽工程", system)
        self.assertIn("工程量", system)
        self.assertIn("unknown", system)
        parts = sent["messages"][1]["content"]
        texts = [json.loads(part["text"]) for part in parts if part["type"] == "text"]
        self.assertEqual(texts[0]["workType"], "electrical")
        self.assertEqual(texts[0]["date"], "2026-10-05")
        self.assertEqual(texts[0]["previousDate"], "2026-10-01")
        self.assertEqual(texts[0]["previousStage"], "not_started")
        self.assertEqual([(t["group"], t["photoIndex"]) for t in texts[1:]],
                         [("previous", 0), ("current", 0), ("current", 1)])
        urls = [part["image_url"]["url"] for part in parts if part["type"] == "image_url"]
        colors = [Image.open(io.BytesIO(base64.b64decode(url.split(",", 1)[1]))).getpixel((10, 10)) for url in urls]
        self.assertGreater(colors[0][1], colors[0][0])
        self.assertGreater(colors[1][0], colors[1][2])
        self.assertGreater(colors[2][2], colors[2][0])

    def test_flash_inspection_uses_new_official_url_nonthinking_json_and_both_image_groups(self):
        for model in ("qwen3.8-flash", "qwen3.8-flash-2026-10-05"):
            env = {"QWEN_API_KEY": "private-test-key", "QWEN_MODEL": model,
                   "QWEN_BASE_URL": "https://maas.qianwenaiapi.com/compatible-mode/v1"}
            with self.subTest(model=model), patch.dict(os.environ, env, clear=True), \
                    patch("urllib.request.urlopen", return_value=provider_response(valid_observation(compare=True))) as network:
                result = inspection([photo("red"), photo("blue")], [photo("green")],
                                    previous_date="2026-10-01", previous_stage="not_started")
                request = network.call_args.args[0]
                self.assertEqual(network.call_count, 1)
                self.assertEqual(request.full_url, "https://maas.qianwenaiapi.com/compatible-mode/v1/chat/completions")
                self.assertEqual(request.get_method(), "POST")
                self.assertEqual(request.get_header("Authorization"), "Bearer private-test-key")
                payload = json.loads(request.data)
                self.assertEqual(payload["model"], model)
                self.assertFalse(payload["enable_thinking"])
                self.assertEqual(payload["response_format"], {"type": "json_object"})
                self.assertEqual(payload["max_tokens"], 4500)
                self.assertEqual(payload["temperature"], 0)
                parts = payload["messages"][1]["content"]
                markers = [json.loads(part["text"]) for part in parts if part["type"] == "text"][1:]
                self.assertEqual([(marker["group"], marker["photoIndex"]) for marker in markers],
                                 [("previous", 0), ("current", 0), ("current", 1)])
                self.assertEqual(sum(part["type"] == "image_url" for part in parts), 3)
                self.assertEqual(result["source"], "qwen/" + model)
                self.assertEqual(result["comparison"]["change"], "advanced")
                self.assertTrue(result["needsReview"])
                self.assertNotIn("private-test-key", json.dumps(result))

    def test_inspection_rejects_new_url_with_query_before_request(self):
        env = {"QWEN_API_KEY": "private-test-key", "QWEN_MODEL": "qwen3.8-flash",
               "QWEN_BASE_URL": "https://maas.qianwenaiapi.com/compatible-mode/v1?redirect=evil"}
        with patch.dict(os.environ, env, clear=True), patch("urllib.request.urlopen") as network:
            with self.assertRaises(ModelServiceError):
                inspection()
        network.assert_not_called()

    def test_provider_output_is_complete_unique_typed_and_server_sourced(self):
        variants = []
        p = valid_observation(); p["observations"].pop(); variants.append(p)
        p = valid_observation(); p["observations"][1]["photoIndex"] = 0; variants.append(p)
        p = valid_observation(); p["observations"][0]["photoIndex"] = True; variants.append(p)
        p = valid_observation(); p["observations"][0]["photoIndex"] = 2; variants.append(p)
        p = valid_observation(); p["stage"] = "finished"; variants.append(p)
        p = valid_observation(); p["summary"] = " "; variants.append(p)
        p = valid_observation(); p["observations"][0]["summary"] = "x" * 2001; variants.append(p)
        p = valid_observation(); p["source"] = "trusted-survey"; variants.append(p)
        p = valid_observation(); p["needsReview"] = False; variants.append(p)
        p = valid_observation(compare=True); p["comparison"]["change"] = "100%"; variants.append(p)
        for response in variants:
            with self.subTest(response=response), \
                    patch.dict(os.environ, {"QWEN_API_KEY": "private-test-key"}, clear=True), \
                    patch("urllib.request.urlopen", return_value=provider_response(response)), \
                    self.assertRaises(ModelServiceError):
                inspection([photo(), photo()], [photo()] if "comparison" in response else None, previous_date="2026-10-01")

    def test_comparison_is_required_with_real_previous_group(self):
        with patch.dict(os.environ, {"QWEN_API_KEY": "private-test-key"}, clear=True), \
                patch("urllib.request.urlopen", return_value=provider_response(valid_observation())), \
                self.assertRaises(ModelServiceError):
            inspection([photo(), photo()], [photo()], previous_date="2026-10-01")

    def test_no_previous_date_cannot_claim_a_chronological_change(self):
        expected = valid_observation(count=1, compare=True)
        with patch.dict(os.environ, {"QWEN_API_KEY": "private-test-key"}, clear=True), \
                patch("urllib.request.urlopen", return_value=provider_response(expected)):
            result = inspection(previous=[photo()])
        self.assertEqual(result["comparison"]["change"], "uncertain")
        self.assertIn("日期", result["comparison"]["summary"])

    def test_invalid_metadata_counts_images_are_rejected_before_network(self):
        variants = [{"date": "2026-02-30"}, {"date": "2026-1-05"}, {"date": "2026-10-05T12:00:00"},
                    {"previous_date": "2026-10-06"}, {"previous_date": "bad"}, {"previous_stage": "done"},
                    {"work_type": "demolition"}, {"images": []}, {"images": [photo()] * 7},
                    {"previous": [photo()] * 7}, {"images": [b"broken"]}, {"previous": [b"broken"]}]
        with patch.dict(os.environ, {"QWEN_API_KEY": "private-test-key"}, clear=True), patch("urllib.request.urlopen") as network:
            for kwargs in variants:
                with self.subTest(kwargs=kwargs), self.assertRaises(PlanError):
                    inspection(**kwargs)
        network.assert_not_called()

    def test_provider_error_never_falls_back_or_exposes_key(self):
        error = urllib.error.HTTPError("https://dashscope.aliyuncs.com", 401, "private-test-key", {}, None)
        with patch.dict(os.environ, {"QWEN_API_KEY": "private-test-key"}, clear=True), \
                patch("urllib.request.urlopen", side_effect=error), self.assertRaises(ModelServiceError) as caught:
            inspection()
        self.assertNotIn("private-test-key", str(caught.exception))

    def test_single_photo_function_keeps_legacy_shape(self):
        with patch.dict(os.environ, {}, clear=True):
            result = analyze_photo(photo(), "客厅", "floor")
        self.assertEqual(set(result), {"stage", "summary", "source", "needsReview"})
        self.assertTrue(result["needsReview"])


class InspectionApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)

    def post(self, current=None, previous=None, **data):
        files = [("files", (f"current-{i}.png", content, "image/png")) for i, content in enumerate(current if current is not None else [photo()])]
        files += [("previous_files", (f"previous-{i}.png", content, "image/png")) for i, content in enumerate(previous or [])]
        return self.client.post("/api/analyze-inspection", files=files,
                                data={"room_name": "客厅", "work_type": "wall", "date": "2026-10-05", **data})

    def test_multifile_endpoint_returns_reviewable_comparison(self):
        with patch.dict(os.environ, {}, clear=True):
            response = self.post([photo(), photo()], [photo()], previous_date="2026-10-01")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(len(response.json()["observations"]), 2)
        self.assertEqual(response.json()["comparison"]["change"], "uncertain")

    def test_dates_empty_groups_counts_and_corrupt_images_are_422(self):
        variants = [{"current": []}, {"current": [photo()] * 7}, {"previous": [photo()] * 7},
                    {"date": "2026-02-30"}, {"previous_date": "2026-10-06"},
                    {"current": [b"broken"]}, {"previous": [b"broken"]}, {"work_type": "other"}]
        for kwargs in variants:
            with self.subTest(kwargs=kwargs):
                response = self.post(**kwargs)
                self.assertEqual(response.status_code, 422, response.text)

    def test_individual_and_combined_payload_limits_are_413(self):
        response = self.post([b"x" * (MAX_IMAGE_BYTES + 1)])
        self.assertEqual(response.status_code, 413, response.text)
        large = b"x" * (8 * 1024 * 1024)
        response = self.post([large, large], [large, large])
        self.assertEqual(response.status_code, 413, response.text)

    def test_invalid_provider_observation_is_502(self):
        invalid = valid_observation(count=1); invalid["observations"] = []
        with patch.dict(os.environ, {"QWEN_API_KEY": "private-test-key"}, clear=True), \
                patch("urllib.request.urlopen", return_value=provider_response(invalid)):
            response = self.post()
        self.assertEqual(response.status_code, 502, response.text)
        self.assertNotIn("private-test-key", response.text)


if __name__ == "__main__":
    unittest.main()
