"""Practical metadata checks use temporary SQLite databases and no external AI calls."""
import unittest
import test_project_library as library_tests
model = library_tests.model


def practical_model():
    value = model()
    photo = {"id": "p", "source": "public_case", "image": "/renovation-case/stage-02-wall.jpg", "caption": "公开照片", "captureDate": "2012-12-20"}
    event = {"id": "e", "action": "create", "status": "open", "date": "2026-10-06", "at": "2026-10-06T03:00:00.000Z", "actor": "示例记录人", "note": "演练", "photos": [photo]}
    value["meta"].update({"issueTracker": {"version": 1, "issues": [{"id": "i", "roomId": "room", "title": "演练任务", "description": "模拟任务", "location": "窗侧", "workType": "wall", "assignee": "示例岗位", "dueDate": "2026-10-07", "createdDate": "2026-10-06", "mode": "demonstration", "status": "open", "events": [event]}]},
        "materialBudget": {"version": 1, "selectedQuoteId": "q", "quotes": [{"id": "q", "name": "方案一", "rooms": {"room": {"floorUnitPrice": None, "floorWastePercent": 5, "wallUnitPrice": 20.5}}, "furniture": {}}]},
        "measurements": [{"id": "m", "wallId": "north", "lengthMeters": 6, "date": "2026-10-06", "source": "演示输入", "note": "", "confirmed": True, "wallSnapshot": {"start": [0, 0], "end": [6, 0]}}], "layoutReviewPending": True})
    return value


class PracticalMetadataTests(unittest.TestCase):
    setUp = library_tests.ProjectLibraryTests.setUp
    tearDown = library_tests.ProjectLibraryTests.tearDown
    create = library_tests.ProjectLibraryTests.create


def test_roundtrip(self):
    value = practical_model()
    saved = self.create(value)
    self.assertEqual(self.client.get('/api/projects/' + saved['id']).json()['model'], value)
    value['meta']['issueTracker']['issues'][0]['events'].append({"id": "begin", "action": "begin", "status": "in_progress", "date": "2026-10-06", "at": "2026-10-06T04:00:00Z", "actor": "岗位", "note": "开始处理", "photos": []})
    value['meta']['issueTracker']['issues'][0]['status'] = 'in_progress'
    updated = self.client.put('/api/projects/' + saved['id'], json={'revision': 1, 'model': value})
    self.assertEqual(updated.status_code, 200, updated.text)
    self.assertEqual(updated.json()['model']['rooms'], saved['model']['rooms'])


def test_reject_invalid_without_write(self):
    mutations = [lambda m: m['meta'].update(layoutReviewPending='yes'),
        lambda m: m['meta']['measurements'][0].update(lengthMeters=True),
        lambda m: m['meta']['measurements'][0].update(confirmed='yes'),
        lambda m: m['meta']['materialBudget']['quotes'][0]['rooms']['room'].update(floorUnitPrice=-1),
        lambda m: m['meta']['materialBudget']['quotes'][0]['rooms']['room'].update(wallUnitPrice=1.001),
        lambda m: m['meta']['issueTracker']['issues'][0]['events'][0].update(at='2026-02-30T12:00:00Z'),
        lambda m: m['meta']['issueTracker']['issues'][0]['events'][0]['photos'][0].update(image='https://arbitrary.example/a.jpg'),
        lambda m: m['meta']['issueTracker']['issues'][0].update(status='closed'),
        lambda m: m['meta']['issueTracker']['issues'][0]['events'][0].update(confirmed='yes')]
    for mutation in mutations:
        value = practical_model(); mutation(value)
        with self.subTest(value=value):
            response = self.client.post('/api/projects', json={'model': value})
            self.assertEqual(response.status_code, 422, response.text)
    self.assertEqual(self.client.get('/api/projects').json()['changeVersion'], 0)


PracticalMetadataTests.test_practical_roundtrip = test_roundtrip
PracticalMetadataTests.test_practical_invalid = test_reject_invalid_without_write

if __name__ == '__main__':
    unittest.main()
