import * as THREE from 'three';
import { resolveOpeningDesign, doorLeafPose } from '../openings.mjs';
import { makeFabricTexture } from './finishes';
import type { Opening } from '../types';

interface OpeningOptions {
  thickness: number;
  wallHeight: number;
  fullHeight: number;
  metadata: Record<string, unknown>;
  curtainSide?: 1 | -1;
}

export function openingAssembly(opening: Opening, options: OpeningOptions) {
  const group = new THREE.Group(); group.name = `${opening.type === 'door' ? '门' : '窗'} · ${opening.id}`;
  const design = resolveOpeningDesign(opening);
  const metadata = { ...options.metadata, openingId: opening.id, openingType: opening.type, design: { ...design }, kind: opening.type };
  group.userData = { ...metadata };
  const sill = opening.type === 'window' ? opening.sill ?? 0 : 0;
  const height = Math.max(0, Math.min(opening.height, options.wallHeight - sill));
  const width = opening.width, left = opening.offset, right = left + width;
  if (height < 0.04) return group;
  const frame = Math.min(0.045, width * 0.18, height * 0.15);
  const rim = new THREE.MeshStandardMaterial({ color: design.color, roughness: opening.type === 'door' ? 0.57 : 0.39, metalness: opening.type === 'window' ? 0.28 : 0.03, side: THREE.DoubleSide });
  const field = rim.clone(); field.color.multiplyScalar(0.9); field.roughness = 0.7;
  const hardware = new THREE.MeshStandardMaterial({ color: '#a8a69b', metalness: 0.8, roughness: 0.3 });
  const glass = new THREE.MeshPhysicalMaterial({ color: design.glassTint === 'smoke' ? '#59676b' : '#cbdedb', metalness: 0.03, roughness: 0.08, transparent: true, opacity: design.glassTint === 'smoke' ? 0.67 : 0.28, transmission: 0.12, thickness: 0.01, side: THREE.DoubleSide, depthWrite: false });
  const usedMaterials = new Set<THREE.Material>();
  const part = (parent: THREE.Group, size: [number, number, number], position: [number, number, number], material: THREE.Material, name: string) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
    usedMaterials.add(material);
    mesh.position.set(...position); mesh.castShadow = material !== glass; mesh.receiveShadow = true;
    mesh.name = `${opening.id} · ${name}`; mesh.userData = { ...metadata }; parent.add(mesh); return mesh;
  };
  const handle = (parent: THREE.Group, x: number, y: number, bothSides: boolean) => {
    for (const side of bothSides ? [-1, 1] : [1]) {
      const rose = new THREE.Mesh(new THREE.CylinderGeometry(0.027, 0.027, 0.018, 14), hardware);
      usedMaterials.add(hardware);
      rose.rotation.x = Math.PI / 2; rose.position.set(x, y, side * 0.034);
      rose.userData = { ...metadata }; rose.name = `${opening.id} · 把手底座`; parent.add(rose);
      part(parent, [0.095, 0.021, 0.022], [x - 0.025, y, side * 0.058], hardware, '把手');
    }
  };
  for (const x of [left + frame / 2, right - frame / 2]) {
    part(group, [frame, height, options.thickness + 0.055], [x, sill + height / 2, 0], rim, '门窗框');
    for (const side of [-1, 1]) part(group, [frame + 0.025, height + 0.025, 0.022], [x, sill + height / 2, side * (options.thickness / 2 + 0.028)], rim, '外侧套线');
  }
  if (height >= opening.height - 0.001) part(group, [width, frame, options.thickness + 0.06], [(left + right) / 2, sill + height - frame / 2, 0], rim, '上框');
  if (opening.type === 'door') {
    part(group, [width, 0.012, options.thickness + 0.06], [(left + right) / 2, 0.009, 0], hardware, '门槛');
    const pose = doorLeafPose(opening);
    const hinge = new THREE.Group(); hinge.name = `${opening.id} · 门扇转轴`;
    hinge.position.set(pose.pivotX, 0.015, pose.pivotZ); hinge.rotation.y = pose.rotation;
    hinge.userData = { ...metadata }; group.add(hinge);
    const leafWidth = pose.leafWidth, leafHeight = Math.max(0.015, height - 0.03);
    const leafCenter = leafWidth / 2;
    if (design.style === 'glass') {
      const bar = Math.min(0.065, leafWidth / 4);
      for (const x of [bar / 2, leafWidth - bar / 2]) part(hinge, [bar, leafHeight, 0.045], [x, leafHeight / 2, 0], rim, '玻璃门边框');
      for (const y of [bar / 2, leafHeight - bar / 2]) part(hinge, [leafWidth, bar, 0.045], [leafCenter, y, 0], rim, '玻璃门横框');
      part(hinge, [Math.max(0.008, leafWidth - bar * 2), Math.max(0.008, leafHeight - bar * 2), 0.009], [leafCenter, leafHeight / 2, 0], glass, '门扇玻璃');
    } else {
      part(hinge, [leafWidth, leafHeight, 0.038], [leafCenter, leafHeight / 2, 0], design.style === 'panel' ? field : rim, '门扇');
      if (design.style === 'panel' && leafWidth > 0.22 && leafHeight > 0.45) {
        const inset = Math.min(0.085, leafWidth * 0.12);
        for (const side of [-1, 1]) {
          for (const x of [inset / 2, leafWidth - inset / 2]) part(hinge, [inset, leafHeight, 0.012], [x, leafHeight / 2, side * 0.024], rim, '门扇竖梃');
          for (const y of [inset / 2, leafHeight * 0.4, leafHeight - inset / 2]) part(hinge, [leafWidth - inset * 2, inset, 0.012], [leafCenter, y, side * 0.024], rim, '门扇横梃');
        }
      }
    }
    for (const y of [leafHeight * 0.2, leafHeight * 0.8]) part(hinge, [0.019, 0.07, 0.062], [0.008, y, 0], hardware, '合页');
    if (leafWidth > 0.17) handle(hinge, leafWidth - 0.1, Math.min(0.96, leafHeight * 0.87), true);
  } else {
    part(group, [width + 0.07, 0.042, options.thickness + 0.15], [(left + right) / 2, sill, 0], rim, '窗台');
    const clearWidth = Math.max(width - frame * 2, 0.008), clearHeight = Math.max(height - frame, 0.008);
    const sash = (parent: THREE.Group, sashWidth: number, center: number, z: number, movable: boolean) => {
      const border = Math.min(0.035, sashWidth / 4, clearHeight / 4);
      for (const x of [center - sashWidth / 2 + border / 2, center + sashWidth / 2 - border / 2]) part(parent, [border, clearHeight, 0.045], [x, sill + clearHeight / 2, z], rim, '窗扇竖框');
      for (const y of [sill + border / 2, sill + clearHeight - border / 2]) part(parent, [sashWidth, border, 0.045], [center, y, z], rim, '窗扇横框');
      part(parent, [Math.max(sashWidth - border * 2, 0.004), Math.max(clearHeight - border * 2, 0.004), 0.008], [center, sill + clearHeight / 2, z], glass, '窗玻璃');
      if (movable && sashWidth > 0.2) part(parent, [0.02, 0.13, 0.025], [center + sashWidth / 2 - border * 1.4, sill + clearHeight * 0.52, z + 0.034], hardware, '窗把手');
    };
    if (design.style === 'casement') {
      const count = clearWidth > 1.3 ? 2 : 1, sashWidth = clearWidth / count;
      for (let i = 0; i < count; i++) {
        const endHinge = count === 2 ? i === 1 : design.hinge === 'end';
        const pivot = left + frame + (endHinge ? (i + 1) * sashWidth : i * sashWidth);
        const hinge = new THREE.Group(); hinge.name = `${opening.id} · 平开窗扇${i + 1}`;
        hinge.position.x = pivot;
        hinge.rotation.y = (endHinge ? Math.PI : 0) - design.swing * THREE.MathUtils.degToRad(design.openAngle) * (endHinge ? -1 : 1);
        hinge.userData = { ...metadata }; group.add(hinge);
        sash(hinge, sashWidth, sashWidth / 2, 0, true);
      }
    } else if (design.style === 'sliding') {
      const sashWidth = clearWidth / 2 + 0.014, travel = clearWidth / 2 - 0.02;
      const openness = design.openAngle / 60;
      sash(group, sashWidth, left + frame + sashWidth / 2 + (design.hinge === 'start' ? travel * openness : 0), -0.024, true);
      sash(group, sashWidth, right - frame - sashWidth / 2 - (design.hinge === 'end' ? travel * openness : 0), 0.025, true);
      for (const z of [-0.024, 0.025]) part(group, [clearWidth, 0.012, 0.014], [(left + right) / 2, sill + 0.011, z], hardware, '推拉轨道');
    } else {
      const count = clearWidth > 1.3 ? 2 : 1;
      for (let i = 0; i < count; i++) sash(group, clearWidth / count, left + frame + clearWidth / count * (i + 0.5), 0, false);
    }
    if (options.curtainSide) {
      const curtainHeight = Math.max(0.2, options.fullHeight - 0.25);
      const cloth = new THREE.MeshStandardMaterial({ color: '#ffffff', map: makeFabricTexture('#e5dfd0'), roughness: 1, side: THREE.DoubleSide });
      for (const x of [left - 0.14, right + 0.14]) {
        const geometry = new THREE.PlaneGeometry(0.28, curtainHeight, 18, 8);
        const points = geometry.attributes.position;
        for (let index = 0; index < points.count; index++) points.setZ(index, Math.sin((points.getX(index) + 0.14) / 0.28 * Math.PI * 8) * 0.025);
        geometry.computeVertexNormals();
        const curtain = new THREE.Mesh(geometry, cloth); curtain.position.set(x, curtainHeight / 2 + 0.04, options.curtainSide * (options.thickness / 2 + 0.13));
        curtain.castShadow = true; curtain.receiveShadow = true; curtain.name = `${opening.id} · 侧帘`; curtain.userData = { ...metadata, kind: 'curtain' }; group.add(curtain);
      }
      part(group, [width + 0.56, 0.025, 0.03], [(left + right) / 2, options.fullHeight - 0.16, options.curtainSide * (options.thickness / 2 + 0.13)], hardware, '窗帘轨道');
    }
  }
  for (const material of [rim, field, hardware, glass]) if (!usedMaterials.has(material)) material.dispose();
  return group;
}
