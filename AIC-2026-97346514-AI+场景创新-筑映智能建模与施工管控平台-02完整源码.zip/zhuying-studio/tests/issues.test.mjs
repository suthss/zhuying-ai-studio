import test from 'node:test';
import assert from 'node:assert/strict';
import {createIssue,transitionIssue,validateIssueTracker,validateIssuePhotos,issueSummary,createWeeklyReport,weeklyMarkdown} from '../src/issues.mjs';
import {validateProject} from '../src/project.mjs';
const house=()=>({id:'home',name:'住宅',source:'manual',width:6,depth:5,height:2.8,warnings:[],openings:[],walls:[{id:'w',start:[0,0],end:[6,0],thickness:.2}],rooms:[{id:'r',name:'卧室',polygon:[[0,0],[6,0],[6,5],[0,5]],area:30,progress:0,material:'wood',evidence:[],tasks:{floor:{stage:'unknown',plannedStage:'unknown',dueDate:''},wall:{stage:'unknown',plannedStage:'unknown',dueDate:''}}}]});
const photo=()=>({id:'p',source:'public_case',image:'/renovation-case/stage-02-wall.jpg',caption:'真实照片',captureDate:'2012-12-20'});
const context=(eventId,date='2026-10-06')=>({id:'issue',eventId,date,at:date+'T03:00:00.000Z',actor:'记录人'});
function fresh(){const m=house();m.meta={issueTracker:createIssue(m,{roomId:'r',title:'核对墙面',description:'现场记录',location:'窗侧',workType:'wall',assignee:'负责人',dueDate:'2026-10-07',photos:[photo()]},context('created'))};return m;}
function act(m,action,eventId,patch={},date='2026-10-06'){return {...m,meta:{...m.meta,issueTracker:transitionIssue(m,'issue',action,{actor:'复核人',note:'核对说明',photos:[],...patch},context(eventId,date))}};}
test('整改完整闭环保留提交、退回、关闭和重新开启证据，不改变施工状态',()=>{
 const initial=fresh();let m=act(initial,'begin','begin');m=act(m,'submit','s1',{photos:[photo()]});m=act(m,'return','return');m=act(m,'submit','s2',{photos:[photo()]});m=act(m,'close','close',{confirmed:true});m=act(m,'reopen','reopen');
 assert.equal(m.meta.issueTracker.issues[0].status,'in_progress');assert.equal(m.meta.issueTracker.issues[0].events.length,7);assert.deepEqual(m.rooms,initial.rooms);assert.equal(initial.meta.issueTracker.issues[0].events.length,1);
 assert.deepEqual(validateProject(JSON.parse(JSON.stringify(m))),m);
});
test('禁止跳过处理、无照片提交、无理由退回和未经人工复核的关闭',()=>{
 let m=fresh();assert.throws(()=>act(m,'close','bad',{confirmed:true}));m=act(m,'begin','begin');assert.throws(()=>act(m,'submit','bad'));m=act(m,'submit','submit',{photos:[photo()]});assert.throws(()=>act(m,'close','bad'));assert.throws(()=>act(m,'return','bad',{note:''}));assert.throws(()=>act(m,'close','bad',{confirmed:true,actor:''}));
});
test('照片引用仅允许本站案例或限定格式内嵌图片，标记不能越界',()=>{
 assert.doesNotThrow(()=>validateIssuePhotos([photo()]));for(const patch of [{image:'https://other.example/a.jpg'},{image:'/renovation-case/../a.jpg'},{captureDate:'2012-02-30'},{point:[1.1,0]},{point:[NaN,.5]},{source:'upload',image:'data:image/svg+xml;base64,AAAA'},{source:'upload',image:'data:image/png;base64,A'}])assert.throws(()=>validateIssuePhotos([{...photo(),...patch}]));
 const original={...photo(),point:[.2,.3]};const copy=validateIssuePhotos([original]);copy[0].point[0]=.9;assert.equal(original.point[0],.2);
});
test('ISO记录时间与布尔确认严格校验，日期倒退和重复事件不能保存',()=>{
 const m=fresh();for(const patch of [{at:'2026-10-06'},{at:'2026-02-30T12:00:00Z'},{at:'2026-10-06T24:00:00Z'},{at:'2026-10-06T12:00:00+24:00'},{confirmed:'yes'}]){const t=structuredClone(m.meta.issueTracker);Object.assign(t.issues[0].events[0],patch);assert.throws(()=>validateIssueTracker(t,m));}
 assert.throws(()=>act(m,'begin','created'));assert.throws(()=>act(m,'begin','earlier',{},'2026-10-05'));
});
test('历史周报按截止日回放，不把未来关闭计入过去，也不改照片拍摄日期',()=>{
 let m=fresh();m=act(m,'begin','begin');m=act(m,'submit','submit',{photos:[photo()]},'2026-10-07');m=act(m,'close','close',{confirmed:true},'2026-10-09');
 assert.equal(issueSummary(m,'2026-10-05').total,0);const r=createWeeklyReport(m,'2026-10-06','2026-10-07');assert.equal(r.summary.review,1);assert.equal(r.summary.closed,0);assert.equal(r.activities.length,3);assert.equal(r.activities.find(e=>e.action==='submit').photos[0].captureDate,'2012-12-20');assert.match(weeklyMarkdown(r,{r:'卧室'}),/待复核/);assert.match(weeklyMarkdown(r),/拍摄日期 2012-12-20/);
 assert.equal(issueSummary(m,'2026-10-08').overdue,1);assert.equal(issueSummary(m,'2026-10-09').overdue,0);assert.throws(()=>createWeeklyReport(m,'2026-10-09','2026-10-06'));
});
test('删除关联房间仍保留审计历史，案例任务明确属于演练',()=>{
 const m=fresh();assert.equal(validateIssueTracker(m.meta.issueTracker,{rooms:[]}).issues[0].orphaned,true);const bad=structuredClone(m.meta.issueTracker);bad.issues[0].orphaned='yes';assert.throws(()=>validateIssueTracker(bad,m));const demo=house();demo.meta={demoData:true};assert.equal(createIssue(demo,{roomId:'r',title:'模拟',description:'',location:'',workType:'wall',assignee:'示例岗位',dueDate:'2026-10-06'},context('e')).issues[0].mode,'demonstration');
});
test('布局待复核允许保存有限尺寸的几何冲突，但不放宽家具数据格式',()=>{
 const m=house();m.furniture=[{id:'desk',roomId:'r',kind:'desk',position:[5.9,4.9],size:[1.2,.75,.6],rotation:0,color:'#b29b7d'}];assert.throws(()=>validateProject(m));m.meta={layoutReviewPending:true};assert.doesNotThrow(()=>validateProject(m));m.furniture[0].size[0]=NaN;assert.throws(()=>validateProject(m));
});
