"""Build reviewable demonstration annotations; these are not dataset truth.

Coordinates were inspected on the actual six extracted frames. Each polygon
tracks an approximate corresponding part of the curved front facade. It is a
coarse observation zone, not a detected individual window or measured area.
"""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'public/facade-demo'
source = json.loads((ASSETS / 'sources.json').read_text(encoding='utf-8'))
I, N, U = 'installed', 'not_installed', 'unknown'
# Four horizontal bands, each with left/middle/right observation zones.
# Perspective offsets and x bounds are individually reviewed per frame.
grids = {
    '2025-06-25': ([586,679,788,888],[350,420,485,550,615],[0,0,-4,-11], [N,N,N,N,N,N,N,N,N,U,U,U]),
    '2025-08-31': ([552,655,777,888],[355,420,487,551,616],[0,0,-3,-9], [N,N,N,I,I,I,I,I,I,U,U,U]),
    '2025-09-06': ([582,682,792,906],[353,422,488,556,621],[0,0,-2,-8], [N,N,N,I,I,I,I,I,I,U,U,U]),
    '2025-10-21': ([152,239,416,573],[396,471,556,639,720],[0,0,-15,-30], [I,I,I,I,U,I,I,U,I,I,I,I]),
    '2025-11-05': ([156,250,422,596],[392,466,545,626,710],[0,0,-8,-21], [I,I,U,I,U,I,I,U,I,I,I,I]),
    '2026-04-25': ([302,435,597,732],[368,444,529,618,712],[0,0,-6,-21], [I,I,I,I,I,I,U,I,I,U,I,I]),
}
observations = []
previews = []
try:
    font = ImageFont.truetype('arial.ttf', 25)
except OSError:
    font = ImageFont.load_default()
for frame in source['frames']:
    xs, ys, offsets, states = grids[frame['date']]
    regions = []
    img = Image.open(ASSETS / Path(frame['image']).name).convert('RGB')
    draw = ImageDraw.Draw(img)
    for row in range(4):
        for col in range(3):
            region_id = f'R{row*3+col+1:02d}'
            # Leave construction slabs and piers outside the interior polygon.
            pixels = [[xs[col]+5,ys[row]+offsets[col]+9],
                      [xs[col+1]-5,ys[row]+offsets[col+1]+9],
                      [xs[col+1]-5,ys[row+1]+offsets[col+1]-9],
                      [xs[col]+5,ys[row+1]+offsets[col]-9]]
            status = states[row*3+col]
            if status == N:
                evidence = '可见楼板、柱或室内开口，未形成连续封闭玻璃面；幕墙框架存在不等于玻璃完成。'
            elif status == I:
                evidence = '可见与框架连续衔接的平面玻璃、反射或封闭窗格；只确认这块观察区域的可见外观。'
            elif frame['date'] in {'2025-06-25','2025-08-31','2025-09-06'}:
                evidence = '区域偏暗或出现白色遮挡/背板，无法可靠区分玻璃与临时覆盖，保留待核对。'
            else:
                evidence = '强反光、雨雪污渍或阴影遮住局部窗格，无法确认整个观察区域均已装玻璃。'
            polygon = [[round(x/1600,6),round(y/900,6)] for x,y in pixels]
            regions.append({'id':region_id,'label':f'第{row+1}观察带 · {("左","中","右")[col]}区',
                            'polygon':polygon,'status':status,'evidence':evidence})
            color = '#53de9b' if status==I else '#e7b65b' if status==N else '#bdcbd9'
            draw.line([tuple(p) for p in pixels]+[tuple(pixels[0])],fill=color,width=4)
            center = (sum(p[0] for p in pixels)/4,sum(p[1] for p in pixels)/4)
            draw.text(center,region_id,font=font,fill='white',stroke_width=2,stroke_fill='#173d2b',anchor='mm')
    observations.append({'id':frame['id'],'date':frame['date'],'dateLabel':frame['date'],
        'dateSource':frame['dateSource'],'image':frame['image'],'sourceFile':frame['sourceFile'],
        'frameSeconds':frame['sampleSeconds'],'stage':'raw' if frame['date']=='2025-06-25' else 'partial',
        'summary':frame['description'],'regions':regions})
    img.thumbnail((640,360))
    previews.append(img.copy())
sample = {'schemaVersion':1,'id':'iitu-visible-facade-v1','title':'IITU 同一工地 · 6 期真实影像',
    'description':'沿着 2025 年 6 月至 2026 年 4 月的画面，观察玻璃安装如何推进。',
    'dataset':{'title':source['datasetTitle'],'url':source['datasetUrl'],'creator':source['author'],
               'license':source['license'],'licenseUrl':source['licenseUrl']},
    'datesAreCaptureDates':True,'observations':observations,
    'plan':{'simulated':True,'label':'可见玻璃安装演示计划','startDate':'2025-06-25','endDate':'2025-09-30',
            'targetPercent':100,'inspectionGapDays':45},
    'annotation':{'method':'manual','label':'筑映人工观察标注，非数据集官方标签；可修改、可复核。',
        'scope':'正面弧形立面约相同范围的4个观察带×3列，共12个粗粒度观察单元；逐帧手动调整多边形，编号对应关系为近似人工匹配，未精密配准。每个单元可能含多个窗格，等权单元率不是面积率、真实窗数或整体工程量。'}}
(ASSETS/'sample.json').write_text(json.dumps(sample,ensure_ascii=False,indent=2),encoding='utf-8')
contact = Image.new('RGB',(1280,1080),'#f0f3ee')
for index,img in enumerate(previews):
    contact.paste(img,(index%2*640,index//2*360))
out=ROOT/'artifacts/facade-demo';out.mkdir(parents=True,exist_ok=True)
contact.save(out/'annotation-contact-sheet.jpg',quality=93)
print('Built 6 observations, 12 corresponding reviewable zones per observation.')
