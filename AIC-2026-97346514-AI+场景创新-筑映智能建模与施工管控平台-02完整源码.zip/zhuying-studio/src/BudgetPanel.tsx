import { useEffect, useId, useMemo, useRef, useState } from 'react';
import type { HouseModel } from './types';
import { calculateBudget, cleanStaleBudgetReferences, compareBudgets, createBudgetConfig, createBudgetQuote,
  exportBudgetCsv, getBudgetConfig, getRoomQuote, parseBudgetInput, setBudgetConfig, validateBudgetConfig } from './budget.mjs';
import type { BudgetConfig, BudgetQuote, BudgetRow, RoomQuantities } from './budget.mjs';
import './budget.css';

const money = (value: number) => `¥${value.toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const area = (value: number) => value.toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 3 });

function QuoteInput({ label, value, kind = 'price', onCommit }: { label: string; value: number | null;
  kind?: 'price' | 'waste'; onCommit: (value: number | null) => void }) {
  const [draft, setDraft] = useState(value === null ? '' : String(value));
  const [error, setError] = useState('');
  const errorId = useId();
  useEffect(() => { setDraft(value === null ? '' : String(value)); setError(''); }, [value]);
  const commit = () => {
    const parsed = parseBudgetInput(draft, kind);
    const problem = parsed.error ?? (kind === 'waste' && parsed.value === null ? '损耗率不能为空；无需损耗请输入 0。' : '');
    if (problem) { setError(problem); return; }
    setError('');
    onCommit(parsed.value);
  };
  return <div className="budget-input-wrap"><input type="text" inputMode="decimal" aria-label={label}
    aria-invalid={!!error} aria-describedby={error ? errorId : undefined} value={draft} placeholder={kind === 'price' ? '待报价' : '0'}
    onChange={event => { setDraft(event.target.value); setError(''); }} onBlur={commit}
    onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }} />
    {error && <span className="budget-field-error" id={errorId} role="alert">{error} 此输入未保存。</span>}</div>;
}

function QuoteName({ quote, onCommit }: { quote: BudgetQuote; onCommit: (name: string) => void }) {
  const [draft, setDraft] = useState(quote.name);
  const [error, setError] = useState('');
  useEffect(() => { setDraft(quote.name); setError(''); }, [quote.id, quote.name]);
  const commit = () => {
    if (!draft.trim()) { setError('方案名称不能为空，此输入未保存。'); return; }
    setError(''); onCommit(draft.trim());
  };
  return <label className="budget-name-field"><span>方案名称</span><input maxLength={160} value={draft} aria-invalid={!!error}
    onChange={event => { setDraft(event.target.value); setError(''); }} onBlur={commit}
    onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }} />
    {error && <span className="budget-field-error" role="alert">{error}</span>}</label>;
}

function Amount({ row }: { row: BudgetRow }) {
  return <span className={row.amount === null ? 'budget-pending' : 'budget-money'}>{row.amount === null ? '待报价' : money(row.amount)}</span>;
}

function WallBasis({ roomName, quantity }: { roomName: string; quantity: RoomQuantities }) {
  return <details className="budget-wall-basis"><summary aria-label={`${roomName}墙面计算依据`}>计算依据</summary>
    <p>边界墙面 {area(quantity.wallGrossArea)} m² − 门窗洞口 {area(quantity.openingDeductionArea)} m² = {area(quantity.wallNetArea)} m²。</p>
    <p>按房间多边形边界逐段乘关联墙高；无关联墙段按模型层高估算。仅扣除洞口在本房间边界上的交叠部分，共享墙分别计算两侧饰面。</p>
    {quantity.estimatedBoundaryLength > 0 && <p>其中 {area(quantity.estimatedBoundaryLength)} m 边界缺少关联墙段，使用模型层高。</p>}
    <ul>{quantity.edges.map(edge => <li key={edge.edgeIndex}>边 {edge.edgeIndex + 1}：{area(edge.length)} m，墙面 {area(edge.grossArea)} m²，扣洞 {area(edge.deductionArea)} m²
      {edge.deductions.length > 0 && `（${edge.deductions.map(opening => `${opening.type === 'door' ? '门' : '窗'} ${opening.openingId}：${area(opening.area)} m²`).join('；')}）`}</li>)}</ul>
  </details>;
}

export default function BudgetPanel({ model, onChange }: { model: HouseModel; onChange: (next: HouseModel) => void }) {
  const [notice, setNotice] = useState('');
  const [csvVisible, setCsvVisible] = useState(false);
  const preview = useRef<HTMLTextAreaElement>(null);
  const parsed = useMemo(() => {
    try { return { config: getBudgetConfig(model), error: '' }; }
    catch (error) { return { config: null, error: error instanceof Error ? error.message : '预算配置无法读取。' }; }
  }, [model]);
  const computed = useMemo(() => {
    if (!parsed.config) return { budget: null, comparison: null, csv: '', error: '' };
    try {
      const quote = parsed.config.quotes.find(item => item.id === parsed.config?.selectedQuoteId)!;
      return { budget: calculateBudget(model, quote), comparison: compareBudgets(model, parsed.config),
        csv: exportBudgetCsv(model, parsed.config), error: '' };
    } catch (error) { return { budget: null, comparison: null, csv: '', error: error instanceof Error ? error.message : '工程量无法计算。' }; }
  }, [model, parsed.config]);
  const persist = (next: BudgetConfig) => {
    try { onChange(setBudgetConfig(model, next)); setNotice('报价配置已更新，工程量随当前模型重算。'); }
    catch (error) { setNotice(error instanceof Error ? error.message : '报价配置未保存。'); }
  };
  if (!parsed.config) return <section className="budget-panel"><h2>材料与费用</h2><p className="budget-error" role="alert">{parsed.error}</p>
    <button type="button" className="budget-button" onClick={() => persist(createBudgetConfig())}>重置为待报价清单</button></section>;
  const config = parsed.config;
  const selected = config.quotes.find(quote => quote.id === config.selectedQuoteId)!;
  const editQuote = (change: (quote: BudgetQuote) => BudgetQuote) => {
    const next = validateBudgetConfig(config, model);
    next.quotes = next.quotes.map(quote => quote.id === selected.id ? change(quote) : quote);
    persist(next);
  };
  const roomPrice = (roomId: string, field: 'floorUnitPrice' | 'floorWastePercent' | 'wallUnitPrice', value: number | null) => {
    if (field === 'floorWastePercent' && value === null) return;
    editQuote(quote => ({ ...quote, rooms: { ...quote.rooms, [roomId]: { ...getRoomQuote(quote, roomId), [field]: value } } }));
  };
  const download = () => {
    try {
      const url = URL.createObjectURL(new Blob(['\uFEFF', computed.csv], { type: 'text/csv;charset=utf-8' }));
      const link = document.createElement('a'); link.href = url; link.download = '筑映-材料报价对比.csv';
      document.body.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000); setNotice('CSV 已准备下载；如下载受限，可展开预览复制。');
    } catch { setCsvVisible(true); setNotice('下载未完成，请使用下方 CSV 预览复制。'); }
  };
  const copy = async () => {
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(computed.csv); setNotice('CSV 已复制。');
    } catch { setCsvVisible(true); setNotice('浏览器未允许复制。已展开 CSV，请选择文字后手动复制。');
      requestAnimationFrame(() => { preview.current?.focus(); preview.current?.select(); }); }
  };
  const budget = computed.budget;
  return <section className="budget-panel" aria-label="材料工程量与费用清单">
    <div className="budget-heading"><div><h2>材料与费用</h2><p>工程量按当前模型计算，单价由你填写。此清单用于方案估算。</p></div>
      <div className="budget-export-actions"><button type="button" className="budget-button" disabled={!budget} onClick={download}>导出 CSV</button>
        <button type="button" className="budget-button" disabled={!budget} onClick={() => { setCsvVisible(value => !value); }}>CSV 预览</button></div></div>
    <div className="budget-quote-toolbar"><div className="budget-quote-switch" aria-label="报价方案">{config.quotes.map(quote =>
      <button type="button" key={quote.id} title={quote.name} aria-pressed={selected.id === quote.id}
        onClick={() => persist({ ...config, selectedQuoteId: quote.id })}>{quote.name}</button>)}</div>
      <div className="budget-quote-create"><button type="button" className="budget-button" disabled={config.quotes.length >= 2}
        onClick={() => persist(createBudgetQuote(config))}>新建第二方案</button>
        <button type="button" className="budget-button" disabled={config.quotes.length >= 2}
          onClick={() => persist(createBudgetQuote(config, selected.id))}>复制为第二方案</button></div></div>
    <QuoteName key={selected.id} quote={selected} onCommit={name => editQuote(quote => ({ ...quote, name }))} />
    {computed.error && <p className="budget-error" role="alert">{computed.error}</p>}
    {budget && <>
      <div className="budget-summary"><p><span>{budget.complete ? '报价合计' : '已报价部分合计'}</span><strong>{money(budget.partialTotal)}</strong>
        <span>{budget.complete ? '全部条目已报价，金额仍按模型估算。' : `${budget.pendingCount} 项待报价，尚无完整总价。`}</span></p>
        <p>{budget.measurementLabel}</p></div>
      {(budget.stale.roomIds.length > 0 || budget.stale.furnitureIds.length > 0) && <div className="budget-stale"><p>
        此方案保留了 {budget.stale.roomIds.length} 个已删除房间、{budget.stale.furnitureIds.length} 个已删除家具的报价，均不计入当前清单。</p>
        <details><summary>查看已失效编号</summary><p>{[...budget.stale.roomIds, ...budget.stale.furnitureIds].join('、')}</p></details>
        <button type="button" className="budget-button" onClick={() => persist(cleanStaleBudgetReferences(model, config, selected.id))}>清理此方案的失效报价</button></div>}
      <div className="budget-section-heading"><h3>地板</h3><p>报价量 = 多边形地面面积 ×（1 + 损耗率）。</p></div>
      <div className="budget-table-wrap"><table className="budget-table"><thead><tr><th scope="col">房间 / 材质</th><th scope="col">净面积 m²</th><th scope="col">损耗 %</th><th scope="col">报价量 m²</th><th scope="col">单价 元/m²</th><th scope="col">金额</th></tr></thead>
        <tbody>{budget.rows.filter(row => row.category === 'floor').map(row => <tr key={row.id}><td data-label="房间 / 材质"><strong>{row.roomName}</strong><span className="budget-row-material">{row.label}</span></td>
          <td data-label="净面积 m²">{area(row.netQuantity)}</td><td data-label="损耗 %"><QuoteInput label={`${row.roomName}地板损耗率（百分比）`} value={row.wastePercent} kind="waste" onCommit={value => roomPrice(row.roomId, 'floorWastePercent', value)} /></td>
          <td data-label="报价量 m²">{area(row.quantity)}</td><td data-label="单价 元/m²"><QuoteInput label={`${row.roomName}地板单价（元每平方米）`} value={row.unitPrice} onCommit={value => roomPrice(row.roomId, 'floorUnitPrice', value)} /></td>
          <td data-label="金额"><Amount row={row} /></td></tr>)}</tbody></table></div>
      <div className="budget-section-heading"><h3>墙面</h3><p>按房间内侧饰面计量，扣除本房间边界门窗洞口。</p></div>
      <div className="budget-table-wrap"><table className="budget-table budget-wall-table"><thead><tr><th scope="col">房间 / 饰面</th><th scope="col">净墙面 m²</th><th scope="col">单价 元/m²</th><th scope="col">金额</th></tr></thead>
        <tbody>{budget.rows.filter(row => row.category === 'wall').map(row => <tr key={row.id}><td data-label="房间 / 饰面"><strong>{row.roomName}</strong><span className="budget-row-material">{row.label}</span>
          <WallBasis roomName={row.roomName} quantity={budget.roomQuantities.find(item => item.roomId === row.roomId)!} /></td>
          <td data-label="净墙面 m²">{area(row.quantity)}</td><td data-label="单价 元/m²"><QuoteInput label={`${row.roomName}墙面单价（元每平方米）`} value={row.unitPrice} onCommit={value => roomPrice(row.roomId, 'wallUnitPrice', value)} /></td>
          <td data-label="金额"><Amount row={row} /></td></tr>)}</tbody></table></div>
      <div className="budget-section-heading"><h3>家具</h3><p>仅统计项目中已保存的家具构件，模型示意家具不计价。</p></div>
      {budget.rows.some(row => row.category === 'furniture') ? <div className="budget-table-wrap"><table className="budget-table budget-furniture-table"><thead><tr><th scope="col">房间 / 家具</th><th scope="col">数量 件</th><th scope="col">按件单价 元</th><th scope="col">金额</th></tr></thead>
        <tbody>{budget.rows.filter(row => row.category === 'furniture').map(row => <tr key={row.id}><td data-label="房间 / 家具"><strong>{row.label}</strong><span className="budget-row-material">{row.roomName}</span></td>
          <td data-label="数量 件">1</td><td data-label="按件单价 元"><QuoteInput label={`${row.roomName}${row.label}单价（元每件）`} value={row.unitPrice}
            onCommit={value => editQuote(quote => ({ ...quote, furniture: { ...quote.furniture, [row.id.slice('furniture:'.length)]: value } }))} /></td>
          <td data-label="金额"><Amount row={row} /></td></tr>)}</tbody></table></div> : <p className="budget-empty">当前项目没有已保存的家具。添加布局家具后，清单会自动更新。</p>}
      {computed.comparison && computed.comparison.budgets.length === 2 && <section className="budget-comparison" aria-label="报价方案对比"><h3>方案对比</h3>
        <p>两套报价均按当前几何与材质重算；每套单价和损耗独立保存。</p>
        <div className="budget-table-wrap"><table className="budget-table"><thead><tr><th scope="col">方案</th><th scope="col">已报价部分合计</th><th scope="col">待报价</th><th scope="col">完整报价合计</th></tr></thead><tbody>
          {computed.comparison.budgets.map(result => <tr key={result.quoteId}><td data-label="方案"><strong>{result.quoteName}</strong></td><td data-label="已报价部分合计">{money(result.partialTotal)}</td>
            <td data-label="待报价">{result.pendingCount} 项</td><td data-label="完整报价合计">{result.total === null ? '待补全单价' : money(result.total)}</td></tr>)}</tbody></table></div>
        <p>{computed.comparison.difference === null ? '单价补全后显示两套报价的合计差额。' : `第二方案比第一方案${computed.comparison.difference >= 0 ? '增加' : '减少'} ${money(Math.abs(computed.comparison.difference))}。`}</p></section>}
      <details className="budget-method"><summary>计算范围与舍入规则</summary>
        <p>净地面面积使用房间多边形重新计算，不读取旧面积字段。墙面按边界分段与墙高计算，门窗只扣除对应墙段在本房间边界内的洞口面积；墙体中心线或内侧边线与实际净尺寸可能有差异。</p>
        <p>计算工程量保留 6 位小数；界面面积显示至 3 位小数。单价最多 2 位小数，各条目金额采用非负数四舍五入至分，再累加整数分。空单价为待报价，输入 0 表示明确的零元报价。地板损耗由你填写，墙面与家具首版不加损耗。</p>
        <p>单价请自行确认是否含人工、税费与辅材，本页不推测市场价格。清单未涵盖吊顶、踢脚线、洞口侧壁、基层处理、水电、安装与运输等项目，不能代替现场测量、施工图工程量或施工报价。改变材质或几何后会保留现有报价，请重新核对适用性。</p>
      </details>
    </>}
    {csvVisible && budget && <section className="budget-csv"><div className="budget-section-heading"><h3>CSV 预览</h3><button type="button" className="budget-button" onClick={() => void copy()}>复制 CSV</button></div>
      <p>包含所有已建立的方案。文本已防护电子表格公式注入；复制受限时可选中下方文字手动复制。</p>
      <textarea ref={preview} readOnly aria-label="可复制的材料报价 CSV" value={computed.csv} onFocus={event => event.currentTarget.select()} /></section>}
    <p className="budget-notice" role="status" aria-live="polite">{notice}</p>
  </section>;
}
