import type { HouseModel, Point } from './types';

export const MEASUREMENT_TOLERANCE: number;
export interface MeasurementRecord {
  id: string; wallId: string; lengthMeters: number; date: string;
  source: string; note: string; confirmed: boolean;
  wallSnapshot?: { start: Point; end: Point };
}
export interface MeasurementReview {
  wallId: string; roomId?: string; modelLength: number | null; deltaMeters: number | null;
  snapshotCurrent: boolean;
  status: 'unmeasured' | 'unconfirmed' | 'geometry_changed' | 'difference' | 'checked' | 'orphaned';
  record: MeasurementRecord | null;
}
export interface MeasurementReviews {
  walls: MeasurementReview[]; orphaned: MeasurementReview[]; error: string | null;
  summary: { totalWalls: number; measuredWalls: number; confirmedCurrentWalls: number; unmeasuredWalls: number;
    differenceWalls: number; geometryChangedWalls: number; orphanedRecords: number };
}
export interface FurnitureDimensions { width: number; depth: number; height: number }
export interface LayoutIssue {
  id: string; type: string; severity: 'conflict' | 'hint' | 'unknown'; basis: 'geometry' | 'heuristic' | 'data';
  message: string; roomId?: string; openingId?: string; wallId?: string; furnitureIds: string[];
}
export interface LayoutAudit {
  issues: LayoutIssue[]; counts: { conflicts: number; hints: number; unknown: number };
  checked: { furniture: number; walls: number; doors: number; windows: number };
  measurementReview: MeasurementReviews;
}
export function validateMeasurements(raw: unknown, model: HouseModel): MeasurementRecord[];
export function getMeasurementReview(model: HouseModel): MeasurementReviews;
export function recordWallMeasurement(model: HouseModel, raw: Omit<MeasurementRecord, 'wallSnapshot'>): HouseModel;
export function parseFurnitureDimensions(raw: { width: string | number; depth: string | number; height: string | number }): FurnitureDimensions;
export function getFurnitureDimensionErrors(model: HouseModel, dimensions: unknown): string[];
export function updateFurnitureDimensions(model: HouseModel, id: string, dimensions: FurnitureDimensions): HouseModel;
export function auditLayout(model: HouseModel): LayoutAudit;
