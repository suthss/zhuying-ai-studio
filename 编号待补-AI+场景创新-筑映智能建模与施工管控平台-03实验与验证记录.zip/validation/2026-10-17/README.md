# 2026-10-17 工程回归验证原始证据

验证对象为当前工作区源码快照。本目录未读取 `.env`，没有真实 AI 或付费调用，没有重训，也未重跑十张图纸识别基准。2026-10-15 的原始记录保持不变。

## 本次结果

| 检查 | 结果 | 本机墙钟时间 |
| --- | --- | ---: |
| 前端全量 `npm test` | 164 项通过，0 失败、0 取消、0 跳过 | 3.443 秒 |
| 后端全量 `tests/test_*.py` | 225 项测试、299 个子用例，0 失败、0 错误、0 跳过 | 11.551 秒 |
| TypeScript 项目构建检查 | 通过 | 2.901 秒 |
| Vite 生产构建 | 通过，保留主包体积警告 | 5.282 秒 |

前端运行器报告 1174.1065 ms。后端 unittest 原始输出报告 9.791 s，包围测试发现与运行的验证 runner 记录 10.954 s；表内时间是外层进程墙钟时间。前后端检查曾并行运行，这些时间不应用于稳定性能、方法加速比或服务 SLA 声明。299 个子用例不与 225 项相加称为独立测试总数。

AI 接口测试使用模拟响应，仅验证契约、校验、状态与失败回退；外层 `urllib.request.urlopen` 阻止未模拟的真实 HTTP 外发。它不证明云端模型准确率。`summary.json` 保存结构化结论，`commands.json` 保存实际执行参数，四个 `*.log` 是原始进程输出。

生产构建处理 1641 个模块；主 JS 为 1207.89 kB，gzip 350.52 kB。大包警告未被移除或包装成通过性能测试。

## 输出与源码隔离

- 使用 bundled Node v24.19.0，Python 3.12.7，Windows 11。
- 前端执行实际 package.json 的 `npm test` 脚本，子进程 PATH 优先指向 bundled Node。
- `tsconfig.validation.json` 继承原项目 `tsconfig.json`，只重定向 `tsBuildInfoFile`。
- `build-validation.mjs` 导入原 `vite.config.ts`，使用原 React 插件和构建设置，只重定向产物、缓存及空的环境目录。没有覆写原 `dist` 与根目录构建缓存，Vite 不读取项目环境文件。
- 测试临时数据库和临时文件、npm 缓存均定位到本目录内。应用源码与已保存用户项目未被修改。
- `source-snapshot-before.json` 与 `source-snapshot-after.json` 记录 198 个源码、测试、脚本、公开资源与构建配置文件的字节数和 SHA-256，前后相同。快照排除环境文件、凭证扩展名、数据库、日志和 Python 缓存。

## 复跑

在相同工作区和依赖环境中执行（不需要配置 API 密钥）：

```powershell
& '<BUNDLED_RUNTIME>/dependencies/python/python.exe' -B -X utf8 artifacts/submission-materials/validation/run-validation.py
```

`run-validation.py` 包含本机 Node、Python、npm 入口路径；迁移机器需按实际安装位置调整这些验证工具路径。源码项目的一般安装与测试方法仍见根目录 README。构建等价检查的真实 argv 保存在 `commands.json`，未把该包装检查误称为逐字执行原 `npm run build`。

## 保留的首次命令问题

首次尝试将 `--tsBuildInfoFile` 与 `tsc --build` 同时传到命令行，得到 TS5094，Vite 因而未执行。这是验证调用参数问题，并非应用类型错误。随后在继承配置中设置该选项，仅重跑 TypeScript/Vite，两项通过；前后端无需重跑。原始失败输出保存在 `initial-attempt-typescript-build.log`，初次摘要和参数也一并保留，没有修改应用以掩盖失败。
