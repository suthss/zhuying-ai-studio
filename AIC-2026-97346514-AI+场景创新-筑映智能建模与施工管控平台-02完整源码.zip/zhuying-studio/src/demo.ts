import type { HouseModel, Room, Stage } from './types';
const room = (id: string, name: string, polygon: [number, number][], material: string, floor: Stage, wall: Stage): Room => ({
  id, name, polygon, material,
  area: Math.abs(polygon.reduce((sum, p, i) => { const q = polygon[(i + 1) % polygon.length]; return sum + p[0] * q[1] - q[0] * p[1]; }, 0)) / 2,
  progress: ((floor === 'complete' ? 1 : floor === 'in_progress' ? .5 : 0) + (wall === 'complete' ? 1 : wall === 'in_progress' ? .5 : 0)) * 50,
  tasks: { floor: { stage: floor, plannedStage: 'complete', dueDate: '2026-10-03' }, wall: { stage: wall, plannedStage: 'complete', dueDate: '2026-10-08' } }, evidence: []
});
export const DEMO_MODEL: HouseModel = {
  id: 'demo-yunqi', name: '云栖居 · 装修项目', width: 12, depth: 9, height: 2.8, source: 'demo', meta: {demoData:true},
  warnings: ['示例模型与工序记录用于演示；家具为示意，不代表照片重建结果。'],
  walls: [
    { id: 'north', start: [0,0], end: [12,0], thickness: .20 },
    { id: 'east', start: [12,0], end: [12,9], thickness: .20 },
    { id: 'south', start: [0,9], end: [12,9], thickness: .20 },
    { id: 'west', start: [0,0], end: [0,9], thickness: .20 },
    { id: 'spine', start: [7,0], end: [7,9], thickness: .16 },
    { id: 'cross', start: [0,4], end: [12,4], thickness: .16 },
    { id: 'kitchen-div', start: [4,0], end: [4,4], thickness: .16 },
    { id: 'bath-div', start: [4,2.1], end: [7,2.1], thickness: .14 }
  ],
  openings: [
    { id:'w1', wallId:'north', type:'window', offset:.65, width:2.5, height:1.4, sill:.85 },
    { id:'w2', wallId:'north', type:'window', offset:8, width:3, height:1.4, sill:.85 },
    { id:'w3', wallId:'south', type:'window', offset:1.2, width:3.8, height:1.8, sill:.55 },
    { id:'w4', wallId:'east', type:'window', offset:5.1, width:2.6, height:1.6, sill:.7 },
    { id:'d1', wallId:'cross', type:'door', offset:4.9, width:1.1, height:2.15 },
    { id:'d2', wallId:'cross', type:'door', offset:8, width:.95, height:2.15 },
    { id:'d3', wallId:'spine', type:'door', offset:5, width:.95, height:2.15 },
    { id:'d4', wallId:'kitchen-div', type:'door', offset:2.7, width:.9, height:2.15 },
    { id:'d5', wallId:'bath-div', type:'door', offset:.5, width:.8, height:2.15 }
  ],
  rooms: [
    room('living','客餐厅',[[0,4],[7,4],[7,9],[0,9]],'wood','complete','in_progress'),
    room('master','主卧',[[7,4],[12,4],[12,9],[7,9]],'wood','complete','complete'),
    room('study','次卧 / 书房',[[7,0],[12,0],[12,4],[7,4]],'wood','in_progress','in_progress'),
    room('kitchen','厨房',[[0,0],[4,0],[4,4],[0,4]],'tile','complete','complete'),
    room('bathroom','卫生间',[[4,0],[7,0],[7,2.1],[4,2.1]],'tile','not_started','in_progress'),
    room('entry','玄关',[[4,2.1],[7,2.1],[7,4],[4,4]],'stone','complete','in_progress')
  ]
};
export const demoAt = (date: string): HouseModel => {
  const model = structuredClone(DEMO_MODEL);
  if (date < '2026-10-04') {
    model.rooms.forEach((r, i) => {
      r.tasks.floor.stage = date < '2026-09-28' ? 'not_started' : i % 2 ? 'in_progress' : 'complete';
      r.tasks.wall.stage = date < '2026-09-28' ? 'in_progress' : 'in_progress';
      r.progress = (r.tasks.floor.stage === 'complete' ? 50 : r.tasks.floor.stage === 'in_progress' ? 25 : 0) + 25;
    });
  }
  return model;
};
