import * as THREE from 'three';
import type { FloorFinish } from '../types';

function rng(seed: number) {
  let value = seed;
  return () => { value = (value * 1664525 + 1013904223) >>> 0; return value / 4294967296; };
}

/** One repeat corresponds to 2 × 2 m; image UVs remain in model metres. */
export function makeFloorTexture(finish: FloorFinish, direction: 0 | 90) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 512;
  const context = canvas.getContext('2d')!;
  const next = rng(927);
  if (finish === 'oak' || finish === 'walnut') {
    const walnut = finish === 'walnut';
    const base = walnut ? [107, 72, 49] : [202, 163, 106];
    context.fillStyle = walnut ? '#543b2c' : '#ac8859'; context.fillRect(0, 0, 512, 512);
    for (let row = 0; row < 10; row++) {
      const shade = Math.round((next() - 0.5) * (walnut ? 34 : 25));
      context.fillStyle = `rgb(${base[0] + shade},${base[1] + shade},${base[2] + shade})`;
      context.fillRect(0, row * 51.2 + 1, 512, 49.6);
      const joint = row % 3 * 150 + 35;
      context.fillStyle = walnut ? '#52392d' : '#a28156';
      context.fillRect(joint, row * 51.2, 1.2, 51.2);
      for (let grain = 0; grain < 70; grain++) {
        const y = row * 51.2 + next() * 51.2;
        context.strokeStyle = walnut ? `rgba(39,22,16,${next() * 0.21})` : `rgba(96,64,26,${next() * 0.16})`;
        context.lineWidth = next() * 1.2 + 0.3;
        context.beginPath(); context.moveTo(0, y);
        context.bezierCurveTo(150, y + next() * 7 - 3, 360, y + next() * 7 - 3, 512, y);
        context.stroke();
      }
    }
  } else if (finish === 'light_tile' || finish === 'gray_stone') {
    const stone = finish === 'gray_stone';
    context.fillStyle = stone ? '#70797b' : '#c9c5b8'; context.fillRect(0, 0, 512, 512);
    for (let x = 0; x < 512; x += 128) for (let y = 0; y < 512; y += 128) {
      const shade = Math.floor(next() * 13);
      context.fillStyle = stone ? `rgb(${132 + shade},${143 + shade},${145 + shade})` : `rgb(${224 + shade},${220 + shade},${207 + shade})`;
      context.fillRect(x + 1.4, y + 1.4, 125.2, 125.2);
      for (let vein = 0; vein < (stone ? 20 : 9); vein++) {
        context.strokeStyle = stone ? `rgba(233,239,232,${0.05 + next() * 0.11})` : `rgba(167,157,138,${next() * 0.09})`;
        context.lineWidth = next() * 1.7;
        const start = y + next() * 128;
        context.beginPath(); context.moveTo(x + 2, start);
        context.bezierCurveTo(x + 42, start + 18, x + 76, start - 19, x + 126, start + 4); context.stroke();
      }
    }
  } else if (finish === 'terrazzo') {
    context.fillStyle = '#e1ded1'; context.fillRect(0, 0, 512, 512);
    const chips = ['#5f776d', '#9d9d8b', '#b2876f', '#f4f0e4', '#bec1ad', '#6f7878'];
    for (let chip = 0; chip < 1550; chip++) {
      const x = next() * 512, y = next() * 512, radius = 1 + next() * 4.5;
      context.fillStyle = chips[Math.floor(next() * chips.length)];
      context.beginPath(); context.moveTo(x - radius, y - radius * 0.45);
      context.lineTo(x + radius * 0.5, y - radius); context.lineTo(x + radius, y + radius * 0.6);
      context.lineTo(x - radius * 0.5, y + radius); context.closePath(); context.fill();
    }
  } else {
    context.fillStyle = '#afb3b0'; context.fillRect(0, 0, 512, 512);
    for (let cloud = 0; cloud < 65; cloud++) {
      const x = next() * 512, y = next() * 512, radius = 25 + next() * 95;
      const shade = next() > 0.5 ? '240,242,231' : '62,75,70';
      const gradient = context.createRadialGradient(x, y, 0, x, y, radius);
      gradient.addColorStop(0, `rgba(${shade},0.045)`); gradient.addColorStop(1, `rgba(${shade},0)`);
      context.fillStyle = gradient; context.fillRect(x - radius, y - radius, radius * 2, radius * 2);
    }
    for (let grain = 0; grain < 17000; grain++) {
      context.fillStyle = next() > 0.5 ? '#ffffff16' : '#32403814';
      context.fillRect(next() * 512, next() * 512, next() * 1.5 + 0.2, next() * 1.5 + 0.2);
    }
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.name = `${finish} · ${direction}°`;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(0.5, 0.5);
  texture.center.set(0.5, 0.5); texture.rotation = direction * Math.PI / 180;
  texture.anisotropy = 8;
  return texture;
}

export function makePlasterBump() {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
  const context = canvas.getContext('2d')!; const next = rng(833);
  context.fillStyle = '#808080'; context.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 6500; i++) {
    const shade = Math.round(85 + next() * 90);
    context.fillStyle = `rgb(${shade},${shade},${shade})`; context.fillRect(next() * 128, next() * 128, 1, 1);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping; texture.repeat.set(7, 7);
  return texture;
}

export function makeFabricTexture(color: string, rug = false) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 256;
  const context = canvas.getContext('2d')!; const next = rng(319);
  context.fillStyle = color; context.fillRect(0, 0, 256, 256);
  for (let line = 0; line < 256; line += 2) {
    context.strokeStyle = `rgba(255,255,240,${0.035 + next() * 0.09})`;
    context.beginPath(); context.moveTo(0, line); context.lineTo(256, line); context.stroke();
    context.strokeStyle = `rgba(70,64,48,${0.025 + next() * 0.05})`;
    context.beginPath(); context.moveTo(line, 0); context.lineTo(line, 256); context.stroke();
  }
  if (rug) {
    context.strokeStyle = '#a6a99a'; context.lineWidth = 1.6;
    for (const inset of [9, 13, 17]) context.strokeRect(inset, inset, 256 - inset * 2, 256 - inset * 2);
  }
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  if (!rug) texture.repeat.set(3, 3);
  texture.anisotropy = 8; return texture;
}
