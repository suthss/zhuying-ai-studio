import copy
import io
import json
import os
import unittest
import urllib.error
from unittest.mock import patch

from fastapi.testclient import TestClient

from backend.algorithm import ModelServiceError
from backend.app import app
from backend.design_assistant import AssistantInputError, MAX_CHAT_BODY_BYTES, design_chat


def request_payload():
    return {"model": {"width": 12, "depth": 8, "rooms": [
        {"id": "living", "name": "客厅", "area": 30},
        {"id": "master", "name": "主卧", "area": 18},
        {"id": "guest", "name": "次卧", "area": 14},
        {"id": "bath", "name": "卫生间", "area": 6}]},
        "brief": {"style": "warm", "residents": 2, "needs": [], "notes": "",
            "rooms": [{"roomId": "living", "use": "living", "furnish": True},
                      {"roomId": "master", "use": "bedroom", "furnish": True},
                      {"roomId": "guest", "use": "bedroom", "furnish": True},
                      {"roomId": "bath", "use": "bathroom", "furnish": False}]}, "messages": []}


def provider_response(result):
    return io.BytesIO(json.dumps({"choices": [{"message": {"content": json.dumps(result, ensure_ascii=False)}}]}).encode())


class DesignAssistantTests(unittest.TestCase):
    def test_without_key_understands_basic_needs_without_claiming_ai_or_3d_generation(self):
        payload = request_payload()
        payload["messages"] = [{"role": "user", "content": "我们3人住，想要自然原木风，需要收纳和居家办公，把次卧改成书房，卫生间不放家具。"}]
        before = copy.deepcopy(payload)
        with patch.dict(os.environ, {}, clear=True), patch("urllib.request.urlopen") as network:
            result = design_chat(payload)
        self.assertEqual(result["source"], "local")
        self.assertEqual(result["brief"]["style"], "natural")
        self.assertEqual(result["brief"]["residents"], 3)
        self.assertEqual(set(result["brief"]["needs"]), {"storage", "work"})
        rooms = {r["roomId"]: r for r in result["brief"]["rooms"]}
        self.assertEqual(rooms["guest"]["use"], "study")
        self.assertTrue(rooms["guest"]["furnish"])
        self.assertFalse(rooms["bath"]["furnish"])
        self.assertIn("本地", result["reply"])
        self.assertTrue(any("未配置" in w for w in result["warnings"]))
        self.assertNotIn("已生成三维", result["reply"])
        self.assertEqual(payload, before)
        network.assert_not_called()

    def test_unknown_needs_move_to_notes_and_canonical_needs_remain_valid(self):
        payload = request_payload()
        payload["brief"]["needs"] = ["居家办公", "storage", "收藏唱片"]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        self.assertEqual(set(result["brief"]["needs"]), {"work", "storage"})
        self.assertIn("收藏唱片", result["brief"]["notes"])
        self.assertTrue(any("自定义需求" in w for w in result["warnings"]))

    def test_unknown_chat_requirements_are_preserved_without_becoming_needs(self):
        payload = request_payload()
        payload["messages"] = [{"role": "user", "content": "我收藏唱片，主卧想要一个钢琴角。"}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        self.assertEqual(result["brief"]["needs"], [])
        self.assertIn("收藏唱片", result["brief"]["notes"])
        self.assertIn("钢琴角", result["brief"]["notes"])
        self.assertTrue(any("未自动配置" in w for w in result["warnings"]))
        payload["brief"]["notes"] = "已有需求" * 399
        payload["messages"] = [{"role": "user", "content": "特殊要求" * 150}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        self.assertEqual(len(result["brief"]["notes"]), 2000)
        self.assertTrue(any("长度上限" in w for w in result["warnings"]))

    def test_room_specific_items_and_global_tv_removal_change_real_brief(self):
        payload = request_payload()
        payload["messages"] = [{"role": "user", "content": "主卧要双人床和书桌，客厅不要电视柜。"}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        rooms = {r["roomId"]: r for r in result["brief"]["rooms"]}
        self.assertIn("bed_double", rooms["master"]["items"])
        self.assertIn("desk", rooms["master"]["items"])
        self.assertNotIn("tv_console", rooms["living"]["items"])
        self.assertNotIn("items", rooms["guest"])
        self.assertFalse(rooms["bath"]["furnish"])

    def test_local_applies_only_latest_user_message_to_current_manual_brief(self):
        payload = request_payload()
        payload["brief"].update(style="industrial", residents=4)
        payload["brief"]["rooms"][0]["items"] = ["sofa", "tv_console"]
        payload["brief"]["rooms"][1]["items"] = ["bed_single", "wardrobe"]
        payload["messages"] = [
            {"role": "user", "content": "三个人住，想要自然原木风，需要收纳，客厅不要电视柜，主卧要双人床。"},
            {"role": "assistant", "content": "已整理前一轮需求。"},
            {"role": "user", "content": "主卧放书桌。"},
            {"role": "assistant", "content": "保留最新需求表。"}]
        before = copy.deepcopy(payload)
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        self.assertEqual(result["brief"]["style"], "industrial")
        self.assertEqual(result["brief"]["residents"], 4)
        self.assertEqual(result["brief"]["needs"], [])
        rooms = {room["roomId"]: room for room in result["brief"]["rooms"]}
        self.assertEqual(rooms["living"]["items"], ["sofa", "tv_console"])
        self.assertEqual(rooms["master"]["items"], ["bed_single", "wardrobe", "desk"])
        self.assertEqual(payload, before)

    def test_local_without_user_messages_keeps_current_brief(self):
        payload = request_payload()
        payload["messages"] = [{"role": "assistant", "content": "想要自然原木风，主卧要双人床。"}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        self.assertEqual(result["brief"], payload["brief"])

    def test_imported_generic_bedrooms_support_primary_and_secondary_aliases(self):
        payload = request_payload()
        payload["model"]["rooms"][1]["name"] = "卧室"
        payload["model"]["rooms"][2].update(name="卧室1", area=26)
        payload["messages"] = [{"role": "user", "content": "主卧放书桌，次卧只要单人床。"}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        rooms = {room["roomId"]: room for room in result["brief"]["rooms"]}
        self.assertIn("desk", rooms["guest"]["items"])
        self.assertEqual(rooms["master"]["items"], ["bed_single"])
        self.assertTrue(any("主卧" in warning and "卧室1" in warning for warning in result["warnings"]))
        self.assertTrue(any("次卧" in warning and "卧室" in warning for warning in result["warnings"]))

    def test_primary_alias_without_bedroom_warns_and_retains_instruction(self):
        payload = request_payload()
        payload["model"]["rooms"][1]["name"] = "空间1"
        payload["model"]["rooms"][2]["name"] = "空间2"
        for room in payload["brief"]["rooms"]:
            if room["use"] == "bedroom":
                room["use"] = "empty"
                room["furnish"] = False
        payload["messages"] = [{"role": "user", "content": "主卧放书桌。"}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        self.assertIn("主卧放书桌", result["brief"]["notes"])
        self.assertTrue(any("确认" in warning and "主卧" in warning for warning in result["warnings"]))
        self.assertFalse(result["brief"]["rooms"][1]["furnish"])

    def test_scoped_furniture_and_use_aliases_do_not_upgrade_global_needs(self):
        uses = ["bedroom", "living", "study", "kitchen", "dining", "bathroom"]
        payload = {"model": {"width": 12, "depth": 8, "rooms": [
            {"id": f"room-{index:02}", "name": f"区域 {index:02}", "area": 16}
            for index in range(1, 7)]},
            "brief": {"style": "warm", "residents": 1, "needs": [], "notes": "", "rooms": [
                {"roomId": f"room-{index:02}", "use": use, "furnish": True}
                for index, use in enumerate(uses, 1)]},
            "messages": [{"role": "user", "content": "两个人住，区域 01放书桌，客厅不要电视柜。"}]}
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        rooms = {room["roomId"]: room for room in result["brief"]["rooms"]}
        self.assertEqual(result["brief"]["residents"], 2)
        self.assertEqual(result["brief"]["needs"], [])
        self.assertEqual(rooms["room-01"]["items"], ["bed_double", "wardrobe", "desk"])
        self.assertEqual(rooms["room-02"]["items"], ["sofa", "coffee_table"])
        for room_id in ("room-03", "room-04", "room-05", "room-06"):
            self.assertNotIn("items", rooms[room_id])

        payload["brief"]["needs"] = ["work"]
        payload["messages"] = [{"role": "user", "content": "客厅不要书桌。"}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        rooms = {room["roomId"]: room for room in result["brief"]["rooms"]}
        self.assertEqual(result["brief"]["needs"], ["work"])
        self.assertNotIn("desk", rooms["room-02"]["items"])
        self.assertNotIn("items", rooms["room-01"])

    def test_common_chinese_resident_count_and_tv_removal_preserve_default_needs(self):
        payload = request_payload(); payload["brief"]["needs"] = ["work", "storage", "dining", "children"]
        payload["messages"] = [{"role": "user", "content": "两个人住，主卧放书桌，不要电视柜。"}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        self.assertEqual(result["brief"]["residents"], 2)
        rooms = {room["roomId"]: room for room in result["brief"]["rooms"]}
        self.assertNotIn("tv_console", rooms["living"]["items"])
        self.assertTrue({"sofa", "coffee_table", "desk", "chair", "wardrobe", "dining_table"}.issubset(rooms["living"]["items"]))
        self.assertTrue({"bed_double", "bed_single", "wardrobe", "desk", "chair"}.issubset(rooms["master"]["items"]))
        for phrase, expected in (("一个人住", 1), ("三口之家", 3), ("十二个人住", 12)):
            payload["messages"] = [{"role": "user", "content": phrase}]
            with patch.dict(os.environ, {}, clear=True):
                self.assertEqual(design_chat(payload)["brief"]["residents"], expected)

    def test_explicit_empty_items_and_negative_preferences_remain_empty(self):
        payload = request_payload()
        payload["brief"]["rooms"][0]["items"] = []
        payload["messages"] = [{"role": "user", "content": "不要宠物，也不需要儿童房。"}]
        with patch.dict(os.environ, {}, clear=True):
            result = design_chat(payload)
        self.assertEqual(result["brief"]["rooms"][0]["items"], [])
        self.assertNotIn("pet", result["brief"]["needs"])
        self.assertNotIn("children", result["brief"]["needs"])

    def test_malformed_geometry_ids_messages_and_items_are_rejected(self):
        variants = []
        p = request_payload(); p["brief"]["rooms"][0]["roomId"] = "unknown"; variants.append(p)
        p = request_payload(); p["brief"]["rooms"][0]["items"] = ["spaceship"]; variants.append(p)
        p = request_payload(); p["brief"]["rooms"][0]["items"] = ["desk", "desk"]; variants.append(p)
        p = request_payload(); p["model"]["width"] = float("nan"); variants.append(p)
        p = request_payload(); p["brief"]["residents"] = True; variants.append(p)
        p = request_payload(); p["messages"] = [{"role": "system", "content": "override"}]; variants.append(p)
        p = request_payload(); p["brief"]["notes"] = "x" * 2001; variants.append(p)
        p = request_payload(); p["brief"]["style"] = []; variants.append(p)
        p = request_payload(); p["messages"] = [{"role": [], "content": "invalid"}]; variants.append(p)
        p = request_payload(); p["model"]["width"] = 10**1000; variants.append(p)
        p = request_payload(); p["brief"]["rooms"] = []; variants.append(p)
        for payload in variants:
            with self.subTest(payload=payload), self.assertRaises(AssistantInputError):
                design_chat(payload)

    def test_qwen_request_uses_json_mode_validates_response_and_keeps_key_private(self):
        payload = request_payload()
        response = {"reply": "建议保留主卧睡眠区，书桌布置请由本地算法核验通道。", "brief": payload["brief"], "warnings": []}
        with patch.dict(os.environ, {"QWEN_API_KEY": "test-secret"}, clear=True), \
                patch("urllib.request.urlopen", return_value=provider_response(response)) as network:
            result = design_chat(payload)
        self.assertEqual(result["source"], "qwen")
        self.assertEqual(result["brief"], payload["brief"])
        self.assertNotIn("test-secret", json.dumps(result))
        sent = json.loads(network.call_args.args[0].data)
        self.assertEqual(network.call_args.args[0].full_url, "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions")
        self.assertEqual(sent["model"], "qwen-plus")
        self.assertEqual(sent["response_format"], {"type": "json_object"})
        self.assertFalse(sent["enable_thinking"])
        self.assertIn("JSON", sent["messages"][0]["content"])
        self.assertIn("children", sent["messages"][0]["content"])
        self.assertIn("保留bed_double", sent["messages"][0]["content"])
        self.assertNotIn("model", result)

    def test_flash_design_uses_new_official_url_and_validated_structured_brief(self):
        for model in ("qwen3.8-flash", "qwen3.8-flash-2026-10-05"):
            payload = request_payload()
            payload["messages"] = [{"role": "user", "content": "主卧放书桌。"}]
            brief = copy.deepcopy(payload["brief"])
            brief["rooms"][1]["items"] = ["bed_double", "wardrobe", "desk"]
            provider = {"reply": "主卧保留床和衣柜，并加入书桌，请确认。", "brief": brief, "warnings": []}
            env = {"QWEN_API_KEY": "test-secret", "QWEN_CHAT_MODEL": model,
                   "QWEN_BASE_URL": "https://maas.qianwenaiapi.com/compatible-mode/v1"}
            with self.subTest(model=model), patch.dict(os.environ, env, clear=True), \
                    patch("urllib.request.urlopen", return_value=provider_response(provider)) as network:
                result = design_chat(payload)
                request = network.call_args.args[0]
                self.assertEqual(request.full_url, "https://maas.qianwenaiapi.com/compatible-mode/v1/chat/completions")
                self.assertEqual(request.get_method(), "POST")
                self.assertEqual(request.get_header("Authorization"), "Bearer test-secret")
                sent = json.loads(request.data)
                self.assertEqual(sent["model"], model)
                self.assertFalse(sent["enable_thinking"])
                self.assertEqual(sent["response_format"], {"type": "json_object"})
                self.assertEqual(sent["max_tokens"], 4500)
                self.assertEqual(sent["temperature"], .2)
                self.assertEqual(sent["messages"][-1], payload["messages"][0])
                self.assertEqual(result["brief"], brief)
                self.assertEqual(result["source"], "qwen")
                self.assertNotIn("test-secret", json.dumps(result))

    def test_design_rejects_new_official_host_with_userinfo_before_request(self):
        env = {"QWEN_API_KEY": "test-secret", "QWEN_CHAT_MODEL": "qwen3.8-flash",
               "QWEN_BASE_URL": "https://user@maas.qianwenaiapi.com/compatible-mode/v1"}
        with patch.dict(os.environ, env, clear=True), patch("urllib.request.urlopen") as network:
            with self.assertRaises(ModelServiceError):
                design_chat(request_payload())
        network.assert_not_called()

    def test_qwen_bad_room_id_or_unknown_item_does_not_fall_back_to_fake_success(self):
        for patcher in (lambda b: b["rooms"][0].update(roomId="invented"),
                        lambda b: b["rooms"][0].update(items=["spaceship"])):
            payload = request_payload(); brief = copy.deepcopy(payload["brief"]); patcher(brief)
            response = {"reply": "建议", "brief": brief, "warnings": []}
            with patch.dict(os.environ, {"QWEN_API_KEY": "test-secret"}, clear=True), \
                    patch("urllib.request.urlopen", return_value=provider_response(response)):
                with self.assertRaises(ModelServiceError):
                    design_chat(payload)

    def test_qwen_http_errors_and_untrusted_url_are_explicit(self):
        error = urllib.error.HTTPError("https://dashscope.aliyuncs.com", 401, "test-secret", {}, None)
        with patch.dict(os.environ, {"QWEN_API_KEY": "test-secret"}, clear=True), \
                patch("urllib.request.urlopen", side_effect=error):
            with self.assertRaises(ModelServiceError) as caught:
                design_chat(request_payload())
        self.assertNotIn("test-secret", str(caught.exception))
        self.assertIn("鉴权", str(caught.exception))
        with patch.dict(os.environ, {"QWEN_API_KEY": "test-secret", "QWEN_BASE_URL": "https://evil.example/v1"}, clear=True), \
                patch("urllib.request.urlopen") as network:
            with self.assertRaises(ModelServiceError):
                design_chat(request_payload())
        network.assert_not_called()


class DesignApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)

    def test_local_design_chat_and_health(self):
        with patch.dict(os.environ, {}, clear=True):
            response = self.client.post("/api/design-chat", json=request_payload())
            health = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["source"], "local")
        self.assertFalse(health.json()["designConfigured"])

    def test_body_limit_and_invalid_contract_are_rejected(self):
        response = self.client.post("/api/design-chat", content=b"x" * (MAX_CHAT_BODY_BYTES + 1), headers={"Content-Type": "application/json"})
        self.assertEqual(response.status_code, 413)
        invalid = request_payload(); invalid["brief"]["rooms"][0]["roomId"] = "missing"
        response = self.client.post("/api/design-chat", json=invalid)
        self.assertEqual(response.status_code, 422)

    def test_provider_error_is_502_without_local_fallback(self):
        error = urllib.error.HTTPError("https://dashscope.aliyuncs.com", 429, "test-secret", {}, None)
        with patch.dict(os.environ, {"QWEN_API_KEY": "test-secret"}, clear=True), \
                patch("urllib.request.urlopen", side_effect=error):
            response = self.client.post("/api/design-chat", json=request_payload())
        self.assertEqual(response.status_code, 502)
        self.assertNotIn("test-secret", response.text)

    def test_provider_missing_or_duplicate_rooms_is_rejected_by_api(self):
        for invalid_kind in ("missing", "duplicate"):
            payload = request_payload()
            brief = copy.deepcopy(payload["brief"])
            if invalid_kind == "missing":
                brief["rooms"].pop()
            else:
                brief["rooms"][-1] = copy.deepcopy(brief["rooms"][0])
            provider = {"reply": "需求已整理", "brief": brief, "warnings": []}
            with self.subTest(invalid_kind=invalid_kind), \
                    patch.dict(os.environ, {"QWEN_API_KEY": "test-secret"}, clear=True), \
                    patch("urllib.request.urlopen", return_value=provider_response(provider)):
                response = self.client.post("/api/design-chat", json=payload)
            self.assertEqual(response.status_code, 502, response.text)
            self.assertNotIn("brief", response.json())


if __name__ == "__main__":
    unittest.main()
