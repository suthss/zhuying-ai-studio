import { doorLeafPose, getOpeningErrors, getRoomOpenings, resolveOpeningDesign } from './openings.mjs';
import { getFurnitureErrors, getFurnitureSchemaErrors } from './furnishing.mjs';
import { validCalendarDate } from './progress.mjs';

const EPS = 1e-6;
export const MEASUREMENT_TOLERANCE = .02;
const finite = value => typeof value === 'number' && Number.isFinite(value);
const point = value => Array.isArray(value) && value.length === 2 && value.every(v => finite(v) && v >= 0 && v <= 100);
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const identifier = value => typeof value === 'string' && value.trim().length > 0 && value.length <= 160;
const lengthOf = wall => Math.hypot(wall.end[0] - wall.start[0], wall.end[1] - wall.start[1]);
const goodWall = wall => object(wall) && point(wall.start) && point(wall.end) && lengthOf(wall) >= .01 && finite(wall.thickness) && wall.thickness >= .02 && wall.thickness <= 2;
const cross = (a, b, c) => (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
const onSegment = (a, b, p) => Math.abs(cross(a, b, p)) < EPS && p[0] >= Math.min(a[0], b[0]) - EPS && p[0] <= Math.max(a[0], b[0]) + EPS && p[1] >= Math.min(a[1], b[1]) - EPS && p[1] <= Math.max(a[1], b[1]) + EPS;
function contains(polygon, p) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const a = polygon[i], b = polygon[j];
    if (onSegment(a, b, p)) return true;
    if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
  }
  return inside;
}
function properIntersection(a, b, c, d) {
  return cross(a, b, c) * cross(a, b, d) < -EPS && cross(c, d, a) * cross(c, d, b) < -EPS;
}
function rectangle(position, width, depth, rotation = 0, padding = 0) {
  const c = Math.cos(rotation), s = Math.sin(rotation);
  return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([sx, sz]) => {
    const x = sx * (width / 2 + padding), z = sz * (depth / 2 + padding);
    return [position[0] + c * x + s * z, position[1] - s * x + c * z];
  });
}
const footprint = (item, padding = 0) => rectangle(item.position, item.size[0], item.size[2], item.rotation, padding);
const goodPolygon = polygon => Array.isArray(polygon) && polygon.length >= 3 && polygon.length <= 200 && polygon.every(point)
  && Math.abs(polygon.reduce((sum, p, i) => { const q = polygon[(i + 1) % polygon.length]; return sum + p[0] * q[1] - q[0] * p[1]; }, 0)) > EPS;
function fitsPolygon(polygon, shape) {
  if (!shape.every(p => contains(polygon, p))) return false;
  for (let i = 0; i < shape.length; i++) {
    const a = shape[i], b = shape[(i + 1) % shape.length];
    if (!contains(polygon, [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2])) return false;
    for (let j = 0; j < polygon.length; j++) if (properIntersection(a, b, polygon[j], polygon[(j + 1) % polygon.length])) return false;
  }
  return true;
}
/** SAT is exact for the convex footprints and wall/leaf rectangles; touching alone is not penetration. */
function convexOverlap(a, b) {
  for (const shape of [a, b]) for (let i = 0; i < shape.length; i++) {
    const p = shape[i], q = shape[(i + 1) % shape.length], normal = [q[1] - p[1], p[0] - q[0]];
    const norm = Math.hypot(...normal); if (norm < EPS) continue;
    const projection = polygon => polygon.map(v => (v[0] * normal[0] + v[1] * normal[1]) / norm);
    const pa = projection(a), pb = projection(b);
    if (Math.min(Math.max(...pa), Math.max(...pb)) - Math.max(Math.min(...pa), Math.min(...pb)) <= EPS) return false;
  }
  return true;
}
function roomForWall(model, wall) {
  if (!goodWall(wall)) return undefined;
  const ux = (wall.end[0] - wall.start[0]) / lengthOf(wall), uz = (wall.end[1] - wall.start[1]) / lengthOf(wall);
  const tolerance = wall.thickness / 2 + .06;
  return model.rooms.find(room => goodPolygon(room.polygon) && room.polygon.some((a, index) => {
    const b = room.polygon[(index + 1) % room.polygon.length];
    const distance = p => Math.abs((p[0] - wall.start[0]) * uz - (p[1] - wall.start[1]) * ux);
    const project = p => (p[0] - wall.start[0]) * ux + (p[1] - wall.start[1]) * uz;
    return distance(a) <= tolerance && distance(b) <= tolerance
      && Math.min(lengthOf(wall), Math.max(project(a), project(b))) - Math.max(0, Math.min(project(a), project(b))) > EPS;
  }))?.id;
}

/** Deleted-wall records are valid history. No geometry claim is inferred from a human confirmation. */
export function validateMeasurements(raw, model) {
  if (raw === undefined) return [];
  const fail = message => { throw new Error(`实测记录无效：${message}`); };
  if (!Array.isArray(raw) || raw.length > 1000) fail('须为最多 1000 条的记录数组。');
  if (!object(model) || !Array.isArray(model.walls)) fail('模型墙体数据无效。');
  const seen = new Set();
  return raw.map(record => {
    if (!object(record) || !identifier(record.id) || !identifier(record.wallId) || seen.has(record.id)) fail('记录编号和墙段编号须有效，记录编号不能重复。');
    seen.add(record.id);
    if (!finite(record.lengthMeters) || record.lengthMeters <= 0 || record.lengthMeters > 200) fail('实测墙长须为大于 0、最多 200 米的有限数。');
    if (!validCalendarDate(record.date)) fail('量测日期须为有效的 YYYY-MM-DD 日历日期。');
    if (typeof record.source !== 'string' || !record.source.trim() || record.source.length > 500) fail('请填写不超过 500 字的量测来源。');
    if (typeof record.note !== 'string' || record.note.length > 2000) fail('备注须为不超过 2000 字的文字。');
    if (typeof record.confirmed !== 'boolean') fail('请明确填写人工确认状态。');
    if (record.wallSnapshot !== undefined && (!object(record.wallSnapshot) || !point(record.wallSnapshot.start) || !point(record.wallSnapshot.end)
      || Math.hypot(record.wallSnapshot.end[0] - record.wallSnapshot.start[0], record.wallSnapshot.end[1] - record.wallSnapshot.start[1]) < .01)) fail('保存时的墙段端点快照无效。');
    return { id: record.id, wallId: record.wallId, lengthMeters: record.lengthMeters, date: record.date, source: record.source.trim(), note: record.note, confirmed: record.confirmed,
      ...(record.wallSnapshot === undefined ? {} : { wallSnapshot: { start: [...record.wallSnapshot.start], end: [...record.wallSnapshot.end] } }) };
  });
}
export function getMeasurementReview(model) {
  let records = [], error = null;
  try { records = validateMeasurements(model.meta?.measurements, model); } catch (e) { error = e.message; }
  const latest = new Map();
  records.forEach(record => { if (!latest.has(record.wallId) || latest.get(record.wallId).date <= record.date) latest.set(record.wallId, record); });
  const walls = (Array.isArray(model.walls) ? model.walls : []).map(wall => {
    const record = latest.get(wall.id), modelLength = goodWall(wall) ? lengthOf(wall) : null;
    const deltaMeters = record && modelLength !== null ? modelLength - record.lengthMeters : null;
    const snapshotCurrent = !!record?.wallSnapshot && goodWall(wall) && ['start', 'end'].every(key => wall[key].every((value, i) => Math.abs(value - record.wallSnapshot[key][i]) < EPS));
    const status = !record || modelLength === null ? 'unmeasured' : !record.confirmed ? 'unconfirmed' : !snapshotCurrent ? 'geometry_changed'
      : Math.abs(deltaMeters) > MEASUREMENT_TOLERANCE + EPS ? 'difference' : 'checked';
    return { wallId: wall.id, roomId: roomForWall(model, wall), modelLength, deltaMeters, snapshotCurrent, status, record: record ?? null };
  });
  const present = new Set(walls.map(wall => wall.wallId));
  const orphaned = records.filter(record => !present.has(record.wallId)).map(record => ({ wallId: record.wallId, modelLength: null, deltaMeters: null, snapshotCurrent: false, status: 'orphaned', record }));
  return { walls, orphaned, error, summary: { totalWalls: walls.length, measuredWalls: walls.filter(wall => wall.record).length,
    confirmedCurrentWalls: walls.filter(wall => wall.status === 'checked').length, unmeasuredWalls: walls.filter(wall => !wall.record).length,
    differenceWalls: walls.filter(wall => wall.deltaMeters !== null && Math.abs(wall.deltaMeters) > MEASUREMENT_TOLERANCE + EPS).length,
    geometryChangedWalls: walls.filter(wall => wall.record && !wall.snapshotCurrent).length, orphanedRecords: orphaned.length } };
}
export function recordWallMeasurement(model, raw) {
  const wall = model.walls.find(item => item.id === raw?.wallId);
  if (!goodWall(wall)) throw new Error('当前墙段不存在或坐标无效，不能追加实测记录。');
  const records = validateMeasurements(model.meta?.measurements, model);
  const next = validateMeasurements([...records, { ...raw, wallSnapshot: { start: [...wall.start], end: [...wall.end] } }], model);
  return { ...model, meta: { ...model.meta, measurements: next } };
}

/** Schema-only validation lets a real dimension produce a visible conflict instead of silently rejecting it. */
export function getFurnitureDimensionErrors(model, dimensions) {
  const errors = [];
  if (!object(dimensions)) return ['请填写家具宽、深、高。'];
  for (const [key, label] of [['width', '宽度'], ['depth', '深度'], ['height', '高度']]) {
    const value = dimensions[key], maximum = key === 'height' ? Math.min(4, model.height - .03) : 6;
    if (!finite(value) || !finite(maximum) || value < .1 || value > maximum) errors.push(`${label}须为 0.10–${finite(maximum) ? maximum.toFixed(2) : '有效层高'} 米的有限数。`);
  }
  return errors;
}
export function parseFurnitureDimensions(raw) {
  const parse = value => typeof value === 'number' ? value : typeof value === 'string' && value.trim() ? Number(value) : NaN;
  return { width: parse(raw?.width), depth: parse(raw?.depth), height: parse(raw?.height) };
}
export function updateFurnitureDimensions(model, id, dimensions) {
  const item = model.furniture?.find(furniture => furniture.id === id);
  if (!item) throw new Error('找不到当前家具。');
  const errors = getFurnitureDimensionErrors(model, dimensions);
  if (errors.length) throw new Error(errors.join(' '));
  return { ...model, meta: { ...model.meta, layoutReviewPending: true }, furniture: model.furniture.map(furniture => furniture.id === id ? { ...furniture, size: [dimensions.width, dimensions.height, dimensions.depth] } : furniture) };
}

function wallRectangle(wall, left, right) {
  const length = lengthOf(wall), ux = (wall.end[0] - wall.start[0]) / length, uz = (wall.end[1] - wall.start[1]) / length;
  return rectangle([wall.start[0] + ux * (left + right) / 2, wall.start[1] + uz * (left + right) / 2], right - left, wall.thickness, -Math.atan2(uz, ux));
}
/** Same interval/vertical-void construction as buildHouse; window sill and furniture height matter. */
function penetratesWall(wall, openings, item, shape, modelHeight) {
  const length = lengthOf(wall), height = wall.height ?? modelHeight;
  if (!finite(height) || height <= 0) return false;
  const rows = openings.filter(opening => opening.wallId === wall.id);
  const breaks = [...new Set([0, length, ...rows.flatMap(opening => [Math.max(0, opening.offset), Math.min(length, opening.offset + opening.width)])])].sort((a, b) => a - b);
  for (let i = 0; i < breaks.length - 1; i++) {
    const left = breaks[i], right = breaks[i + 1], middle = (left + right) / 2;
    if (right - left <= EPS || !convexOverlap(shape, wallRectangle(wall, left, right))) continue;
    const voids = rows.filter(opening => opening.offset < middle && opening.offset + opening.width > middle)
      .map(opening => [opening.type === 'window' ? opening.sill ?? 0 : 0, Math.min(height, (opening.type === 'window' ? opening.sill ?? 0 : 0) + opening.height)]).sort((a, b) => a[0] - b[0]);
    let cursor = 0;
    for (const [bottom, top] of voids) {
      if (Math.min(bottom, height, item.size[1]) - cursor > EPS) return true;
      cursor = Math.max(cursor, top);
    }
    if (Math.min(height, item.size[1]) - cursor > EPS) return true;
  }
  return false;
}
function openingGeometry(wall, opening) {
  const length = lengthOf(wall), ux = (wall.end[0] - wall.start[0]) / length, uz = (wall.end[1] - wall.start[1]) / length, normal = [-uz, ux];
  const world = (x, z) => [wall.start[0] + ux * x + normal[0] * z, wall.start[1] + uz * x + normal[1] * z];
  const design = resolveOpeningDesign(opening), pose = doorLeafPose(opening), pivot = world(pose.pivotX, pose.pivotZ);
  const leafThickness = design.style === 'panel' ? .062 : design.style === 'glass' ? .045 : .038;
  const leaf = rectangle(world(pose.centerX, pose.centerZ), pose.leafWidth, leafThickness, pose.rotation - Math.atan2(uz, ux));
  const sweep = angle => {
    if (angle <= EPS) return null;
    const fan = [pivot], steps = Math.max(2, Math.ceil(angle / 2));
    for (let i = 0; i <= steps; i++) {
      const p = doorLeafPose({ ...opening, design: { ...design, openAngle: angle * i / steps } });
      // The inscribed fan stays inside the actual swept leaf; current body thickness is checked separately.
      fan.push(world(p.pivotX + Math.cos(p.rotation) * p.leafWidth, p.pivotZ - Math.sin(p.rotation) * p.leafWidth));
    }
    return fan;
  };
  return { design, leaf, sweep, normal, midpoint: world(opening.offset + opening.width / 2, 0), rotation: -Math.atan2(uz, ux) };
}

/** Fresh, deterministic model audit. No audit state or compliance result is written into the model. */
export function auditLayout(model) {
  const issues = [], seen = new Set(), measurementReview = getMeasurementReview(model);
  const add = issue => { if (!seen.has(issue.id)) { seen.add(issue.id); issues.push({ furnitureIds: [], ...issue }); } };
  const rooms = Array.isArray(model.rooms) ? model.rooms : [], walls = Array.isArray(model.walls) ? model.walls : [], openings = Array.isArray(model.openings) ? model.openings : [], furniture = Array.isArray(model.furniture) ? model.furniture : [];
  const safeModel = { ...model, rooms, walls, openings, furniture };
  const validWalls = walls.filter(goodWall), validOpenings = openings.filter(opening => {
    try {
      const errors = getOpeningErrors(safeModel, opening);
      if (errors.length) add({ id: `opening-data:${opening?.id}`, type: 'opening_data', severity: 'unknown', basis: 'data', openingId: opening?.id, wallId: opening?.wallId, roomId: roomForWall(safeModel, walls.find(wall => wall.id === opening?.wallId)), message: `${opening?.type === 'window' ? '窗' : '门'} ${opening?.id ?? '未知'} 参数待核对：${errors[0]}` });
      return errors.length === 0;
    } catch { add({ id: `opening-data:${opening?.id}`, type: 'opening_data', severity: 'unknown', basis: 'data', message: '门窗关联或参数无效，开启与墙体开口检验未完成。' }); return false; }
  });
  walls.filter(wall => !goodWall(wall)).forEach(wall => add({ id: `wall-data:${wall?.id}`, type: 'wall_data', severity: 'unknown', basis: 'data', wallId: wall?.id, message: `墙段 ${wall?.id ?? '未知'} 坐标或厚度待核对。` }));
  const validItems = [];
  for (const item of furniture) {
    const room = rooms.find(room => room.id === item?.roomId), dimensionErrors = getFurnitureDimensionErrors(safeModel, { width: item?.size?.[0], height: item?.size?.[1], depth: item?.size?.[2] });
    if (getFurnitureSchemaErrors(safeModel, item).length || dimensionErrors.length || !room || !goodPolygon(room.polygon)) {
      add({ id: `furniture-data:${item?.id}`, type: 'furniture_data', severity: 'unknown', basis: 'data', roomId: room?.id, furnitureIds: item?.id ? [item.id] : [], message: `家具 ${item?.id ?? '未知'} 的尺寸、位置或房间轮廓待核对；未计入几何检验。` }); continue;
    }
    const shape = footprint(item), name = `${room.name} · ${item.id}`;
    validItems.push({ item, shape });
    if (!fitsPolygon(room.polygon, shape)) add({ id: `outside:${item.id}`, type: 'outside_room', severity: 'conflict', basis: 'geometry', roomId: room.id, furnitureIds: [item.id], message: `${name} 超出当前房间轮廓。` });
    for (const wall of validWalls) if (penetratesWall(wall, validOpenings, item, shape, model.height)) add({ id: `wall:${item.id}:${wall.id}`, type: 'wall_collision', severity: 'conflict', basis: 'geometry', roomId: room.id, wallId: wall.id, furnitureIds: [item.id], message: `${name} 与墙段 ${wall.id} 的实体部分相交。` });
    // Retain the generator's 6 cm room edge / 2.5 cm wall padding as a planning hint.
    try {
      if (getFurnitureErrors(safeModel, item).some(error => error.includes('超出房间或侵入墙体')) && !issues.some(issue => issue.furnitureIds.includes(item.id) && ['outside_room', 'wall_collision'].includes(issue.type))) add({ id: `wall-clearance:${item.id}`, type: 'wall_clearance', severity: 'hint', basis: 'heuristic', roomId: room.id, furnitureIds: [item.id], message: `${name} 未满足布置器的墙边预留范围（房间边缘 6 cm / 墙体外扩 2.5 cm），请核对安装余量。` });
    } catch { /* Invalid linked geometry already appears as an unknown issue above. */ }
  }
  for (let i = 0; i < validItems.length; i++) for (let j = i + 1; j < validItems.length; j++) {
    const a = validItems[i], b = validItems[j], key = [a.item.id, b.item.id].sort().join(':');
    if (convexOverlap(a.shape, b.shape)) add({ id: `overlap:${key}`, type: 'furniture_collision', severity: 'conflict', basis: 'geometry', roomId: a.item.roomId, furnitureIds: [a.item.id, b.item.id], message: `家具 ${a.item.id} 与 ${b.item.id} 的占地范围相交。` });
    else if (convexOverlap(a.shape, footprint(b.item, .025))) add({ id: `spacing:${key}`, type: 'furniture_spacing', severity: 'hint', basis: 'heuristic', roomId: a.item.roomId, furnitureIds: [a.item.id, b.item.id], message: `家具 ${a.item.id} 与 ${b.item.id} 间距小于布置器预留的 2.5 cm，请核对安装和使用空间。` });
  }
  for (const opening of validOpenings.filter(opening => opening.type === 'door')) {
    const wall = validWalls.find(wall => wall.id === opening.wallId); if (!wall) continue;
    const geometry = openingGeometry(wall, opening), sweep = geometry.sweep(geometry.design.openAngle), reservedSweep = geometry.design.openAngle < 90 ? geometry.sweep(90) : null;
    for (const { item, shape } of validItems) {
      const key = `${opening.id}:${item.id}`;
      if (convexOverlap(shape, geometry.leaf)) add({ id: `leaf:${key}`, type: 'door_leaf', severity: 'conflict', basis: 'geometry', roomId: item.roomId, openingId: opening.id, furnitureIds: [item.id], message: `家具 ${item.id} 与门 ${opening.id} 在当前 ${geometry.design.openAngle}° 状态的门扇相交。` });
      if (sweep && convexOverlap(shape, sweep)) add({ id: `sweep:${key}`, type: 'door_sweep', severity: 'conflict', basis: 'geometry', roomId: item.roomId, openingId: opening.id, furnitureIds: [item.id], message: `家具 ${item.id} 侵入门 ${opening.id} 从闭合到当前 ${geometry.design.openAngle}° 的扫掠范围。` });
      else if (reservedSweep && convexOverlap(shape, reservedSweep)) add({ id: `reserved-sweep:${key}`, type: 'door_reserved_sweep', severity: 'hint', basis: 'heuristic', roomId: item.roomId, openingId: opening.id, furnitureIds: [item.id], message: `门 ${opening.id} 若继续开启至 90°，预留范围可能碰到家具 ${item.id}；当前角度为 ${geometry.design.openAngle}°。` });
    }
    for (const room of rooms.filter(room => goodPolygon(room.polygon) && getRoomOpenings(safeModel, room.id).some(item => item.id === opening.id))) {
      const { normal, midpoint, rotation } = geometry;
      const sign = contains(room.polygon, [midpoint[0] + normal[0] * .2, midpoint[1] + normal[1] * .2]) ? 1 : -1;
      // Matches furnishing.mjs .65 m passage -> .85 m approach; it is a planning envelope, not a code width.
      const approach = rectangle([midpoint[0] + normal[0] * sign * .46, midpoint[1] + normal[1] * sign * .46], opening.width + .25, .85, rotation);
      for (const { item, shape } of validItems.filter(row => row.item.roomId === room.id)) if (convexOverlap(shape, approach)) add({ id: `approach:${opening.id}:${item.id}`, type: 'door_approach', severity: 'hint', basis: 'heuristic', roomId: room.id, openingId: opening.id, furnitureIds: [item.id], message: `${room.name} 门 ${opening.id} 的门口预留区被家具 ${item.id} 占用（门宽外加 25 cm、向内 85 cm），需现场核对通行。` });
    }
  }
  if (measurementReview.error) add({ id: 'measurement-data', type: 'measurement_data', severity: 'unknown', basis: 'data', message: measurementReview.error });
  return { issues, counts: { conflicts: issues.filter(issue => issue.severity === 'conflict').length, hints: issues.filter(issue => issue.severity === 'hint').length, unknown: issues.filter(issue => issue.severity === 'unknown').length },
    checked: { furniture: validItems.length, walls: validWalls.length, doors: validOpenings.filter(opening => opening.type === 'door').length, windows: validOpenings.filter(opening => opening.type === 'window').length }, measurementReview };
}
