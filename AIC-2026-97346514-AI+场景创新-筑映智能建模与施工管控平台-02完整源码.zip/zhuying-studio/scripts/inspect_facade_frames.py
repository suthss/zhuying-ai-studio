"""Create a local contact sheet from the selected public videos."""
import json
from pathlib import Path
import cv2
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "artifacts" / "facade-demo"
files = sorted(v for v in WORK.glob("*") if v.suffix.lower() in (".mp4", ".mov"))
canvas = Image.new("RGB", (1200, 382 * ((len(files) + 1) // 2)), "#f5f5f0")
draw = ImageDraw.Draw(canvas)
font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 18)
out = []
for i, video in enumerate(files):
    capture = cv2.VideoCapture(str(video))
    fps = capture.get(cv2.CAP_PROP_FPS)
    duration = capture.get(cv2.CAP_PROP_FRAME_COUNT) / fps if fps else 0
    sample = min(1, duration * .4)
    capture.set(cv2.CAP_PROP_POS_MSEC, sample * 1000)
    ok, frame = capture.read()
    capture.release()
    if not ok:
        print("bad", video.name)
        continue
    im = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    im.save(WORK / (video.stem + "-frame.jpg"), quality=94)
    im.thumbnail((600, 338))
    x, y = (i % 2) * 600, (i // 2) * 382
    canvas.paste(im, (x, y))
    draw.text((x + 10, y + 345), video.name[:22], font=font, fill="#152a25")
    out.append({"file": video.name, "fps": fps, "duration": duration,
                "sample": sample, "width": frame.shape[1], "height": frame.shape[0]})
canvas.save(WORK / "contact-sheet.jpg")
(WORK / "video-meta.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
print(json.dumps(out, indent=2))
