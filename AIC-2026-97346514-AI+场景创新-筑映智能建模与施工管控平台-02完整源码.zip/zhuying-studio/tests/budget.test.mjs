import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateBudget, calculateLineAmount, calculateRoomQuantities, cleanStaleBudgetReferences, compareBudgets,
  createBudgetConfig, createBudgetQuote, csvSafeCell, exportBudgetCsv, getBudgetMeasurementLabel, getRoomQuote,
  parseBudgetInput, polygonFloorArea, setBudgetConfig, validateBudgetConfig } from '../src/budget.mjs';

const room = (id, polygon) => ({ id, name: id, polygon, area: 999, material: 'wood' });
function model() {
  return { id: 'house', name: '测试项目', height: 3, rooms: [room('a', [[0, 0], [4, 0], [4, 4], [0, 4]]),
    room('b', [[4, 0], [8, 0], [8, 4], [4, 4]])],
  walls: [
    { id: 'north', start: [0, 0], end: [8, 0], thickness: .2 },
    { id: 'south', start: [0, 4], end: [8, 4], thickness: .2 },
    { id: 'west', start: [0, 0], end: [0, 4], thickness: .2 },
    { id: 'east', start: [8, 0], end: [8, 4], thickness: .2 },
    { id: 'shared', start: [4, 0], end: [4, 4], thickness: .16 },
    { id: 'unrelated', start: [0, 2], end: [8, 2], thickness: .2 }], openings: [
      { id: 'only-b', wallId: 'north', type: 'window', offset: 5, width: 2, height: 1.5, sill: 1 },
      { id: 'between', wallId: 'shared', type: 'door', offset: 1, width: 1, height: 2 },
      { id: 'inside', wallId: 'unrelated', type: 'door', offset: 1, width: 1, height: 2 }],
    furniture: [{ id: 'chair-a', roomId: 'a', kind: 'chair' }], meta: {} };
}

test('地面从多边形重新计算，凹房间不会当作包围盒或读取旧area', () => {
  const polygon = [[0, 0], [4, 0], [4, 1], [1, 1], [1, 4], [0, 4]];
  assert.equal(polygonFloorArea(polygon), 7);
  assert.equal(polygonFloorArea([...polygon].reverse()), 7);
  const house = { ...model(), walls: [], openings: [], rooms: [room('l', polygon)] };
  const quantities = calculateRoomQuantities(house, house.rooms[0]);
  assert.equal(quantities.floorArea, 7);
  assert.equal(quantities.perimeter, 16);
  assert.equal(quantities.wallGrossArea, 48);
  assert.equal(quantities.estimatedBoundaryLength, 16);
});

test('真实边界门窗扣除：共享墙分别计饰面，长外墙开口只扣所在房间', () => {
  const house = model();
  const a = calculateRoomQuantities(house, house.rooms[0]);
  const b = calculateRoomQuantities(house, house.rooms[1]);
  assert.equal(a.wallGrossArea, 48);
  assert.equal(a.openingDeductionArea, 2, 'only the shared door touches room a');
  assert.equal(a.wallNetArea, 46);
  assert.equal(b.openingDeductionArea, 5, 'room b includes its own external window plus shared door');
  assert.equal(b.wallNetArea, 43);
  assert.equal(a.estimatedBoundaryLength, 0);
  assert.equal(a.edges.flatMap(edge => edge.deductions).some(opening => opening.openingId === 'inside'), false);
});

test('跨房间的洞口按交叠宽度裁剪；反向墙起点正确定位开口', () => {
  const house = model();
  house.openings = [{ id: 'straddle', wallId: 'north', type: 'door', offset: 3, width: 2, height: 2 }];
  assert.equal(calculateRoomQuantities(house, house.rooms[0]).openingDeductionArea, 2);
  assert.equal(calculateRoomQuantities(house, house.rooms[1]).openingDeductionArea, 2);
  house.walls.find(wall => wall.id === 'north').start = [8, 0];
  house.walls.find(wall => wall.id === 'north').end = [0, 0];
  house.openings = [{ id: 'reverse', wallId: 'north', type: 'window', offset: 1, width: 2, height: 1, sill: 1 }];
  assert.equal(calculateRoomQuantities(house, house.rooms[0]).openingDeductionArea, 0);
  assert.equal(calculateRoomQuantities(house, house.rooms[1]).openingDeductionArea, 2);
});

test('边界墙高分段计算，洞口联合扣除不会重复或产生负面积', () => {
  const house = model();
  house.walls.find(wall => wall.id === 'north').height = 2;
  house.openings = [
    { id: 'opening-1', wallId: 'north', type: 'window', offset: 1, width: 2, height: 1.5, sill: 1 },
    { id: 'opening-2', wallId: 'north', type: 'window', offset: 2, width: 1, height: 1, sill: 1 }];
  const quantities = calculateRoomQuantities(house, house.rooms[0]);
  assert.equal(quantities.wallGrossArea, 44);
  assert.equal(quantities.openingDeductionArea, 2);
  assert.equal(quantities.wallNetArea, 42);
});

test('待报价与明确0元不同：部分合计不能作为完整总价或方案价差', () => {
  const house = model(), config = createBudgetConfig();
  const empty = calculateBudget(house, config.quotes[0]);
  assert.equal(empty.pendingCount, 5);
  assert.equal(empty.total, null);
  assert.equal(empty.partialTotal, 0);
  assert.ok(empty.rows.every(row => row.amount === null));
  config.quotes[0].rooms.a = { floorUnitPrice: 10, floorWastePercent: 0, wallUnitPrice: 0 };
  const partial = calculateBudget(house, config.quotes[0]);
  assert.equal(partial.partialTotal, 160);
  assert.equal(partial.pendingCount, 3);
  assert.equal(partial.total, null);
  assert.equal(partial.rows.find(row => row.id === 'wall:a').amount, 0);
  const both = createBudgetQuote(config, 'quote-a');
  assert.equal(compareBudgets(house, both).difference, null);
  const csv = exportBudgetCsv(house, config);
  assert.ok(csv.includes('尚有 3 项待报价，非完整总价'));
});

test('地板损耗、财务逐行四舍五入至分与整数分合计', () => {
  const house = model(), config = createBudgetConfig();
  for (const item of house.rooms) config.quotes[0].rooms[item.id] = { floorUnitPrice: 12.34, floorWastePercent: 10, wallUnitPrice: 1.01 };
  config.quotes[0].furniture['chair-a'] = 23.45;
  const budget = calculateBudget(house, config.quotes[0]);
  assert.equal(budget.rows[0].quantity, 17.6);
  assert.equal(budget.rows[0].amount, 217.18);
  assert.equal(budget.total, 547.70);
  assert.equal(calculateLineAmount(.1, .05), .01, 'half-cent rounds up without binary decimal drift');
  assert.equal(calculateLineAmount(.29, 1), .29);
  assert.equal(calculateLineAmount(0, null), null);
  assert.throws(() => calculateLineAmount(Infinity, 1));
  assert.throws(() => calculateLineAmount(1, NaN));
  assert.throws(() => calculateLineAmount(1e14, 1e7));
});

test('复制的两套方案独立持久化；几何与材质改变自动重算当前方案', () => {
  const house = model(), config = createBudgetConfig();
  config.quotes[0].rooms.a = { floorUnitPrice: 10, floorWastePercent: 5, wallUnitPrice: null };
  const next = createBudgetQuote(config, config.selectedQuoteId);
  next.quotes[1].rooms.a.floorUnitPrice = 20;
  assert.equal(config.quotes.length, 1);
  assert.equal(config.quotes[0].rooms.a.floorUnitPrice, 10);
  assert.equal(next.quotes[0].rooms.a.floorUnitPrice, 10);
  assert.equal(next.selectedQuoteId, next.quotes[1].id);
  const saved = setBudgetConfig(house, next);
  next.quotes[1].rooms.a.floorUnitPrice = 99;
  assert.equal(saved.meta.materialBudget.quotes[1].rooms.a.floorUnitPrice, 20);
  const geometryChange = structuredClone(saved);
  geometryChange.rooms[0].polygon = [[0, 0], [2, 0], [2, 4], [0, 4]];
  geometryChange.rooms[0].material = 'tile';
  const changed = calculateBudget(geometryChange, saved.meta.materialBudget.quotes[1]);
  assert.equal(changed.rows[0].netQuantity, 8);
  assert.equal(changed.rows[0].amount, 168);
  assert.equal(changed.rows[0].label, '浅色瓷砖');
  assert.throws(() => createBudgetQuote(next));
});

test('已删构件报价明示且排除，仅清理所选方案，新增房间默认待报价', () => {
  const house = model(), config = createBudgetConfig();
  config.quotes[0].rooms.removed = { floorUnitPrice: 999, floorWastePercent: 10, wallUnitPrice: 999 };
  config.quotes[0].furniture.deletedChair = 999;
  const two = createBudgetQuote(config, 'quote-a');
  const budget = calculateBudget(house, two.quotes[0]);
  assert.deepEqual(budget.stale, { roomIds: ['removed'], furnitureIds: ['deletedChair'] });
  assert.equal(budget.partialTotal, 0);
  const cleaned = cleanStaleBudgetReferences(house, two, 'quote-a');
  assert.deepEqual(cleaned.quotes[0].rooms, {});
  assert.ok(Object.hasOwn(cleaned.quotes[1].rooms, 'removed'));
  assert.deepEqual(getRoomQuote(cleaned.quotes[0], 'newRoom'), { floorUnitPrice: null, floorWastePercent: 0, wallUnitPrice: null });
});

test('空/非法输入与恶意配置不伪装0元，不默存NaN、负数、超范围或多余字段', () => {
  assert.deepEqual(parseBudgetInput(''), { value: null, error: null });
  assert.deepEqual(parseBudgetInput('0012.30'), { value: 12.3, error: null });
  for (const input of ['NaN', 'Infinity', '-1', '1e3', '1,000', '1.234', '=1+1', '10000000.01']) assert.ok(parseBudgetInput(input).error);
  assert.ok(parseBudgetInput('100.01', 'waste').error);
  for (const value of [undefined, NaN, Infinity, -1, 1.234, .000000001, 10000000.01]) {
    const config = createBudgetConfig();
    config.quotes[0].rooms.a = { floorUnitPrice: value, floorWastePercent: 0, wallUnitPrice: null };
    assert.throws(() => validateBudgetConfig(config, model()));
  }
  const config = createBudgetConfig();
  config.selectedQuoteId = 'absent';
  assert.throws(() => validateBudgetConfig(config));
  config.selectedQuoteId = 'quote-a'; config.quotes[0].extra = true;
  assert.throws(() => validateBudgetConfig(config));
});

test('CSV单元格拦截公式与控制空白，保留逗号/引号/换行且空单价保持待报价', () => {
  for (const input of ['=1+1', '+SUM(A1)', '-1+2', '@SUM(A1)', '  =cmd()', '\t+cmd()', '\r=cmd()', '\n=cmd()']) {
    assert.ok(csvSafeCell(input).startsWith('"\''), input);
  }
  assert.equal(csvSafeCell('房间,"名称"\n备注'), '"房间,""名称""\n备注"');
  const house = model(), config = createBudgetConfig();
  house.rooms[0].name = '=HYPERLINK("evil")';
  config.quotes[0].name = '  +SUM(A1)';
  const csv = exportBudgetCsv(house, config);
  assert.ok(csv.includes('"\'  +SUM(A1)"'));
  assert.ok(csv.includes('"\'=HYPERLINK(""evil"")"'));
  assert.ok(csv.includes('"","","待报价"'));
});

test('一段墙的实测与旧快照不能宣称全房实测；全墙确认仍标模型估算', () => {
  const house = model();
  const records = house.walls.map(wall => ({ id: `m-${wall.id}`, wallId: wall.id, confirmed: true,
    date: '2026-10-06', source: '人工现场测量', note: '',
    lengthMeters: Math.hypot(wall.end[0] - wall.start[0], wall.end[1] - wall.start[1]), wallSnapshot: { start: [...wall.start], end: [...wall.end] } }));
  house.meta.measurements = [records[0]];
  assert.ok(getBudgetMeasurementLabel(house).includes('未全部'));
  house.meta.measurements = records;
  assert.ok(getBudgetMeasurementLabel(house).includes('面积与墙高仍为模型估算'));
  house.walls[0].end[0] += .5;
  assert.ok(getBudgetMeasurementLabel(house).includes('未全部'));
});

test('最新的待确认记录覆盖较旧确认记录，坏实测结构保持待核对', () => {
  const house = model();
  house.meta.measurements = house.walls.map(wall => ({ id: `m-${wall.id}`, wallId: wall.id, confirmed: true,
    date: '2026-10-05', source: '人工现场测量', note: '',
    lengthMeters: Math.hypot(wall.end[0] - wall.start[0], wall.end[1] - wall.start[1]), wallSnapshot: { start: [...wall.start], end: [...wall.end] } }));
  house.meta.measurements.push({ ...house.meta.measurements[0], id: 'latest', date: '2026-10-06', confirmed: false });
  assert.ok(getBudgetMeasurementLabel(house).includes('未全部'));
  house.meta.measurements = 'bad';
  assert.ok(getBudgetMeasurementLabel(house).includes('实测记录待核对'));
});
