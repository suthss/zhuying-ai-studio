"""Expand AI room cells into one consistent, exact, metre-based wall graph.

The provider chooses the grid, room allocation and evidenced openings. This
adapter constructs shared boundaries once, rather than asking the provider to
independently draw overlapping room polygons and disconnected wall segments.
No image inference, heuristic hole filling or invented opening happens here.
"""
from collections import defaultdict
import math
import re


USES = {"living", "bedroom", "study", "kitchen", "bathroom", "entry", "dining", "empty"}
MAX_AXIS = 33
MAX_ROOMS = 40
MAX_WALLS = 160
MAX_OPENINGS = 120
EPSILON = 1e-7


def _number(value, low, high, label):
    try:
        valid = type(value) in (int, float) and math.isfinite(value) and low <= value <= high
    except OverflowError:
        valid = False
    if not valid:
        raise ValueError(f"AI 网格的{label}须为 {low:g} 至 {high:g} 范围内的有限数值。")
    return round(float(value), 4)


def _identifier(value, label):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", value):
        raise ValueError(f"AI 网格的{label}须使用 1 至 80 位字母、数字、下划线或连字符。")
    return value


def _axis(raw, extent, label):
    if not isinstance(raw, list) or not 2 <= len(raw) <= MAX_AXIS:
        raise ValueError(f"AI 网格{label}轴须包含 2 至 {MAX_AXIS} 个坐标。")
    values = [_number(value, 0, extent, f"{label}轴坐标") for value in raw]
    if abs(values[0]) > EPSILON or abs(values[-1] - extent) > EPSILON:
        raise ValueError(f"AI 网格{label}轴必须从 0 开始，在声明尺寸 {extent:g} 米处结束。")
    if any(second - first < .15 - EPSILON for first, second in zip(values, values[1:])):
        raise ValueError(f"AI 网格{label}轴须严格升序，相邻结构坐标至少间隔 0.15 米。")
    return values


def _connected(cells):
    pending = [next(iter(cells))]
    visited = set()
    while pending:
        cell = pending.pop()
        if cell in visited:
            continue
        visited.add(cell)
        column, row = cell
        pending.extend(neighbor for neighbor in ((column - 1, row), (column + 1, row),
                                                (column, row - 1), (column, row + 1))
                       if neighbor in cells and neighbor not in visited)
    return len(visited) == len(cells)


def _ring(cells, xs, ys, label):
    """Trace integer grid edges; map corners to original coordinates only once."""
    edges = set()
    for column, row in cells:
        corners = ((column, row), (column + 1, row), (column + 1, row + 1), (column, row + 1))
        for start, end in zip(corners, corners[1:] + corners[:1]):
            reverse = (end, start)
            if reverse in edges:
                edges.remove(reverse)
            else:
                edges.add((start, end))
    outgoing, incoming = defaultdict(list), defaultdict(list)
    for start, end in edges:
        outgoing[start].append(end)
        incoming[end].append(start)
    if any(len(outgoing[point]) != 1 or len(incoming[point]) != 1 for point in set(outgoing) | set(incoming)):
        raise ValueError(f"AI 房间 {label} 单元在角点自触；请用四邻连续单元修正轮廓。")
    start = min(outgoing)
    ring, point = [], start
    while not ring or point != start:
        if point in ring or len(ring) > len(edges):
            raise ValueError(f"AI 房间 {label} 单元无法构成简单闭合轮廓。")
        ring.append(point)
        point = outgoing[point][0]
    if len(ring) != len(edges):
        raise ValueError(f"AI 房间 {label} 单元包含孔洞；请调整分区，不要用环形单元包围留白。")
    # Remove only vertices lying on a straight line. Concave corners are kept.
    corners = [point for index, point in enumerate(ring)
               if not (ring[index - 1][0] == point[0] == ring[(index + 1) % len(ring)][0]
                       or ring[index - 1][1] == point[1] == ring[(index + 1) % len(ring)][1])]
    if len(corners) > 60:
        raise ValueError(f"AI 房间 {label} 轮廓转角过多；请简化至 60 个转角以内。")
    return [[xs[column], ys[row]] for column, row in corners]


def _walls(occupied, room_groups, xs, ys, height):
    segments = set()
    for (column, row), room_id in occupied.items():
        neighbors = (((column, row - 1), (column, row), (column + 1, row)),
                     ((column + 1, row), (column + 1, row), (column + 1, row + 1)),
                     ((column, row + 1), (column, row + 1), (column + 1, row + 1)),
                     ((column - 1, row), (column, row), (column, row + 1)))
        for neighbor, first, second in neighbors:
            other_room = occupied.get(neighbor)
            if other_room is not None and room_groups[other_room] == room_groups[room_id]:
                continue
            start, end = sorted((first, second))
            segments.add((start, end, other_room is None))
    # A single global merge creates continuous walls across grid subdivisions.
    lines = defaultdict(list)
    for start, end, exterior in segments:
        horizontal = start[1] == end[1]
        fixed = start[1] if horizontal else start[0]
        low, high = (start[0], end[0]) if horizontal else (start[1], end[1])
        lines[(horizontal, fixed, exterior)].append((low, high))
    merged = []
    for (horizontal, fixed, exterior), intervals in lines.items():
        intervals.sort()
        low, high = intervals[0]
        for next_low, next_high in intervals[1:]:
            if next_low <= high:
                high = max(high, next_high)
            else:
                merged.append((horizontal, fixed, low, high, exterior))
                low, high = next_low, next_high
        merged.append((horizontal, fixed, low, high, exterior))
    merged.sort(key=lambda item: (not item[0], item[1], item[2], item[3], item[4]))
    if len(merged) > MAX_WALLS:
        raise ValueError("AI 网格生成的墙体超过 160 段；请简化细碎分区。")
    walls = []
    for index, (horizontal, fixed, low, high, exterior) in enumerate(merged, 1):
        start = [xs[low], ys[fixed]] if horizontal else [xs[fixed], ys[low]]
        end = [xs[high], ys[fixed]] if horizontal else [xs[fixed], ys[high]]
        walls.append({"id": f"grid-wall-{index:03d}", "start": start, "end": end,
                      "thickness": .22 if exterior else .18, "height": height})
    return walls


def _opening_wall_hint(center, orientation, opening_width, walls):
    """Explain feasible centers to the repair prompt without moving an opening."""
    along = 0 if orientation == "horizontal" else 1
    across = 1 - along
    neighbors = []
    for wall in walls:
        start, end = wall["start"], wall["end"]
        if abs(start[across] - end[across]) > EPSILON:
            continue
        perpendicular = abs(center[across] - start[across])
        overflow = max(start[along] - center[along], center[along] - end[along], 0.)
        neighbors.append((math.hypot(perpendicular, overflow), wall["id"], wall))
    neighbors.sort(key=lambda item: (item[0], item[1]))
    if not neighbors:
        return " 当前模型没有此方向的实体墙，请依据户型图核对开口方向。"
    axis, fixed_axis = ("x", "y") if along == 0 else ("y", "x")
    hints = []
    for _, identifier, wall in neighbors[:3]:
        start, end = wall["start"], wall["end"]
        low, high = start[along] + opening_width / 2, end[along] - opening_width / 2
        endpoints = (f"start=[{start[0]:g},{start[1]:g}] end=[{end[0]:g},{end[1]:g}]")
        if low <= high + EPSILON:
            feasible = f"可用中心 {axis} 范围=[{low:g},{high:g}]，{fixed_axis}={start[across]:g}"
        else:
            feasible = f"墙长不足 {opening_width:g} 米，没有可用中心范围"
        hints.append(f"{identifier}: {endpoints}，{feasible}")
    return " 最近的同方向实体墙（至多 3 条）：" + "；".join(hints) + "。请修改开口中心使其完整落在实际承载墙上，不可越过墙端。"


def _openings(raw, walls, width, depth, height):
    if not isinstance(raw, list) or len(raw) > MAX_OPENINGS:
        raise ValueError("AI 网格门窗须为数组且不超过 120 个。")
    openings, identifiers = [], set()
    for item in raw:
        if not isinstance(item, dict):
            raise ValueError("AI 网格门窗格式无效。")
        identifier = _identifier(item.get("id"), "门窗编号")
        if identifier in identifiers:
            raise ValueError(f"AI 门窗编号 {identifier} 重复。")
        identifiers.add(identifier)
        kind, orientation = item.get("type"), item.get("orientation")
        if not isinstance(kind, str) or kind not in {"door", "window"} or not isinstance(orientation, str) or orientation not in {"horizontal", "vertical"}:
            raise ValueError(f"AI 门窗 {identifier} 须提供 door/window 类型及 horizontal/vertical 方向。")
        center = item.get("center")
        if not isinstance(center, list) or len(center) != 2:
            raise ValueError(f"AI 门窗 {identifier} 必须提供米制中心点 center:[x,y]。")
        center = [_number(center[0], 0, width, "门窗中心 x"), _number(center[1], 0, depth, "门窗中心 y")]
        opening_width = _number(item.get("width"), .4, 4, "门窗宽度")
        # A 2D plan supplies horizontal openings, not their vertical sizes.
        # Missing vertical dimensions get editable modelling defaults; explicit
        # invalid AI dimensions remain errors rather than silently being healed.
        default_height = min(2.1 if kind == "door" else 1.2, height)
        opening_height = _number(item["height"] if "height" in item else default_height, .5, height, "门窗高度")
        default_sill = 0. if kind == "door" else min(.85, max(0., height - opening_height))
        sill = _number(item["sill"] if "sill" in item else default_sill, 0, height, "窗台高度")
        if (kind == "door" and sill != 0) or sill + opening_height > height + EPSILON:
            raise ValueError(f"AI 门窗 {identifier} 的窗台或高度越界；门的 sill 必须为 0。")
        along = 0 if orientation == "horizontal" else 1
        across = 1 - along
        matches = []
        for wall in walls:
            if abs(wall["start"][across] - wall["end"][across]) > EPSILON:
                continue
            distance = abs(center[across] - wall["start"][across])
            offset = center[along] - wall["start"][along] - opening_width / 2
            length = wall["end"][along] - wall["start"][along]
            if distance <= .2 + EPSILON and offset >= -EPSILON and offset + opening_width <= length + EPSILON:
                matches.append((distance, wall["id"], max(0., offset)))
        matches.sort()
        if not matches:
            raise ValueError(f"AI 门窗 {identifier} 未对齐同方向实体墙或越过墙端；请修正中心点、方向或宽度。"
                             + _opening_wall_hint(center, orientation, opening_width, walls))
        if len(matches) > 1 and abs(matches[0][0] - matches[1][0]) <= EPSILON:
            raise ValueError(f"AI 门窗 {identifier} 位于两面墙之间，承载墙不明确；请贴近实际墙中心线。")
        _, wall_id, offset = matches[0]
        opening = {"id": identifier, "wallId": wall_id, "type": kind, "offset": round(offset, 4),
                   "width": opening_width, "height": opening_height, "sill": sill}
        if any(other["wallId"] == wall_id and min(offset + opening_width, other["offset"] + other["width"])
               - max(offset, other["offset"]) > EPSILON for other in openings):
            raise ValueError(f"AI 门窗 {identifier} 与同墙门窗重叠；请修正中心点或宽度。")
        openings.append(opening)
    return openings


def _label_cells(grid, source_rooms, xs, ys):
    """A single-owner row-major matrix cannot accidentally overlap room cells."""
    if "labels" not in grid:
        return None
    identifiers = set()
    for room in source_rooms:
        if not isinstance(room, dict):
            raise ValueError("AI 网格房间格式无效。")
        if "cells" in room:
            raise ValueError("AI 网格 labels 和 rooms.cells 不可混用；请仅用 labels 矩阵分配单元。")
        identifier = _identifier(room.get("id"), "房间编号")
        if identifier in identifiers:
            raise ValueError(f"AI 房间编号 {identifier} 重复。")
        identifiers.add(identifier)
    labels = grid["labels"]
    if not isinstance(labels, list) or len(labels) != len(ys) - 1:
        raise ValueError(f"AI 网格 labels 须包含 {len(ys) - 1} 行，每行对应一个 y 轴单元。")
    cells = {identifier: [] for identifier in identifiers}
    for row_index, row in enumerate(labels):
        if not isinstance(row, list) or len(row) != len(xs) - 1:
            raise ValueError(f"AI 网格 labels 第 {row_index + 1} 行须包含 {len(xs) - 1} 列，每列对应一个 x 轴单元。")
        for column_index, label in enumerate(row):
            if label is None:
                continue
            if not isinstance(label, str) or label not in identifiers:
                raise ValueError(f"AI 网格 labels 第 {row_index + 1} 行第 {column_index + 1} 列须为已定义的房间 id 或 null。")
            cells[label].append([column_index, row_index])
    return cells


def expand_scene_grid(raw, width, height):
    """Return normal rooms/walls/openings geometry, or a repairable ValueError."""
    width = _number(width, .15, 100, "建筑宽度")
    height = _number(height, .5, 20, "层高")
    if not isinstance(raw, dict) or raw.get("coordinateSystem") != "metres" or not isinstance(raw.get("grid"), dict):
        raise ValueError("AI 重建须提供 geometry.coordinateSystem=metres 和 geometry.grid 单元分区。")
    depth = _number(raw.get("depth"), .15, 100, "建筑深度")
    grid = raw["grid"]
    xs, ys = _axis(grid.get("x"), width, "x"), _axis(grid.get("y"), depth, "y")
    source_rooms = grid.get("rooms")
    if not isinstance(source_rooms, list) or not 1 <= len(source_rooms) <= MAX_ROOMS:
        raise ValueError("AI 网格须包含 1 至 40 个房间。")
    label_cells = _label_cells(grid, source_rooms, xs, ys)
    rooms, occupied, room_groups, group_cells, group_rooms = [], {}, {}, defaultdict(set), defaultdict(list)
    for source in source_rooms:
        if not isinstance(source, dict):
            raise ValueError("AI 网格房间格式无效。")
        identifier = _identifier(source.get("id"), "房间编号")
        if identifier in room_groups:
            raise ValueError(f"AI 房间编号 {identifier} 重复。")
        name, use = source.get("name"), source.get("use")
        if not isinstance(name, str) or not name.strip() or len(name) > 80 or not isinstance(use, str) or use not in USES:
            raise ValueError(f"AI 房间 {identifier} 的名称或用途无效。")
        shared_group = _identifier(source["wallGroup"], "开放空间组编号") if "wallGroup" in source else None
        group = ("shared", shared_group) if shared_group else ("room", identifier)
        room_groups[identifier] = group
        source_cells = label_cells[identifier] if label_cells is not None else source.get("cells")
        if not isinstance(source_cells, list) or not source_cells or len(source_cells) > 1024:
            raise ValueError(f"AI 房间 {identifier} 须包含 1 至 1024 个单元。")
        cells = set()
        for cell in source_cells:
            if (not isinstance(cell, list) or len(cell) != 2 or any(type(value) is not int for value in cell)
                    or not 0 <= cell[0] < len(xs) - 1 or not 0 <= cell[1] < len(ys) - 1):
                raise ValueError(f"AI 房间 {identifier} 的 cells 须为网格范围内零起始整数 [列,行]。")
            cell = tuple(cell)
            if cell in occupied or cell in cells:
                raise ValueError(f"AI 房间 {identifier} 的单元 {list(cell)} 重复或与其他房间重叠。")
            cells.add(cell)
        if not _connected(cells):
            raise ValueError(f"AI 房间 {identifier} 的单元必须四邻连通；角点相接不算连通。")
        polygon = _ring(cells, xs, ys, identifier)
        rooms.append({"id": identifier, "name": name.strip(), "use": use, "polygon": polygon,
                      "boundaryType": "closed", "wallGroup": shared_group or identifier})
        occupied.update({cell: identifier for cell in cells})
        group_cells[group].update(cells)
        group_rooms[group].append(identifier)
    if not _connected(set(occupied)):
        raise ValueError("AI 建筑单元整体不连通；请保留房间之间的真实连接区域。")
    columns, rows = zip(*occupied)
    if min(columns) != 0 or max(columns) != len(xs) - 2 or min(rows) != 0 or max(rows) != len(ys) - 2:
        raise ValueError("AI 建筑外轮廓未覆盖声明宽度或深度；请调整轴尺寸或边缘单元。")
    for group, cells in group_cells.items():
        if len(group_rooms[group]) > 1 and not _connected(cells):
            raise ValueError(f"AI 开放空间组 {group[1]} 的房间必须彼此四邻连通。")
    for room in rooms:
        if len(group_rooms[room_groups[room["id"]]]) > 1:
            room["boundaryType"] = "open_zone"
    walls = _walls(occupied, room_groups, xs, ys, height)
    openings = _openings(grid.get("openings", []), walls, width, depth, height)
    return {"coordinateSystem": "metres", "depth": depth, "rooms": rooms, "walls": walls, "openings": openings}
