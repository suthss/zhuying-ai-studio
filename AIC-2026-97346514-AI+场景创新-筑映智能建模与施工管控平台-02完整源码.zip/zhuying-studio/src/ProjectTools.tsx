import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Camera, ClipboardCheck, Download, FileText, Ruler, Wallet } from 'lucide-react';
import BrandMark from './BrandMark';
import BudgetPanel from './BudgetPanel';
import LayoutAuditPanel from './LayoutAuditPanel';
import IssuePanel from './IssuePanel';
import { localToday } from './calendar';
import RenovationCase from './RenovationCase';
import { createWeeklyReport, weeklyMarkdown } from './issues.mjs';
import type { HouseModel } from './types';
import './project-tools.css';

export type ToolTab='issues'|'budget'|'audit'|'weekly'|'case';
const TABS=[{id:'issues' as const,label:'整改中心',icon:ClipboardCheck},{id:'budget' as const,label:'材料清单',icon:Wallet},{id:'audit' as const,label:'尺寸与布局',icon:Ruler},{id:'weekly' as const,label:'业主周报',icon:FileText},{id:'case' as const,label:'公开案例',icon:Camera}];
function download(name:string,value:string,type:string) {const url=URL.createObjectURL(new Blob([value],{type}));const link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function WeeklyPanel({model}:{model:HouseModel}) {
  const [end,setEnd]=useState(localToday()),[start,setStart]=useState(()=>{const date=new Date(localToday()+'T00:00:00Z');date.setUTCDate(date.getUTCDate()-6);return date.toISOString().slice(0,10);}),[notice,setNotice]=useState('');
  const computed=useMemo(()=>{try{return{report:createWeeklyReport(model,start,end),error:''};}catch(e){return{report:null,error:e instanceof Error?e.message:'日期无效。'};}},[model,start,end]);
  const report=computed.report;
  const names=Object.fromEntries(model.rooms.map(r=>[r.id,r.name]));
  const markdown=report?weeklyMarkdown(report,names):'';
  return <section className="tools-section" aria-label="业主周报"><div className="tools-section-heading"><div><h2>这一周，现场发生了什么。</h2><p>处理记录、巡检证据和待跟进问题，整理在一处。</p></div>{report&&<div className="tools-actions"><button className="tools-button" onClick={()=>{download(`${model.name}-周报.md`,markdown,'text/markdown;charset=utf-8');setNotice('周报已生成，也可展开预览复制。');}}><Download size={15}/>导出周报</button><button className="tools-button" onClick={()=>download(`${model.name}-周报.json`,JSON.stringify(report,null,2),'application/json')}>导出完整记录</button></div>}</div>
    <div className="tools-field-grid report-dates"><label>开始日期<input type="date" value={start} max={end} onChange={e=>setStart(e.target.value)}/></label><label>结束日期<input type="date" value={end} max={localToday()} onChange={e=>setEnd(e.target.value)}/></label></div>
    {computed.error&&<p className="tools-error" role="alert">{computed.error}</p>}{report&&<>
      {report.demonstration&&<p className="tools-notice">案例演练周报 · 任务、责任人与流转为模拟，公开照片日期另行标注。</p>}
      <div className="issue-summary"><span><strong>{report.activities.length}</strong>本周处理记录</span><span><strong>{report.inspections.length}</strong>已确认巡检</span><span><strong>{report.summary.review}</strong>待复核</span><span><strong>{report.summary.overdue}</strong>逾期未关闭</span></div>
      <div className="weekly-grid"><article><h3>本周处理</h3>{report.activities.length?report.activities.map(event=><div className="weekly-row" key={event.id}><span>{event.date} · {event.actor}</span><strong>{event.title}</strong><p>{event.note||'记录处理进展'}</p>{!!event.photos.length&&<div className="weekly-photos">{event.photos.map(photo=><figure key={photo.id}><img src={photo.image} alt={photo.caption} loading="lazy"/><figcaption>{photo.source==='public_case'?'公开影像':'现场记录'} · {photo.captureDate??'拍摄日期未知'}</figcaption></figure>)}</div>}</div>):<p className="tools-empty">本期没有已记录的处理动作。</p>}</article><article><h3>接下来需要跟进</h3>{report.issues.filter(i=>i.status!=='closed').map(issue=><div className="weekly-row" key={issue.id}><strong>{issue.title}</strong><p>{issue.assignee} · 期限 {issue.dueDate}</p><span>{names[issue.roomId]??'历史房间'}{issue.mode==='demonstration'?' · 演练任务':''}</span></div>)}{!report.issues.some(i=>i.status!=='closed')&&<p className="tools-empty">{report.summary.total?'已记录的问题均已关闭。':'截至期末尚无问题记录。'}</p>}<h3>本期巡检</h3>{report.inspections.map(record=><div className="weekly-row" key={record.id}><strong>{record.roomName} · {record.date}</strong><p>{record.summary}</p><span>{record.photoCount} 张照片</span></div>)}{!report.inspections.length&&<p className="tools-muted">本期没有已确认巡检，不推测未记录的现场进度。</p>}</article></div>
      <details className="tools-preview"><summary>查看／复制周报正文</summary><textarea aria-label="业主周报正文" readOnly value={markdown}/></details><details className="tools-preview"><summary>周报数据说明</summary>{report.limits.map(line=><p key={line}>{line}</p>)}</details>
    </>}{notice&&<p role="status" className="tools-notice">{notice}</p>}
  </section>;
}

export default function ProjectTools({model,onChange,onClose,onLocate,onCreate,onFacade,tab,onTabChange,initialRoomId,persistence}:{model:HouseModel;onChange:(next:HouseModel)=>void;onClose:()=>void;onLocate:(roomId:string,openingId?:string)=>void;onCreate:(next:HouseModel)=>Promise<void>;onFacade:()=>void;tab:ToolTab;onTabChange:(tab:ToolTab)=>void;initialRoomId?:string;persistence:{label:string;error:string|null;busy:boolean;onSave:()=>void}}) {
  const dialog=useRef<HTMLElement>(null),previous=useRef(document.activeElement instanceof HTMLElement?document.activeElement:null),close=useRef(onClose);close.current=onClose;
  useEffect(()=>{dialog.current?.focus({preventScroll:true});const key=(event:KeyboardEvent)=>{if(event.key==='Escape'){event.preventDefault();close.current();return;}if(event.key!=='Tab')return;const controls=Array.from(dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input:not(:disabled):not([type=file]),textarea:not(:disabled),select:not(:disabled),summary,[tabindex="0"]')??[]).filter(el=>el.getClientRects().length);const first=controls[0],last=controls.at(-1);if(!first||!last)return;if(event.shiftKey&&(document.activeElement===first||document.activeElement===dialog.current)){event.preventDefault();last.focus();}else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===dialog.current)){event.preventDefault();first.focus();}};document.addEventListener('keydown',key);return()=>{document.removeEventListener('keydown',key);queueMicrotask(()=>{if(previous.current?.isConnected&&!previous.current.closest('[inert]'))previous.current.focus({preventScroll:true});});};},[]);
  const demo=model.source==='demo'||model.meta?.demoData===true;
  return <section className="project-tools" role="dialog" aria-modal="true" aria-labelledby="project-tools-title" tabIndex={-1} ref={dialog}>
    <header className="tools-header"><div className="tools-brand"><BrandMark size={30}/><span id="project-tools-title">筑映 · 项目管理</span></div><span className="tools-project-name">{model.name}{demo&&<span className="tools-tag">演示项目</span>}</span><span className="tools-save-state" role="status">{persistence.label}</span><button className="tools-button" disabled={persistence.busy} onClick={persistence.onSave}>保存项目</button><button className="tools-button" onClick={onClose}><ArrowLeft size={16}/>返回模型</button></header>
    <nav className="tools-tabs" aria-label="项目管理功能">{TABS.map(item=><button key={item.id} aria-current={tab===item.id?'page':undefined} className={tab===item.id?'selected':''} onClick={()=>onTabChange(item.id)}><item.icon size={18}/>{item.label}</button>)}</nav>
    <main className="tools-content" key={`${model.id}/${tab}`}>{persistence.error&&<p className="tools-error" role="alert">{persistence.error}。修改仍保留在当前草稿，请重试保存或返回模型导出备份。</p>}
      {!!model.meta?.publicCase&&<div className="tools-case-banner"><span>公开影像案例</span><p>真实照片与日期 · 模拟任务与责任人 · 房间几何仅示意</p><button className="tools-text-button" onClick={()=>onTabChange('case')}>查看来源<ArrowRight size={14}/></button></div>}
      {tab==='issues'&&<IssuePanel model={model} onChange={onChange} onLocate={onLocate} initialRoomId={initialRoomId}/>}
      {tab==='budget'&&<BudgetPanel model={model} onChange={onChange}/>}
      {tab==='audit'&&<LayoutAuditPanel model={model} onChange={onChange} onLocate={onLocate}/>}
      {tab==='weekly'&&<WeeklyPanel model={model}/>}
      {tab==='case'&&<RenovationCase onCreate={onCreate} onFacade={onFacade}/>}
    </main>
  </section>;
}
