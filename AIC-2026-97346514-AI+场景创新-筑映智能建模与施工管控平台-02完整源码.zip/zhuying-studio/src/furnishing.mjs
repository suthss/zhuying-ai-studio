import { doorLeafPose, getOpeningErrors, getRoomOpenings, resolveOpeningDesign } from './openings.mjs';

const EPS = 1e-6;
const USES = new Set(['living','bedroom','study','kitchen','bathroom','entry','dining','empty']);
const NEEDS = new Set(['work','storage','dining','children','pet','senior','accessibility','relax']);
const STYLES = new Set(['warm','minimal','natural','industrial']);
const USE_NAMES = { living:'客厅',bedroom:'卧室',study:'书房',kitchen:'厨房',bathroom:'卫生间',entry:'玄关',dining:'餐厅',empty:'空房间' };
const CATALOG = {
  sofa: { size:[2.3,.82,.88],label:'沙发' }, coffee_table:{size:[1.05,.42,.58],label:'茶几'},
  // The reserved height includes a television above the low console.
  tv_console:{size:[1.6,1.35,.38],label:'电视柜'},bed_double:{size:[1.55,.72,2],label:'双人床'},
  bed_single:{size:[.95,.68,1.9],label:'单人床'},wardrobe:{size:[1.5,2.15,.58],label:'衣柜'},
  desk:{size:[1.25,.76,.6],label:'书桌'},chair:{size:[.5,.83,.5],label:'椅子'},
  dining_table:{size:[1.35,.75,.8],label:'餐桌'},kitchen_counter:{size:[1.8,.9,.58],label:'厨房操作台'},
  sink_cabinet:{size:[.9,.88,.58],label:'水槽柜'},toilet:{size:[.42,.78,.7],label:'马桶'},
  shoe_cabinet:{size:[.95,.9,.35],label:'鞋柜'},
};
const finite = value => typeof value === 'number' && Number.isFinite(value);
const point = value => Array.isArray(value) && value.length === 2 && value.every(v=>finite(v)&&v>=0&&v<=100);
const id = value => typeof value === 'string' && value.trim().length > 0 && value.length <= 160;
const normalizeAngle = value => ((value + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
const cross = (a,b,c) => (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
const area = polygon => Math.abs(polygon.reduce((sum,a,index)=>{const b=polygon[(index+1)%polygon.length];return sum+a[0]*b[1]-b[0]*a[1];},0))/2;
function contains(polygon,p) {
  let inside=false;
  for(let i=0,j=polygon.length-1;i<polygon.length;j=i++) {
    const a=polygon[i],b=polygon[j];
    if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside;
  }
  return inside;
}
function distanceToSegment(p,a,b) {
  const dx=b[0]-a[0],dz=b[1]-a[1],squared=dx*dx+dz*dz;
  const t=squared>EPS?Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dz)/squared)):0;
  return Math.hypot(p[0]-a[0]-dx*t,p[1]-a[1]-dz*t);
}
function boundaryDistance(polygon,p) {return Math.min(...polygon.map((a,index)=>distanceToSegment(p,a,polygon[(index+1)%polygon.length])));}
function onSegment(a,b,p) {return Math.abs(cross(a,b,p))<EPS&&p[0]>=Math.min(a[0],b[0])-EPS&&p[0]<=Math.max(a[0],b[0])+EPS&&p[1]>=Math.min(a[1],b[1])-EPS&&p[1]<=Math.max(a[1],b[1])+EPS;}
function intersects(a,b,c,d,touch=true) {
  const abC=cross(a,b,c),abD=cross(a,b,d),cdA=cross(c,d,a),cdB=cross(c,d,b);
  return (abC*abD < -EPS && cdA*cdB < -EPS) || (touch&&(onSegment(a,b,c)||onSegment(a,b,d)||onSegment(c,d,a)||onSegment(c,d,b)));
}
function overlaps(a,b) {
  for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++)if(intersects(a[i],a[(i+1)%a.length],b[j],b[(j+1)%b.length]))return true;
  return contains(a,b[0])||contains(b,a[0]);
}
function rectangle(position,width,depth,rotation=0,padding=0) {
  const cosine=Math.cos(rotation),sine=Math.sin(rotation);
  return [[-1,-1],[1,-1],[1,1],[-1,1]].map(([sx,sz])=>{
    const x=sx*(width/2+padding),z=sz*(depth/2+padding);
    return [position[0]+cosine*x+sine*z,position[1]-sine*x+cosine*z];
  });
}
function footprint(item,padding=0) {return rectangle(item.position,item.size[0],item.size[2],item.rotation,padding);}
function fitsPolygon(polygon,shape,margin=.06) {
  if(!shape.every(p=>contains(polygon,p)&&boundaryDistance(polygon,p)>=margin-EPS))return false;
  for(let i=0;i<shape.length;i++) {
    const a=shape[i],b=shape[(i+1)%shape.length];
    if(!contains(polygon,[(a[0]+b[0])/2,(a[1]+b[1])/2]))return false;
    for(let j=0;j<polygon.length;j++)if(intersects(a,b,polygon[j],polygon[(j+1)%polygon.length],false))return false;
  }
  return true;
}

export function getDefaultFurniture(use,needs=[]) {
  if(!USES.has(use)||!Array.isArray(needs)||needs.some(need=>!NEEDS.has(need)))throw new Error('房间用途或需求类型无效。');
  const defaults={living:['sofa','coffee_table','tv_console'],bedroom:['bed_double','wardrobe'],study:['desk','chair'],
    kitchen:['kitchen_counter','sink_cabinet'],bathroom:['toilet','sink_cabinet'],entry:['shoe_cabinet'],dining:['dining_table','chair'],empty:[]};
  const result=[...defaults[use]];
  if(needs.includes('work')&&['living','bedroom'].includes(use))result.push('desk','chair');
  if(needs.includes('storage')&&['living','study'].includes(use))result.push('wardrobe');
  if(needs.includes('dining')&&use==='living')result.push('dining_table','chair');
  if(needs.includes('children')&&use==='bedroom')result.push('bed_single');
  return [...new Set(result)];
}

export function createDesignBrief(model) {
  const ordered=[...model.rooms].sort((a,b)=>b.area-a.area), largest=ordered[0]?.id;
  const rooms=model.rooms.map(room=>{
    const name=String(room.name).toLowerCase();
    const use=/卧|寝|bed/.test(name)?'bedroom':/书|study|office/.test(name)?'study':/客|living/.test(name)?'living':/厨|kitchen/.test(name)?'kitchen':/卫|浴|bath|toilet/.test(name)?'bathroom':/玄|门厅|entry|hall/.test(name)?'entry':/餐|dining/.test(name)?'dining':room.id===largest&&room.area>=10?'living':room.area>=9?'bedroom':room.area>=5?'study':'empty';
    return {roomId:room.id,use,furnish:use!=='empty'};
  });
  return {style:'warm',residents:2,needs:[],rooms,notes:''};
}

export function validateDesignBrief(model,value) {
  const fail=message=>{throw new Error(`装修问答无效：${message}`);};
  if(!value||typeof value!=='object'||Array.isArray(value))fail('请提供完整问答对象。');
  if(!STYLES.has(value.style))fail('风格须为温暖、极简、自然或工业。');
  if(!Number.isInteger(value.residents)||value.residents<1||value.residents>12)fail('居住人数须为 1–12 的整数。');
  if(!Array.isArray(value.needs)||value.needs.length>8||value.needs.some(need=>!NEEDS.has(need)))fail('需求须来自支持的八类选项。');
  if(typeof value.notes!=='string'||value.notes.length>2000)fail('补充说明须为不超过 2000 字的文字。');
  if(!Array.isArray(model.rooms)||model.rooms.length>100||!Array.isArray(value.rooms)||value.rooms.length!==model.rooms.length)fail('每个房间都需要确认用途。');
  const expected=new Set(model.rooms.map(room=>room.id)),seen=new Set();
  const rooms=value.rooms.map(room=>{
    if(!room||typeof room!=='object'||!expected.has(room.roomId)||seen.has(room.roomId)||!USES.has(room.use)||typeof room.furnish!=='boolean')fail('房间编号、用途或布置选项无效，不能重复房间。');
    seen.add(room.roomId);
    if(room.items!==undefined&&(!Array.isArray(room.items)||room.items.length>30||room.items.some(kind=>!Object.hasOwn(CATALOG,kind))))fail('家具清单须为支持的家具种类，单房间最多 30 件。');
    return {roomId:room.roomId,use:room.use,furnish:room.furnish,...(room.items===undefined?{}:{items:[...room.items]})};
  });
  return {style:value.style,residents:value.residents,needs:[...new Set(value.needs)],rooms,notes:value.notes};
}

function roomContext(model,room,passage=.65) {
  const polygon=room.polygon;
  const minX=Math.min(...polygon.map(p=>p[0])),maxX=Math.max(...polygon.map(p=>p[0]));
  const minZ=Math.min(...polygon.map(p=>p[1])),maxZ=Math.max(...polygon.map(p=>p[1]));
  const walls=model.walls.filter(w=>point(w.start)&&point(w.end)&&finite(w.thickness)&&w.thickness>0&&Math.max(w.start[0],w.end[0])+w.thickness>=minX&&Math.min(w.start[0],w.end[0])-w.thickness<=maxX&&Math.max(w.start[1],w.end[1])+w.thickness>=minZ&&Math.min(w.start[1],w.end[1])-w.thickness<=maxZ).map(w=>{
    const length=Math.hypot(w.end[0]-w.start[0],w.end[1]-w.start[1]);
    return rectangle([(w.start[0]+w.end[0])/2,(w.start[1]+w.end[1])/2],length,w.thickness,-Math.atan2(w.end[1]-w.start[1],w.end[0]-w.start[0]),.025);
  });
  const zones=[],entries=[],windows=[];
  for(const opening of getRoomOpenings(model,room.id)) {
    const wall=model.walls.find(w=>w.id===opening.wallId);
    const length=Math.hypot(wall.end[0]-wall.start[0],wall.end[1]-wall.start[1]);
    const ux=(wall.end[0]-wall.start[0])/length,uz=(wall.end[1]-wall.start[1])/length;
    const normal=[-uz,ux], middle=opening.offset+opening.width/2;
    const midpoint=[wall.start[0]+ux*middle,wall.start[1]+uz*middle];
    const positive=contains(polygon,[midpoint[0]+normal[0]*.2,midpoint[1]+normal[1]*.2]);
    const sign=positive?1:-1, approachDepth=Math.max(.8,passage+.2);
    if(opening.type==='window') {
      const inward=[normal[0]*sign,normal[1]*sign];
      windows.push({midpoint,inward,width:opening.width,sill:opening.sill??0,
        rotation:normalizeAngle(-Math.atan2(uz,ux)+(sign===-1?Math.PI:0)),
        zone:rectangle([midpoint[0]+inward[0]*.22,midpoint[1]+inward[1]*.22],opening.width+.28,.44,-Math.atan2(uz,ux))});
      continue;
    }
    const approachCenter=[midpoint[0]+normal[0]*sign*(approachDepth/2+.035),midpoint[1]+normal[1]*sign*(approachDepth/2+.035)];
    zones.push(rectangle(approachCenter,opening.width+.25,approachDepth,-Math.atan2(uz,ux)));
    entries.push([midpoint[0]+normal[0]*sign*(approachDepth+.05),midpoint[1]+normal[1]*sign*(approachDepth+.05)]);
    const design=resolveOpeningDesign(opening), sweep=Math.max(90,design.openAngle);
    const pose=doorLeafPose(opening), pivot=[wall.start[0]+ux*pose.pivotX,wall.start[1]+uz*pose.pivotX];
    const fan=[pivot];
    for(let i=0;i<=20;i++) {
      const leaf=doorLeafPose({...opening,design:{...design,openAngle:sweep*i/20}});
      const localX=Math.cos(leaf.rotation)*(leaf.leafWidth+.08),localZ=-Math.sin(leaf.rotation)*(leaf.leafWidth+.08);
      fan.push([pivot[0]+ux*localX+normal[0]*localZ,pivot[1]+uz*localX+normal[1]*localZ]);
    }
    zones.push(fan);
  }
  return {room,polygon,walls,zones,entries,windows,passage,area:area(polygon),
    minX,maxX,minZ,maxZ};
}

function schemaErrors(model,item) {
  if(!item||typeof item!=='object'||Array.isArray(item))return ['家具数据须为对象。'];
  const errors=[];
  if(!id(item.id)||!id(item.roomId))errors.push('家具及房间编号无效。');
  if(!Object.hasOwn(CATALOG,item.kind))errors.push('家具类型不受支持。');
  if(!point(item.position))errors.push('家具位置须为 0–100 米之间的有限坐标。');
  if(!Array.isArray(item.size)||item.size.length!==3||!item.size.every(finite)||item.size[0]<.1||item.size[0]>6||item.size[2]<.1||item.size[2]>6||item.size[1]<.1||item.size[1]>Math.min(4,model.height-.03))errors.push('家具宽高深须为有限正数，宽深不超过 6 米，高度须低于层高。');
  if(!finite(item.rotation)||Math.abs(item.rotation)>Math.PI*2+EPS)errors.push('家具旋转须为 ±2π 范围内的有限弧度数。');
  if(typeof item.color!=='string'||!/^#[0-9a-f]{6}$/i.test(item.color))errors.push('家具颜色须为六位十六进制颜色。');
  if(!model.rooms.some(room=>room.id===item.roomId))errors.push('家具关联的房间不存在。');
  return errors;
}
function geometryErrors(context,item,others,protectWindows=false) {
  const errors=[],shape=footprint(item);
  if(!fitsPolygon(context.polygon,shape)||context.walls.some(wall=>overlaps(shape,wall)))errors.push('家具超出房间或侵入墙体，请调整位置、尺寸或方向。');
  if(context.zones.some(zone=>overlaps(shape,zone)))errors.push('家具侵入门口通路或门扇开启扫掠区。');
  // Improved daylight rules apply to newly generated candidates. Existing
  // saved arrangements keep their geometric import contract and remain editable.
  if(protectWindows&&context.windows.some(window=>item.size[1]>window.sill+.08&&overlaps(shape,window.zone)))errors.push('高家具遮挡窗前采光或开启空间，请远离窗洞。');
  for(const other of others)if(other.id!==item.id&&point(other.position)&&Array.isArray(other.size)&&other.size.length===3&&other.size.every(finite)&&finite(other.rotation)&&overlaps(shape,footprint(other,.025)))errors.push(`家具与 ${other.id} 重叠或间距不足。`);
  return errors;
}
export function getFurnitureErrors(model,item) {
  const errors=schemaErrors(model,item);
  if(errors.length)return errors;
  const room=model.rooms.find(r=>r.id===item.roomId);
  if(!Array.isArray(room.polygon)||room.polygon.length<3||!room.polygon.every(point))return ['家具关联的房间轮廓无效。'];
  return geometryErrors(roomContext(model,room),item,Array.isArray(model.furniture)?model.furniture:[]);
}

/** Editable review drafts retain finite schema while geometry is reported separately. */
export function getFurnitureSchemaErrors(model,item) { return schemaErrors(model,item); }

/** A thin visual rug; it never adds an unrequested item to the furniture list. */
export function getRoomRug(model,roomId) {
  const room=model.rooms.find(room=>room.id===roomId),items=(model.furniture??[]).filter(item=>item.roomId===roomId);
  if(!room||!Array.isArray(room.polygon)||room.polygon.length<3||!room.polygon.every(point))return null;
  const sofa=items.find(item=>item.kind==='sofa'),coffee=items.find(item=>item.kind==='coffee_table');
  const bed=items.find(item=>item.kind==='bed_double'||item.kind==='bed_single');
  const anchor=sofa&&coffee?coffee:bed;
  if(!anchor||schemaErrors(model,anchor).length)return null;
  const context=roomContext(model,room),rotation=sofa&&coffee?sofa.rotation:anchor.rotation;
  const width=sofa&&coffee?Math.max(coffee.size[0]+.45,sofa.size[0]+.28):anchor.size[0]+.48;
  const depth=sofa&&coffee?coffee.size[2]+1.1:anchor.size[2]+.38;
  for(const scale of [1,.9,.8,.7]) {
    const size=[width*scale,.012,depth*scale],shape=rectangle(anchor.position,size[0],size[2],rotation);
    if(fitsPolygon(context.polygon,shape,.09)&&!context.walls.some(wall=>overlaps(shape,wall))&&!context.zones.some(zone=>overlaps(shape,zone)))return {position:[...anchor.position],size,rotation,color: '#dcd8c9'};
  }
  return null;
}

function distanceToFurniture(p,item) {
  const dx=p[0]-item.position[0],dz=p[1]-item.position[1],cos=Math.cos(item.rotation),sin=Math.sin(item.rotation);
  const localX=dx*cos-dz*sin,localZ=dx*sin+dz*cos;
  return Math.hypot(Math.max(0,Math.abs(localX)-item.size[0]/2),Math.max(0,Math.abs(localZ)-item.size[2]/2));
}
function routeGrid(context) {
  if(context.grid)return context.grid;
  const count=26,stepX=(context.maxX-context.minX)/count,stepZ=(context.maxZ-context.minZ)/count,radius=context.passage/2;
  const cells=Array(count*count).fill(null);
  for(let z=0;z<count;z++)for(let x=0;x<count;x++) {
    const p=[context.minX+(x+.5)*stepX,context.minZ+(z+.5)*stepZ];
    if(contains(context.polygon,p)&&boundaryDistance(context.polygon,p)>radius&& !context.walls.some(wall=>contains(wall,p)||boundaryDistance(wall,p)<radius))cells[z*count+x]=p;
  }
  return context.grid={count,cells,stepX,stepZ};
}
function retainsPassage(context,items,ratio) {
  if(items.reduce((sum,item)=>sum+item.size[0]*item.size[2],0)>context.area*ratio)return false;
  const {count,cells,stepX,stepZ}=routeGrid(context),radius=context.passage/2;
  const free=cells.map(p=>!!p&&items.every(item=>distanceToFurniture(p,item)>=radius));
  const total=free.filter(Boolean).length;
  if(total<4)return false;
  const shapes=items.map(item=>footprint(item,radius));
  const components=new Int32Array(cells.length).fill(-1),sizes=[];
  for(let start=0;start<cells.length;start++)if(free[start]&&components[start]===-1) {
    const component=sizes.length,queue=[start];components[start]=component;let head=0;
    while(head<queue.length) {
      const index=queue[head++],x=index%count,z=Math.floor(index/count);
      for(const [nx,nz] of [[x-1,z],[x+1,z],[x,z-1],[x,z+1]]) {
        if(nx<0||nx>=count||nz<0||nz>=count)continue;
        const next=nz*count+nx;if(!free[next]||components[next]!==-1)continue;
        const a=cells[index],b=cells[next],mid=[(a[0]+b[0])/2,(a[1]+b[1])/2];
        if(!contains(context.polygon,mid)||[...shapes,...context.walls].some(shape=>shape.some((p,i)=>intersects(a,b,p,shape[(i+1)%shape.length]))))continue;
        components[next]=component;queue.push(next);
      }
    }
    sizes.push(queue.length);
  }
  const largest=Math.max(...sizes),main=sizes.indexOf(largest);
  if(largest<total*.65)return false;
  for(const entry of context.entries) {
    let nearest=-1,distance=Infinity;
    cells.forEach((p,index)=>{if(free[index]) {const d=Math.hypot(p[0]-entry[0],p[1]-entry[1]);if(d<distance){distance=d;nearest=index;}}});
    if(nearest<0||distance>Math.max(.8,Math.hypot(stepX,stepZ)*1.4)||components[nearest]!==main)return false;
  }
  return true;
}

const forwardOf = rotation => [Math.sin(rotation),Math.cos(rotation)];
function anchorCoordinates(anchor,position) {
  const dx=position[0]-anchor.position[0],dz=position[1]-anchor.position[1];
  return {side:dx*Math.cos(anchor.rotation)-dz*Math.sin(anchor.rotation),
    front:dx*Math.sin(anchor.rotation)+dz*Math.cos(anchor.rotation)};
}
function backSupport(context,candidate,size) {
  const [width,,depth]=size,forward=forwardOf(candidate.rotation),side=[Math.cos(candidate.rotation),-Math.sin(candidate.rotation)];
  const back=[candidate.position[0]-forward[0]*depth/2,candidate.position[1]-forward[1]*depth/2];
  // Three samples prevent a bed being rewarded for merely pointing a corner at a wall.
  const distances=[-.38,0,.38].map(amount=>boundaryDistance(context.polygon,[back[0]+side[0]*width*amount,back[1]+side[1]*width*amount]));
  return {back,distance:distances.reduce((sum,d)=>sum+d,0)/3,skew:Math.max(...distances)-Math.min(...distances)};
}
function candidates(context,kind,size,placed) {
  const result=[],angles=new Set([0,Math.PI/2]);
  const [width,,depth]=size;
  const edges=context.polygon.map((a,index)=>{const b=context.polygon[(index+1)%context.polygon.length];return {a,b,length:Math.hypot(b[0]-a[0],b[1]-a[1])};}).sort((a,b)=>b.length-a.length).slice(0,20);
  edges.forEach(({a,b,length})=>{
    const dx=b[0]-a[0],dz=b[1]-a[1];
    if(length<.01)return;
    const normal=[-dz/length,dx/length],mid=[(a[0]+b[0])/2,(a[1]+b[1])/2];
    const sign=contains(context.polygon,[mid[0]+normal[0]*.12,mid[1]+normal[1]*.12])?1:-1;
    const rotation=normalizeAngle(-Math.atan2(dz,dx)+(sign===-1?Math.PI:0));if(angles.size<8)angles.add(rotation);
    for(const fraction of [.15,.25,.35,.5,.65,.75,.85])for(const gap of [.18,.28])result.push({position:[a[0]+dx*fraction+normal[0]*sign*(depth/2+gap),a[1]+dz*fraction+normal[1]*sign*(depth/2+gap)],rotation});
  });
  const sofa=placed.find(item=>item.kind==='sofa');
  const anchor=kind==='coffee_table'||kind==='tv_console'?sofa:kind==='chair'?placed.findLast(item=>item.kind==='desk'||item.kind==='dining_table'):null;
  if(anchor&&kind!=='tv_console')for(const sign of kind==='coffee_table'?[1]:[1,-1])for(const distance of [.35,.45,.6,.75]) {
    const forward=forwardOf(anchor.rotation),offset=(anchor.size[2]+depth)/2+distance;
    result.unshift({position:[anchor.position[0]+forward[0]*offset*sign,anchor.position[1]+forward[1]*offset*sign],rotation:normalizeAngle(anchor.rotation+(kind==='chair'&&sign===1?Math.PI:0)),preferred:true});
  }
  if(kind==='tv_console'&&anchor) {
    // Project the sofa's viewing axis onto every opposite boundary, keeping
    // the cabinet's back against that wall and the screen facing the sofa.
    const forward=forwardOf(anchor.rotation);
    for(const {a,b} of edges) {
      const edge=[b[0]-a[0],b[1]-a[1]],denominator=forward[0]*edge[1]-forward[1]*edge[0];
      if(Math.abs(denominator)<EPS)continue;
      const delta=[a[0]-anchor.position[0],a[1]-anchor.position[1]];
      const distance=(delta[0]*edge[1]-delta[1]*edge[0])/denominator;
      const fraction=(delta[0]*forward[1]-delta[1]*forward[0])/denominator;
      if(distance<1.5||fraction<0||fraction>1)continue;
      for(const gap of [.18,.28,.4])result.unshift({position:[anchor.position[0]+forward[0]*(distance-depth/2-gap),anchor.position[1]+forward[1]*(distance-depth/2-gap)],rotation:normalizeAngle(anchor.rotation+Math.PI),preferred:true});
    }
  }
  if(kind==='desk')for(const window of context.windows)for(const gap of [.36,.5,.65]) {
    result.unshift({position:[window.midpoint[0]+window.inward[0]*(depth/2+gap),window.midpoint[1]+window.inward[1]*(depth/2+gap)],rotation:window.rotation,preferred:true});
  }
  for(let x=1;x<=10;x++)for(let z=1;z<=10;z++)for(const rotation of angles)result.push({position:[context.minX+(context.maxX-context.minX)*x/11,context.minZ+(context.maxZ-context.minZ)*z/11],rotation});
  const center=[(context.minX+context.maxX)/2,(context.minZ+context.maxZ)/2];
  const freestanding=['coffee_table','dining_table','chair'].includes(kind);
  result.forEach(candidate=>{
    const middle=Math.hypot(candidate.position[0]-center[0],candidate.position[1]-center[1]);
    const support=backSupport(context,candidate,size);
    candidate.score=freestanding?middle*.65:support.distance*4+support.skew*7+middle*.05;
    if(kind==='bed_double'||kind==='bed_single'||kind==='sofa') {
      candidate.score+=support.distance*3;
      for(const window of context.windows) {
        const delta=[support.back[0]-window.midpoint[0],support.back[1]-window.midpoint[1]];
        const wallDistance=Math.abs(delta[0]*window.inward[0]+delta[1]*window.inward[1]);
        const lateral=Math.abs(delta[0]*window.inward[1]-delta[1]*window.inward[0]);
        if(wallDistance<.65&&lateral<(window.width+width)/2)candidate.score+=9;
      }
    }
    if(anchor) {
      const {side,front}=anchorCoordinates(anchor,candidate.position),facing=forwardOf(candidate.rotation);
      const alignment=facing[0]*Math.sin(anchor.rotation)+facing[1]*Math.cos(anchor.rotation);
      if(kind==='coffee_table')candidate.score=Math.abs(side)*5+Math.abs(front-(anchor.size[2]+depth)/2-.45)*4+(front<0?30:0)+middle*.03;
      if(kind==='tv_console')candidate.score+=Math.abs(side)*9+(front<1.4?25:0)+(alignment+1)*7;
      if(kind==='chair')candidate.score=Math.abs(side)*5+Math.abs(Math.abs(front)-(anchor.size[2]+depth)/2-.4)*4+(front>0?alignment+1:1-alignment)*5+(candidate.preferred?-2:0);
    }
    if(kind==='desk'&&context.windows.length) {
      const nearest=Math.min(...context.windows.map(window=>Math.hypot(candidate.position[0]-window.midpoint[0],candidate.position[1]-window.midpoint[1])));
      candidate.score+=nearest*4;
      if(candidate.preferred)candidate.score-=2;
    }
    if(kind==='dining_table')candidate.score=middle*1.3+Math.max(0,.8-boundaryDistance(context.polygon,candidate.position))*5;
  });
  return result.sort((a,b)=>a.score-b.score);
}

function styleDesign(style,use,room) {
  const palettes={warm:{floorFinish:'oak',wallColor:'#f4f0e8',wallFinish:'paint',wood:'#b79770',textile:'#c6c2b7'},
    minimal:{floorFinish:'light_tile',wallColor:'#f2f3ef',wallFinish:'paint',wood:'#b9c0b7',textile:'#b9c1bc'},
    natural:{floorFinish:'oak',wallColor:'#e7eddf',wallFinish:'plaster',wood:'#aa946f',textile:'#b6c2a8'},
    industrial:{floorFinish:'gray_stone',wallColor:'#c9ceca',wallFinish:'plaster',wood:'#897e6d',textile:'#838d89'}};
  const palette=palettes[style],wet=use==='kitchen'||use==='bathroom';
  const xs=room.polygon.map(p=>p[0]),zs=room.polygon.map(p=>p[1]);
  return {palette,design:{floorFinish:wet?'light_tile':palette.floorFinish,wallColor:palette.wallColor,wallFinish:palette.wallFinish,floorDirection:Math.max(...xs)-Math.min(...xs)>=Math.max(...zs)-Math.min(...zs)?0:90}};
}

/** Deterministic geometric layout; notes stay text, never executable instructions. */
export function generateFurnishedModel(model,rawBrief) {
  const brief=validateDesignBrief(model,rawBrief);
  if(!Array.isArray(model.walls)||!model.walls.length||model.walls.length>500||model.walls.some(w=>!point(w.start)||!point(w.end)||!finite(w.thickness)||w.thickness<.02||w.thickness>2||Math.hypot(w.end[0]-w.start[0],w.end[1]-w.start[1])<.01)||!Array.isArray(model.openings)||model.openings.length>500||model.openings.some(opening=>getOpeningErrors(model,opening).length)||!finite(model.width)||model.width<.1||model.width>100||!finite(model.depth)||model.depth<.1||model.depth>100||!finite(model.height)||model.height<2||model.height>6||!model.rooms.length||model.rooms.some(room=>!Array.isArray(room.polygon)||room.polygon.length<3||room.polygon.length>200||!room.polygon.every(point)||area(room.polygon)<EPS))throw new Error('请先校正有效的房间轮廓与墙体，再生成家具布局。');
  const next=structuredClone(model),warnings=[],choices=new Map(brief.rooms.map(room=>[room.roomId,room]));
  const aiSuggestions=Array.isArray(model.meta?.aiReview?.roomSuggestions)?model.meta.aiReview.roomSuggestions:[];
  const appliedNames=new Map(aiSuggestions.filter(suggestion=>suggestion&&suggestion.applied===true&&typeof suggestion.name==='string'&&suggestion.name.trim().length>0&&suggestion.name.length<=80).map(suggestion=>[suggestion.roomId,suggestion]));
  const counts={};brief.rooms.forEach(room=>{counts[room.use]=(counts[room.use]??0)+1;});
  const seen={},usedNames=new Set();next.furniture=[];next.designBrief=structuredClone(brief);
  next.rooms.forEach((room,roomIndex)=>{
    const choice=choices.get(room.id),{palette,design}=styleDesign(brief.style,choice.use,room);
    if(choice.use!=='empty') {
      seen[choice.use]=(seen[choice.use]??0)+1;
      const applied=appliedNames.get(room.id);
      let name=applied?.use===choice.use&&applied.name===room.name?room.name:USE_NAMES[choice.use]+(counts[choice.use]>1?seen[choice.use]:'');
      while(usedNames.has(name))name+='2';room.name=name;
    }
    usedNames.add(room.name);room.design=design;
    if(!choice.furnish||choice.use==='empty')return;
    const kinds=choice.items??getDefaultFurniture(choice.use,brief.needs);
    const accessible=brief.needs.includes('senior')||brief.needs.includes('accessibility');
    const context=roomContext(next,room,accessible?.85:.65),placed=[];
    const ratio=accessible?.46:brief.needs.includes('pet')||brief.needs.includes('relax')?.48:.58;
    const order={sofa:0,bed_double:0,bed_single:0,dining_table:0,kitchen_counter:0,wardrobe:1,sink_cabinet:1,toilet:1,shoe_cabinet:1,desk:2,tv_console:2,coffee_table:3,chair:4};
    // Anchor pieces are solved first even if an AI suggestion lists their
    // companion before them. Output identifiers retain the original list order.
    kinds.map((kind,itemIndex)=>({kind,itemIndex})).sort((a,b)=>order[a.kind]-order[b.kind]||a.itemIndex-b.itemIndex).forEach(({kind,itemIndex})=>{
      if(next.furniture.length>=300){if(!warnings.includes('家具总数已达 300 件，剩余清单未继续布置。'))warnings.push('家具总数已达 300 件，剩余清单未继续布置。');return;}
      const size=[...CATALOG[kind].size];size[1]=Math.min(size[1],model.height-.15);
      // Household size changes recommended capacity, while the explicit list
      // remains exact: never add a chair or a bed the user did not request.
      if(kind==='sofa')size[0]=brief.residents===1?1.8:Math.min(3.2,size[0]+Math.max(0,brief.residents-2)*.25);
      if(kind==='dining_table')size[0]=brief.residents===1?1:Math.min(2.2,size[0]+Math.max(0,brief.residents-2)*.15);
      if(kind==='wardrobe'&&brief.needs.includes('storage'))size[0]=Math.min(2.4,size[0]+Math.max(0,brief.residents-2)*.15);
      const color=['toilet','sink_cabinet'].includes(kind)?'#eeeee8':['sofa','bed_double','bed_single','chair'].includes(kind)?palette.textile:palette.wood;
      let selected=null,attempts=0;
      for(const candidate of candidates(context,kind,size,placed)) {
        const item={id:`furniture-${roomIndex+1}-${itemIndex+1}-${kind}`,roomId:room.id,kind,position:candidate.position.map(value=>Math.round(value*1000)/1000),size,rotation:Math.round(candidate.rotation*1e6)/1e6,color};
        if(!point(item.position)||geometryErrors(context,item,next.furniture,true).length)continue;
        if(retainsPassage(context,[...placed,item],ratio)){selected=item;break;}
        if(++attempts>=24)break;
      }
      if(selected){placed.push(selected);next.furniture.push(selected);}else warnings.push(`${room.name}：${CATALOG[kind].label}没有满足墙距、门区及基本通路的可用位置，已跳过。`);
    });
    next.furniture.sort((a,b)=>Number(a.id.split('-')[1])-Number(b.id.split('-')[1])||Number(a.id.split('-')[2])-Number(b.id.split('-')[2]));
  });
  return {model:next,warnings};
}
