import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Box, Layers3, Upload, Download, ChevronDown, ChevronRight, Plus, ScanLine, ImagePlus, RotateCcw, Maximize2, X, Check, LoaderCircle, FolderOpen, Settings2, Eye, EyeOff, Grid2X2, Clock3, AlertTriangle, FileImage, Move3D, MousePointer2, Camera, CheckCircle2, Pencil, ArrowUpRight, Trash2, DoorOpen, View } from 'lucide-react';
import HouseViewer from './HouseViewer';
import StructureEditor from './StructureEditor';
import RoomDesignPanel from './RoomDesignPanel';
import OpeningDesigner from './OpeningDesigner';
import DesignAssistant from './DesignAssistant';
import PlanRecognitionReview from './PlanRecognitionReview';
import { createAIPlanBrief, getAIPlanReview } from './ai-plan.mjs';
import { generateFurnishedModel } from './furnishing.mjs';
import BrandMark from './BrandMark';
import FacadeDemo from './FacadeDemo';
import ConstructionPanel from './ConstructionPanel';
import InspectionDialog from './InspectionDialog';
import InspectionEvidenceViewer from './InspectionEvidenceViewer';
import ProjectGuide, { type GuideAction } from './ProjectGuide';
import ProjectLibrary from './ProjectLibrary';
import ProjectTools, {type ToolTab} from './ProjectTools';
import { auditLayout } from './layout-audit.mjs';
import { useProjectLibrary } from './useProjectLibrary';
import './library-workspace.css';
import { PanelLeft, PanelRight, Sun, Moon, SlidersHorizontal, ArrowRight, CircleHelp, ClipboardCheck, Ruler } from 'lucide-react';
import './plan-recognition.css';
import { Sparkles, Sofa } from 'lucide-react';
import { DEMO_MODEL, demoAt } from './demo';
import { applyInspection, confirmedProgress, getRoomAlerts, removeInspection, roomAtDate, validCalendarDate } from './progress.mjs';
import { validateProject } from './project.mjs';
import { updateRoomDesign, resetRoomDesign } from './design.mjs';
import { updateOpening } from './openings.mjs';
import type { DesignBrief, Evidence, HouseModel, Opening, Room, RoomDesign, Task, WorkType } from './types';

const STORAGE_KEY = 'zhuying-model-v1';
const TODAY = new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
type PlanEngine = 'auto' | 'neural' | 'classic';
type AIPlanMode = 'rebuild' | 'assist' | 'local';
function loadModel(): HouseModel {
  try { const raw = localStorage.getItem(STORAGE_KEY); if (raw) return validateProject(JSON.parse(raw)); } catch { /* Invalid saved data never enters application state. */ }
  return structuredClone(DEMO_MODEL);
}
function dataUrl(file: File): Promise<string> { return new Promise((resolve,reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result)); r.onerror = reject; r.readAsDataURL(file); }); }
function saveFile(name: string, body: string, type = 'application/json') { const url = URL.createObjectURL(new Blob([body],{type})); const a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }
function Plan({ model, selected, onSelect, onEnter }: { model: HouseModel; selected: string | null; onSelect: (id: string) => void; onEnter?: (id:string)=>void }) {
  return <svg className="plan-svg" viewBox={`-1 -1 ${model.width + 2} ${model.depth + 2}`} role="img" aria-label="可点击的二维户型图">
    {model.rooms.map(r => <g key={r.id} onClick={() => onSelect(r.id)} onDoubleClick={()=>onEnter?.(r.id)} role="button" tabIndex={0} aria-label={`选择${r.name}`} onKeyDown={e => {if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelect(r.id)}}}>
      <polygon points={r.polygon.map(p => p.join(',')).join(' ')} fill={selected === r.id ? '#d1e4d6' : '#f4f5f1'} stroke="#bac6bd" strokeWidth=".03" />
      <text x={r.polygon.reduce((a,p)=>a+p[0],0)/r.polygon.length} y={r.polygon.reduce((a,p)=>a+p[1],0)/r.polygon.length} textAnchor="middle" dominantBaseline="middle" fontSize=".34" fill="#375047">{r.name}</text>
    </g>)}
    {model.walls.map(w => <line key={w.id} x1={w.start[0]} y1={w.start[1]} x2={w.end[0]} y2={w.end[1]} stroke="#4b5d54" strokeWidth={w.thickness} strokeLinecap="square"/>)}
    {model.openings.map(o => {const w=model.walls.find(w=>w.id===o.wallId);if(!w)return null; const dx=w.end[0]-w.start[0],dz=w.end[1]-w.start[1],l=Math.hypot(dx,dz);return <line key={o.id} x1={w.start[0]+dx/l*o.offset} y1={w.start[1]+dz/l*o.offset} x2={w.start[0]+dx/l*(o.offset+o.width)} y2={w.start[1]+dz/l*(o.offset+o.width)} stroke={o.type==='window'?'#6eacbb':'#f4f5f1'} strokeWidth={w.thickness+.04}/>;})}
  </svg>;
}

export default function App() {
  const [model,setModel] = useState<HouseModel>(loadModel);
  const [selected,setSelected] = useState<string|null>(model.rooms[0]?.id ?? null);
  const [view,setView] = useState<'3d'|'plan'>('3d');
  const [mode,setMode] = useState<'material'|'progress'>('material');
  const [cutaway,setCutaway] = useState(true);
  const [furniture,setFurniture] = useState(true);
  const [labels,setLabels] = useState(true);
  const [camera,setCamera] = useState<'perspective'|'top'>('perspective');
  const [resetKey,setResetKey] = useState(0);
  const [focusKey,setFocusKey] = useState(0);
  const [interiorRoom,setInteriorRoom] = useState<string|null>(null);
  const [selectedOpening,setSelectedOpening] = useState<string|null>(null);
  const [designTab,setDesignTab] = useState<'room'|'openings'>('room');
  const [modal,setModal] = useState<'import'|'settings'|null>(null);
  const [inspectionOpen,setInspectionOpen] = useState(false);
  const [viewedEvidence,setViewedEvidence] = useState<Evidence|null>(null);
  const [guideOpen,setGuideOpen] = useState(()=>{try{return localStorage.getItem('zhuying-guide-seen-v1')!=='1';}catch{return true;}});
  const [structureOpen,setStructureOpen] = useState(false);
  const [assistantOpen,setAssistantOpen] = useState(false);
  const [resourcesOpen,setResourcesOpen] = useState(()=>window.innerWidth>=1100);
  const [inspectorOpen,setInspectorOpen] = useState(()=>window.innerWidth>=1100);
  const [narrow,setNarrow] = useState(()=>window.innerWidth<1100);
  const [timelineOpen,setTimelineOpen] = useState(false);
  const [theme,setTheme] = useState<'light'|'dark'>(()=>{try{const stored=localStorage.getItem('zhuying-theme');if(stored==='light'||stored==='dark')return stored;}catch{}return window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';});
  const [libraryOpen,setLibraryOpen] = useState(false);
  const [facadeDemoOpen,setFacadeDemoOpen] = useState(false);
  const [toolsOpen,setToolsOpen]=useState(false),[toolsTab,setToolsTab]=useState<ToolTab>('issues');
  const [libraryAction,setLibraryAction] = useState(false);
  const busyRef = useRef(false);
  const modalRef = useRef<HTMLElement>(null);
  const closeAssistant = useCallback(()=>setAssistantOpen(false),[]);
  const closeInspection = useCallback(()=>setInspectionOpen(false),[]);
  const closeEvidence = useCallback(()=>setViewedEvidence(null),[]);
  const closeGuide = useCallback(()=>{setGuideOpen(false);try{localStorage.setItem('zhuying-guide-seen-v1','1');}catch{}},[]);
  const [toast,setToast] = useState('');
  const [date,setDate] = useState(TODAY);
  const [health,setHealth] = useState<{online:boolean;vision:boolean;design:boolean;planNeural:boolean;planWeights:boolean}>({online:false,vision:false,design:false,planNeural:false,planWeights:false});
  const [planEngine,setPlanEngine] = useState<PlanEngine>('auto');
  const [planMode,setPlanMode] = useState<AIPlanMode>('rebuild');
  const [planStyle,setPlanStyle] = useState<DesignBrief['style']>('warm');
  const [planCandidate,setPlanCandidate] = useState<HouseModel|null>(null);
  const [planFile,setPlanFile] = useState<File|null>(null);
  const [planPreview,setPlanPreview] = useState('');
  const [realWidth,setRealWidth] = useState(12);
  const [height,setHeight] = useState(2.8);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState('');
  const [modelName,setModelName] = useState(model.name);
  const [editingName,setEditingName] = useState('');
  const inputPlan = useRef<HTMLInputElement>(null);
  const workspace = useRef<HTMLDivElement>(null);
  const library = useProjectLibrary(model,setModel,resetWorkspace,!!modal||assistantOpen||structureOpen||inspectionOpen||toolsOpen||busy);
  const layoutCheck=useMemo(()=>auditLayout(model),[model]);
  function resetWorkspace(next:HouseModel) {
    setSelected(next.rooms[0]?.id??null);setSelectedOpening(null);setInteriorRoom(null);setDate(TODAY);
    setView('3d');setCamera('perspective');setResetKey(value=>value+1);setModelName(next.name);
    setAssistantOpen(false);setStructureOpen(false);setInspectionOpen(false);setViewedEvidence(null);setToolsOpen(false);
    setModal(null);setPlanFile(null);setPlanPreview('');setPlanCandidate(null);setError('');
  }
  async function libraryOperation(operation:()=>Promise<void>,message?:string) {
    setLibraryAction(true);
    try {await operation();if(message)setToast(message);}
    catch(failure){setToast(failure instanceof Error?failure.message:'项目库操作失败，当前草稿已保留。');throw failure;}
    finally{setLibraryAction(false);}
  }
  const saveLabel = !library.ready?'恢复工作区…':library.saving?'正在保存…':library.record?(library.dirty?'修改待保存':library.error?'项目库待同步':'已保存至项目库'):'本地草稿';
  const room = model.rooms.find(r=>r.id===selected) ?? model.rooms[0];
  const displayModel = useMemo(()=>mode==='progress'?{...model,rooms:model.rooms.map(r=>{
    const observed = date<TODAY?(model.source==='demo'?(()=>{const history=demoAt(date).rooms.find(h=>h.id===r.id);return history?{...r,tasks:{...r.tasks,floor:{...r.tasks.floor,stage:history.tasks.floor.stage},wall:{...r.tasks.wall,stage:history.tasks.wall.stage}}}:r;})():roomAtDate(r,date)):r;
    return {...observed,progress:confirmedProgress(observed).percent??0};
  })}:model,[model,mode,date]);
  const observedRoom = displayModel.rooms.find(r=>r.id===room?.id)??room;
  const hasDemoData = model.source === 'demo' || model.meta?.demoData === true;
  const alertDate = date;
  const alerts = displayModel.rooms.flatMap(r=>getRoomAlerts(r,alertDate).map(a=>({...a,room:r})));
  const area = model.rooms.reduce((a,r)=>a+r.area,0);
  const overall = displayModel.rooms.reduce((sum,r)=>{const p=confirmedProgress(r);return {completed:sum.completed+p.completed,known:sum.known+p.known,total:sum.total+p.total};},{completed:0,known:0,total:0});
  const hasRecognition = model.source==='opencv'||model.meta?.engine==='neural'||model.meta?.engine==='classic';
  const neuralResult = model.meta?.engine==='neural'||model.meta?.algorithm==='cubicasa5k-hg-v1';
  const aiPlanReview = getAIPlanReview(model);
  const effectivePlanMode:AIPlanMode = health.vision ? planMode : 'local';
  const recognitionMeta = model.meta?.recognition&&typeof model.meta.recognition==='object'?model.meta.recognition as Record<string,unknown>:{};
  const recognitionSeconds = typeof recognitionMeta.inferenceSeconds==='number'&&Number.isFinite(recognitionMeta.inferenceSeconds)?recognitionMeta.inferenceSeconds:null;
  const recognitionDevice = recognitionMeta.device==='cpu'?'CPU':typeof recognitionMeta.device==='string'&&recognitionMeta.device.startsWith('cuda')?'GPU':null;
  const planUsesNeural = planEngine==='neural'||(planEngine==='auto'&&health.planNeural);
  // Keep the original single-project key intact as a migration backup; the library backs up each tab in IndexedDB.
  useEffect(()=>{try{localStorage.setItem('zhuying-theme',theme);}catch{}document.documentElement.style.colorScheme=theme;},[theme]);
  useEffect(()=>{busyRef.current=busy;},[busy]);
  useEffect(()=>{
    const query=window.matchMedia('(max-width:1099px)');
    const change=()=>{setNarrow(query.matches);setResourcesOpen(!query.matches);setInspectorOpen(!query.matches);};
    query.addEventListener('change',change);
    return()=>query.removeEventListener('change',change);
  },[]);
  useEffect(()=>{
    if(!modal)return;
    const previous=document.activeElement instanceof HTMLElement?document.activeElement:null;
    modalRef.current?.focus();
    const onKey=(event:KeyboardEvent)=>{
      if(event.key==='Escape'&&!busyRef.current){event.preventDefault();setModal(null);}
      if(event.key!=='Tab')return;
      const elements=Array.from(modalRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled),[tabindex="0"]')??[]).filter(el=>el.getClientRects().length);
      const first=elements[0],last=elements[elements.length-1];
      if(!first){event.preventDefault();return;}
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===modalRef.current)){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===modalRef.current)){event.preventDefault();first.focus();}
    };
    document.addEventListener('keydown',onKey);
    return()=>{document.removeEventListener('keydown',onKey);queueMicrotask(()=>{if(previous?.isConnected&&!previous.closest('[inert]'))previous.focus();});};
  },[modal]);
  useEffect(()=>{
    if(!narrow||(!resourcesOpen&&!inspectorOpen)||modal||assistantOpen||structureOpen||inspectionOpen||viewedEvidence||guideOpen||toolsOpen)return;
    const previous=document.activeElement instanceof HTMLElement?document.activeElement:null;
    const panel=document.getElementById(resourcesOpen?'studio-resources':'studio-inspector');
    panel?.querySelector<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled)')?.focus({preventScroll:true});
    const escape=(event:KeyboardEvent)=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();setResourcesOpen(false);setInspectorOpen(false);}};
    document.addEventListener('keydown',escape);
    return()=>{document.removeEventListener('keydown',escape);queueMicrotask(()=>{if(previous?.isConnected&&!previous.closest('[inert]'))previous.focus({preventScroll:true});});};
  },[narrow,resourcesOpen,inspectorOpen,modal,assistantOpen,structureOpen,inspectionOpen,viewedEvidence,guideOpen,toolsOpen]);
  useEffect(()=>{
    const dialogOpen=!!modal||assistantOpen||structureOpen||inspectionOpen||!!viewedEvidence||guideOpen||facadeDemoOpen||toolsOpen||libraryAction||!library.ready;
    if(!dialogOpen&&!(narrow&&(resourcesOpen||inspectorOpen)))return;
    const surfaces=Array.from(document.querySelectorAll<HTMLElement>(dialogOpen?'.app-shell > header,.app-shell > nav,.app-shell > aside,.app-shell > main,.app-shell > .project-library':'.app-shell > main'));
    const previous=surfaces.map(surface=>surface.inert);
    surfaces.forEach(surface=>{surface.inert=true;});
    return()=>{surfaces.forEach((surface,index)=>{surface.inert=previous[index];});};
  },[modal,assistantOpen,structureOpen,inspectionOpen,viewedEvidence,guideOpen,facadeDemoOpen,toolsOpen,narrow,resourcesOpen,inspectorOpen,libraryAction,library.ready]);
  useEffect(()=>{ if(!toast)return;const t=setTimeout(()=>setToast(''),4300);return()=>clearTimeout(t);},[toast]);
  useEffect(()=>{ const check=()=>fetch('/api/health').then(r=>r.ok?r.json():Promise.reject()).then(d=>setHealth({online:true,vision:!!(d.vision_configured??d.visionConfigured??d.qwenConfigured),design:!!d.designConfigured,planNeural:d.planRecognition?.available===true,planWeights:d.planRecognition?.weightsPresent===true})).catch(()=>setHealth({online:false,vision:false,design:false,planNeural:false,planWeights:false}));check();const t=setInterval(check,30000);return()=>clearInterval(t);},[]);
  useEffect(()=>{setEditingName(room?.name??'');},[room?.id,room?.name]);
  useEffect(()=>{const notify=(event:Event)=>{const result=(event as CustomEvent<{bytes:number;error?:string}>).detail;setToast(result.error?`模型导出失败：${result.error}`:`已生成 GLB 模型，${Math.round(result.bytes/1024)} KB`);};window.addEventListener('zhuying:export-complete',notify);return()=>window.removeEventListener('zhuying:export-complete',notify);},[]);
  function openModal(type: typeof modal|'photo') {setError('');if(type==='photo'){setInspectionOpen(true);return;}if(type==='import')setPlanCandidate(null);setModal(type);setModelName(model.name);setHeight(model.height);}
  function guideAction(action:GuideAction) {
    closeGuide();
    if(action==='tools'||action==='case'){openTools(action==='case'?'case':'issues');return;}
    if(action==='facade-demo'){setFacadeDemoOpen(true);return;}
    if(action==='library'){setLibraryOpen(true);return;}
    if(action==='import'){openModal('import');return;}
    if(action==='structure'){setStructureOpen(true);return;}
    if(action==='design'){setAssistantOpen(true);return;}
    if(action==='interior'){enterRoom(room.id);return;}
    setMode('progress');setInteriorRoom(null);setDate(TODAY);
    if(action==='timeline'){setTimelineOpen(true);if(narrow){setResourcesOpen(false);setInspectorOpen(false);}return;}
    setInspectorOpen(true);if(narrow)setResourcesOpen(false);
    if(action==='inspection')openModal('photo');
  }
  function openTools(tab:ToolTab='issues') {setToolsTab(tab);setToolsOpen(true);}
  function changePracticalModel(next:HouseModel) {setModel(validateProject(next));}
  async function createPublicCase(next:HouseModel) {await library.create(validateProject(next));setLibraryOpen(false);setToolsTab('issues');setToolsOpen(true);setMode('progress');setToast('已建立独立案例演练项目，照片真实，任务与房间几何为演示。');}
  function locateToolRoom(roomId:string,openingId?:string) {setToolsOpen(false);setSelected(roomId);setInteriorRoom(null);setFocusKey(k=>k+1);if(openingId){selectOpening(openingId);}else{setInspectorOpen(true);if(narrow)setResourcesOpen(false);}}
  function updateRoom(update: (r:Room)=>Room) {setModel(m=>({...m,source:m.source==='demo'?'manual':m.source,rooms:m.rooms.map(r=>{if(r.id!==room.id)return r;const next=update(r);next.progress=confirmedProgress(next).percent??0;return next;})}));}
  function editTask(type:WorkType,patch:Partial<Task>) {
    if(date<TODAY)return;
    if(patch.dueDate&&!validCalendarDate(patch.dueDate)){setToast('请填写有效的计划完成日期。');return;}
    updateRoom(r=>({...r,tasks:{...r.tasks,[type]:{stage:'unknown',plannedStage:'unknown',dueDate:'',...r.tasks[type],...patch}}}));
  }
  function saveInspection(evidence:Evidence) {
    const next={...model,source:model.source==='demo'?'manual' as const:model.source,rooms:model.rooms.map(r=>r.id===room.id?applyInspection(r,evidence):r)};
    setModel(validateProject(next));setDate(TODAY);setMode('progress');setInteriorRoom(null);setInspectorOpen(true);if(narrow)setResourcesOpen(false);
    setToast('巡检已保存，施工状态按最新确认记录更新。');
  }
  function deleteInspection(id:string) {
    try {const next={...model,rooms:model.rooms.map(r=>r.id===room.id?removeInspection(r,id):r)};setModel(validateProject(next));setToast('记录已删除，施工状态已按剩余证据重算。');}
    catch(e){setToast(e instanceof Error?e.message:'记录删除失败，请导出项目并重试。');}
  }
  function changeDesign(patch:Partial<RoomDesign>) {setModel(m=>updateRoomDesign(m,room.id,patch));setMode('material');}
  function selectRoom(id:string,openPanel=false) {setSelected(id);setSelectedOpening(null);if(interiorRoom&&interiorRoom!==id)setInteriorRoom(null);if(window.innerWidth<1100){setResourcesOpen(false);if(openPanel)setInspectorOpen(true);}}
  function selectOpening(id:string) {setSelectedOpening(id);setDesignTab('openings');setMode('material');setInspectorOpen(true);if(narrow)setResourcesOpen(false);}
  function changeOpening(id:string,patch:Partial<Opening>) {try{const updated=updateOpening(model,id,patch);const next={...updated,meta:{...updated.meta,layoutReviewPending:true}};validateProject(next);setModel(next);}catch(e){setToast(e instanceof Error?e.message:'门窗参数无效，请核对尺寸。');throw e;}}
  function enterRoom(id:string) {setSelected(id);setSelectedOpening(null);setInteriorRoom(id);setMode('material');setView('3d');if(window.innerWidth<1100){setResourcesOpen(false);setInspectorOpen(false);}}
  function focusRoom() {setInteriorRoom(null);setView('3d');setFocusKey(n=>n+1);}
  async function choosePlan(file?:File) {if(!file||busy)return;setError('');if(file.size>10*1024*1024){setError('户型图片不能超过10MB');return;}try{const preview=await dataUrl(file);setPlanFile(file);setPlanPreview(preview);}catch{setError('无法读取这张图片，请重新选择完整的 PNG、JPG 或 WEBP 文件。');}}
  async function parsePlan() {
    if(!planFile || busy)return;setBusy(true);setError('');
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),200000);
    const fd=new FormData();fd.append('file',planFile);fd.append('real_width',String(realWidth));fd.append('height',String(height));fd.append('engine',planEngine);fd.append('ai_mode',effectivePlanMode);fd.append('design_style',planStyle);
    try {
      const response=await fetch('/api/parse-plan',{method:'POST',body:fd,signal:controller.signal});const d=await response.json();
      if(!response.ok)throw new Error(typeof d.detail==='string'?d.detail:'识别失败，请使用更清晰、边界完整的户型图，或切换识别方式。');
      const next:HouseModel=validateProject(d.model??d);next.name=planFile.name.replace(/\.[^.]+$/,'');
      const prepared=generateFurnishedModel(next,createAIPlanBrief(next,planStyle));
      prepared.model.warnings=[...new Set([...prepared.model.warnings,...prepared.warnings])].slice(0,100);
      setPlanCandidate(validateProject(prepared.model));
    }catch(e){setError(controller.signal.aborted?'识别请求超时，当前项目已保留。可重试，或选择本地识别。':e instanceof Error?e.message:'识别服务无法连接，请启动本地算法服务。');}finally{clearTimeout(timeout);setBusy(false);}
  }
  async function adoptPlan() {
    if(!planCandidate||busy)return;setBusy(true);setError('');
    try {await library.create(planCandidate);setLibraryOpen(false);setFurniture(true);setMode('material');setAssistantOpen(true);setToast('已保存独立模型与家具初稿，继续确认你的居住需求。');}
    catch(e){setError(e instanceof Error?e.message:'模型保存失败，请重试。当前项目已保留。');}
    finally{setBusy(false);}
  }
  function selectDate(next:string) {
    setDate(next);
  }
  function resetDemo() {void libraryOperation(async()=>{await library.create(structuredClone(DEMO_MODEL));setLibraryOpen(false);setFurniture(true);},'已载入独立示例项目，示例不计入真实施工总览。').catch(()=>{});}
  function exportModel() {saveFile(`${model.name}.json`,JSON.stringify(model,null,2));setToast('项目已导出，包含户型、装修方案、任务与现场照片。');}
  async function importProject(file:File) {if(libraryAction||busy)return;setLibraryAction(true);try{if(file.size>50*1024*1024)throw new Error('项目文件超过50MB，请减少照片后导入。');const m=validateProject(JSON.parse(await file.text()));await library.create(m);setLibraryOpen(false);setToast('已作为独立项目加入项目库，原模型继续保留。');}catch(failure){setToast(failure instanceof Error?failure.message:'项目文件无效，请选择筑映导出的完整JSON文件。');}finally{setLibraryAction(false);}}
  function applyFurnishedModel(next:HouseModel) {setModel(validateProject(next));setAssistantOpen(false);setSelected(next.rooms[0]?.id??null);setSelectedOpening(null);setInteriorRoom(null);setFurniture(true);setLabels(true);setMode('material');setDesignTab('room');setView('3d');setCamera('perspective');setResetKey(k=>k+1);setToast(`家居方案已生成，放置 ${next.furniture?.length??0} 件家具。`);}

  return <div className={`app-shell ${libraryOpen?'library-view':''} ${resourcesOpen?'resources-open':'resources-closed'} ${inspectorOpen?'inspector-open':'inspector-closed'} ${timelineOpen?'timeline-open':''}`} data-theme={theme} data-workspace-mode={mode}>
    <header className="topbar">
      <a className="brand" href="#" aria-label="筑映工作台"><BrandMark size={34}/><span>筑映<span className="brand-caption">空间设计 · 施工观察</span></span></a>
      <span className="top-divider"/>
      <button className="project-name project-switcher" title="打开项目库，切换房屋模型" disabled={!library.ready||libraryAction||busy} onClick={()=>setLibraryOpen(true)}><span>{model.name}</span><span className="project-tag">{hasDemoData?'示例项目':library.record?.status==='archived'?'已归档':library.record?'库中项目':'本地草稿'}</span><ChevronDown size={13}/></button>
      <div className="top-actions"><button className="button ghost facade-demo-entry" onClick={()=>setFacadeDemoOpen(true)}><Camera size={15}/>施工观察</button><span className={`save-status ${library.error?'save-error':''}`} role="status">{library.saving?<LoaderCircle className="spin" size={13}/>:<Check size={13}/>}<span>{saveLabel}</span></span><button className={`button ghost library-entry ${libraryOpen?'active':''}`} disabled={!library.ready||libraryAction||busy} onClick={()=>setLibraryOpen(value=>!value)}><FolderOpen size={15}/>项目库</button><span className={`service-status ${health.online?'online':''}`} title={health.online?'本地算法服务已连接':'启动算法服务后可识别户型图'}><span/>{health.online?'算法服务已连接':'算法服务未连接'}</span><button className="button ghost" onClick={exportModel}><Download size={15}/>导出项目</button><button className="button primary" disabled={!library.ready||libraryAction||busy} onClick={()=>openModal('import')}><Plus size={16}/>导入户型</button></div>
    </header>
    {libraryOpen?<ProjectLibrary projects={library.projects} activeId={library.record?.id??null} loading={library.loading} error={library.error} saving={library.saving||libraryAction} onOpen={id=>libraryOperation(async()=>{await library.open(id);setLibraryOpen(false);})} onSaveCurrent={()=>libraryOperation(library.flush,'当前模型已保存到项目库。')} onImport={()=>openModal('import')} onDuplicate={id=>libraryOperation(()=>library.duplicate(id),'已创建独立副本。')} onMetadata={(id,patch)=>libraryOperation(()=>library.metadata(id,patch),'项目资料已更新。')} onRetry={library.refresh} onBack={()=>setLibraryOpen(false)}/>:<>
    <nav className="studio-rail" aria-label="工作台导航">
      <div className="rail-main">
        <button className={resourcesOpen?'selected':''} aria-label="切换空间资源面板" aria-expanded={resourcesOpen} aria-controls="studio-resources" onClick={()=>{setResourcesOpen(!resourcesOpen);if(window.innerWidth<1100)setInspectorOpen(false);}}><PanelLeft size={21}/><span>空间</span></button>
        <span className="rail-divider"/>
        <button className={mode==='material'?'selected':''} aria-label="进入装修设计" aria-pressed={mode==='material'} onClick={()=>{setMode('material');setDesignTab('room');setInspectorOpen(true);if(window.innerWidth<1100)setResourcesOpen(false);}}><SlidersHorizontal size={21}/><span>设计</span></button>
        <button className={mode==='progress'?'selected':''} aria-label="进入施工记录" aria-pressed={mode==='progress'} onClick={()=>{setMode('progress');setInteriorRoom(null);setInspectorOpen(true);if(window.innerWidth<1100)setResourcesOpen(false);}}><Layers3 size={21}/><span>施工</span></button>
        <button aria-label="打开施工观察样例" onClick={()=>setFacadeDemoOpen(true)}><Camera size={21}/><span>观察</span></button>
        <button aria-label="打开项目管理" onClick={()=>openTools()}><ClipboardCheck size={21}/><span>管理</span></button>
        <button aria-label="打开设计助手" onClick={()=>setAssistantOpen(true)}><Sparkles size={21}/><span>AI 设计</span></button>
      </div>
      <div className="rail-bottom">
        <button aria-label="打开使用指南" onClick={()=>setGuideOpen(true)}><CircleHelp size={20}/><span>指南</span></button>
        <button aria-label={theme==='light'?'切换为深色外观':'切换为浅色外观'} onClick={()=>setTheme(theme==='light'?'dark':'light')}>{theme==='light'?<Moon size={20}/>:<Sun size={20}/>}<span>{theme==='light'?'深色':'浅色'}</span></button>
        <button aria-label="打开项目设置" onClick={()=>openModal('settings')}><Settings2 size={20}/><span>设置</span></button>
      </div>
    </nav>
    {(resourcesOpen||inspectorOpen)&&<button className="panel-scrim" tabIndex={-1} aria-label="关闭侧边面板" onClick={()=>{setResourcesOpen(false);setInspectorOpen(false);}}/>}
    <aside className="sidebar" id="studio-resources" aria-label="空间资源">
      <div className="sidebar-heading"><span>空间目录</span><button className="icon-button" title="项目设置" aria-label="项目设置" onClick={()=>openModal('settings')}><Settings2 size={17}/></button></div>
      <div className="asset-preview"><div className="asset-top"><FileImage size={15}/><span>户型结构</span><span className="small-tag">平面图</span></div><Plan model={model} selected={selected} onSelect={selectRoom} onEnter={enterRoom}/><div className="asset-bottom"><span>{model.width.toFixed(1)} × {model.depth.toFixed(1)} m</span><button onClick={()=>{setInteriorRoom(null);setView('plan')}}>查看<ArrowUpRight size={13}/></button></div></div>
      {hasRecognition&&<section className="recognition-result" aria-label="户型识别结果"><div className="recognition-result-main"><ScanLine size={17}/><div><strong>{aiPlanReview?.geometryRebuilt?'AI 自主重建':aiPlanReview?.status==='applied'||aiPlanReview?.status==='reviewed'?'AI 辅助校正':neuralResult?'CubiCasa 神经模型识别':'基础线条识别'}<span className="recognition-review-tag">待核对</span></strong><p>当前模型：{model.rooms.length} 个空间 · {model.openings.filter(o=>o.type==='door').length} 扇门 · {model.openings.filter(o=>o.type==='window').length} 扇窗{recognitionDevice?` · 本机 ${recognitionDevice}`:''}{recognitionSeconds!==null?` · 推理 ${recognitionSeconds.toFixed(1)} 秒`:''}</p></div><button onClick={()=>setStructureOpen(true)}><Pencil size={13}/>核对与校正</button></div>{model.warnings.length>0&&<details className="recognition-result-notes"><summary><AlertTriangle size={13}/><span>{model.warnings[0]}</span><ChevronDown size={13}/></summary><div>{model.warnings.slice(1).map((warning,index)=><p key={index}>{warning}</p>)}<p>可在「校正结构」中调整墙体、房间轮廓与门窗；房间用途请在设计问答中确认。</p></div></details>}</section>}
      <div className="level-title"><Layers3 size={16}/><span>一层空间</span><span className="count">{model.rooms.length}</span></div>
      <div className="room-list">{model.rooms.map(r=>{const p=confirmedProgress(displayModel.rooms.find(observed=>observed.id===r.id)??r);return <button key={r.id} className={`room-item ${selected===r.id?'selected':''}`} onClick={()=>selectRoom(r.id,true)} onDoubleClick={()=>enterRoom(r.id)}><span className="room-item-icon" aria-hidden="true"><Box size={15}/></span><span className="room-item-name">{r.name}<small>{r.area.toFixed(1)} m²</small></span><span className={`room-mini-progress ${p.total>0&&p.completed===p.total?'finished':''}`}>{p.known===0?'待核对':`${p.completed}/${p.total} 项`}</span></button>;})}</div>
      <div className="sidebar-section"><span>现场资料</span><button className="icon-button" title="上传现场照片" aria-label="上传现场照片" onClick={()=>openModal('photo')}><Plus size={16}/></button></div>
      <button className="photo-upload" onClick={()=>openModal('photo')}><span><ImagePlus size={21}/></span><strong>添加房间照片</strong></button>
      <details className="sidebar-footer"><summary>项目操作<ChevronDown size={14}/></summary><button onClick={exportModel}><Download size={15}/>导出项目备份</button><button disabled={libraryAction||!library.ready} onClick={()=>setLibraryOpen(true)}><FolderOpen size={15}/>管理多个项目</button><button disabled={libraryAction||!library.ready} onClick={resetDemo}><Box size={15}/>载入独立示例</button><label><Upload size={15}/>导入已保存项目<input type="file" accept=".json" disabled={libraryAction||!library.ready} onChange={e=>{if(e.target.files?.[0])void importProject(e.target.files[0]);e.target.value=''}}/></label><p>{library.record?'模型与巡检已存入本机项目库。':'当前是本地草稿，请保存到项目库。'}定期导出以备份。</p></details>
    </aside>
    <main className="main-workspace">
      <div className="workspace-heading"><div className="workspace-title-group"><h1>{mode==='material'?'空间设计':'施工记录'}</h1><div className="workspace-context">一层<span>·</span>{model.rooms.length} 个空间<span>·</span>{area.toFixed(1)} m²</div></div><div className="workspace-heading-actions">{mode==='progress'?<button className="button studio-design-action" onClick={()=>openModal('photo')}><Camera size={16}/>记录巡检</button>:<button className="button studio-design-action" onClick={()=>setAssistantOpen(true)}><Sparkles size={16}/>AI 设计<ArrowRight size={14}/></button>}</div></div>
      <div className="workspace-practical-actions"><button onClick={()=>openTools('case')}><Camera size={14}/>没有现场项目？体验真实室内案例<ArrowRight size={14}/></button><button onClick={()=>openTools('audit')}><Ruler size={14}/>{layoutCheck.counts.conflicts?`${layoutCheck.counts.conflicts} 处布局冲突待处理`:'尺寸与布局复核'}</button></div>
      {(!library.record||library.error||library.backupError)&&<section className="library-workspace-notice" role={library.error?'alert':'status'}><div><FolderOpen size={17}/><p><strong>{library.error?'项目库需要处理':library.backupError?'本机草稿备份失败':'本地草稿'}</strong><span>{library.error??(library.backupError?'请保存到项目库或导出，避免刷新丢失草稿。':'保存后可随时继续。')}</span></p></div><div className="library-notice-actions"><button disabled={library.saving||libraryAction||!library.ready} onClick={()=>void libraryOperation(library.flush,'当前模型已保存到项目库。').catch(()=>{})}>{library.saving?<LoaderCircle className="spin" size={13}/>:<Check size={13}/>}保存到项目库</button>{library.error&&<><button disabled={library.saving||libraryAction} onClick={()=>void libraryOperation(library.saveCopy,'本地草稿已另存为独立副本。').catch(()=>{})}>另存本地副本</button><button onClick={exportModel}>导出当前草稿</button>{library.record&&<button disabled={library.saving||libraryAction} onClick={()=>{if(window.confirm('将放弃当前未保存的修改并打开库中最新版本。建议先导出或另存副本。'))void libraryOperation(library.reload,'已载入项目库最新版本。').catch(()=>{});}}>放弃草稿并载入</button>}</>}</div></section>}
      <div className="viewer-card" ref={workspace}>
        <div className="viewer-toolbar"><div className="segmented"><button className={view==='3d'?'active':''} aria-pressed={view==='3d'} onClick={()=>setView('3d')}><Box size={15}/>三维模型</button><button className={view==='plan'?'active':''} aria-pressed={view==='plan'} onClick={()=>{setInteriorRoom(null);setView('plan')}}><Grid2X2 size={15}/>户型平面</button></div><div className="toolbar-right"><button className="icon-button" title="重置视角" aria-label="重置视角" onClick={()=>{setInteriorRoom(null);setResetKey(n=>n+1);setCamera('perspective')}}><RotateCcw size={17}/></button><button className="icon-button" title="全屏模型" aria-label="全屏模型" onClick={()=>{if(document.fullscreenElement)void document.exitFullscreen();else void workspace.current?.requestFullscreen().catch(()=>setToast('浏览器未允许全屏，可收起侧栏放大模型。'))}}><Maximize2 size={17}/></button><button className="icon-button inspector-toggle" title="空间设计面板" aria-label="切换空间设计面板" aria-expanded={inspectorOpen} aria-controls="studio-inspector" onClick={()=>{setInspectorOpen(!inspectorOpen);if(window.innerWidth<1100)setResourcesOpen(false);}}><PanelRight size={17}/></button></div></div>
        <div className={`model-surface ${interiorRoom?'interior-active':''}`}>{view==='3d'?<HouseViewer theme={theme} model={displayModel} selectedRoom={selected} onSelectRoom={id=>{if(interiorRoom){setSelected(interiorRoom);setSelectedOpening(null);}else selectRoom(id);}} viewMode={mode} cameraMode={camera} cutaway={cutaway} showFurniture={furniture} showLabels={labels} resetKey={resetKey} focusKey={focusKey} interiorRoom={interiorRoom} onEnterRoom={enterRoom} onExitRoom={()=>setInteriorRoom(null)} selectedOpening={selectedOpening} onSelectOpening={selectOpening}/>:<div className="full-plan"><Plan model={model} selected={selected} onSelect={selectRoom} onEnter={enterRoom}/></div>}
          <div className="model-caption"><span className="caption-mark"/><span>{hasDemoData?'参数化示例模型':'户型图生成模型'}</span><span className="scale-label">单位：米</span></div>
          <div className={`floating-tools ${interiorRoom?'interior-disabled':''}`}><button className={cutaway?'active':''} title="剖切墙体" aria-label="剖切墙体" onClick={()=>setCutaway(!cutaway)}><Layers3 size={19}/></button><button className={camera==='top'?'active':''} title="俯视模型" aria-label="俯视模型" onClick={()=>{setCamera(c=>c==='top'?'perspective':'top');setView('3d')}}><Grid2X2 size={19}/></button><button className={labels?'active':''} title="房间标签" aria-label="房间标签" onClick={()=>setLabels(!labels)}>{labels?<Eye size={19}/>:<EyeOff size={19}/>}</button>{(hasDemoData||!!model.furniture?.length)&&<button className={furniture?'active':''} title={model.furniture!==undefined?'方案家具':'示意家具'} aria-label={model.furniture!==undefined?'方案家具':'示意家具'} onClick={()=>setFurniture(!furniture)}><Box size={19}/></button>}</div>
          {mode==='material'&&room&&<div className="model-room-chip"><strong>{room.name}</strong><button onClick={focusRoom}><Maximize2 size={11}/>聚焦</button><button className="model-enter-button" aria-label="进入当前房间环视" onClick={()=>enterRoom(room.id)}><View size={12}/>进入房间</button></div>}
          <div className="viewer-bottom"><span><MousePointer2 size={13}/>{mode==='material'?'单击选择空间，双击进入房间':'点击空间查看施工记录'}</span><span><Move3D size={13}/>拖动旋转 · 滚轮缩放</span><button disabled={view!=='3d'} title={view!=='3d'?'请切换到三维模型后导出':'导出三维模型'} onClick={()=>{window.dispatchEvent(new Event('zhuying:export-glb'));setToast('正在导出三维模型…')}}><Download size={13}/>导出 GLB</button></div>
          {mode==='progress'&&<div className="progress-legend"><span><i style={{background:'#7eaf92'}}/>已完成</span><span><i style={{background:'#d4aa69'}}/>施工中</span><span><i style={{background:'#b7bec3'}}/>未开始 / 待核对</span></div>}
        </div>
      </div>
      <div className={`lower-panel ${timelineOpen?'expanded':''}`}><div className="timeline-heading"><div><Clock3 size={15}/><button className="timeline-expand" aria-expanded={timelineOpen} aria-controls="construction-timeline" onClick={()=>setTimelineOpen(!timelineOpen)}><strong>施工记录</strong><ChevronDown size={13}/></button><span>{model.source==='demo'?'示例时间线':'已保存的现场记录'}</span></div><button onClick={()=>openModal('photo')}><Plus size={14}/>添加巡检</button></div>{timelineOpen&&<div className="timeline" id="construction-timeline">{(model.source==='demo'?['2026-09-24','2026-09-28',TODAY]:[...new Set([TODAY,...model.rooms.flatMap(r=>(r.evidence??[]).map(e=>e.date))])].sort()).map(d=><button key={d} className={`timeline-point ${date===d?'active':''}`} onClick={()=>selectDate(d)}><span className="timeline-dot"/><strong>{d.slice(5).replace('-','月')}日</strong><small>{model.source==='demo'?(d===TODAY?'当前示例':'历史示例'):'查看当日证据'}</small></button>)}<div className="timeline-end">{model.source==='demo'?'演示记录，非真实施工数据':'施工状态按最近确认记录展示'}</div></div>}</div>
      <footer className="workspace-footer"><span>{model.rooms.length} 个空间 · {model.walls.length} 段墙体 · 层高 {model.height.toFixed(2)} m</span><span>{model.furniture!==undefined?'家具为设计方案，可继续修改':'请核对墙体与尺寸'}</span></footer>
    </main>
    <aside className="inspector" id="studio-inspector" aria-label="空间设计面板">
      <div className="inspector-title"><span>空间详情</span><button className="structure-button" onClick={()=>setStructureOpen(true)}><Pencil size={13}/>校正结构</button></div>
      {room&&<><div className="room-heading"><div className="room-type-icon"><Box size={24}/></div><h2>{room.name}</h2><p>一层 / {room.area.toFixed(1)} m²</p><div className="room-view-actions"><button className="room-focus-button" onClick={focusRoom}><Maximize2 size={12}/>聚焦空间</button><button className="room-enter-button" onClick={()=>interiorRoom?setInteriorRoom(null):enterRoom(room.id)}><View size={13}/>{interiorRoom?'返回整屋':'进入房间环视'}</button></div></div>
        <div className="inspector-tabs has-openings"><button className={mode==='material'&&designTab==='room'?'active':''} aria-label="打开装修设计面板" aria-pressed={mode==='material'&&designTab==='room'} onClick={()=>{setMode('material');setDesignTab('room')}}><Pencil size={13}/>材质设计</button><button className={mode==='material'&&designTab==='openings'?'active':''} aria-label="打开门窗设计面板" aria-pressed={mode==='material'&&designTab==='openings'} onClick={()=>{setMode('material');setDesignTab('openings')}}><DoorOpen size={13}/>门窗编辑</button><button className={mode==='progress'?'active':''} aria-label="打开施工记录面板" aria-pressed={mode==='progress'} onClick={()=>{setInteriorRoom(null);setMode('progress')}}><Clock3 size={13}/>施工记录</button></div>
        {mode==='material'&&designTab==='openings'&&<OpeningDesigner model={model} room={room} selectedOpening={selectedOpening} onSelect={selectOpening} onChange={changeOpening} onStructure={()=>setStructureOpen(true)}/>}
        {mode==='material'&&designTab==='room'&&<><RoomDesignPanel room={room} onChange={changeDesign} onReset={()=>{setModel(m=>resetRoomDesign(m,room.id));setToast(`已恢复${room.name}的默认材质。`);}}/><details className="room-properties"><summary>空间属性<ChevronDown size={13}/></summary><div className="inspect-section"><label className="field-label">房间名称<div className="input-with-icon"><input value={editingName} onChange={e=>setEditingName(e.target.value)} onBlur={()=>{if(editingName.trim()&&editingName.trim()!==room.name)updateRoom(r=>({...r,name:editingName.trim()}));else setEditingName(room.name)}} aria-label="房间名称"/><Pencil size={14}/></div></label><div className="field-row"><label className="field-label">面积<div className="static-field">{room.area.toFixed(1)}<span>m²</span></div></label><label className="field-label">层高<div className="static-field">{model.height.toFixed(2)}<span>m</span></div></label></div></div></details></>}
        {mode==='progress'&&<ConstructionPanel room={room} observedRoom={observedRoom} date={date} today={TODAY} demo={hasDemoData} onTask={editTask} onAdd={()=>openModal('photo')} onView={setViewedEvidence} onDelete={deleteInspection} onReturnToday={()=>selectDate(TODAY)} onIssues={()=>openTools('issues')}/>}
      </>}
      {mode==='progress'&&<div className="alerts-section"><h3><AlertTriangle size={16}/>计划与待核对<span>{alerts.length}</span></h3>{alerts.length?alerts.slice(0,3).map((a,i)=><button key={i} className="alert-item" onClick={()=>selectRoom(a.room.id)}><strong>{a.room.name}</strong><span>{a.title}</span><small>截至 {alertDate}</small></button>):<div className="no-alert"><CheckCircle2 size={17}/>暂无已知滞后任务</div>}</div>}
    </aside>
    </>}
    {!library.ready&&<div className="workspace-restoring" role="status"><LoaderCircle className="spin" size={19}/><span>正在恢复已保存的工作区…</span></div>}
    {toast&&<div role="status" className="toast"><CheckCircle2 size={17}/>{toast}</div>}
    {guideOpen&&room&&<ProjectGuide model={model} room={room} onAction={guideAction} onClose={closeGuide}/>}
    {facadeDemoOpen&&<FacadeDemo onClose={()=>setFacadeDemoOpen(false)}/>}
    {toolsOpen&&<ProjectTools model={model} persistence={{label:saveLabel,error:library.error,busy:library.saving||libraryAction||!library.ready,onSave:()=>void libraryOperation(library.flush,'项目已保存。').catch(()=>{})}} initialRoomId={selected??undefined} tab={toolsTab} onTabChange={setToolsTab} onChange={changePracticalModel} onClose={()=>setToolsOpen(false)} onLocate={locateToolRoom} onCreate={createPublicCase} onFacade={()=>{setToolsOpen(false);setFacadeDemoOpen(true);}}/>}
    {assistantOpen&&<DesignAssistant model={model} aiConfigured={health.design} onApply={applyFurnishedModel} onClose={closeAssistant}/>}
    {structureOpen&&<StructureEditor model={{...model,meta:{...model.meta,layoutReviewPending:true}}} initialWallId={model.openings.find(o=>o.id===selectedOpening)?.wallId} initialRoomId={selected??undefined} onSave={next=>{setModel(next);setInteriorRoom(null);setSelectedOpening(null);setToast('结构已更新，尺寸与家具布局已重新复核；可从管理页查看结果。')}} onClose={()=>setStructureOpen(false)}/>}
    {inspectionOpen&&room&&<InspectionDialog model={model} room={room} aiConfigured={health.vision} today={TODAY} onSave={saveInspection} onClose={closeInspection}/>}
    {viewedEvidence&&room&&<InspectionEvidenceViewer key={viewedEvidence.id} room={room} evidence={viewedEvidence} onClose={closeEvidence}/>}
    {modal&&<div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget&&!busy)setModal(null)}}><section ref={modalRef} tabIndex={-1} className={`modal ${modal==='import'?'wide':''}`} role="dialog" aria-modal="true" aria-label={modal==='import'?'导入户型图':'项目设置'}><div className="modal-heading"><div><h2>{modal==='import'?'从一张图纸，开始设计。':'项目设置'}</h2><p>{modal==='import'?'上传户型图，确认尺度，建立可编辑的三维空间。':'修改项目名称与全屋尺度。'}</p></div><button className="icon-button" aria-label="关闭" disabled={busy} onClick={()=>setModal(null)}><X size={21}/></button></div>
      {modal==='import'&&(planCandidate?<PlanRecognitionReview model={planCandidate} sourceImage={planPreview} busy={busy} onBack={()=>{setPlanCandidate(null);setError('')}} onApply={()=>void adoptPlan()}/>:<>
        <fieldset className="ai-model-mode" disabled={busy}><legend>希望怎样建立你的家？</legend><div className="ai-mode-options">
          <button type="button" aria-pressed={effectivePlanMode==='rebuild'} disabled={!health.vision||busy} onClick={()=>setPlanMode('rebuild')}><strong><Sparkles size={15}/>AI 自主重建</strong><span>结合原图，自主规划空间与结构。</span></button>
          <button type="button" aria-pressed={effectivePlanMode==='assist'} disabled={!health.vision||busy} onClick={()=>setPlanMode('assist')}><strong><Pencil size={15}/>AI 辅助校正</strong><span>保留结构，核对空间用途。</span></button>
          <button type="button" aria-pressed={effectivePlanMode==='local'} disabled={busy} onClick={()=>setPlanMode('local')}><strong><ScanLine size={15}/>本地识别</strong><span>图片留在本机，提取初步结构。</span></button>
        </div><p className="ai-import-privacy">{effectivePlanMode==='local'?'当前仅使用本地识别，户型图不发送至模型服务。':effectivePlanMode==='rebuild'?'已接入千问：点击生成后，发送原图与空间名称摘要，由 AI 重新建模和规划。':'已接入千问：点击生成后，发送原图、编号结构图与识别摘要，辅助核对空间用途。'}{!health.vision&&' 配置视觉模型后可启用 AI 重建。'}</p></fieldset>
        <div className="import-grid">
          <div className={`dropzone ${planPreview?'has-preview':''}`} role="button" aria-label="选择户型图片" tabIndex={busy?-1:0} aria-disabled={busy} onKeyDown={e=>{if(!busy&&(e.key==='Enter'||e.key===' ')){e.preventDefault();inputPlan.current?.click();}}} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();void choosePlan(e.dataTransfer.files[0])}} onClick={()=>{if(!busy)inputPlan.current?.click()}}>{planPreview?<img src={planPreview} alt="待解析户型图"/>:<><ScanLine size={42}/><strong>拖入户型图，或点击选择</strong><span>PNG / JPG / WEBP，最大 10MB</span></>}<input ref={inputPlan} type="file" disabled={busy} accept="image/png,image/jpeg,image/webp" onChange={e=>void choosePlan(e.target.files?.[0])}/></div>
          <div className="import-options">
            <label className="field-label plan-engine-field">初步识别方式<select value={planEngine} disabled={busy} onChange={e=>setPlanEngine(e.target.value as PlanEngine)}><option value="auto">自动选择（推荐）</option><option value="neural" disabled={!health.planNeural}>神经模型精细识别{health.planNeural?'':'（未就绪）'}</option><option value="classic">基础线条识别</option></select></label>
            <label className="field-label">外墙中心线总宽度（米）<input type="number" disabled={busy} min="2" max="100" step="0.1" value={realWidth} onChange={e=>setRealWidth(Number(e.target.value))}/></label>
            <label className="field-label">房屋层高（米）<input type="number" disabled={busy} min="2" max="6" step="0.1" value={height} onChange={e=>setHeight(Number(e.target.value))}/></label>
            <details className="note-box plan-engine-note ai-engine-details"><summary><strong>{planEngine==='classic'?'基础线条 · 适合清晰结构图':health.planNeural?'CubiCasa 模型已就绪':health.planWeights?'模型尚未就绪':'模型权重尚未安装'}</strong><ChevronDown size={13}/></summary><p>{planEngine==='classic'?'通过图像线条提取墙体与房间轮廓，门窗可在识别后人工补充。':planEngine==='neural'?'使用本地专用模型识别墙体、房间、门与窗，生成可编辑结构。':'清晰闭合结构图使用基础几何识别，其他图使用本地专用模型；模型未就绪或失败时回退，并展示实际方式。'}</p><p>图片需清晰、边界完整。复杂装饰、尺寸文字、细墙仍可能漏检；生成后请核对空间、门窗与实际比例。</p>{!health.online&&<p className="plan-service-note">本地算法服务未连接，请启动服务后识别。</p>}</details>
            <label className="field-label ai-style-label">家具与材质初稿<select value={planStyle} disabled={busy} onChange={e=>setPlanStyle(e.target.value as DesignBrief['style'])}><option value="warm">温暖现代</option><option value="natural">自然原木</option><option value="minimal">清爽极简</option><option value="industrial">沉稳工业</option></select></label>
            <button className="button secondary" disabled={busy} onClick={async()=>{try{const r=await fetch('/demo-plan.png');const b=await r.blob();await choosePlan(new File([b],'示例户型.png',{type:'image/png'}));}catch{setError('示例图加载失败')}}}><FileImage size={16}/>使用示例户型图</button>
          </div>
        </div>
        {busy&&<div className="plan-recognition-progress" role="status"><LoaderCircle className="spin" size={18}/><div><strong>{effectivePlanMode==='rebuild'?'正在识别图纸、由 AI 重建空间并检查结构…':effectivePlanMode==='assist'?'正在提取结构，并由 AI 对照图纸核对…':planUsesNeural?'正在识别墙体、房间、门窗…':'正在提取墙体线条与房间轮廓…'}</strong><p>完成后先预览模型与家具初稿，再保存为独立项目。{effectivePlanMode!=='local'?'AI 重建涉及坐标与结构校验，复杂图纸可能需要重新修正候选。':'首次加载本地模型可能较慢。'}</p></div></div>}
        <div className="modal-footer"><span>外墙总宽度决定尺度；AI 建模仍需核对图纸与实际测量。</span><button className="button primary" disabled={!health.online||!planFile||busy||(planEngine==='neural'&&!health.planNeural)||!(realWidth>=2&&realWidth<=100&&height>=2&&height<=6)} onClick={()=>void parsePlan()}>{busy?<LoaderCircle className="spin" size={17}/>:<Box size={17}/>} {busy?'识别并建模中':effectivePlanMode==='rebuild'?'AI 重建并预览':'生成模型并预览'}</button></div>
      </>)}
      {modal==='settings'&&<><label className="field-label">项目名称<input value={modelName} onChange={e=>setModelName(e.target.value)}/></label><label className="field-label">房屋层高（米）<input type="number" min="2" max="6" step=".1" value={height} onChange={e=>setHeight(Number(e.target.value))}/></label><div className="note-box"><p>当前户型：{model.width.toFixed(1)} × {model.depth.toFixed(1)} m。尺度改变请重新导入户型图。门窗开口可在“校正结构”中补充。</p></div>{model.warnings.map((w,i)=><p className="field-hint" key={i}>{w}</p>)}<div className="modal-footer"><span>门窗或家具超出新层高时，请先校正或重新生成方案。</span><button className="button primary" disabled={!modelName.trim()||height<2||height>6||model.openings.some(o=>(o.sill??0)+o.height>height)||(model.furniture??[]).some(f=>f.size[1]>height-.03)} onClick={()=>{setModel(m=>({...m,name:modelName.trim(),height,walls:m.walls.map(w=>({...w,height}))}));setModal(null);setToast('项目设置已更新')}}><Check size={16}/>保存设置</button></div></>}
      {error&&<div className="form-error" role="alert"><AlertTriangle size={16}/>{error}</div>}
    </section></div>}
  </div>;
}
