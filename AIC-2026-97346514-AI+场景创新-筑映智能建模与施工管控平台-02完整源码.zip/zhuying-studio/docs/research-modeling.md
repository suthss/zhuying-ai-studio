# 户型图与室内照片建模：来源核实与第一版取舍

核实日期：2026-10-04。仅阅读 GitHub 原作者仓库、许可证、依赖文件及论文；未执行第三方代码，未下载模型或大数据集。

## 借鉴来源

| 原作者项目 | 已核实能力 | 许可证与依赖 | 第一版借鉴点与限制 |
| --- | --- | --- | --- |
| [FloorplanToBlender3d](https://github.com/grebtsew/FloorplanToBlender3d) | 用户型图片生成 Blender 三维模型，提供图像检测、模型生成及服务器示例。检测代码包含阈值、形态学、轮廓、连通域及门窗模板特征匹配。 | [GPL-3.0](https://github.com/grebtsew/FloorplanToBlender3d/blob/master/license)；README 指定 Blender > 2.93、Python >= 3.8；[依赖](https://github.com/grebtsew/FloorplanToBlender3d/blob/master/requirements.txt)固定 OpenCV 4.2、NumPy 1.22 等旧版本。 | 借鉴“图片→二维结构→几何拉伸”的分层思路。本项目独立实现，不拷贝其源代码。作者提示大图须缩小、非指定版本可能需要修改；它并不提供装修时序识别。 |
| [CubiCasa5k](https://github.com/CubiCasa/CubiCasa5k) | 5000 张户型图、80 余类对象；多任务模型输出语义分割与热图，并提供训练、评估示例。 | 网络代码[CC BY-NC 4.0](https://github.com/CubiCasa/CubiCasa5k/blob/master/LICENSE)，原始数据[CC BY-NC-SA 4.0](https://doi.org/10.5281/zenodo.2613548)；Python 3.6.5、PyTorch 1.0、CUDA、OpenCV 3.1；[依赖](https://github.com/CubiCasa/CubiCasa5k/blob/master/requirements.txt)。 | 借鉴墙体、房间、门窗的标签结构和“分割→矢量化”思路；后续可做研究基准。不是可直接用于任何商业产品的无约束素材，也不包含同套房屋的装修照片序列。README 所述完整 LMDB 约 105 GB，首版无需下载。 |
| [Floor-SP](https://github.com/woodfrog/floor-sp) | 输入对齐全景 RGBD 扫描；先预测房间、角点/边，再用逐房间最短路径与坐标下降生成二维房间多边形；合并近共线边和近角点。 | [MIT](https://github.com/woodfrog/floor-sp/blob/master/LICENSE)；Python 3.5、PyTorch 0.4、Mask R-CNN；[依赖](https://github.com/woodfrog/floor-sp/blob/master/requirements.txt)。 | 借鉴邻接一致性、轮廓闭合、共线边合并的几何约束。它不是普通户型图片或单张手机照片直接重建系统，不运行其旧环境。 |

Floor-SP 的输入范围另外经[原作者论文](https://jcchen.me/floor-sp/assets/floor_sp.pdf)核实。CubiCasa5k 对象与数据规模经[原作者论文](https://arxiv.org/abs/1904.01920)交叉核实。

## 第一版独立实现建议

1. **清晰单层户型图**：灰度与二值化，提取足够长/厚的横竖墙体候选；过滤文字噪声；合并近共线线段；保留不确定结果供人工修正。首版明确以正交户型为主要输入，不宣称通用 CAD 解析能力。
2. **比例标定与拓扑**：用户输入一段已知长度、墙高和墙厚；坐标换算到米；端点吸附、闭环检查、房间提取；记录构件唯一编号、门窗开口和几何来源。缺少尺度时必须标注“估计尺度”。
3. **参数化三维生成**：按墙段生成带开口的墙体，按房间多边形生成地板，门窗使用独立构件；保留二维结构 JSON，三维网格作为渲染输出。墙高/厚/材质变更后重新生成模型；屋顶隐藏、墙体降高、俯视与斜视用于室内观察。
4. **照片作为证据**：上传时绑定房间/构件和日期；保存照片与人工确认的工序状态。可以接入视觉模型产生待复核建议；未接入模型时应明示人工标注，不伪称已完成 AI 识别。普通单张照片不提供可靠绝对尺寸或隐藏结构，因此不直接改变几何骨架。
5. **进度计算**：任务绑定构件，按计划日期与已确认状态计算逾期；各工序权重由用户设定，缺证据显示信息不足。模拟任务需明确标识；照片可见完成状态与验收通过分开记录。

## 验证建议

- 几何：使用已知尺寸的自制户型作为可复现样例，检查墙段提取、房间数、开口、单位与闭环；再用用户提供的真实图检验泛化，避免只在一张样例上报告性能。
- 可视化：检查模型旋转、缩放、点选构件、层高变更、屋顶/墙高模式与导出能否保持编号及关联。
- 进度：测试未到期、逾期未完成、已完成、缺少照片与人工修改后的更新。
- 研究定位：首版是几何规则算法与可编辑三维原型；视觉模型及训练评估是后续阶段。没有配对的真实施工计划与连续照片，不能声称已验证真实延期预测效果。
