const stageLabels = {
  not_started: '未开始',
  in_progress: '施工中',
  complete: '已完成',
  unknown: '待复核',
};

const stageRanks = { not_started: 0, in_progress: 1, complete: 2 };
const stages = new Set(Object.keys(stageLabels));
const changes = new Set(['advanced', 'unchanged', 'regressed', 'uncertain']);

export const WORK_TYPES = Object.freeze([
  { id: 'electrical', label: '水电施工', shortLabel: '水电', description: '管线铺设、线路安装与水电验收' },
  { id: 'waterproof', label: '防水施工', shortLabel: '防水', description: '防水涂层施工、闭水试验与验收' },
  { id: 'masonry', label: '泥瓦施工', shortLabel: '泥瓦', description: '砌筑、找平与瓷砖铺贴' },
  { id: 'carpentry', label: '木工施工', shortLabel: '木工', description: '吊顶、木作基层与定制柜体安装' },
  { id: 'floor', label: '地面铺设', shortLabel: '地面', description: '地板或地面饰材铺设与收口' },
  { id: 'wall', label: '墙面涂饰', shortLabel: '墙面', description: '墙面基层处理、涂饰与饰面安装' },
].map(Object.freeze));
const workTypes = new Set(WORK_TYPES.map(work => work.id));

export function stageLabel(stage) {
  return stageLabels[stage] ?? stageLabels.unknown;
}

/** An absent optional trade is inactive; legacy floor/wall tasks remain active. */
export function activeWorkTypes(room) {
  return WORK_TYPES.map(work => work.id).filter(type => room.tasks?.[type] && room.tasks[type].enabled !== false);
}

/** Equal-weight stage bounds, never a measured quantity or construction volume. */
export function confirmedProgress(room, asOfDate) {
  const current = asOfDate === undefined ? room : roomAtDate(room, asOfDate);
  const types = activeWorkTypes(current);
  const ranks = types.map(type => stageRanks[current.tasks[type].stage]);
  const knownRanks = ranks.filter(Number.isFinite);
  const total = types.length, known = knownRanks.length;
  const rankSum = knownRanks.reduce((sum, rank) => sum + rank, 0);
  return {
    percent: known ? rankSum / (total * 2) * 100 : null,
    upperPercent: total ? (rankSum / 2 + total - known) / total * 100 : null,
    coverage: total ? known / total : 0,
    completed: knownRanks.filter(rank => rank === 2).length,
    known,
    unknown: total - known,
    total,
  };
}

export function validCalendarDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

/** Calendar dates are compared without relying on the host timezone. */
export function isDelayed(task, asOfDate) {
  const actual = stageRanks[task.stage], planned = stageRanks[task.plannedStage];
  return task.enabled !== false && Number.isFinite(actual) && Number.isFinite(planned)
    && validCalendarDate(task.dueDate) && validCalendarDate(asOfDate)
    && task.dueDate < asOfDate && planned > actual;
}

export function getRoomAlerts(room, asOfDate) {
  if (!validCalendarDate(asOfDate)) return [];
  return activeWorkTypes(room).flatMap(type => {
    const task = room.tasks[type], label = WORK_TYPES.find(work => work.id === type).shortLabel;
    if (isDelayed(task, asOfDate)) return [{ workType: type, title: `${label}施工进度滞后`, kind: 'delayed' }];
    if (task.stage === 'unknown' && Number.isFinite(stageRanks[task.plannedStage]) && validCalendarDate(task.dueDate) && task.dueDate < asOfDate) {
      return [{ workType: type, title: `${label}已过计划日期，待补充确认记录`, kind: 'missing_evidence' }];
    }
    return [];
  });
}

/** Newest valid calendar date wins; the last appended observation wins ties. */
export function latestEvidence(evidence, workType, asOfDate) {
  if (asOfDate !== undefined && !validCalendarDate(asOfDate)) return undefined;
  let latest;
  for (const record of evidence ?? []) {
    if (!record.confirmed || record.workType !== workType || !validCalendarDate(record.date) || (asOfDate !== undefined && record.date > asOfDate)) continue;
    if (!latest || record.date >= latest.date) latest = record;
  }
  return latest;
}

/** Replay confirmed evidence only; plans, activation and authored design survive. */
export function roomAtDate(room, date) {
  if (!validCalendarDate(date)) throw new RangeError('回放日期必须是有效的 YYYY-MM-DD 日历日期。');
  const copy = structuredClone(room);
  for (const type of WORK_TYPES.map(work => work.id)) {
    if (copy.tasks[type]) copy.tasks[type].stage = latestEvidence(copy.evidence, type, date)?.stage ?? 'unknown';
  }
  copy.progress = confirmedProgress(copy).percent ?? 0;
  return copy;
}

const shortText = (value, max = 160) => typeof value === 'string' && value.trim().length > 0 && value.length <= max;
const summaryText = value => typeof value === 'string' && value.length <= 12000;
const object = value => !!value && typeof value === 'object' && !Array.isArray(value);
function imageBytes(value) {
  if (typeof value !== 'string' || value.length > 15 * 1024 * 1024) return -1;
  const match = /^data:image\/(?:png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(value);
  if (!match || match[1].length % 4 !== 0) return -1;
  const encoded = match[1];
  return encoded.length / 4 * 3 - (encoded.endsWith('==') ? 2 : encoded.endsWith('=') ? 1 : 0);
}
const evidenceFailure = () => { throw new Error('施工记录格式无效，请检查日期、照片、工序及历史对比引用。'); };

/** Shared by import and inspection mutations; it never edits imported metadata. */
export function validateEvidenceRecords(records) {
  if (!Array.isArray(records) || records.length > 1000) evidenceFailure();
  const ids = new Map();
  for (let index = 0; index < records.length; index++) {
    const record = records[index];
    if (!object(record) || !shortText(record.id) || ids.has(record.id) || !validCalendarDate(record.date) || !workTypes.has(record.workType)
      || !stages.has(record.stage) || (record.aiStage !== undefined && !stages.has(record.aiStage)) || !summaryText(record.summary)
      || !shortText(record.source) || typeof record.confirmed !== 'boolean' || imageBytes(record.image) < 0) evidenceFailure();
    ids.set(record.id, { record, index });
    let count = 1, bytes = imageBytes(record.image);
    if (record.photos !== undefined) {
      if (!Array.isArray(record.photos) || record.photos.length < 1 || record.photos.length > 6) evidenceFailure();
      const photoIds = new Set();
      count = record.photos.length;
      bytes = 0;
      for (const photo of record.photos) {
        if (!object(photo) || !shortText(photo.id) || photoIds.has(photo.id) || !shortText(photo.viewpoint, 240) || imageBytes(photo.image) < 0) evidenceFailure();
        photoIds.add(photo.id);
        bytes += imageBytes(photo.image);
      }
      if (record.image !== record.photos[0].image) evidenceFailure();
    }
    if (bytes > 30 * 1024 * 1024) evidenceFailure();
    if (record.observations !== undefined) {
      if (!Array.isArray(record.observations) || record.observations.length > count) evidenceFailure();
      const seen = new Set();
      for (const observation of record.observations) {
        if (!object(observation) || !Number.isInteger(observation.photoIndex) || observation.photoIndex < 0 || observation.photoIndex >= count
          || seen.has(observation.photoIndex) || !summaryText(observation.summary)) evidenceFailure();
        seen.add(observation.photoIndex);
      }
    }
  }
  for (let index = 0; index < records.length; index++) {
    const record = records[index], comparison = record.comparison;
    if (comparison === undefined) continue;
    if (!object(comparison) || !shortText(comparison.previousEvidenceId) || !validCalendarDate(comparison.previousDate)
      || !summaryText(comparison.summary) || !changes.has(comparison.change) || !shortText(comparison.source)) evidenceFailure();
    const previous = ids.get(comparison.previousEvidenceId);
    if (!previous || !previous.record.confirmed || previous.record.workType !== record.workType || previous.record.date !== comparison.previousDate
      || previous.record.date > record.date || (previous.record.date === record.date && previous.index >= index)) evidenceFailure();
  }
  return records;
}

function refreshTask(room, type) {
  room.tasks[type] ??= { stage: 'unknown', plannedStage: 'unknown', dueDate: '', enabled: true };
  room.tasks[type].stage = latestEvidence(room.evidence, type)?.stage ?? 'unknown';
  room.progress = confirmedProgress(room).percent ?? 0;
  return room;
}

/** Append a checked record; an older upload cannot replace a later observation. */
export function applyInspection(room, evidence) {
  const records = [...(room.evidence ?? []), evidence];
  validateEvidenceRecords(records);
  const copy = structuredClone(room);
  copy.evidence = structuredClone(records);
  // Draft observations are not facts. In particular, adding the first draft
  // to a legacy room must not erase its current manually recorded task value.
  if (!evidence.confirmed && !latestEvidence(copy.evidence, evidence.workType)) return copy;
  return refreshTask(copy, evidence.workType);
}

/** Removal updates the affected trade and invalidates comparisons to that record. */
export function removeInspection(room, id) {
  const copy = structuredClone(room);
  const removed = copy.evidence?.find(record => record.id === id);
  if (!removed) return copy;
  copy.evidence = copy.evidence.filter(record => record.id !== id);
  for (const record of copy.evidence) if (record.comparison?.previousEvidenceId === id) delete record.comparison;
  if (!removed.confirmed && !latestEvidence(copy.evidence, removed.workType)) return copy;
  return refreshTask(copy, removed.workType);
}
