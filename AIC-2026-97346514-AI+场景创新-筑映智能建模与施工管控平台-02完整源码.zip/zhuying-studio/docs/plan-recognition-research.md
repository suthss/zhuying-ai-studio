# 户型识别方案核查

核查日期：2026-10-04。以下区分仓库说明、代码阅读结论和本项目建议；本次研究没有执行这些仓库的代码，也没有复现其论文准确率。

后续接入状态（2026-10-05）：本项目已在本机加载真实 CubiCasa 官方权重，使用适配后的网络和独立矢量化运行推理。下文“未执行／未下载”描述的是最初方案核查阶段；当前实现、复现命令与剩余限制见 [算法说明](../backend/ALGORITHM.md)，实际运行记录存 `artifacts/recognition-*.json`。未复现上游论文准确率，也未把十张自绘回归图或两张无真值公开示例当成真实户型泛化评测。

## 结论

优先接入 **CubiCasa5k 官方预训练多任务模型**，将原始 PNG/JPEG 的墙、房间、门窗预测转成项目的可编辑几何。Yytsi 的轻量模型虽然容易安装，但它在渲染训练输入前删除了 SVG 中的家具、洁具、文字、尺寸线等内容，与用户上传的普通图片差异较大；不能据其验证集 mIoU 宣称普通户型图识别更好。

| 方案 | 已核实的输入与输出 | 现有 Windows CPU 环境 | 本项目用途 |
|---|---|---|---|
| [CubiCasa/CubiCasa5k](https://github.com/CubiCasa/CubiCasa5k) | 输入为原始 PNG 图片；21 个热图通道、12 类房间、11 类图标，含独立门/窗类别 | 官方演示依赖旧 PyTorch/CUDA；网络本身是标准 PyTorch 层，可适配 CPU 并实测 | 首选结构识别模型 |
| [Yytsi/floorplan-to-3d](https://github.com/Yytsi/floorplan-to-3d) | 官方接口输入 SVG；四类 floor/wall/door/window，输出结构外环与洞 | ResNet34-UNet，约 98 MB，官方支持 CPU；PNG/JPEG 需另写适配 | 对清理后的结构图做辅助候选 |
| [Cornell-VAILab/Raster2Seq](https://github.com/Cornell-VAILab/Raster2Seq) | PNG/JPEG 经 Pillow 读入；生成带语义的房间多边形序列，CubiCasa 版本含门窗 | 官方验证环境为 Linux/CUDA，并需编译 deformable attention；约 1.45 GB checkpoint | 后续服务器方案，暂不作为首轮本机路线 |
| [rbg-research/Floor-Plan-Detection](https://github.com/rbg-research/Floor-Plan-Detection) | 原图识别加超分辨率；实际沿用 CubiCasa 官方 checkpoint | README 指出核心推理有基本 CPU 回退，但部分脚本仍使用 .cuda() 与 Linux 路径 | 参考超分辨率及 CPU 适配，不是独立新模型 |
| [zlzeng/DeepFloorplan](https://github.com/zlzeng/DeepFloorplan) | JPEG 原图、512×512；房间类型与墙/开口两任务，门窗合并类别 | 官方 Python 2.7 / TensorFlow 1.10.1；当前 Python 3.12/PyTorch 环境需明显移植 | 本轮不优先 |

## 官方 CubiCasa 原图模型

[官方图像加载器](https://github.com/CubiCasa/CubiCasa5k/blob/master/floortrans/loaders/svg_loader.py)读取 `F1_scaled.png` 或 `F1_original.png`，转换 RGB，归一化到 `[-1, 1]`；SVG 用于标注，而不是识别时必需的输入。PNG/JPEG 经相同 RGB 预处理即可输入卷积网络。

[官方示例](https://github.com/CubiCasa/CubiCasa5k/blob/master/samples.ipynb)在加载前把最后卷积和上采样层改为 44 通道。12 类房间包含厨房、客厅、卧室、浴室、玄关、储藏间等；11 类图标包含独立门窗及部分固定设施。类别候选仍应通过用户确认，不保证中国户型风格的语义标签正确。

[官方几何后处理](https://github.com/CubiCasa/CubiCasa5k/blob/master/floortrans/post_prosessing.py)组合墙角热图、墙线、图标、门窗和房间分割，再合并同类房间网格。此代码依赖旧版本 NumPy/Shapely 等 API；迁移时需验证，而不能直接把全部研究环境依赖安装进现有后端。

### 权重与构建注意

- [官方 README 的权重页](https://drive.google.com/file/d/1gRB7ez1e4H7a9Y09lLqRuna0luZO5VRK/view)：2026-10-04 HTTP 200，标题 `model_best_val_loss_var.pkl`。
- [同一官方文件的下载地址](https://drive.usercontent.google.com/download?id=1gRB7ez1e4H7a9Y09lLqRuna0luZO5VRK&export=download&confirm=t)：HEAD 验证 HTTP 200，`application/octet-stream`，`Content-Length: 208651193`，约 209 MB。研究阶段只读取了响应元数据，未下载/加载。
- [官方网络代码](https://github.com/CubiCasa/CubiCasa5k/blob/master/floortrans/models/hg_furukawa_original.py)可以直接构建最终 44 通道网络；`get_model()` 会额外初始化姿态估计权重，而最终 floorplan checkpoint 已覆盖全部参数。适配器应直接构造最终网络，避免再下载约 69 MB 的 `model_1427.pth`。
- 实际加载应使用 `map_location='cpu'`，优先验证 `weights_only=True`，检查张量形状与完整 state dict；不应为加载错误无条件开启 pickle 执行。

以上最后两点是本项目的移植建议，CPU 延迟与识别效果必须以实际图片推理为准。

本机已有 Python 3.12、PyTorch 2.7.1 与 torchvision 0.22.1，支持 CUDA 11.8。接入时建议先比较长边 512/768 的等比例缩放，保留逆变换；这是本项目的速度/细节取舍，并非官方指定的推理分辨率。GPU 可用时优先 GPU，CPU 限制线程并缓存已加载网络。不要把原图硬拉成正方形；若补边应在还原坐标前移除。四旋转平均通常要四次网络前向，宜作为精细模式独立实测，不能默认把 GPU 延迟套用到 CPU。

## Yytsi 的适用范围

[源码 svg_render.py](https://github.com/Yytsi/floorplan-to-3d/blob/main/src/buildingcv/svg_render.py)通过 SVG `class` 删除家具、固定设施、文字、尺寸等子树，再 rasterize。普通 PNG 无这些语义标签，无法等价清理。[官方接口](https://github.com/Yytsi/floorplan-to-3d/blob/main/server/main.py)也把上传内容保存为 `.svg`。

[PolygonExtractor](https://github.com/Yytsi/floorplan-to-3d/blob/main/src/buildingcv/extract_polygons.py)执行逐类闭运算、CCOMP 轮廓/洞提取、Douglas–Peucker 简化和小区域过滤，只导出 wall/door/window。`floor` 是默认背景，并没有独立室内区域、房间实例或用途分类，因此还需拓扑分区。

[模型卡](https://huggingface.co/Yytsi/floorplan-to-3d-walls)自报验证 mIoU 0.983；其局限包括 Nordic CAD 风格、512 分辨率和细墙漏检。该数值不是用户 PNG/JPEG 的实测准确率。

[官方文件清单](https://huggingface.co/Yytsi/floorplan-to-3d-walls/tree/main)与 Hugging Face API 核实：

- `best.safetensors`：97,851,168 bytes。
- SHA256：`d7f6a0fd06e2931aecfc8c4849192c5e153701578026efc78d9a6246731a8d6c`。
- revision：`68843a3ab7b12aa03b23c36f955a0d8099b4e2ee`。
- 输入：RGB、512×512、保留长宽比 letterbox、ImageNet normalization，ResNet34 编码器。
- [权重下载](https://huggingface.co/Yytsi/floorplan-to-3d-walls/resolve/main/best.safetensors)、[配置文件](https://huggingface.co/Yytsi/floorplan-to-3d-walls/blob/main/config.yaml)。

## Raster2Seq 和其他方案

[Raster2Seq 官方 README](https://github.com/Cornell-VAILab/Raster2Seq)说明了房间语义多边形与自回归角点生成，提供预训练模型，CubiCasa checkpoint 的基准 RoomF1 为 88.7。[predict.py](https://github.com/Cornell-VAILab/Raster2Seq/blob/master/predict.py)明确用 Pillow 读取输入图片，因此满足真实 raster 输入要求。

[官方 Hugging Face 仓库](https://huggingface.co/haopt/Raster2Seq)可下载 `cubicasa5k/checkpoint.pth`；API 核实为 1,452,141,664 bytes，SHA256 `f7c0ef9379aa8cf11349da8b2179214e0d495af758383984a2361a1309aab3b7`，revision `c9a9c439ba66594dab701b77b7df52a5f75a5fce`。更直接的房间多边形输出值得后续比较，但官方 Linux/CUDA 的扩展编译要求使它不适合本轮 Windows CPU 快速落地。

[rbg README](https://github.com/rbg-research/Floor-Plan-Detection)提供原图→超分辨率→CubiCasa→Blender 流程，官方权重 ID 与 CubiCasa 一致。README 自己说明脚本路径与 checkpoint wiring 尚未完全对齐。超分辨率可能改善低分辨率图片，但其额外耗时和门窗效果应单独测；不把论文某个相对改善数值套到本项目。

[DeepFloorplan demo.py](https://github.com/zlzeng/DeepFloorplan/blob/master/demo.py)可以读取 JPEG，但使用 Python 2 API、SciPy 已删除的图像函数和 TensorFlow Session；官方预训练下载链接为 SharePoint。它把门窗共用开口类别，最终仍需区分；移植成本高于 CubiCasa。

## 权利来源

- [CubiCasa5k LICENSE](https://github.com/CubiCasa/CubiCasa5k/blob/master/LICENSE)为 **CC BY-NC 4.0**。该声明对应仓库代码；原始训练数据的 Zenodo 记录 DOI:10.5281/zenodo.2613548 另标为 CC BY-NC-SA 4.0。应分别核对并保留适用的署名、修改与许可条件。[CC 官方说明](https://creativecommons.org/licenses/by-nc/4.0/)可核对这些要求。
- [Yytsi 代码 LICENSE](https://github.com/Yytsi/floorplan-to-3d/blob/main/LICENSE)和其模型卡标 MIT；[Raster2Seq 代码](https://github.com/Cornell-VAILab/Raster2Seq/blob/master/LICENSE)与模型卡亦标 MIT。它们用 CubiCasa 数据训练，模型卡 MIT 不应被写成训练数据也可任意商业使用。这里未判定训练后权重的派生权利问题；商业化需另外厘清来源与许可。
- [rbg LICENSE](https://github.com/rbg-research/Floor-Plan-Detection/blob/main/LICENSE)标 MIT，但其部分 Blender 工具来自 GPL 的 FloorplanToBlender3d；不整体照搬并假定所有内容均是 MIT。
- [DeepFloorplan LICENSE](https://github.com/zlzeng/DeepFloorplan/blob/master/LICENSE)为 GPL-3.0。

本项目接入材料的具体来源和许可说明见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。

## 本项目建议的接入和评估方式

以下为工程建议，尚不是实验结果。

1. 对原图清除透明背景、纠正方向、保留长宽比，保留坐标逆变换与用户尺寸标定。
2. 用 CubiCasa 原图网络得到房间/墙/图标概率及角点热图；限制最大输入长边和线程，先一次旋转推理，复杂图再选择四旋转增强。
3. 结合图像中的厚墙证据去掉孤立错误构件；修正短裂缝和共享墙端点，不跨越真实门口强行补墙。
4. 提取真实多边形而不是每个区域的 bounding rectangle，保留凹形房间。门窗投影到最近的有效父墙并校验范围、重叠、宽度；不能放到墙上则保留待核对提示。
5. 将候选叠加在原图上让用户确认尺寸、房间用途和识别错误，再进入家具问答。低质量结果不悄悄生成演示户型。
6. 固定原图、家具丰富图、彩色营销图、低分辨率/旋转图、斜墙和凹形户型的回归样本，比较旧算法与新模型的房间个数、室内面积、墙轮廓和门窗位置。只在实测证据支持时声明提升。

