import type {HouseModel,WorkType} from './types';
export type IssueState='open'|'in_progress'|'review'|'closed';
export type IssueAction='create'|'begin'|'submit'|'close'|'return'|'reopen'|'comment'|'update';
export interface IssuePhoto {id:string;image:string;caption:string;source:'upload'|'inspection'|'public_case';captureDate:string|null;point?:[number,number]}
export interface IssueEvent {id:string;action:IssueAction;status:IssueState;date:string;at:string;actor:string;note:string;photos:IssuePhoto[];confirmed?:boolean}
export interface Issue {id:string;roomId:string;title:string;description:string;location:string;workType:WorkType;assignee:string;dueDate:string;createdDate:string;status:IssueState;mode:'actual'|'demonstration';events:IssueEvent[];orphaned?:boolean}
export interface IssueTracker {version:1;issues:Issue[]}
export interface IssueSummary {issues:Issue[];total:number;open:number;inProgress:number;review:number;closed:number;overdue:number}
export interface IssueContext {id?:string;eventId:string;date:string;at:string;actor?:string}
export interface WeeklyReport {schemaVersion:1;type:string;projectId:string;projectName:string;startDate:string;endDate:string;demonstration:boolean;summary:Omit<IssueSummary,'issues'>;issues:Issue[];activities:(IssueEvent&{issueId:string;title:string;roomId:string;mode:string})[];inspections:{roomId:string;roomName:string;id:string;date:string;workType:WorkType;stage:string;summary:string;photoCount:number}[];limits:string[]}
export const ISSUE_STATES:Record<IssueState,string>;
export function validateIssuePhotos(raw:unknown):IssuePhoto[];
export function validateIssueTracker(raw:unknown,model?:HouseModel):IssueTracker;
export function createIssue(model:HouseModel,input:{roomId:string;title:string;description:string;location:string;workType:WorkType;assignee:string;dueDate:string;photos:IssuePhoto[]},context:IssueContext&{id:string;actor:string}):IssueTracker;
export function transitionIssue(model:HouseModel,issueId:string,action:Exclude<IssueAction,'create'>,input:{actor:string;note:string;photos?:IssuePhoto[];confirmed?:boolean},context:IssueContext):IssueTracker;
export function issueSummary(model:HouseModel,asOf:string):IssueSummary;
export function createWeeklyReport(model:HouseModel,startDate:string,endDate:string):WeeklyReport;
export function weeklyMarkdown(report:WeeklyReport,roomNames?:Record<string,string>):string;
