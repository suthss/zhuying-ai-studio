import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { auditLayout, getFurnitureDimensionErrors, parseFurnitureDimensions, recordWallMeasurement, updateFurnitureDimensions } from './layout-audit.mjs';
import type { MeasurementRecord, MeasurementReview } from './layout-audit.mjs';
import type { FurnitureItem, HouseModel } from './types';
import './layout-audit.css';
import { localToday } from './calendar';

interface Props { model: HouseModel; onChange: (next: HouseModel) => void; onLocate: (roomId: string, openingId?: string) => void }
const STATUS: Record<MeasurementReview['status'], string> = { unmeasured: '待量测', unconfirmed: '待人工确认', geometry_changed: '墙段已变动 · 待重新核对', difference: '长度存在差异', checked: '已录实测核对', orphaned: '原墙段已删除' };
const FURNITURE: Record<string, string> = { sofa: '沙发', coffee_table: '茶几', tv_console: '电视柜', bed_double: '双人床', bed_single: '单人床', wardrobe: '衣柜', desk: '书桌', chair: '椅子', dining_table: '餐桌', kitchen_counter: '厨房操作台', sink_cabinet: '水槽柜', toilet: '马桶', shoe_cabinet: '鞋柜' };
const display = (value: number | null) => value === null ? '待核对' : `${value.toFixed(3)} m`;
const signed = (value: number | null) => value === null ? '待核对' : `${value >= 0 ? '+' : ''}${(value * 100).toFixed(1)} cm`;

export default function LayoutAuditPanel({ model, onChange, onLocate }: Props) {
  const audit = useMemo(() => auditLayout(model), [model]);
  const [wallId, setWallId] = useState(() => model.walls[0]?.id ?? '');
  const [filter, setFilter] = useState('all');
  const wall = model.walls.find(wall => wall.id === wallId) ?? model.walls[0];
  const row = audit.measurementReview.walls.find(row => row.wallId === wall?.id);
  const visibleIssues = audit.issues.filter(issue => filter === 'all' || issue.severity === filter);
  const currentRecords = audit.measurementReview.summary;
  const wallLabel = (id: string) => { const review=audit.measurementReview.walls.find(item=>item.wallId===id);const name=model.rooms.find(room=>room.id===review?.roomId)?.name;return `墙段 ${model.walls.findIndex(wall => wall.id === id) + 1}${name?` · ${name}`:''}`; };
  return <div className="layout-audit-panel">
    <div className="layout-audit-intro"><h3>实测与布局复核</h3><p>尺寸来源于当前模型；实测记录由人填写并确认。修改墙体、门窗或家具后，下面结果会自动重算。</p></div>
    <section className="layout-audit-section" aria-labelledby="layout-check-heading">
      <div className="layout-audit-heading"><h4 id="layout-check-heading">当前布局</h4><span>布局待复核</span></div>
      <p className="layout-audit-count" aria-live="polite">{audit.counts.conflicts} 项几何冲突 · {audit.counts.hints} 项现场核对提示 · {audit.counts.unknown} 项数据待核对</p>
      <p className="layout-audit-help">已检验 {audit.checked.furniture} 件家具、{audit.checked.walls} 段墙、{audit.checked.doors} 樘门。模型检查不能代替现场量测和通行验收。</p>
      <label className="layout-audit-filter">查看结果<select value={filter} onChange={event => setFilter(event.target.value)}><option value="all">全部结果</option><option value="conflict">几何冲突</option><option value="hint">现场核对提示</option><option value="unknown">数据待核对</option></select></label>
      {visibleIssues.length ? <ul className="layout-audit-issues">{visibleIssues.map(issue => <li key={issue.id}>
        <span className="layout-audit-kind">{issue.severity === 'conflict' ? '几何冲突' : issue.severity === 'hint' ? '预留提示' : '待核对'}</span>
        {issue.roomId ? <button type="button" onClick={() => onLocate(issue.roomId!, issue.openingId)} aria-label={`定位：${issue.message}`}>{issue.message}<span>查看模型</span></button> : <p>{issue.message}</p>}
      </li>)}</ul> : <p className="layout-audit-empty">{filter === 'all' ? '当前检测范围内未发现布局问题；家具实物尺寸、窗扇与完整通路仍需现场核对。' : '当前类别没有结果。'}</p>}
      <details className="layout-audit-scope"><summary>检测范围与预留假设</summary><p>检查旋转家具占地、多边形房间边界、墙体实体、家具相撞以及门从闭合到当前角度的门叶和扫掠范围。墙体检查按开口与家具高度切分。</p><p>门扫掠以不超过 2° 的分段计算。90° 备用开启、门宽外加 25 cm / 向内 85 cm 门口预留和布置器墙距属于提示。未检查窗扇扫掠、抽屉开启、电器散热、完整路线或法规通行宽度。</p></details>
    </section>
    <section className="layout-audit-section" aria-labelledby="layout-measure-heading">
      <div className="layout-audit-heading"><h4 id="layout-measure-heading">墙段实测记录</h4><span>{currentRecords.confirmedCurrentWalls} / {currentRecords.totalWalls} 段当前核对</span></div>
      <p className="layout-audit-help">沿模型墙段起点到终点记录长度。模型墙轴线与现场净空边线的量法可能不同，请在来源中注明。差值在 ±2 cm 内只作显示参考，不表示模型精确。</p>
      {audit.measurementReview.error && <p className="layout-audit-error" role="alert">{audit.measurementReview.error}</p>}
      <div className="layout-audit-walls" aria-label="选择待量测墙段">{audit.measurementReview.walls.map(item => <button type="button" key={item.wallId} aria-pressed={item.wallId === wall?.id} className={item.wallId === wall?.id ? 'selected' : ''} onClick={() => setWallId(item.wallId)}>
        <strong>{wallLabel(item.wallId)}</strong><span>{STATUS[item.status]}</span><small>模型 {display(item.modelLength)}{item.record ? ` · 实测 ${display(item.record.lengthMeters)} · 差 ${signed(item.deltaMeters)}` : ' · 实测待核对'}</small>
      </button>)}</div>
      {row?.roomId&&<button className="tools-text-button" type="button" onClick={()=>onLocate(row.roomId!)}>在模型中查看对应房间</button>}
      {wall && row && <MeasurementForm key={`${model.id}:${wall.id}`} model={model} wallId={wall.id} row={row} onChange={onChange} />}
      {!!audit.measurementReview.orphaned.length && <details className="layout-audit-orphans"><summary>保留的已删除墙段记录（{audit.measurementReview.orphaned.length} 条）</summary>{audit.measurementReview.orphaned.map(item => <p key={item.record!.id}><strong>{item.wallId} · 原墙段已删除</strong><span>{item.record!.date} · 实测 {display(item.record!.lengthMeters)} · {item.record!.source}</span>{item.record!.note && <span>{item.record!.note}</span>}</p>)}</details>}
    </section>
    <section className="layout-audit-section" aria-labelledby="layout-furniture-heading">
      <div className="layout-audit-heading"><h4 id="layout-furniture-heading">家具尺寸核对</h4><span>米 · 合法输入即时生效</span></div>
      <p className="layout-audit-help">先量实物再填写宽、深、高。当前录入值和几何检查不证明家具已实测；调整后保留冲突供复核。</p>
      {model.furniture?.length ? model.furniture.map(item => <FurnitureDimensionsEditor key={`${model.id}:${item.id}`} item={item} model={model} onChange={onChange} onLocate={onLocate} />) : <p className="layout-audit-empty">当前模型没有家具，可在设计问答中选择家具后核对。</p>}
    </section>
  </div>;
}

function MeasurementForm({ model, wallId, row, onChange }: { model: HouseModel; wallId: string; row: MeasurementReview; onChange: Props['onChange'] }) {
  const id = useId(), errorRef = useRef<HTMLParagraphElement>(null);
  const [length, setLength] = useState(''), [date, setDate] = useState(localToday), [source, setSource] = useState(''), [note, setNote] = useState('');
  const [confirmed, setConfirmed] = useState(false), [error, setError] = useState(''), [saved, setSaved] = useState(false);
  const resetConfirmation = () => { setConfirmed(false); setSaved(false); setError(''); };
  function save(event: React.FormEvent) {
    event.preventDefault();
    try {
      const record: Omit<MeasurementRecord, 'wallSnapshot'> = { id: `measurement-${crypto.randomUUID()}`, wallId, lengthMeters: length.trim() ? Number(length) : NaN, date, source, note, confirmed };
      onChange(recordWallMeasurement(model, record)); setError(''); setSaved(true); setConfirmed(false);
    } catch (e) { setError(e instanceof Error ? e.message : '请检查实测记录。'); queueMicrotask(() => errorRef.current?.focus()); }
  }
  return <form className="layout-audit-measure-form" onSubmit={save} noValidate>
    <p className="layout-audit-help">{row.record ? `最近记录：${row.record.date} · ${row.record.source} · ${row.record.confirmed ? '人工已确认' : '尚未确认'}。追加记录保留历史。` : '这段墙尚无实测记录，尺寸保持待核对。'}</p>
    {row.record?.note && <p className="layout-audit-record-note">最近备注：{row.record.note}</p>}
    <div className="layout-audit-fields"><label htmlFor={`${id}-length`}>实测长度（m）<input id={`${id}-length`} type="number" min="0.001" max="200" step="0.001" inputMode="decimal" value={length} onChange={event => { setLength(event.target.value); resetConfirmation(); }} /></label><label htmlFor={`${id}-date`}>量测日期<input id={`${id}-date`} type="date" value={date} onChange={event => { setDate(event.target.value); resetConfirmation(); }} /></label></div>
    <label htmlFor={`${id}-source`}>量测来源 / 量法<input id={`${id}-source`} maxLength={500} placeholder="例如：张工 / 激光测距 / 墙轴线两端" value={source} onChange={event => { setSource(event.target.value); resetConfirmation(); }} /></label>
    <label htmlFor={`${id}-note`}>备注<textarea id={`${id}-note`} maxLength={2000} rows={2} value={note} onChange={event => { setNote(event.target.value); resetConfirmation(); }} /></label>
    <label className="layout-audit-confirm"><input type="checkbox" checked={confirmed} onChange={event => { setConfirmed(event.target.checked); setSaved(false); }} /><span>我已核对量测值、日期、墙段和量法</span></label>
    {error && <p className="layout-audit-error" ref={errorRef} tabIndex={-1} role="alert">{error}</p>}
    <div className="layout-audit-form-actions"><button className="button secondary" type="submit">追加实测记录</button><span role="status">{saved ? '记录已保存；当前尺寸差异见墙段列表。' : '未勾选确认时保存为待确认记录。'}</span></div>
  </form>;
}

function FurnitureDimensionsEditor({ item, model, onChange, onLocate }: { item: FurnitureItem; model: HouseModel; onChange: Props['onChange']; onLocate: Props['onLocate'] }) {
  const id = useId();
  const initial = () => ({ width: String(item.size?.[0] ?? ''), depth: String(item.size?.[2] ?? ''), height: String(item.size?.[1] ?? '') });
  const [draft, setDraft] = useState(initial), [error, setError] = useState('');
  useEffect(() => { setDraft(initial()); }, [item.id, item.size?.[0], item.size?.[1], item.size?.[2]]);
  const dimensions = parseFurnitureDimensions(draft), errors = getFurnitureDimensionErrors(model, dimensions);
  function change(key: keyof typeof draft, value: string) {
    const nextDraft = { ...draft, [key]: value }; setDraft(nextDraft); setError('');
    const nextDimensions = parseFurnitureDimensions(nextDraft);
    if (getFurnitureDimensionErrors(model, nextDimensions).length) return;
    try { onChange(updateFurnitureDimensions(model, item.id, nextDimensions)); } catch (e) { setError(e instanceof Error ? e.message : '尺寸未保存，请重试。'); }
  }
  return <div className="layout-audit-furniture">
    <button type="button" className="layout-audit-furniture-title" onClick={() => onLocate(item.roomId)}><strong>{model.rooms.find(room => room.id === item.roomId)?.name ?? '未知房间'} · {FURNITURE[item.kind] ?? item.kind}</strong><span>定位家具所在房间</span></button>
    <div className="layout-audit-dimensions">{(['width', 'depth', 'height'] as const).map(key => <label key={key} htmlFor={`${id}-${key}`}>{{ width: '宽', depth: '深', height: '高' }[key]}（m）<input id={`${id}-${key}`} type="number" step="0.01" min="0.1" max={key === 'height' ? Math.min(4, model.height - .03) : 6} inputMode="decimal" value={draft[key]} onChange={event => change(key, event.target.value)} aria-invalid={!!errors.length} aria-describedby={errors.length || error ? `${id}-error` : undefined} /></label>)}</div>
    {(errors.length > 0 || error) && <p id={`${id}-error`} className="layout-audit-error" role="alert">{error || errors[0]} 当前输入尚未更新模型。</p>}
    <small>当前录入尺寸 · 实物量测仍需人工核对</small>
  </div>;
}
