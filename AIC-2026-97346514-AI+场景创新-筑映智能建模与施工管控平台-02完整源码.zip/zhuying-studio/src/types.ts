export type Point = [number, number];
export type Stage = 'not_started' | 'in_progress' | 'complete' | 'unknown';
export interface Wall { id: string; start: Point; end: Point; thickness: number; height?: number }
export type OpeningStyle = 'flush' | 'panel' | 'glass' | 'fixed' | 'casement' | 'sliding';
export interface OpeningDesign { color: string; style: OpeningStyle; openAngle: number; hinge: 'start' | 'end'; swing: 1 | -1; glassTint: 'clear' | 'smoke' }
export interface Opening { id: string; wallId: string; type: 'door' | 'window'; offset: number; width: number; height: number; sill?: number; design?: OpeningDesign }
export type WorkType = 'electrical' | 'waterproof' | 'masonry' | 'carpentry' | 'floor' | 'wall';
export interface Task { stage: Stage; plannedStage: Stage; dueDate: string; note?: string; enabled?: boolean }
export type FloorFinish = 'oak' | 'walnut' | 'light_tile' | 'gray_stone' | 'terrazzo' | 'concrete';
export interface RoomDesign { floorFinish: FloorFinish; wallColor: string; wallFinish: 'paint' | 'plaster'; floorDirection: 0 | 90 }
export type RoomUse = 'living' | 'bedroom' | 'study' | 'kitchen' | 'bathroom' | 'entry' | 'dining' | 'empty';
export type FurnitureKind = 'sofa' | 'coffee_table' | 'tv_console' | 'bed_double' | 'bed_single' | 'wardrobe' | 'desk' | 'chair' | 'dining_table' | 'kitchen_counter' | 'sink_cabinet' | 'toilet' | 'shoe_cabinet';
export interface FurnitureItem { id: string; roomId: string; kind: FurnitureKind; position: Point; size: [number, number, number]; rotation: number; color: string }
export interface DesignBrief {
  style: 'warm' | 'minimal' | 'natural' | 'industrial'; residents: number;
  needs: string[]; rooms: { roomId: string; use: RoomUse; furnish: boolean; items?: FurnitureKind[] }[]; notes: string;
}
export interface Room { id: string; name: string; polygon: Point[]; area: number; material: string; progress: number; tasks: { floor: Task; wall: Task } & Partial<Record<Exclude<WorkType, 'floor' | 'wall'>, Task>>; evidence?: Evidence[]; design?: RoomDesign }
export interface EvidencePhoto { id: string; image: string; viewpoint: string }
export interface EvidenceComparison { previousEvidenceId: string; previousDate: string; summary: string; change: 'advanced' | 'unchanged' | 'regressed' | 'uncertain'; source: string }
export interface Evidence { id: string; date: string; image: string; photos?: EvidencePhoto[]; workType: WorkType; stage: Stage; aiStage?: Stage; summary: string; confirmed: boolean; source: string; comparison?: EvidenceComparison; observations?: { photoIndex: number; summary: string }[] }
export interface HouseModel {
  id: string; name: string; width: number; depth: number; height: number;
  walls: Wall[]; openings: Opening[]; rooms: Room[];
  source: 'demo' | 'opencv' | 'manual'; warnings: string[];
  furniture?: FurnitureItem[]; designBrief?: DesignBrief;
  meta?: Record<string, unknown>
}
export interface ViewerProps {
  theme?: 'light' | 'dark';
  model: HouseModel; selectedRoom: string | null; onSelectRoom: (id: string) => void;
  viewMode: 'material' | 'progress'; cameraMode: 'perspective' | 'top';
  cutaway: boolean; showFurniture: boolean; showLabels: boolean; resetKey: number; focusKey: number;
  interiorRoom: string | null; onEnterRoom: (id: string) => void; onExitRoom: () => void;
  selectedOpening: string | null; onSelectOpening: (id: string) => void;
}
