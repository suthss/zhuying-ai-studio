# 界面升级验证（2026-10-06）

本轮按用户要求安装并应用 UI UX Pro Max、Impeccable。升级对象为主工作台、材质面板、项目库、设计问答、导入与帮助外观，以及独立的施工观察室。当前视觉规范见根目录 [DESIGN.md](../DESIGN.md)。

## 实际结果

- 主工作台使用暖石白、炭灰、黄铜及本地中文可变字体，保留品牌 SVG；设计模式让出施工时间线的位置给模型。
- 导航增加文字，重复提示与模式切换合并；项目操作、材料说明、影像来源与同步解释采用折叠详情。
- 材质即时预览、门窗编辑、房间内实时环视、四步设计问答和功能指南仍可操作。
- 施工观察室保留 6 期真实影像、12 个标定单元、人工确认与独立 AI 建议；模拟计划、无法判断及证据区间仍显式显示。

## 验证证据

`npm test`：128 项通过，0 失败。最终 `npm run build`：TypeScript 与 Vite 构建通过，本地字体可打包；CSS 216.74kB（gzip 38.95kB），JS 1121.26kB（gzip 321.79kB）。保留已有主包超过 1000kB 的提示。本轮未改算法模块，未发起新的云模型请求。

浏览器检查了默认桌面 1280×720、手机 390×844、平板 900×760。手机工作台／项目库／施工观察室没有页面横向溢出；平板材质面板为单列，色样宽度与滚动宽度同为 251px。验证了地板切换及恢复、门窗入口、进入与退出室内环视、手机项目库和备份入口、帮助、模拟计划和 JSON 预览。

最终深色环视按钮为文字 `#242820`／背景 `#efece2`，对比约 12.7:1；修复了旧组件的 `!important` 白字覆盖。暗色项目库主按钮与 hover 配色亦统一。减少动态效果规则沿用并覆盖短过渡，未新增循环背景动画。

终审发现主工作台“AI 设计”／“记录巡检”的黄铜文字对画布偏弱，已将 `.studio-design-action` 文字改为 `var(--ink)`。最终计算样式为文字 `#252823`／画布 `#ebe8df`，对比约 12.19:1；黄铜描边和选中反馈继续保留。浏览器最后检查的 warning 与 error 均为空。

报告 JSON 预览可解析，包含截至日期 `2026-04-25`、6 条观测、`plan.simulated: true`、人工标注、局限和 AI 建议字段。实际点击项目备份入口后，浏览器下载事件接口超时，因此这轮不声称已验证文件落盘；JSON 数据往返已有测试覆盖。

Impeccable 单次检测报告保存在 `artifacts/ui-redesign/impeccable-detect.json`：191 条规范建议，1 条关于 JSON 预览等宽字体的警告，无错误。该字体使用已记录到 DESIGN.md；颜色／字级的建议不等于交互失败，本轮以真实页面和控件检查补充判断。

字体从固定官方来源生成，Sans 约 1.72MiB、Serif 约 0.31MiB。最终检查源码字符覆盖、连续 400–700 字重和输出哈希，更新了来源清单；字体缺字采用系统回退。详情见 [字体记录](../public/fonts/SOURCES.md)。

## 终审范围与截图

Impeccable 最终终审结论为 `ship`，范围限定为主工作台、施工项目库和施工观察室的本轮页面；不构成全站或算法准确率认证。本轮基于既有界面执行 Operate polish，跳过视觉方向锦标赛、FORM seed 和 decision comp，没有声明与设计 comp 完全还原。测试结束后恢复默认浏览器尺寸与浅色工作台。

实测截图均已保存：

- [浅色工作台](../artifacts/ui-redesign/desktop.png)
- [深色工作台](../artifacts/ui-redesign/dark.png)
- [手机工作台](../artifacts/ui-redesign/mobile.png)
- [施工记录工作台](../artifacts/ui-redesign/construction.png)
- [施工项目库](../artifacts/ui-redesign/library.png)
- [手机施工项目库](../artifacts/ui-redesign/library-mobile.png)
- [施工观察室](../artifacts/ui-redesign/facade.png)
- [手机施工观察室](../artifacts/ui-redesign/facade-mobile.png)
