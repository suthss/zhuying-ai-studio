import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';

// Compile the real viewer modules in memory, without requiring Node's TS loader.
// Three stays external so geometry, addons and tests share the same constructors.
const result = await build({
  stdin: { contents: `export * as THREE from 'three';
    export { buildHouse, disposeTree } from './src/viewer/buildHouse.ts';
    export { createFurniture, createFurnitureCollection } from './src/viewer/furniture.ts';
    export { DEMO_MODEL } from './src/demo.ts';
    export { INTERIOR_EYE_HEIGHT, findInteriorStandingPoint, applyInteriorAngles } from './src/viewer/interior.ts';
    export { fitStageCamera } from './src/viewer/studio.ts';`,
    resolveDir: fileURLToPath(new URL('../../', import.meta.url)), loader: 'ts' },
  bundle: true, platform: 'node', format: 'esm', write: false,
  plugins: [{ name: 'shared-three', setup(builder) {
    builder.onResolve({ filter: /^three(?:\/|$)/ }, args => ({ path: import.meta.resolve(args.path), external: true }));
  } }],
});
export const viewer = await import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString('base64')}`);

// Geometry assertions do not need rasterized pixels. The browser checks cover
// actual textures and WebGL; this narrow adapter supplies only canvas drawing.
export function withCanvas(callback) {
  const previous = Object.getOwnPropertyDescriptor(globalThis, 'document');
  const drawing = new Proxy({}, { get(_target, key) {
    if (key === 'createRadialGradient' || key === 'createLinearGradient') return () => ({ addColorStop() {} });
    return () => {};
  } });
  Object.defineProperty(globalThis, 'document', { configurable: true, value: { createElement(tag) {
    if (tag !== 'canvas') throw new Error(`Unexpected element: ${tag}`);
    return { width: 0, height: 0, getContext: () => drawing };
  } } });
  try { return callback(); }
  finally { if (previous) Object.defineProperty(globalThis, 'document', previous); else delete globalThis.document; }
}
