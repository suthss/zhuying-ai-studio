import { useEffect, useMemo, useRef, useState } from 'react';
import { Archive, ArchiveRestore, ArrowLeft, ArrowUpRight, Check, CheckCircle2, ChevronRight, Clock3, Copy, FolderOpen, Layers3, LoaderCircle, MapPin, Pencil, RefreshCw, Search, ShieldQuestion, Upload, X, AlertTriangle, Save } from 'lucide-react';
import type { ProjectSummary } from './project-library';
import './project-library.css';

type ActionResult = void | Promise<void>;
export interface ProjectLibraryProps {
  projects: ProjectSummary[];
  activeId: string | null;
  loading: boolean;
  error: string | null;
  saving: boolean;
  onOpen: (id: string) => ActionResult;
  onSaveCurrent: () => ActionResult;
  onImport: () => ActionResult;
  onDuplicate: (id: string) => ActionResult;
  onMetadata: (id: string, metadata: { name?: string; location?: string; status?: 'active' | 'archived' }) => ActionResult;
  onRetry: () => ActionResult;
  onBack: () => ActionResult;
}

type ProjectFilter = 'all' | 'active' | 'attention' | 'archived';
const FILTERS: { id: ProjectFilter; label: string }[] = [
  { id: 'all', label: '全部项目' }, { id: 'active', label: '进行中' },
  { id: 'attention', label: '待关注' }, { id: 'archived', label: '已归档' },
];

function dateLabel(value: string | null, includeTime = false) {
  if (!value) return '暂无巡检';
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) return value;
  return new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Asia/Shanghai', month: '2-digit', day: '2-digit',
    ...(includeTime ? { hour: '2-digit', minute: '2-digit', hour12: false } : {}),
  }).format(new Date(timestamp));
}

function PlanPreview({ project }: { project: ProjectSummary }) {
  const preview = project.preview;
  const points = preview.rooms.flatMap(room => room.polygon).concat(preview.walls.flatMap(wall => [wall.start, wall.end]));
  const coordinates = points.filter(point => point.every(Number.isFinite));
  const minX = Math.min(0, ...coordinates.map(point => point[0]));
  const minY = Math.min(0, ...coordinates.map(point => point[1]));
  const maxX = Math.max(preview.width, 1, ...coordinates.map(point => point[0]));
  const maxY = Math.max(preview.depth, 1, ...coordinates.map(point => point[1]));
  const span = Math.max(maxX - minX, maxY - minY);
  const padding = span * .085;
  return <svg viewBox={`${minX - padding} ${minY - padding} ${maxX - minX + padding * 2} ${maxY - minY + padding * 2}`} className="library-plan" role="img" aria-label={`${project.name}，${project.stats.roomCount} 个房间的户型预览`}>
    <title>{project.name}户型预览</title>
    {preview.rooms.map((room, index) => <g key={room.id}>
      <polygon points={room.polygon.map(point => point.join(',')).join(' ')} className={`library-plan-room room-tone-${index % 3}`} strokeWidth={span * .003} />
      {room.polygon.length > 2 && <text x={room.polygon.reduce((total, point) => total + point[0], 0) / room.polygon.length} y={room.polygon.reduce((total, point) => total + point[1], 0) / room.polygon.length} fontSize={span * .055} textAnchor="middle" dominantBaseline="middle">{room.name}</text>}
    </g>)}
    {preview.walls.map((wall, index) => <line key={index} x1={wall.start[0]} y1={wall.start[1]} x2={wall.end[0]} y2={wall.end[1]} className="library-plan-wall" strokeWidth={span * .011} strokeLinecap="square" />)}
  </svg>;
}

export default function ProjectLibrary({ projects, activeId, loading, error, saving, onOpen, onSaveCurrent, onImport, onDuplicate, onMetadata, onRetry, onBack }: ProjectLibraryProps) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<ProjectFilter>('all');
  const [editing, setEditing] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [confirmArchive, setConfirmArchive] = useState<string | null>(null);
  const [actionError, setActionError] = useState('');
  const [pending, setPending] = useState<string | null>(null);
  const editingInput = useRef<HTMLInputElement>(null);
  const archiveCancel = useRef<HTMLButtonElement>(null);
  const title = useRef<HTMLHeadingElement>(null);
  const returnFocus = useRef<HTMLElement | null>(null);
  const pendingRef = useRef(false);
  const realActive = useMemo(() => projects.filter(project => project.status === 'active' && !project.stats.demo), [projects]);
  const totals = useMemo(() => realActive.reduce((sum, project) => ({
    completed: sum.completed + project.stats.completed, total: sum.total + project.stats.total,
    unknown: sum.unknown + project.stats.unknown, overdue: sum.overdue + project.stats.overdue,
  }), { completed: 0, total: 0, unknown: 0, overdue: 0 }), [realActive]);
  const attention = (project: ProjectSummary) => project.status === 'active' && (project.stats.unknown > 0 || project.stats.overdue > 0);
  const filterCounts = {
    all: projects.length, active: projects.filter(project => project.status === 'active').length,
    attention: projects.filter(attention).length, archived: projects.filter(project => project.status === 'archived').length,
  };
  const visible = useMemo(() => {
    const phrase = query.trim().toLocaleLowerCase();
    return projects.filter(project => {
      const matchesFilter = filter === 'all' || (filter === 'attention' ? attention(project) : project.status === filter);
      return matchesFilter && (!phrase || `${project.name} ${project.location}`.toLocaleLowerCase().includes(phrase));
    });
  }, [projects, query, filter]);
  const disabled = saving || pending !== null;
  const displayedError = actionError || error;
  const conflict = !!displayedError && /conflict|409|冲突|其他.*修改|版本/i.test(displayedError);

  useEffect(() => { title.current?.focus({ preventScroll: true }); }, []);
  useEffect(() => { if (editing) editingInput.current?.focus(); }, [editing]);
  useEffect(() => { if (confirmArchive) archiveCancel.current?.focus({ preventScroll: true }); }, [confirmArchive]);
  useEffect(() => {
    if (editing && !projects.some(project => project.id === editing)) setEditing(null);
    if (confirmArchive && !projects.some(project => project.id === confirmArchive)) setConfirmArchive(null);
  }, [projects, editing, confirmArchive]);
  const finishInline = () => {
    setEditing(null); setConfirmArchive(null);
    requestAnimationFrame(() => {
      const target = returnFocus.current?.isConnected ? returnFocus.current : title.current;
      target?.focus({ preventScroll: true });
    });
  };
  const act = async (key: string, action: () => ActionResult, after?: () => void) => {
    if (pendingRef.current || saving) return;
    pendingRef.current = true; setPending(key); setActionError('');
    try { await action(); after?.(); }
    catch (reason) { setActionError(reason instanceof Error ? reason.message : '操作未完成，请重新载入项目库后重试。'); }
    finally { pendingRef.current = false; setPending(null); }
  };
  const editProject = (project: ProjectSummary, element: HTMLElement) => {
    returnFocus.current = element; setConfirmArchive(null); setActionError('');
    setName(project.name); setLocation(project.location); setEditing(project.id);
  };

  return <section className="project-library" aria-labelledby="project-library-title">
    <div className="project-library-inner">
      <div className="library-topline"><button className="library-back" onClick={() => void act('back', onBack)} disabled={disabled}><ArrowLeft size={16} />返回建模工作台</button><span className={`library-sync ${error ? 'is-offline' : ''}`} role="status">{loading || saving || pending ? <LoaderCircle className="library-spinner" size={13} /> : error ? <AlertTriangle size={13} /> : <span className="library-sync-dot" />}{saving || pending === 'save' ? '正在保存' : pending?.startsWith('open-') ? '正在打开项目' : pending ? '正在处理操作' : loading ? '正在同步项目库' : error ? '同步暂不可用' : '定期刷新已提交巡检'}</span></div>
      <header className="library-heading"><div><h1 id="project-library-title" ref={title} tabIndex={-1}>施工项目库<span>{projects.length.toString().padStart(2, '0')}</span></h1><p>模型、设计与现场记录。</p></div><div className="library-heading-actions"><button className="library-button" disabled={disabled} onClick={() => void act('save', onSaveCurrent)}>{pending === 'save' ? <LoaderCircle className="library-spinner" size={16} /> : <Save size={16} />}保存当前模型</button><button className="library-button is-primary" disabled={disabled} onClick={() => void act('import', onImport)}><Upload size={16} />导入新户型</button></div></header>
      <div className="library-overview" aria-label="进行中的真实项目施工总览">
        <div className="library-overview-intro"><span className="library-overview-icon"><Layers3 size={22} /></span><div><strong>现场总览</strong><p>真实项目 · 示例不计入</p></div></div>
        <div className="library-metric"><span>进行中项目</span><strong>{realActive.length}<small>个</small></strong></div>
        <div className="library-metric"><span>已确认完成工序</span><strong>{totals.completed}<small>/ {totals.total}</small></strong></div>
        <button className="library-metric is-interactive" onClick={() => { setFilter('attention'); setQuery(''); }}><span><ShieldQuestion size={13} />待核对工序</span><strong>{totals.unknown}<small>项</small></strong></button>
        <button className={`library-metric is-interactive ${totals.overdue ? 'has-alert' : ''}`} onClick={() => { setFilter('attention'); setQuery(''); }}><span><Clock3 size={13} />计划告警</span><strong>{totals.overdue}<small>项</small></strong></button>
      </div>
      <div className="library-toolbar"><nav className="library-filters" aria-label="项目筛选">{FILTERS.map(item => <button key={item.id} onClick={() => setFilter(item.id)} aria-pressed={filter === item.id} className={filter === item.id ? 'selected' : ''}>{item.label}<span>{filterCounts[item.id]}</span></button>)}</nav><label className="library-search"><Search size={16} /><span className="library-visually-hidden">搜索项目名称或地点</span><input type="search" placeholder="搜索项目名称或地点" value={query} onChange={event => setQuery(event.target.value)} />{query && <button onClick={() => setQuery('')} aria-label="清空项目搜索"><X size={14} /></button>}</label></div>
      {displayedError && <div className="library-error" role="alert"><AlertTriangle size={19} /><div><strong>{conflict ? '项目已有更新，请先核对最新记录' : actionError ? '项目操作未完成' : '项目同步未完成'}</strong><p>{displayedError}</p>{conflict && <p>重新载入项目库，再打开对应项目查看最新版本。</p>}</div><button className="library-button" disabled={disabled || loading} onClick={() => void act('retry', onRetry, () => setActionError(''))}><RefreshCw size={14} />重新载入项目库</button></div>}
      {loading && projects.length === 0 ? <div className="library-loading" role="status"><LoaderCircle className="library-spinner" size={25} /><strong>正在读取项目库</strong><p>读取已保存的模型与施工记录。</p></div> : projects.length === 0 ? <div className="library-empty"><span className="library-empty-mark"><FolderOpen size={34} /></span><h2>第一个项目，从当前模型开始。</h2><p>把当前房屋保存到项目库，或导入另一张户型图。<br />每个项目会独立保存设计、现场照片和施工时间线。</p><div><button className="library-button is-primary" disabled={disabled} onClick={() => void act('save', onSaveCurrent)}><Save size={16} />保存当前模型</button><button className="library-button" disabled={disabled} onClick={() => void act('import', onImport)}><Upload size={16} />导入新户型</button></div><small>保存后可在这里切换多个项目，继续设计或添加巡检。</small></div> : visible.length === 0 ? <div className="library-empty is-filter-empty"><Search size={30} /><h2>没有符合条件的项目</h2><p>试试其他名称、地点，或查看全部项目。</p><button className="library-button" onClick={() => { setQuery(''); setFilter('all'); }}>查看全部项目</button></div> : <div className="library-project-grid">{visible.map(project => {
        const isCurrent = project.id === activeId;
        const isArchived = project.status === 'archived';
        const stats = project.stats;
        const percent = stats.total > 0 ? Math.max(0, Math.min(100, stats.completed / stats.total * 100)) : 0;
        const isEditing = editing === project.id;
        const isConfirming = confirmArchive === project.id;
        return <article key={project.id} className={`library-project-card ${isCurrent ? 'is-current' : ''} ${isArchived ? 'is-archived' : ''}`} aria-labelledby={`project-title-${project.id}`}>
          <button className="library-preview-button" disabled={disabled} onClick={() => void act(`open-${project.id}`, () => onOpen(project.id))} aria-label={`打开 ${project.name}`}><div className="library-preview-tags">{isCurrent && <span className="library-tag is-current"><Check size={11} />当前工作台</span>}{isArchived && <span className="library-tag"><Archive size={11} />已归档</span>}{stats.demo && <span className="library-tag is-demo">含示例数据</span>}</div><PlanPreview project={project} /><span className="library-preview-caption">{stats.roomCount} 个空间<span>{stats.area.toFixed(1)} m²</span></span><span className="library-preview-open"><ArrowUpRight size={18} /></span></button>
          <div className="library-card-content"><div className="library-card-title"><div><h2 id={`project-title-${project.id}`}>{project.name}</h2><p><MapPin size={12} />{project.location || '尚未填写项目地点'}</p></div><button className="library-icon-button" title="编辑项目名称与地点" aria-label={`编辑 ${project.name} 的名称与地点`} disabled={disabled} onClick={event => isEditing ? finishInline() : editProject(project, event.currentTarget)}><Pencil size={15} /></button></div>
            <div className="library-card-progress"><div><span>已确认完成工序</span><strong>{stats.completed}<small> / {stats.total}</small></strong></div><div className="library-progress-track" role="meter" aria-label={`${project.name} 已确认完成工序占比`} aria-valuemin={0} aria-valuemax={stats.total || 1} aria-valuenow={stats.completed} aria-valuetext={`${stats.completed} 项完成，共 ${stats.total} 项已启用工序`}><span style={{ width: `${percent}%` }} /></div><p>状态确认覆盖 <strong>{stats.known} / {stats.total}</strong>{stats.total === 0 && <span>先启用需要跟踪的工序</span>}</p></div>
            <div className="library-card-details"><span><Clock3 size={13} />最近巡检<strong>{dateLabel(stats.latestInspectionDate)}</strong></span><span><RefreshCw size={12} />项目更新<strong>{dateLabel(project.updatedAt, true)}</strong></span></div>
            <div className="library-card-alerts">{stats.overdue > 0 && <span className="library-status is-overdue"><AlertTriangle size={12} />{stats.overdue} 项计划告警</span>}{stats.unknown > 0 && <span className="library-status"><ShieldQuestion size={12} />{stats.unknown} 项待核对</span>}{stats.unknown === 0 && stats.overdue === 0 && <span className="library-status is-clear"><CheckCircle2 size={12} />{stats.total > 0 ? '已启用工序均有确认状态' : '尚未启用施工工序'}</span>}</div>
            {isEditing && <form className="library-inline-form" onSubmit={event => { event.preventDefault(); if (name.trim()) void act(`metadata-${project.id}`, () => onMetadata(project.id, { name: name.trim(), location: location.trim() }), finishInline); }} onKeyDown={event => { if (event.key === 'Escape' && !disabled) { event.preventDefault(); finishInline(); } }}><label htmlFor={`project-name-${project.id}`}>项目名称<input ref={editingInput} id={`project-name-${project.id}`} value={name} onChange={event => setName(event.target.value)} required maxLength={120} disabled={disabled} autoComplete="off" /></label><label htmlFor={`project-location-${project.id}`}>项目地点<span>选填</span><input id={`project-location-${project.id}`} value={location} onChange={event => setLocation(event.target.value)} maxLength={240} disabled={disabled} placeholder="例如：杭州 · 云栖居 3 栋" autoComplete="off" /></label><div><button className="library-button" type="button" disabled={disabled} onClick={finishInline}>取消</button><button className="library-button is-primary" type="submit" disabled={disabled || !name.trim()}>{pending === `metadata-${project.id}` ? <LoaderCircle className="library-spinner" size={14} /> : <Check size={14} />}保存信息</button></div></form>}
            {isConfirming && <div className="library-archive-confirm" role="group" aria-label={`确认归档 ${project.name}`} onKeyDown={event => { if (event.key === 'Escape' && !disabled) { event.preventDefault(); finishInline(); } }}><strong>将这个项目归档？</strong><p>模型、照片与记录都会保留，之后可恢复为进行中。归档后不计入现场总览。</p><div><button ref={archiveCancel} className="library-button" disabled={disabled} onClick={finishInline}>暂不归档</button><button className="library-button" disabled={disabled} onClick={() => void act(`archive-${project.id}`, () => onMetadata(project.id, { status: 'archived' }), finishInline)}><Archive size={14} />确认归档</button></div></div>}
            <footer className="library-card-actions"><button className="library-open-project" disabled={disabled} onClick={() => void act(`open-${project.id}`, () => onOpen(project.id))}>{pending === `open-${project.id}` ? <LoaderCircle className="library-spinner" size={14} /> : <FolderOpen size={14} />}打开项目<ChevronRight size={14} /></button><div><button className="library-icon-button" title="复制为独立项目" aria-label={`复制 ${project.name} 为独立项目`} disabled={disabled} onClick={() => void act(`duplicate-${project.id}`, () => onDuplicate(project.id))}>{pending === `duplicate-${project.id}` ? <LoaderCircle className="library-spinner" size={14} /> : <Copy size={15} />}</button><button className="library-icon-button" title={isArchived ? '恢复为进行中' : '归档项目'} aria-label={`${isArchived ? '恢复' : '归档'} ${project.name}`} aria-expanded={isArchived ? undefined : isConfirming} disabled={disabled} onClick={event => { returnFocus.current = event.currentTarget; if (isArchived) void act(`restore-${project.id}`, () => onMetadata(project.id, { status: 'active' }), finishInline); else if (isConfirming) finishInline(); else { setEditing(null); setConfirmArchive(project.id); } }}>{isArchived ? <ArchiveRestore size={16} /> : <Archive size={16} />}</button></div></footer>
          </div>
        </article>;
      })}</div>}
      <footer className="library-page-note"><details><summary>关于记录与同步</summary><p>每个模型独立保存，施工状态来自已确认的巡检。自动刷新不代表摄像头实时监控，照片状态仍需现场核对。</p></details><span className="library-page-count">{visible.length} / {projects.length} 个项目</span></footer>
    </div>
  </section>;
}
