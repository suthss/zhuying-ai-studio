"""Project library integration checks use a fresh SQLite file for every test."""

import copy
import json
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

from backend.app import app
from backend import project_library as library

ROOT = Path(__file__).resolve().parent.parent
IMAGE = "data:image/png;base64,AAAA"


def model(name="测试住宅"):
    return {"id": "source-model", "name": name, "source": "manual", "width": 6, "depth": 5, "height": 2.8,
            "walls": [{"id": "north", "start": [0, 0], "end": [6, 0], "thickness": .2}],
            "openings": [{"id": "door", "wallId": "north", "type": "door", "offset": .3, "width": .9, "height": 2.1}],
            "rooms": [{"id": "room", "name": "卧室", "polygon": [[0, 0], [6, 0], [6, 5], [0, 5]],
                       "area": 30, "material": "wood", "progress": 0,
                       "tasks": {"floor": {"stage": "unknown", "plannedStage": "complete", "dueDate": "2026-10-03"},
                                 "wall": {"stage": "in_progress", "plannedStage": "in_progress", "dueDate": "2026-10-03"}},
                       "evidence": []}], "warnings": [], "meta": {"originalFile": "图纸.png"}}


def evidence(record_id="first", date="2026-10-03", stage="in_progress"):
    return {"id": record_id, "date": date, "image": IMAGE, "workType": "floor", "stage": stage,
            "summary": "测试证据", "source": "manual", "confirmed": True,
            "photos": [{"id": "photo-1", "image": IMAGE, "viewpoint": "入口"},
                       {"id": "photo-2", "image": "data:image/png;base64,AAAB", "viewpoint": "窗边"}],
            "observations": [{"photoIndex": 0, "summary": "入口视角"}, {"photoIndex": 1, "summary": "窗边视角"}]}


class ProjectLibraryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="zhuying-library-test-")
        self.db = Path(self.temporary.name) / "nested" / "library.sqlite3"
        self.environment = patch.dict(os.environ, {"PROJECT_DATABASE_PATH": str(self.db)})
        self.environment.start()
        self.client = TestClient(app)

    def tearDown(self):
        self.client.close()
        self.environment.stop()
        self.temporary.cleanup()

    def create(self, value=None, **extra):
        response = self.client.post("/api/projects", json={"model": model() if value is None else value, **extra})
        self.assertEqual(response.status_code, 201, response.text)
        return response.json()

    def test_empty_library_is_created_without_demo_or_fake_projects(self):
        response = self.client.get("/api/projects")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["projects"], [])
        self.assertEqual(response.json()["changeVersion"], 0)
        self.assertTrue(response.json()["serverTime"].endswith("Z"))
        self.assertTrue(self.db.is_file())

    def test_full_model_and_multi_photo_history_survive_a_new_process(self):
        value = model()
        first, second = evidence(), evidence("second", "2026-10-05", "complete")
        second["comparison"] = {"previousEvidenceId": "first", "previousDate": "2026-10-03",
                                "summary": "比对测试", "change": "advanced", "source": "manual"}
        value["rooms"][0]["evidence"] = [first, second]
        value["rooms"][0]["tasks"]["floor"]["stage"] = "complete"
        value["rooms"][0]["design"] = {"floorFinish": "walnut", "wallColor": "#DCCFBD", "wallFinish": "plaster", "floorDirection": 90}
        created = self.create(value, location="  上海测试位置  ")
        self.assertNotEqual(created["id"], value["id"])
        self.assertEqual(created["revision"], 1)
        self.assertEqual(created["location"], "上海测试位置")
        self.assertEqual(created["model"], value)
        fresh_process = subprocess.run([sys.executable, "-c",
            "import json,sys; from backend.project_library import get_project; print(json.dumps(get_project(sys.argv[1])))",
            created["id"]], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", check=True)
        self.assertEqual(json.loads(fresh_process.stdout), created)

    def test_summary_has_polygon_area_enabled_trades_and_no_photo_payload(self):
        value = model()
        room = value["rooms"][0]
        room["area"] = 99  # Geometry drives the overview even if imported area metadata differs.
        room["tasks"]["floor"]["stage"] = "complete"
        room["tasks"]["electrical"] = {"stage": "unknown", "plannedStage": "complete", "dueDate": "2026-10-02"}
        room["tasks"]["waterproof"] = {"stage": "unknown", "plannedStage": "complete", "dueDate": "2026-10-01", "enabled": False}
        room["evidence"] = [evidence()]
        created = self.create(value)
        with patch.object(library, "library_today", return_value="2026-10-05"):
            overview = self.client.get("/api/projects").json()
        row = overview["projects"][0]
        self.assertEqual(overview["changeVersion"], 1)
        self.assertEqual(row["id"], created["id"])
        self.assertEqual(row["stats"], {"roomCount": 1, "area": 30, "completed": 1, "known": 2,
            "total": 3, "unknown": 1, "latestInspectionDate": "2026-10-03", "demo": False, "overdue": 1})
        self.assertEqual(row["preview"]["rooms"][0]["polygon"], room["polygon"])
        self.assertNotIn("model", row)
        self.assertNotIn("schedule", row)
        self.assertNotIn("base64", json.dumps(row))

    def test_plan_only_warnings_change_at_midnight_without_a_model_write(self):
        value = model()
        value["rooms"][0]["tasks"]["wall"]["plannedStage"] = "complete"
        self.create(value)
        with patch.object(library, "library_today", return_value="2026-10-03"):
            first = library.list_projects()
        with patch.object(library, "library_today", return_value="2026-10-04"):
            next_day = library.list_projects()
        self.assertEqual(first["projects"][0]["stats"]["overdue"], 0)
        self.assertEqual(next_day["projects"][0]["stats"]["overdue"], 2)
        self.assertEqual(first["changeVersion"], next_day["changeVersion"])

    def test_two_models_with_identical_source_ids_are_saved_independently(self):
        first, second = self.create(model("第一套")), self.create(model("第二套"))
        self.assertNotEqual(first["id"], second["id"])
        changed = copy.deepcopy(first["model"])
        changed["rooms"][0]["tasks"]["floor"]["stage"] = "complete"
        response = self.client.put(f"/api/projects/{first['id']}", json={"revision": 1, "model": changed})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["revision"], 2)
        self.assertEqual(self.client.get(f"/api/projects/{second['id']}").json()["model"], second["model"])
        self.assertEqual(len(self.client.get("/api/projects").json()["projects"]), 2)

    def test_stale_revision_never_overwrites_another_clients_saved_changes(self):
        first = self.create()
        path = f"/api/projects/{first['id']}"
        changed = self.client.put(path, json={"revision": 1, "name": "最新名称"})
        self.assertEqual(changed.status_code, 200)
        self.assertEqual(changed.json()["model"]["name"], "最新名称")
        stale = self.client.put(path, json={"revision": 1, "name": "旧页面的名称"})
        self.assertEqual(stale.status_code, 409)
        self.assertEqual(stale.json()["detail"]["reason"], "revision_conflict")
        self.assertEqual(stale.json()["detail"]["currentRevision"], 2)
        self.assertEqual(self.client.get(path).json()["name"], "最新名称")
        self.assertEqual(self.client.get("/api/projects").json()["changeVersion"], 2)

    def test_archive_and_restore_preserve_the_entire_model(self):
        saved = self.create()
        path = f"/api/projects/{saved['id']}"
        archived = self.client.put(path, json={"revision": 1, "status": "archived"}).json()
        self.assertEqual(archived["status"], "archived")
        self.assertEqual(archived["model"], saved["model"])
        restored = self.client.put(path, json={"revision": 2, "status": "active", "location": "  新位置  "}).json()
        self.assertEqual(restored["status"], "active")
        self.assertEqual(restored["location"], "新位置")
        self.assertEqual(restored["model"], saved["model"])

    def test_retrying_same_creation_does_not_add_models_or_bump_versions(self):
        saved = self.create(clientKey="36e4c9a0-4c24-446b-9ac9-267efbd7f2c3", location="位置")
        retried = self.create(clientKey="36e4c9a0-4c24-446b-9ac9-267efbd7f2c3", location="  位置  ")
        self.assertEqual(saved, retried)
        overview = self.client.get("/api/projects").json()
        self.assertEqual(len(overview["projects"]), 1)
        self.assertEqual(overview["changeVersion"], 1)

    def test_reusing_creation_key_for_changed_content_is_a_conflict(self):
        saved = self.create(clientKey="request-key")
        response = self.client.post("/api/projects", json={"model": model("修改后的模型"), "clientKey": "request-key"})
        self.assertEqual(response.status_code, 409)
        self.assertEqual(response.json()["detail"]["reason"], "creation_conflict")
        self.assertEqual(self.client.get(f"/api/projects/{saved['id']}").json(), saved)
        self.assertEqual(self.client.get("/api/projects").json()["changeVersion"], 1)

    def test_concurrent_creation_retries_resolve_to_one_project(self):
        library.list_projects()  # Initialize SQLite before exercising simultaneous writes.
        payload = {"model": model(), "clientKey": "concurrent-request"}
        with ThreadPoolExecutor(max_workers=6) as executor:
            results = list(executor.map(lambda _: library.create_project(copy.deepcopy(payload)), range(12)))
        self.assertEqual(len({row["id"] for row in results}), 1)
        self.assertTrue(all(row["revision"] == 1 for row in results))
        self.assertEqual(library.list_projects()["changeVersion"], 1)

    def test_invalid_model_fields_return_422_without_creating_a_partial_project(self):
        mutations = [
            lambda value: value.update(width=True),
            lambda value: value.update(meta=[]),
            lambda value: value["walls"][0].update(end=[0, 0]),
            lambda value: value["openings"][0].update(wallId=[]),
            lambda value: value["openings"][0].update(width=7),
            lambda value: value["rooms"][0]["tasks"]["floor"].update(stage=[]),
            lambda value: value["rooms"][0]["tasks"].update(teleport={}),
            lambda value: value["rooms"][0].update(evidence=[evidence(), evidence()]),
            lambda value: value["rooms"][0].update(evidence=[{**evidence(), "workType": []}]),
            lambda value: value["rooms"][0].update(evidence=[{**evidence(), "image": "https://arbitrary.example/image.png"}]),
            lambda value: value.update(furniture=[{"id": "item", "roomId": [], "kind": []}]),
            lambda value: value.update(designBrief={"style": "warm", "residents": 2, "needs": [[]], "notes": "", "rooms": []}),
        ]
        for mutation in mutations:
            value = model()
            mutation(value)
            with self.subTest(value=value):
                response = self.client.post("/api/projects", json={"model": value})
                self.assertEqual(response.status_code, 422, response.text)
        self.assertEqual(self.client.get("/api/projects").json()["changeVersion"], 0)

    def test_invalid_payload_revision_and_unknown_id_have_actionable_statuses(self):
        saved = self.create()
        for payload in [{"model": model(), "clientKey": ""}, {"model": model(), "extra": True}, {"model": None}]:
            self.assertEqual(self.client.post("/api/projects", json=payload).status_code, 422)
        for payload in [{"revision": True, "name": "名称"}, {"revision": 1}, {"revision": 1, "status": "deleted"}, {"revision": 1, "model": None}]:
            self.assertEqual(self.client.put(f"/api/projects/{saved['id']}", json=payload).status_code, 422)
        self.assertEqual(self.client.get("/api/projects/missing").status_code, 404)
        self.assertEqual(self.client.put("/api/projects/missing", json={"revision": 1, "name": "名字"}).status_code, 404)

    def test_duplicate_keys_non_finite_numbers_and_non_objects_are_rejected(self):
        for body in ['{"model":{},"model":{}}', '{"model":{"width":NaN}}', '{"model":{"width":Infinity}}', '[]', '{broken']:
            with self.subTest(body=body):
                response = self.client.post("/api/projects", content=body, headers={"Content-Type": "application/json"})
                self.assertEqual(response.status_code, 422)
        self.assertEqual(self.client.post("/api/projects", content="{}", headers={"Content-Type": "text/plain"}).status_code, 415)

    def test_declared_and_streamed_size_limits_are_enforced_before_write(self):
        response = self.client.post("/api/projects", content="{}", headers={"Content-Type": "application/json", "Content-Length": str(library.MAX_PROJECT_BODY_BYTES + 1)})
        self.assertEqual(response.status_code, 413)
        with patch.object(library, "MAX_PROJECT_BODY_BYTES", 8):
            response = self.client.post("/api/projects", content='{ "test": "long" }', headers={"Content-Type": "application/json", "Content-Length": "1"})
        self.assertEqual(response.status_code, 413)
        self.assertEqual(library.list_projects()["changeVersion"], 0)

    def test_database_unavailable_returns_503_without_internal_path_or_traceback(self):
        with patch.dict(os.environ, {"PROJECT_DATABASE_PATH": self.temporary.name}):
            response = self.client.get("/api/projects")
        self.assertEqual(response.status_code, 503)
        self.assertNotIn(self.temporary.name, response.text)
        self.assertNotIn("Traceback", response.text)

    def test_full_frontend_demo_with_generated_furniture_is_saved_and_reimportable(self):
        script = """
          import { build } from 'esbuild';
          const output = await build({stdin: {contents: `
            import { DEMO_MODEL } from './src/demo.ts';
            import { createDesignBrief, generateFurnishedModel } from './src/furnishing.mjs';
            import { validateProject } from './src/project.mjs';
            export const demo = validateProject(DEMO_MODEL);
            export const furnished = validateProject(generateFurnishedModel(DEMO_MODEL, createDesignBrief(DEMO_MODEL)).model);
          `, resolveDir: process.cwd(), loader: 'ts'}, bundle: true, platform: 'node', format: 'esm', write: false});
          const data = await import('data:text/javascript;base64,' + Buffer.from(output.outputFiles[0].text).toString('base64'));
          process.stdout.write(JSON.stringify({demo: data.demo, furnished: data.furnished}));
        """
        result = subprocess.run(["node", "--input-type=module", "-e", script], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", check=True)
        data = json.loads(result.stdout)
        for value in data.values():
            saved = self.create(value)
            fetched = self.client.get(f"/api/projects/{saved['id']}").json()
            self.assertEqual(fetched["model"], value)
        self.assertGreater(len(data["furnished"]["furniture"]), 0)
        returned = self.client.get(f"/api/projects/{saved['id']}").json()["model"]
        validation = subprocess.run(["node", "--input-type=module", "-e", "import { validateProject } from './src/project.mjs'; let input=''; for await (const part of process.stdin) input+=part; process.stdout.write(JSON.stringify(validateProject(JSON.parse(input))));"],
            cwd=ROOT, input=json.dumps(returned, ensure_ascii=False), capture_output=True, text=True, encoding="utf-8", check=True)
        self.assertEqual(json.loads(validation.stdout), returned)
        self.assertTrue(all(row["stats"]["demo"] for row in self.client.get("/api/projects").json()["projects"]))


if __name__ == "__main__":
    unittest.main()
