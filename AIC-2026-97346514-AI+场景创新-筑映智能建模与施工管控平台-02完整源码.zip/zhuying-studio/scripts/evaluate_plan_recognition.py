"""Measure any HouseModel parser on the self-drawn recognition stress suite.

Example:
  .venv/Scripts/python.exe scripts/evaluate_plan_recognition.py \
      --parser backend.algorithm:parse_floor_plan --output artifacts/recognition-baseline.json

The parser is selected at runtime rather than importing an unimplemented API.
It must accept image_bytes, real_width=..., height=... and return a HouseModel
dict, or {"model": HouseModel}. Synthetic results do not estimate real-world
accuracy. No project files, providers, credentials or UI state are modified.
"""

from __future__ import annotations

import argparse
import importlib
import json
import math
from pathlib import Path
import statistics
import sys
import time

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
RESOLUTION = 60  # Evaluation pixels per metre, independent of input resolution.
WALL_TOLERANCE = .12


def point_to_pixel(point):
    return tuple(round(float(component) * RESOLUTION) + 20 for component in point)


def canvas_shape(target, model):
    width = max(float(target["width"]), float(model.get("width", target["width"])))
    depth = max(float(target["depth"]), float(model.get("depth", target["depth"])))
    if not math.isfinite(width + depth) or min(width, depth) <= 0 or max(width, depth) > 150:
        raise ValueError("Parser returned nonfinite or excessive dimensions")
    return round(depth * RESOLUTION) + 41, round(width * RESOLUTION) + 41


def room_mask(room, shape):
    mask = np.zeros(shape, dtype=np.uint8)
    polygon = np.array([point_to_pixel(point) for point in room["polygon"]], dtype=np.int32)
    if len(polygon) >= 3:
        cv2.fillPoly(mask, [polygon], 1)
    return mask.astype(bool)


def room_metrics(target, model, shape):
    expected = [room_mask(room, shape) for room in target["rooms"]]
    predicted = [room_mask(room, shape) for room in model.get("rooms", [])]
    candidates = []
    for left_index, left in enumerate(expected):
        for right_index, right in enumerate(predicted):
            union = np.count_nonzero(left | right)
            iou = np.count_nonzero(left & right) / union if union else 0
            candidates.append((iou, left_index, right_index))
    # Greedy matching is transparent and sufficient for small regression plans.
    # This is deliberately not described as optimal assignment or benchmark AP.
    selected_left, selected_right, pairs = set(), set(), []
    for iou, left, right in sorted(candidates, reverse=True):
        if iou <= 0 or left in selected_left or right in selected_right:
            continue
        selected_left.add(left)
        selected_right.add(right)
        pairs.append((iou, left, right))
    matched = [iou for iou, _, _ in pairs]
    true_positives = sum(iou >= .5 for iou in matched)
    precision = true_positives / len(predicted) if predicted else 0
    recall = true_positives / len(expected) if expected else 0
    return {
        "expectedRooms": len(expected), "predictedRooms": len(predicted),
        "roomCountExact": len(expected) == len(predicted),
        "matchedRoomMeanIoU": statistics.mean(matched) if matched else 0,
        "targetRoomMeanIoU": sum(matched) / len(expected) if expected else 0,
        "roomPrecisionAtIoU50": precision, "roomRecallAtIoU50": recall,
        "roomF1AtIoU50": harmonic(precision, recall),
    }


def harmonic(precision, recall):
    return 2 * precision * recall / (precision + recall) if precision + recall else 0


def wall_mask(walls, shape):
    mask = np.zeros(shape, dtype=np.uint8)
    for wall in walls:
        cv2.line(mask, point_to_pixel(wall["start"]), point_to_pixel(wall["end"]), 1, 1)
    return mask


def wall_metrics(target, model, shape):
    expected = wall_mask(target["walls"], shape)
    predicted = wall_mask(model.get("walls", []), shape)
    radius = round(WALL_TOLERANCE * RESOLUTION)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * radius + 1, 2 * radius + 1))
    expected_band = cv2.dilate(expected, kernel).astype(bool)
    predicted_band = cv2.dilate(predicted, kernel).astype(bool)
    precision = (np.count_nonzero(predicted.astype(bool) & expected_band) /
                 np.count_nonzero(predicted)) if np.any(predicted) else 0
    recall = (np.count_nonzero(expected.astype(bool) & predicted_band) /
              np.count_nonzero(expected)) if np.any(expected) else 0
    return {"wallToleranceMetres": WALL_TOLERANCE,
            "wallPrecision": precision, "wallRecall": recall,
            "wallF1": harmonic(precision, recall),
            "expectedWallSegments": len(target["walls"]),
            "predictedWallSegments": len(model.get("walls", []))}


def opening_location(opening, walls):
    wall = walls.get(opening["wallId"])
    if wall is None:
        return None
    ax, az = wall["start"]
    bx, bz = wall["end"]
    distance = math.hypot(bx - ax, bz - az)
    if not distance:
        return None
    offset = float(opening["offset"]) + float(opening["width"]) / 2
    return ax + (bx - ax) / distance * offset, az + (bz - az) / distance * offset


def opening_metrics(target, model):
    expected, predicted = target["openings"], model.get("openings", [])
    expected_walls = {wall["id"]: wall for wall in target["walls"]}
    predicted_walls = {wall["id"]: wall for wall in model.get("walls", [])}
    candidates = []
    for left_index, left in enumerate(expected):
        first = opening_location(left, expected_walls)
        for right_index, right in enumerate(predicted):
            second = opening_location(right, predicted_walls)
            if first is None or second is None or left["type"] != right["type"]:
                continue
            distance = math.dist(first, second)
            if distance <= .3 and abs(float(left["width"]) - float(right["width"])) <= .35:
                candidates.append((distance, left_index, right_index))
    used_left, used_right = set(), set()
    for _, left, right in sorted(candidates):
        if left in used_left or right in used_right:
            continue
        used_left.add(left)
        used_right.add(right)
    precision = len(used_right) / len(predicted) if predicted else 0
    recall = len(used_left) / len(expected) if expected else 0
    return {"expectedOpenings": len(expected), "predictedOpenings": len(predicted),
            "matchedOpenings": len(used_left),
            "openingPrecision": precision if predicted or expected else None,
            "openingRecall": recall if expected else None,
            "openingF1": harmonic(precision, recall) if expected else None}


def evaluate_case(parser, path, case, models_directory=None):
    target = json.loads((path / case["groundTruth"]).read_text(encoding="utf-8"))
    model_path = None
    if models_directory is not None:
        models_directory.mkdir(parents=True, exist_ok=True)
        safe_name = "".join(character if character.isalnum() or character in "-_" else "_"
                            for character in case["id"])
        model_path = models_directory / f"{safe_name}.json"
        # A rejected rerun must not leave an old successful model displayed by
        # an overlay or frontend validation as though it were the new result.
        model_path.unlink(missing_ok=True)
    start = time.perf_counter()
    try:
        model = parser((path / case["image"]).read_bytes(), real_width=target["width"],
                       height=target["height"])
        elapsed = time.perf_counter() - start
        if isinstance(model, dict) and "model" in model:
            model = model["model"]
        if not isinstance(model, dict):
            raise TypeError("Parser must return a HouseModel dict")
        shape = canvas_shape(target, model)
        metrics = room_metrics(target, model, shape)
        metrics.update(wall_metrics(target, model, shape))
        metrics.update(opening_metrics(target, model))
        metrics["depthRelativeError"] = abs(float(model["depth"]) - target["depth"]) / target["depth"]
        metrics["widthRelativeError"] = abs(float(model["width"]) - target["width"]) / target["width"]
        if model_path is not None:
            model_path.write_text(
                json.dumps(model, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return {"id": case["id"], "status": "parsed", "latencySeconds": elapsed,
                "expectedRooms": len(target["rooms"]), "expectedOpenings": len(target["openings"]),
                "algorithm": model.get("meta", {}).get("algorithm"),
                "engine": model.get("meta", {}).get("engine", "unreported"),
                "fallbackReason": model.get("meta", {}).get("fallbackReason"), "metrics": metrics,
                "warnings": model.get("warnings", [])}
    except Exception as error:
        return {"id": case["id"], "status": "rejected",
                "expectedRooms": len(target["rooms"]), "expectedOpenings": len(target["openings"]),
                "latencySeconds": time.perf_counter() - start,
                "errorType": type(error).__name__, "error": str(error)}


def summarize(results):
    parsed = [result for result in results if result["status"] == "parsed"]
    total = len(results)
    summary = {"totalCases": total, "parsedCases": len(parsed), "rejectedCases": total - len(parsed),
               "neuralParsedCases": sum(result.get("engine") == "neural" for result in parsed),
               "classicParsedCases": sum(result.get("engine") == "classic" for result in parsed),
               "fallbackParsedCases": sum(bool(result.get("fallbackReason")) for result in parsed),
               "roomCountExactCases": sum(result["metrics"]["roomCountExact"] for result in parsed),
               "roomCountExactRateIncludingRejections":
                   sum(result["metrics"]["roomCountExact"] for result in parsed) / total if total else 0,
               "meanLatencySeconds": statistics.mean(r["latencySeconds"] for r in results) if results else 0}
    for metric in ("targetRoomMeanIoU", "roomF1AtIoU50", "wallF1"):
        # A rejection earns zero. Reporting parsed cases alone would overstate improvement.
        summary[f"{metric}IncludingRejections"] = (
            sum(result["metrics"][metric] for result in parsed) / total if total else 0)
    if parsed:
        summary["meanDepthRelativeErrorParsedOnly"] = statistics.mean(
            result["metrics"]["depthRelativeError"] for result in parsed)
    eligible_openings = [result for result in parsed if result["metrics"]["openingF1"] is not None]
    if eligible_openings:
        summary["meanOpeningF1ParsedCasesWithOpenings"] = statistics.mean(
            result["metrics"]["openingF1"] for result in eligible_openings)
    all_opening_cases = [result for result in results if result["expectedOpenings"]]
    if all_opening_cases:
        summary["meanOpeningF1IncludingRejections"] = sum(
            result["metrics"]["openingF1"] if result["status"] == "parsed" else 0
            for result in all_opening_cases) / len(all_opening_cases)
    return summary


def main():
    argument_parser = argparse.ArgumentParser(description=__doc__)
    argument_parser.add_argument("--parser", default="backend.algorithm:parse_floor_plan",
                                 help="Import path module:function accepting image_bytes, real_width, height")
    argument_parser.add_argument("--fixtures", type=Path,
                                 default=ROOT / "tests" / "fixtures" / "plan-recognition")
    argument_parser.add_argument("--output", type=Path, default=None)
    argument_parser.add_argument("--save-models", type=Path, default=None,
                                 help="Optional directory to save parsed HouseModel JSON for overlays")
    arguments = argument_parser.parse_args()
    module_name, separator, function_name = arguments.parser.partition(":")
    if not separator:
        argument_parser.error("--parser must be module:function")
    parser = getattr(importlib.import_module(module_name), function_name)
    manifest = json.loads((arguments.fixtures / "manifest.json").read_text(encoding="utf-8"))
    results = [evaluate_case(parser, arguments.fixtures, case, arguments.save_models)
               for case in manifest["cases"]]
    report = {"parser": arguments.parser, "scope": manifest["scope"],
              "metricsNote": "Greedy room IoU; wall centreline raster tolerance 0.12m; opening centre 0.30m and width 0.35m tolerances.",
              "summary": summarize(results), "cases": results}
    if arguments.output:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
    for result in results:
        if result["status"] == "parsed":
            metrics = result["metrics"]
            print(f"{result['id']}: rooms {metrics['predictedRooms']}/{metrics['expectedRooms']}, "
                  f"IoU {metrics['targetRoomMeanIoU']:.3f}, wall F1 {metrics['wallF1']:.3f}, "
                  f"depth error {metrics['depthRelativeError']:.1%}, engine {result['engine']}"
                  + (" (fallback)" if result["fallbackReason"] else ""))
        else:
            print(f"{result['id']}: REJECTED ({result['errorType']}) {result['error']}")


if __name__ == "__main__":
    main()
