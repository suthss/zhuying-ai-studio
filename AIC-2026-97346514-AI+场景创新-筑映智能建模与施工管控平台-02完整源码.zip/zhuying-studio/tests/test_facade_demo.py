"""Public facade review contracts: temporary assets, mocked provider, no keys loaded."""
import copy
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
import urllib.error
from unittest.mock import patch

from fastapi import FastAPI
from fastapi.testclient import TestClient
from PIL import Image, ImageDraw

from backend import facade_demo
from backend.algorithm import ModelServiceError, PlanError


def sample_manifest():
    return {"observations": [{
        "id": "iitu-2025-06-25", "image": "/facade-demo/evidence.png",
        "regions": [
            {"id": "F1", "label": "立面观察区 1", "polygon": [[.1, .2], [.3, .2], [.3, .4], [.1, .4]], "status": "installed"},
            {"id": "F2", "label": "立面观察区 2", "polygon": [[.35, .2], [.55, .2], [.55, .4], [.35, .4]], "status": "not_installed"},
            {"id": "F3", "label": "立面观察区 3", "polygon": [[.6, .2], [.8, .2], [.8, .4], [.6, .4]], "status": "installed"},
        ],
    }]}


def valid_result():
    return {"stage": "partial", "summary": "可见玻璃与未封闭区域，反光区域需人工复核。", "regions": [
        {"id": "F1", "status": "installed", "evidence": "窗格呈连续封闭面。"},
        {"id": "F2", "status": "not_installed", "evidence": "可见空窗开口与内侧楼板。"},
        {"id": "F3", "status": "unknown", "evidence": "严重反光，无法确认是否填充玻璃。"},
    ]}


def provider_response(result=None, *, content=None, outer=None):
    if outer is None:
        if content is None:
            content = json.dumps(valid_result() if result is None else result, ensure_ascii=False)
        outer = {"choices": [{"message": {"content": content}}]}
    return io.BytesIO(json.dumps(outer, ensure_ascii=False).encode("utf-8"))


class FacadeReviewTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.assets = Path(self.directory.name) / "assets"
        self.assets.mkdir()
        Image.new("RGB", (480, 320), "#a8b5bb").save(self.assets / "evidence.png")
        self.manifest = sample_manifest()
        self.write_manifest()
        self.asset_patch = patch.object(facade_demo, "ASSETS", self.assets)
        self.asset_patch.start()
        self.addCleanup(self.asset_patch.stop)
        self.env_patch = patch.dict(os.environ, {
            "QWEN_API_KEY": "unit-test-only", "QWEN_MODEL": "qwen3.8-flash",
            "QWEN_BASE_URL": "https://maas.qianwenaiapi.com/compatible-mode/v1",
        }, clear=True)
        self.env_patch.start()
        self.addCleanup(self.env_patch.stop)
        app = FastAPI()
        app.include_router(facade_demo.router)
        self.client = TestClient(app)
        self.addCleanup(self.client.close)
        self.observation_id = "iitu-2025-06-25"

    def write_manifest(self):
        (self.assets / "sample.json").write_text(json.dumps(self.manifest, ensure_ascii=False), encoding="utf-8")

    def review(self, response=None):
        with patch.object(facade_demo.urllib.request, "urlopen", return_value=provider_response() if response is None else response) as provider:
            result = facade_demo.review_facade(self.observation_id)
        return result, provider

    def test_load_known_bundled_id_resolves_only_local_asset(self):
        with patch.object(facade_demo.urllib.request, "urlopen") as network:
            observation, image = facade_demo.load_observation(self.observation_id)
        self.assertEqual(observation, self.manifest["observations"][0])
        self.assertEqual(image.size, (480, 320))
        network.assert_not_called()

    def test_path_like_and_non_string_ids_are_rejected_before_io_or_cloud(self):
        ids = ["../outside", "F/../../secret", "C:\\secret", "https://other.invalid/a", "a%2F..", "", "x" * 81, None, 12, [], {}]
        with patch.object(facade_demo.urllib.request, "urlopen") as network:
            for observation_id in ids:
                with self.subTest(observation_id=observation_id), self.assertRaises(PlanError):
                    facade_demo.review_facade(observation_id)
        network.assert_not_called()

    def test_unknown_safe_id_has_explanatory_error_and_no_provider_call(self):
        with patch.object(facade_demo.urllib.request, "urlopen") as network, self.assertRaisesRegex(PlanError, "找不到"):
            facade_demo.review_facade("iitu-unknown-date")
        network.assert_not_called()

    def test_manifest_cannot_reference_file_outside_public_assets(self):
        outside = self.assets.parent / "outside.png"
        Image.new("RGB", (480, 320), "white").save(outside)
        for image_url in ["/facade-demo/../outside.png", "https://other.invalid/evidence.png", "/private/evidence.png"]:
            with self.subTest(image_url=image_url):
                self.manifest["observations"][0]["image"] = image_url
                self.write_manifest()
                with patch.object(facade_demo.urllib.request, "urlopen") as network, self.assertRaises(PlanError):
                    facade_demo.review_facade(self.observation_id)
                network.assert_not_called()

    def test_invalid_region_calibration_is_rejected(self):
        variants = [[], [{"id": "F1", "polygon": [[0, 0], [1, 0]]}],
                    [{"id": "F1", "polygon": [[0, 0], [1, 0], [1.01, 1]]}],
                    [{"id": "F1", "polygon": [[0, 0], [1, 0], [True, 1]]}],
                    [{"id": "F1", "polygon": [[0, 0], [1, 0], [float("nan"), 1]]}],
                    [copy.deepcopy(sample_manifest()["observations"][0]["regions"][0])] * 2]
        for regions in variants:
            with self.subTest(regions=regions):
                self.manifest["observations"][0]["regions"] = regions
                self.write_manifest()
                with patch.object(facade_demo.urllib.request, "urlopen") as network, self.assertRaises(PlanError):
                    facade_demo.review_facade(self.observation_id)
                network.assert_not_called()

    def test_missing_key_keeps_public_replay_available_and_never_calls_provider(self):
        for key in ["", "   "]:
            with self.subTest(key=key), patch.dict(os.environ, {"QWEN_API_KEY": key}), patch.object(facade_demo.urllib.request, "urlopen") as network:
                with self.assertRaisesRegex(ModelServiceError, "尚未配置"):
                    facade_demo.review_facade(self.observation_id)
                network.assert_not_called()

    def test_complete_review_preserves_unknown_and_never_mutates_manual_states(self):
        before = (self.assets / "sample.json").read_bytes()
        result, _ = self.review()
        self.assertEqual(result["source"], "qwen/qwen3.8-flash")
        self.assertEqual(result["stage"], "partial")
        self.assertTrue(result["needsReview"])
        self.assertEqual(result["regions"], valid_result()["regions"])
        self.assertEqual(result["regions"][2]["status"], "unknown")
        self.assertEqual((self.assets / "sample.json").read_bytes(), before)
        self.assertNotIn("progress", result)
        self.assertNotIn("completionPercent", result)

    def test_provider_gets_original_numbered_and_crop_images_without_manual_truth(self):
        _, provider = self.review()
        request = provider.call_args.args[0]
        payload = json.loads(request.data)
        self.assertEqual(request.full_url, "https://maas.qianwenaiapi.com/compatible-mode/v1/chat/completions")
        self.assertEqual(provider.call_args.kwargs["timeout"], 60)
        self.assertEqual(payload["response_format"], {"type": "json_object"})
        self.assertFalse(payload["enable_thinking"])
        content = payload["messages"][1]["content"]
        regions = json.loads(content[0]["text"])["regions"]
        self.assertEqual([r["id"] for r in regions], ["F1", "F2", "F3"])
        self.assertTrue(all("status" not in r for r in regions))
        urls = [item["image_url"]["url"] for item in content if item["type"] == "image_url"]
        self.assertEqual(len(urls), 3)
        self.assertTrue(all(url.startswith("data:image/jpeg;base64,") for url in urls))
        self.assertNotEqual(urls[0], urls[1])
        self.assertNotEqual(urls[0], urls[2])

    def test_contact_sheet_contains_each_original_crop_and_is_state_independent(self):
        original = Image.new("RGB", (480, 320), "#999999")
        source_draw = ImageDraw.Draw(original)
        for left, right, color in [(48, 144, "#df3020"), (168, 264, "#20c040"), (288, 384, "#3050df")]:
            source_draw.rectangle((left, 60, right, 140), fill=color)
        original.save(self.assets / "evidence.png")
        captured = []
        real_encoder = facade_demo._inspection_image_url

        def capture_image(image):
            captured.append(image.copy())
            return real_encoder(image)

        with patch.object(facade_demo, "_inspection_image_url", side_effect=capture_image):
            _, provider = self.review()
        self.assertEqual(len(captured), 3)
        sheet = captured[2]
        self.assertEqual(sheet.size, (1440, 1440))
        # Per-cell interiors must retain the distinct local source pixels;
        # using a duplicated full-frame image would fail these comparisons.
        self.assertEqual(sheet.getpixel((240, 200)), (223, 48, 32))
        self.assertEqual(sheet.getpixel((720, 200)), (32, 192, 64))
        self.assertEqual(sheet.getpixel((1200, 200)), (48, 80, 223))
        first_payload = json.loads(provider.call_args.args[0].data)
        user_data = json.loads(first_payload["messages"][1]["content"][0]["text"])
        self.assertEqual(user_data["cropOrder"], ["F1", "F2", "F3"])
        self.assertTrue(all(set(region) == {"id", "label", "polygon"} for region in user_data["regions"]))
        # Change every manual state without changing pixels or calibration;
        # the complete visual/text input must stay byte-for-byte identical.
        for region in self.manifest["observations"][0]["regions"]:
            region["status"] = "unknown" if region["status"] != "unknown" else "installed"
        self.write_manifest()
        _, second_provider = self.review()
        self.assertEqual(json.loads(second_provider.call_args.args[0].data), first_payload)

    def test_foreign_and_duplicate_or_missing_regions_fail_atomically(self):
        variants = []
        missing = valid_result()
        missing["regions"].pop()
        variants.append(missing)
        duplicate = valid_result()
        duplicate["regions"][2] = copy.deepcopy(duplicate["regions"][0])
        variants.append(duplicate)
        foreign = valid_result()
        foreign["regions"][2]["id"] = "another-project-region"
        variants.append(foreign)
        extra = valid_result()
        extra["regions"].append({"id": "F4", "status": "installed", "evidence": "不应存在"})
        variants.append(extra)
        for response in variants:
            with self.subTest(response=response), self.assertRaisesRegex(ModelServiceError, "完整有效"):
                self.review(provider_response(response))

    def test_invalid_state_or_empty_evidence_does_not_infer_completion(self):
        variants = []
        for state in ["complete", "completed", "50%", None, ["installed"]]:
            item = valid_result()
            item["regions"][0]["status"] = state
            variants.append(item)
        for evidence in ["", "  ", None, 4]:
            item = valid_result()
            item["regions"][0]["evidence"] = evidence
            variants.append(item)
        for response in variants:
            with self.subTest(response=response), self.assertRaises(ModelServiceError):
                self.review(provider_response(response))

    def test_invalid_stage_summary_or_provider_envelope_is_rejected(self):
        invalid_results = [{}, [], {**valid_result(), "stage": "completed"}, {**valid_result(), "summary": "  "}]
        for response in invalid_results:
            with self.subTest(response=response), self.assertRaises(ModelServiceError):
                self.review(provider_response(response))
        for outer in [{}, {"choices": []}, {"choices": [{"message": {"content": None}}]}]:
            with self.subTest(outer=outer), self.assertRaises(ModelServiceError):
                self.review(provider_response(outer=outer))

    def test_single_complete_json_fence_is_accepted(self):
        content = "说明：\n```json\n" + json.dumps(valid_result(), ensure_ascii=False) + "\n```"
        result, _ = self.review(provider_response(content=content))
        self.assertEqual(result["regions"], valid_result()["regions"])

    def test_malformed_truncated_and_ambiguous_json_is_rejected(self):
        full = json.dumps(valid_result(), ensure_ascii=False)
        for content in ["not json", full[:-4], "```json\n" + full, "```json\n" + full + "\n```\n```json\n" + full + "\n```"]:
            with self.subTest(content=content[:30]), self.assertRaises(ModelServiceError):
                self.review(provider_response(content=content))

    def test_provider_response_size_is_bounded(self):
        with self.assertRaisesRegex(ModelServiceError, "过大"):
            self.review(io.BytesIO(b"x" * 1_000_001))

    def test_provider_auth_and_rate_limit_errors_are_actionable(self):
        for code, message in [(401, "鉴权失败"), (403, "鉴权失败"), (429, "调用受限"), (500, "HTTP 500")]:
            error = urllib.error.HTTPError("https://provider.invalid", code, "private-provider-error", {}, None)
            with self.subTest(code=code), patch.object(facade_demo.urllib.request, "urlopen", side_effect=error):
                with self.assertRaisesRegex(ModelServiceError, message) as caught:
                    facade_demo.review_facade(self.observation_id)
                self.assertNotIn("private-provider-error", str(caught.exception))

    def test_provider_timeout_and_network_errors_do_not_change_states(self):
        before = (self.assets / "sample.json").read_bytes()
        for error in [TimeoutError("timeout"), urllib.error.URLError("unreachable"), OSError("offline")]:
            with self.subTest(error=type(error).__name__), patch.object(facade_demo.urllib.request, "urlopen", side_effect=error):
                with self.assertRaisesRegex(ModelServiceError, "连接失败或超时"):
                    facade_demo.review_facade(self.observation_id)
        self.assertEqual((self.assets / "sample.json").read_bytes(), before)

    def test_route_success_returns_suggestions_only(self):
        with patch.object(facade_demo.urllib.request, "urlopen", return_value=provider_response()) as network:
            response = self.client.post("/api/facade-demo/analyze", json={"observationId": self.observation_id})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["needsReview"])
        self.assertEqual(response.json()["regions"][2]["status"], "unknown")
        network.assert_called_once()

    def test_route_rejects_invalid_json_body_and_id_without_cloud_call(self):
        payloads = [b"{broken", b"\xff", b"[]", b"null", b"1", b"{}", b'{"observationId":"../private"}', b'{"observationId": ["F1"]}', b'{"observationId":"missing-date"}']
        with patch.object(facade_demo.urllib.request, "urlopen") as network:
            for payload in payloads:
                with self.subTest(payload=payload):
                    response = self.client.post("/api/facade-demo/analyze", content=payload, headers={"Content-Type": "application/json"})
                    self.assertEqual(response.status_code, 422)
        network.assert_not_called()

    def test_route_requires_json_content_type(self):
        for content_type in ["text/plain", "application/octet-stream", "multipart/form-data"]:
            with self.subTest(content_type=content_type), patch.object(facade_demo.urllib.request, "urlopen") as network:
                response = self.client.post("/api/facade-demo/analyze", content=b'{}', headers={"Content-Type": content_type})
                self.assertEqual(response.status_code, 415)
                network.assert_not_called()

    def test_route_rejects_body_above_limit_before_json_or_cloud(self):
        with patch.object(facade_demo.urllib.request, "urlopen") as network:
            response = self.client.post("/api/facade-demo/analyze", content=b" " * 8193, headers={"Content-Type": "application/json"})
        self.assertEqual(response.status_code, 413)
        network.assert_not_called()

    def test_route_accepts_exact_body_limit_and_charset_parameter(self):
        body = json.dumps({"observationId": self.observation_id}).encode().ljust(8192, b" ")
        with patch.object(facade_demo.urllib.request, "urlopen", return_value=provider_response()) as network:
            response = self.client.post("/api/facade-demo/analyze", content=body, headers={"Content-Type": "application/json; charset=utf-8"})
        self.assertEqual(response.status_code, 200)
        network.assert_called_once()

    def test_route_missing_key_is_service_error_and_preserves_manual_file(self):
        before = (self.assets / "sample.json").read_bytes()
        with patch.dict(os.environ, {"QWEN_API_KEY": ""}), patch.object(facade_demo.urllib.request, "urlopen") as network:
            response = self.client.post("/api/facade-demo/analyze", json={"observationId": self.observation_id})
        self.assertEqual(response.status_code, 502)
        self.assertIn("尚未配置", response.json()["detail"])
        self.assertEqual((self.assets / "sample.json").read_bytes(), before)
        network.assert_not_called()

    def test_route_provider_failures_are_service_errors_not_partial_success(self):
        for failure in [TimeoutError("timeout"), urllib.error.HTTPError("https://provider.invalid", 401, "auth", {}, None)]:
            with self.subTest(failure=type(failure).__name__), patch.object(facade_demo.urllib.request, "urlopen", side_effect=failure):
                response = self.client.post("/api/facade-demo/analyze", json={"observationId": self.observation_id})
                self.assertEqual(response.status_code, 502)
        with patch.object(facade_demo.urllib.request, "urlopen", return_value=provider_response(content="incomplete")):
            response = self.client.post("/api/facade-demo/analyze", json={"observationId": self.observation_id})
        self.assertEqual(response.status_code, 502)
        self.assertNotIn("regions", response.json())


if __name__ == "__main__":
    unittest.main()
