import io
import importlib.util
import json
import os
import unittest
import urllib.error
from unittest.mock import patch

from PIL import Image, ImageDraw

from backend.algorithm import MAX_IMAGE_BYTES, ModelServiceError, PlanError, analyze_photo, parse_floor_plan


def plan_bytes(gap=False):
    """A 12 by 8 metre closed shell, partitioned into six rooms."""
    image = Image.new("RGB", (1300, 900), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((50, 50, 1250, 850), outline="black", width=15)
    for x in (450, 850):
        draw.line((x, 50, x, 850), fill="black", width=11)
    draw.line((50, 450, 1250, 450), fill="black", width=11)
    if gap:
        draw.rectangle((50, 80, 68, 840), fill="white")
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return buffer.getvalue()


class FloorPlanTests(unittest.TestCase):
    def test_closed_plan_generates_six_rooms_and_metric_geometry(self):
        model = parse_floor_plan(plan_bytes(), real_width=12.0, height=2.9)
        self.assertEqual(len(model["rooms"]), 6)
        self.assertEqual(model["source"], "opencv")
        self.assertAlmostEqual(model["width"], 12.0)
        self.assertAlmostEqual(model["depth"], 8.0, delta=0.12)
        self.assertEqual(model["height"], 2.9)
        self.assertGreaterEqual(len(model["walls"]), 7)
        self.assertEqual(model["openings"], [])
        for room in model["rooms"]:
            self.assertGreater(room["area"], 14)
            self.assertLess(room["area"], 17)
            self.assertEqual(room["progress"], 0)
            self.assertTrue(room["material"])
            self.assertEqual(set(room["tasks"]), {"floor", "wall"})
            for task in room["tasks"].values():
                self.assertEqual(task["stage"], "unknown")
                self.assertEqual(task["plannedStage"], "unknown")
                self.assertEqual(task["dueDate"], "")
            for x, z in room["polygon"]:
                self.assertGreaterEqual(x, 0)
                self.assertGreaterEqual(z, 0)
                self.assertLessEqual(x, model["width"])
                self.assertLessEqual(z, model["depth"])

    def test_scale_changes_dimensions_and_area_consistently(self):
        small = parse_floor_plan(plan_bytes(), real_width=6)
        large = parse_floor_plan(plan_bytes(), real_width=12)
        self.assertAlmostEqual(large["depth"], 2 * small["depth"], places=2)
        self.assertAlmostEqual(large["rooms"][0]["area"], 4 * small["rooms"][0]["area"], delta=0.04)

    def test_blank_image_is_rejected_instead_of_fabricating_house(self):
        image = Image.new("RGB", (1000, 800), "white")
        buffer = io.BytesIO()
        image.save(buffer, "PNG")
        with self.assertRaisesRegex(PlanError, "墙|wall"):
            parse_floor_plan(buffer.getvalue())

    def test_nonimage_and_oversize_inputs_are_rejected(self):
        with self.assertRaises(PlanError):
            parse_floor_plan(b"this is not an image")
        with self.assertRaisesRegex(PlanError, "10"):
            parse_floor_plan(b"0" * (MAX_IMAGE_BYTES + 1))

    def test_invalid_metric_parameters_are_rejected(self):
        for value in (0, -1, float("nan"), float("inf")):
            with self.assertRaises(PlanError):
                parse_floor_plan(plan_bytes(), real_width=value)

    def test_excessive_decoded_dimensions_are_rejected(self):
        image = Image.new("RGB", (5000, 4001), "white")
        buffer = io.BytesIO()
        image.save(buffer, "PNG")
        with self.assertRaisesRegex(PlanError, "尺寸"):
            parse_floor_plan(buffer.getvalue())


class PhotoTests(unittest.TestCase):
    def test_without_api_key_returns_unknown_and_requires_review(self):
        with patch.dict(os.environ, {}, clear=True):
            observation = analyze_photo(plan_bytes(), "客厅", "floor")
        self.assertEqual(observation["stage"], "unknown")
        self.assertTrue(observation["needsReview"])
        self.assertEqual(observation["source"], "manual_review")
        self.assertIn("未配置", observation["summary"])

    def test_work_type_is_validated(self):
        with self.assertRaises(PlanError):
            analyze_photo(plan_bytes(), "客厅", "anything")

    def test_provider_observation_remains_reviewable_and_key_is_not_returned(self):
        response = io.BytesIO(json.dumps({"choices": [{"message": {"content": json.dumps({
            "stage": "in_progress", "summary": "可见地面部分铺设，遮挡区域需补拍。"}, ensure_ascii=False)}}]}).encode())
        env = {"QWEN_API_KEY": "unit-test-secret", "QWEN_MODEL": "qwen-vl-plus"}
        with patch.dict(os.environ, env, clear=True), patch("urllib.request.urlopen", return_value=response) as request:
            observation = analyze_photo(plan_bytes(), "客厅", "floor")
        self.assertEqual(observation["stage"], "in_progress")
        self.assertTrue(observation["needsReview"])
        self.assertEqual(observation["source"], "qwen/qwen-vl-plus")
        self.assertNotIn("unit-test-secret", json.dumps(observation))
        self.assertEqual(request.call_count, 1)
        sent_request = request.call_args.args[0]
        self.assertEqual(sent_request.full_url, "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions")
        sent = json.loads(sent_request.data)
        self.assertEqual(sent["model"], "qwen-vl-plus")
        self.assertNotIn("enable_thinking", sent)
        self.assertNotIn("response_format", sent)

    def test_flash_single_photo_uses_new_official_url_and_nonthinking_json_mode(self):
        for model in ("qwen3.8-flash", "qwen3.8-flash-2026-10-05"):
            expected = {"stage": "unknown", "summary": "照片未提供完整覆盖，需人工复核。"}
            response = io.BytesIO(json.dumps({"choices": [{"message": {"content": json.dumps(expected, ensure_ascii=False)}}]}).encode())
            env = {"QWEN_API_KEY": "unit-test-secret", "QWEN_MODEL": model,
                   "QWEN_BASE_URL": "https://maas.qianwenaiapi.com/compatible-mode/v1"}
            with self.subTest(model=model), patch.dict(os.environ, env, clear=True), \
                    patch("urllib.request.urlopen", return_value=response) as network:
                observation = analyze_photo(plan_bytes(), "客厅", "floor")
                request = network.call_args.args[0]
                self.assertEqual(request.full_url, "https://maas.qianwenaiapi.com/compatible-mode/v1/chat/completions")
                self.assertEqual(request.get_method(), "POST")
                self.assertEqual(request.get_header("Authorization"), "Bearer unit-test-secret")
                payload = json.loads(request.data)
                self.assertEqual(payload["model"], model)
                self.assertFalse(payload["enable_thinking"])
                self.assertEqual(payload["response_format"], {"type": "json_object"})
                self.assertEqual(payload["max_tokens"], 700)
                self.assertEqual(payload["temperature"], 0)
                self.assertEqual([part["type"] for part in payload["messages"][1]["content"]], ["text", "image_url"])
                self.assertEqual(observation["source"], "qwen/" + model)
                self.assertTrue(observation["needsReview"])
                self.assertNotIn("unit-test-secret", json.dumps(observation))

    def test_only_exact_official_url_is_allowed_before_single_photo_request(self):
        base = "https://maas.qianwenaiapi.com/compatible-mode/v1"
        rejected = [base.replace("https://", "http://"),
                    "https://maas.qianwenai.com/compatible-mode/v1",
                    "https://maas.qianwenaiapi.com.evil.example/compatible-mode/v1",
                    "https://evilmaas.qianwenaiapi.com/compatible-mode/v1",
                    "https://user@maas.qianwenaiapi.com/compatible-mode/v1",
                    "https://maas.qianwenaiapi.com@evil.example/compatible-mode/v1",
                    base + "/chat/completions", base + "/../other", base + "?redirect=evil", base + "#fragment"]
        for url in rejected:
            with self.subTest(url=url), \
                    patch.dict(os.environ, {"QWEN_API_KEY": "unit-test-secret", "QWEN_BASE_URL": url}, clear=True), \
                    patch("urllib.request.urlopen") as network:
                with self.assertRaises(ModelServiceError):
                    analyze_photo(plan_bytes(), "客厅", "floor")
            network.assert_not_called()

    def test_invalid_provider_output_does_not_become_a_success(self):
        response = io.BytesIO(b'{"choices":[{"message":{"content":"not json"}}]}')
        with patch.dict(os.environ, {"QWEN_API_KEY": "unit-test-secret"}, clear=True), \
                patch("urllib.request.urlopen", return_value=response):
            with self.assertRaisesRegex(ModelServiceError, "JSON"):
                analyze_photo(plan_bytes(), "客厅", "wall")

    def test_provider_auth_error_does_not_expose_secret(self):
        error = urllib.error.HTTPError("https://dashscope.aliyuncs.com", 401, "unit-test-secret", {}, None)
        with patch.dict(os.environ, {"QWEN_API_KEY": "unit-test-secret"}, clear=True), \
                patch("urllib.request.urlopen", side_effect=error):
            with self.assertRaises(ModelServiceError) as caught:
                analyze_photo(plan_bytes(), "客厅", "wall")
        self.assertNotIn("unit-test-secret", str(caught.exception))
        self.assertIn("鉴权", str(caught.exception))

    def test_untrusted_provider_url_is_rejected_before_request(self):
        env = {"QWEN_API_KEY": "unit-test-secret", "QWEN_BASE_URL": "https://example.com/compatible-mode/v1"}
        with patch.dict(os.environ, env, clear=True), patch("urllib.request.urlopen") as request:
            with self.assertRaisesRegex(ModelServiceError, "官方"):
                analyze_photo(plan_bytes(), "客厅", "wall")
        request.assert_not_called()


@unittest.skipUnless(importlib.util.find_spec("fastapi") and importlib.util.find_spec("httpx")
                     and importlib.util.find_spec("multipart"), "API test dependencies are not installed")
class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from backend.app import app
        cls.client = TestClient(app)

    def test_parse_endpoint_returns_house_model(self):
        response = self.client.post("/api/parse-plan", files={"file": ("plan.png", plan_bytes(), "image/png")},
                                    data={"real_width": "12", "height": "2.9", "engine": "classic"})
        self.assertEqual(response.status_code, 200, response.text)
        model = response.json()
        self.assertEqual(len(model["rooms"]), 6)
        self.assertEqual(model["height"], 2.9)

    def test_photo_endpoint_without_key_and_health_are_honest(self):
        with patch.dict(os.environ, {}, clear=True):
            health = self.client.get("/api/health")
            response = self.client.post("/api/analyze-photo", files={"file": ("photo.png", plan_bytes(), "image/png")},
                                        data={"room_name": "客厅", "work_type": "floor"})
        self.assertFalse(health.json()["visionConfigured"])
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["stage"], "unknown")
        self.assertTrue(response.json()["needsReview"])

    def test_invalid_upload_has_actionable_error_status(self):
        response = self.client.post("/api/parse-plan", files={"file": ("plan.png", b"not an image", "image/png")})
        self.assertEqual(response.status_code, 422)
        self.assertIn("图片", response.json()["detail"])
        oversized = self.client.post("/api/parse-plan", files={"file": (
            "big.png", b"0" * (MAX_IMAGE_BYTES + 1), "image/png")})
        self.assertEqual(oversized.status_code, 413)


if __name__ == "__main__":
    unittest.main()
