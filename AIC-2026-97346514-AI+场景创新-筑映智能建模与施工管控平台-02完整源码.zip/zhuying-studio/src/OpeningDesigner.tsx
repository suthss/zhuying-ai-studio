import { useEffect, useMemo, useState } from 'react';
import { DoorOpen, PanelsTopLeft, Check, Ruler, Plus, AlertTriangle, SlidersHorizontal } from 'lucide-react';
import { doorStyles, windowStyles, getRoomOpenings, getOpeningErrors, resolveOpeningDesign } from './openings.mjs';
import type { HouseModel, Opening, OpeningDesign, Room } from './types';
import './opening-designer.css';

interface Props {
  model: HouseModel; room: Room; selectedOpening: string | null;
  onSelect: (id: string) => void;
  onChange: (id: string, patch: Partial<Opening>) => void;
  onStructure: () => void;
}
const FRAME_COLORS = [
  { color: '#c9b99b', label: '浅木' }, { color: '#76553c', label: '胡桃木' },
  { color: '#f0eee8', label: '暖白' }, { color: '#596b63', label: '墨绿' },
  { color: '#343b3b', label: '石墨' }, { color: '#a7b1b2', label: '银灰' },
];
const wallNames: Record<string, string> = { north: '北侧外墙', east: '东侧外墙', south: '南侧外墙', west: '西侧外墙', spine: '卧室隔墙', cross: '南北隔墙', 'kitchen-div': '厨房隔墙', 'bath-div': '卫生间隔墙' };
function wallLabel(model: HouseModel, id: string) { return wallNames[id] ?? `墙段 ${model.walls.findIndex(w => w.id === id) + 1}`; }
function draftOf(opening: Opening) { return { width: String(opening.width), height: String(opening.height), offset: String(opening.offset), sill: String(opening.sill ?? 0), wallId: opening.wallId }; }

export default function OpeningDesigner(props: Props) {
  const openings = getRoomOpenings(props.model, props.room.id);
  const opening = props.model.openings.find(o => o.id === props.selectedOpening) ?? openings[0];
  return <div className="opening-designer">
    <div className="opening-intro"><SlidersHorizontal size={15}/><p>选择门窗，调整样式、尺寸与开启方式。也可以直接点击模型中的门窗。</p></div>
    {!openings.length && !opening ? <div className="opening-empty"><PanelsTopLeft size={30}/><strong>这个空间还没有门窗</strong><p>在结构编辑器中，选择墙段并添加门或窗。</p><button className="button secondary" onClick={props.onStructure}><Plus size={14}/>添加门窗</button></div> : <>
      <div className="opening-list" aria-label="当前房间的门窗">{openings.map((o, index) => <button key={o.id} className={opening?.id === o.id ? 'selected' : ''} aria-pressed={opening?.id === o.id} aria-label={`编辑${o.type === 'door' ? '房门' : '窗户'}${index + 1}`} onClick={() => props.onSelect(o.id)}>{o.type === 'door' ? <DoorOpen size={18}/> : <PanelsTopLeft size={18}/>}<span><strong>{o.type === 'door' ? '房门' : '窗户'} {index + 1}</strong><small>{wallLabel(props.model, o.wallId)}</small></span><small>{o.width.toFixed(2)} × {o.height.toFixed(2)} m</small></button>)}</div>
      {opening && <OpeningControls key={opening.id} opening={opening} model={props.model} onChange={props.onChange}/>}
    </>}
    <button className="opening-structure-link" onClick={props.onStructure}><Plus size={13}/>添加、删除或校正门窗位置</button>
  </div>;
}

function OpeningControls({ opening, model, onChange }: { opening: Opening; model: HouseModel; onChange: Props['onChange'] }) {
  const [draft, setDraft] = useState(() => draftOf(opening));
  const [error, setError] = useState('');
  const [applied, setApplied] = useState(false);
  useEffect(() => { setDraft(draftOf(opening)); setError(''); }, [opening.id, opening.width, opening.height, opening.offset, opening.sill, opening.wallId]);
  const design = resolveOpeningDesign(opening);
  const candidate = useMemo(() => {const number = (value:string) => value.trim()===''?NaN:Number(value);return { ...opening, wallId: draft.wallId, width: number(draft.width), height: number(draft.height), offset: number(draft.offset), ...(opening.type === 'window' ? { sill: number(draft.sill) } : { sill: 0 }) };}, [opening, draft]);
  const errors = getOpeningErrors(model, candidate);
  const dirty = Object.entries(draft).some(([key, value]) => value !== draftOf(opening)[key as keyof typeof draft]);
  function changeDesign(patch: Partial<OpeningDesign>) {
    try { onChange(opening.id, { design: { ...design, ...patch } }); setError(''); } catch (e) { setError(e instanceof Error ? e.message : '请检查门窗参数。'); }
  }
  function applyDimensions() {
    if (errors.length) return;
    try { onChange(opening.id, { width: candidate.width, height: candidate.height, offset: candidate.offset, sill: candidate.sill, wallId: candidate.wallId }); setError(''); setApplied(true); } catch (e) { setError(e instanceof Error ? e.message : '请检查尺寸与位置。'); }
  }
  return <>
    <section className="opening-section"><div className="opening-section-heading"><h3>{opening.type === 'door' ? '门扇样式' : '窗型'}</h3><span>实时预览</span></div><div className="opening-style-options">{(opening.type === 'door' ? doorStyles : windowStyles).map(s => <button key={s.id} aria-label={`选择${s.label}`} aria-pressed={design.style === s.id} className={design.style === s.id ? 'active' : ''} onClick={() => changeDesign({ style: s.id, openAngle: s.id === 'fixed' || s.id === 'sliding' ? 0 : design.openAngle })}>{opening.type === 'door' ? <DoorOpen size={17}/> : <PanelsTopLeft size={17}/>}<span>{s.label}</span></button>)}</div>
      <h4>{opening.type === 'door' ? '门扇与门套颜色' : '窗框颜色'}</h4><div className="opening-colors">{FRAME_COLORS.map(c => <button key={c.color} title={c.label} aria-label={`门窗颜色${c.label}`} aria-pressed={design.color.toLowerCase() === c.color} onClick={() => changeDesign({ color: c.color })} style={{ backgroundColor: c.color }} className={design.color.toLowerCase() === c.color ? 'active' : ''}>{design.color.toLowerCase() === c.color && <Check size={14}/>}</button>)}<label title="自定义门窗颜色"><input aria-label="自定义门窗颜色" type="color" value={design.color} onChange={e => changeDesign({ color: e.target.value })}/></label></div>
      {(opening.type === 'window' || design.style === 'glass') && <label className="field-label opening-field">玻璃效果<select aria-label="门窗玻璃效果" value={design.glassTint} onChange={e => changeDesign({ glassTint: e.target.value as OpeningDesign['glassTint'] })}><option value="clear">清透玻璃</option><option value="smoke">烟灰玻璃</option></select></label>}
    </section>
    {(opening.type === 'door' || design.style === 'casement') && <section className="opening-section"><div className="opening-section-heading"><h3>开启方式</h3><strong>{design.openAngle}°</strong></div><input className="opening-angle" type="range" min="0" max={opening.type === 'door' ? 100 : 60} step="5" value={design.openAngle} aria-label="门窗开启角度" onChange={e => changeDesign({ openAngle: Number(e.target.value) })}/><div className="opening-range-labels"><span>闭合</span><span>{opening.type === 'door' ? '100°' : '60°'}</span></div><div className="opening-inline-field"><span>铰链位置</span><div className="direction-buttons"><button className={design.hinge === 'start' ? 'active' : ''} aria-pressed={design.hinge === 'start'} onClick={() => changeDesign({ hinge: 'start' })}>墙段起点侧</button><button className={design.hinge === 'end' ? 'active' : ''} aria-pressed={design.hinge === 'end'} onClick={() => changeDesign({ hinge: 'end' })}>墙段终点侧</button></div></div><div className="opening-inline-field"><span>开启方向</span><select aria-label="门窗开启方向" value={design.swing} onChange={e => changeDesign({ swing: Number(e.target.value) as 1 | -1 })}><option value="1">墙段正侧</option><option value="-1">墙段反侧</option></select></div><p className="opening-help">位置与方向以户型墙段为基准；请在模型中核对门扇的开启空间。</p></section>}
    <section className="opening-section"><div className="opening-section-heading"><h3><Ruler size={13}/>尺寸与位置</h3><span>单位：米</span></div><p className="opening-help">样式与颜色即时生效；尺寸和位置修改后，点击下方“应用尺寸与位置”更新模型。</p><label className="field-label opening-field">所在墙段<select aria-label="门窗所在墙段" value={draft.wallId} onChange={e => { setDraft(d => ({ ...d, wallId: e.target.value })); setApplied(false); }}>{model.walls.map(w => <option key={w.id} value={w.id}>{wallLabel(model, w.id)}</option>)}</select></label><div className="opening-dimensions">{(['width', 'height', 'offset', ...(opening.type === 'window' ? ['sill'] : [])] as (keyof Omit<typeof draft, 'wallId'>)[]).map(key => <label key={key} className="field-label">{{ width: '开口宽度', height: '开口高度', offset: '距墙段起点', sill: '窗台高度' }[key]}<div><input aria-label={{ width: '门窗开口宽度', height: '门窗开口高度', offset: '门窗位置偏移', sill: '窗台高度' }[key]} type="number" min={key === 'width' || key === 'height' ? .12 : 0} step=".05" value={draft[key]} onChange={e => { setDraft(d => ({ ...d, [key]: e.target.value })); setApplied(false); }}/><span>m</span></div></label>)}</div>{(error || (dirty && errors.length > 0)) && <p className="opening-error" role="alert"><AlertTriangle size={14}/>{error || errors[0]}</p>}<button className="button secondary opening-apply" disabled={!dirty || errors.length > 0} onClick={applyDimensions}><Check size={14}/>{applied && !dirty ? '尺寸已应用' : '应用尺寸与位置'}</button><p className="opening-help">{dirty?'尺寸尚未应用。':''}超出墙体或与已有开口重叠的尺寸无法应用。</p></section>
  </>;
}
