import { useEffect, useState } from 'react';
import { ArrowRight, ExternalLink, Image, LoaderCircle } from 'lucide-react';
import { createIssue } from './issues.mjs';
import type { IssuePhoto } from './issues.mjs';
import { localToday } from './calendar';
import type { HouseModel, Room } from './types';

interface CaseFrame {id:string;image:string;alt:string;view:string;sourceTimeSeconds:number;fullFrame:string}
interface CaseStage {id:string;roomId:string;label:string;capturedDate:string;images:CaseFrame[];image:string;dateEvidence:{image:string;sourceTimeSeconds:number};summary?:string}
interface PublicCase {schemaVersion:1;id:string;title:string;subtitle:string;source:{url:string;attribution:string;publishedAt:string;license:{label:string;url:string}};stages:CaseStage[];referenceStages:CaseStage[]}
export function casePhotos(model:HouseModel): (IssuePhoto&{roomId:string})[] {
  const raw=model.meta?.publicCasePhotos;if(!Array.isArray(raw))return[];
  return raw.filter(p=>p&&typeof p==='object'&&typeof p.image==='string'&&/^\/renovation-case\/[a-zA-Z0-9_-]+\.(?:jpg|png|webp)$/.test(p.image)&&typeof p.roomId==='string') as (IssuePhoto&{roomId:string})[];
}
function demoRoom(id:string,name:string,x:number):Room {return{id,name,polygon:[[x,0],[x+5,0],[x+5,4],[x,4]],area:20,material:'concrete',progress:0,tasks:{floor:{enabled:true,stage:'unknown',plannedStage:'unknown',dueDate:''},wall:{enabled:true,stage:'unknown',plannedStage:'unknown',dueDate:''}},evidence:[],design:{floorFinish:'concrete',floorDirection:0,wallFinish:'plaster',wallColor:'#eeeae1'}};}
export function createRenovationModel(data:PublicCase):HouseModel {
  const rooms=[demoRoom('rub-5-169','5-169 · 同室时序示意',0),demoRoom('rub-2-169','2-169 · 独立阶段参考',6)];
  const walls=rooms.flatMap(r=>r.polygon.map((start,i)=>({id:`${r.id}-wall-${i}`,start,end:r.polygon[(i+1)%4],thickness:.14})));
  const photos=[...data.stages,...data.referenceStages].flatMap(stage=>stage.images.map(frame=>({id:frame.id,roomId:`rub-${stage.roomId}`,image:frame.image,caption:`${stage.capturedDate} · ${stage.roomId} · ${stage.label} · ${frame.view==='wall'?'墙侧':'窗侧'}`,captureDate:stage.capturedDate,source:'public_case' as const})));
  const model:HouseModel={id:`rub-case-${crypto.randomUUID()}`,name:'波鸿大学 IC 楼 · 公开案例演练',width:11,depth:4,height:2.8,source:'manual',walls,
    openings:rooms.flatMap(r=>[{id:`${r.id}-window`,wallId:`${r.id}-wall-0`,type:'window' as const,offset:1,width:3,height:1.4,sill:.8},{id:`${r.id}-door`,wallId:`${r.id}-wall-2`,type:'door' as const,offset:1,width:.9,height:2.1}]),rooms,furniture:[],
    warnings:['房间尺寸、相对位置、门窗及模型仅为操作示意，不是该楼的实测户型或照片三维重建。','影像及拍摄日期为公开资料；任务、责任人、处理期限和操作流转为模拟演练。'],
    meta:{demoData:true,publicCase:{id:data.id,url:data.source.url,attribution:data.source.attribution,geometry:'illustrative',tasks:'simulated'},publicCasePhotos:photos}};
  const date=localToday();
  const tracker=createIssue(model,{roomId:'rub-5-169',title:'核对墙面阶段变化',description:'演练任务：对照两期同室墙侧影像，记录石膏板安装到批灰的可见变化。不是数据集记录的真实缺陷。',location:'墙侧影像',workType:'wall',assignee:'示例现场负责人',dueDate:date,photos:photos.filter(p=>p.roomId==='rub-5-169'&&p.id==='stage-01-wall')},{id:crypto.randomUUID(),eventId:crypto.randomUUID(),date,at:new Date().toISOString(),actor:'案例演练初始化'});
  model.meta!.issueTracker=tracker;return model;
}

export default function RenovationCase({onCreate,onFacade}:{onCreate:(model:HouseModel)=>Promise<void>;onFacade:()=>void}) {
  const [data,setData]=useState<PublicCase|null>(null),[error,setError]=useState(''),[busy,setBusy]=useState(false),[view,setView]=useState('wall');
  useEffect(()=>{const abort=new AbortController();fetch('/renovation-case/data.json',{signal:abort.signal}).then(r=>{if(!r.ok)throw new Error('案例资料加载失败。');return r.json();}).then(d=>{if(d.schemaVersion!==1||d.stages?.length!==2||!Array.isArray(d.referenceStages)||d.stages.some((s:CaseStage)=>s.roomId!=='5-169'))throw new Error('案例资料格式无效。');setData(d);}).catch(e=>{if(e.name!=='AbortError')setError(e.message);});return()=>abort.abort();},[]);
  async function create(){if(!data||busy)return;setBusy(true);setError('');try{await onCreate(createRenovationModel(data));}catch(e){setError(e instanceof Error?e.message:'案例保存失败。');}finally{setBusy(false);}}
  return <section className="tools-section renovation-case" aria-label="公开室内翻修案例">
    <div className="tools-section-heading"><div><span className="tools-tag">真实室内影像 · CC BY 4.0</span><h2>同一个房间，看到施工变化。</h2><p>波鸿大学 IC 楼 · 5-169 房间，两期真实观察。</p></div><button className="tools-button primary" disabled={!data||busy} onClick={()=>void create()}>{busy?<LoaderCircle className="spin" size={16}/>:<ArrowRight size={16}/>}建立案例演练项目</button></div>
    {error&&<p role="alert" className="tools-error">{error}</p>}{!data&&!error&&<p role="status">正在载入公开案例…</p>}
    {data&&<><div className="case-view-toggle" role="group" aria-label="案例拍摄视角"><button aria-pressed={view==='wall'} className="tools-button" onClick={()=>setView('wall')}>墙侧对照</button><button aria-pressed={view==='window'} className="tools-button" onClick={()=>setView('window')}>窗侧对照</button></div>
      <div className="case-comparison">{data.stages.map(stage=>{const frame=stage.images.find(f=>f.view===view)??stage.images[0];return <figure key={stage.id}><img src={frame.image} alt={frame.alt}/><figcaption><strong>{stage.capturedDate}</strong><span>{stage.label}</span><span>房间 {stage.roomId} · 源视频已有彩色标注</span></figcaption><details><summary>核对日期与原始画面</summary><a href={stage.dateEvidence.image} target="_blank" rel="noreferrer">片头日期与房间编号<ExternalLink size={13}/></a><a href={frame.fullFrame} target="_blank" rel="noreferrer">完整源帧 · 第{frame.sourceTimeSeconds}秒<ExternalLink size={13}/></a></details></figure>;})}</div>
      <div className="case-next-step"><div><h3>用真实照片，演练处理流程。</h3><p>建立独立项目后，开始处理 → 引用第二期墙侧影像 → 提交复核 → 人工关闭 → 生成周报。</p></div><span className="tools-tag">任务与责任人模拟 · 模型尺寸示意</span></div>
      <details className="case-reference"><summary><Image size={16}/>查看另一房间的完成阶段参考</summary><p>房间 2-169，与上面房间不同，不作为同室第三期，也不用于证明上面任务已经解决。</p>{data.referenceStages.map(stage=><figure key={stage.id}><img src={stage.image} alt={`房间${stage.roomId}独立阶段参考`}/><figcaption>{stage.capturedDate} · {stage.roomId} · {stage.label}</figcaption></figure>)}</details>
      <details className="case-source"><summary>案例来源与使用范围</summary><p>{data.source.attribution}</p><p>发布日期 {data.source.publishedAt}。两期拍摄日期来自原视频片头。原始数据没有实际户型、尺寸、预算、责任人或整改事件。</p><a href={data.source.url} target="_blank" rel="noreferrer">原始数据集<ExternalLink size={14}/></a><a href={data.source.license.url} target="_blank" rel="noreferrer">{data.source.license.label}<ExternalLink size={14}/></a></details>
    </>}
    <button className="tools-text-button" onClick={onFacade}>也可查看 6 期外立面施工案例<ArrowRight size={15}/></button>
  </section>;
}
