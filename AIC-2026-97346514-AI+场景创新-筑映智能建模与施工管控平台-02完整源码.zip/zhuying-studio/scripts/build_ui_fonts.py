"""Build the locally hosted Zhuying Chinese variable web fonts.

Run from any directory with the project's Python environment::

    .venv/Scripts/python.exe scripts/build_ui_fonts.py

Requires fonttools[woff]==4.60.1 and brotli. Upstream files are cached under
artifacts/ui-fonts/upstream and checked against pinned SHA-256 checksums.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

import fontTools
from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts" / "ui-fonts"
PUBLIC = ROOT / "public" / "fonts"
COMMIT = "9710da1eacb3be272583c3224dcb70f9da6eadbb"
BASE_URL = f"https://raw.githubusercontent.com/google/fonts/{COMMIT}/ofl"
FONTTOOLS_VERSION = "4.60.1"
SPECS = (
    {
        "directory": "notosanssc",
        "upstream_name": "Noto Sans SC",
        "filename": "NotoSansSC[wght].ttf",
        "family": "Zhuying Sans",
        "output": "zhuying-sans.woff2",
        "source_commit": "523d033d6cb47f4a80c58a35753646f5c3608a78",
        "gb2312": True,
        "hashes": {
            "NotoSansSC[wght].ttf": "a3041811a78c361b1de50f953c805e0244951c21c5bd412f7232ef0d899af0da",
            "OFL.txt": "1c05c68c34f9708415aada51f17e1b0092d2cea709bf4a94cd38114f9e73d7d9",
            "METADATA.pb": "c6c4bdb785793b2de1da177caeeffcd0c90d7680bdab2de8f88ab45007bc59bc",
        },
    },
    {
        "directory": "notoserifsc",
        "upstream_name": "Noto Serif SC",
        "filename": "NotoSerifSC[wght].ttf",
        "family": "Zhuying Serif",
        "output": "zhuying-serif.woff2",
        "source_commit": "985fa52c81c1d6692ccdd82bc3656e8fb932fd89",
        "gb2312": False,
        "hashes": {
            "NotoSerifSC[wght].ttf": "050080d9255a86808f2945bffac582b31ef32bc36411ce29563b4961670c66f9",
            "OFL.txt": "5e0da210fb04058a8c0087985d2d456b931c2579811a49655721d3cf0c36b6d6",
            "METADATA.pb": "e0c253c6f850fc3ef6e7fc398361133dd55acc408c931822a3f69cfac08554c2",
        },
    },
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def upstream_file(spec: dict, filename: str) -> Path:
    path = ARTIFACTS / "upstream" / spec["directory"] / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        url = f'{BASE_URL}/{spec["directory"]}/{quote(filename)}'
        request = Request(url, headers={"User-Agent": "Zhuying-font-build/1.0"})
        with urlopen(request, timeout=120) as response:
            data = response.read()
        # Validate bytes before caching an upstream download.
        if hashlib.sha256(data).hexdigest() != spec["hashes"][filename]:
            raise ValueError(f"Unexpected SHA-256 for {url}")
        path.write_bytes(data)
    if sha256(path) != spec["hashes"][filename]:
        raise ValueError(f"Cached upstream file does not match its checksum: {path}")
    return path


def gb2312_han() -> set[int]:
    """The 6,763 Han characters in GB 2312's two Chinese character levels."""
    result: set[int] = set()
    for lead in range(0xB0, 0xF8):
        for trail in range(0xA1, 0xFF):
            try:
                character = bytes((lead, trail)).decode("gb2312")
            except UnicodeDecodeError:
                continue
            result.add(ord(character))
    if len(result) != 6763:
        raise ValueError(f"Unexpected GB 2312 Han character count: {len(result)}")
    return result


def source_characters() -> tuple[set[int], str, int]:
    """Include UI Han, punctuation and other supported characters in src text."""
    codepoints = set(range(0x20, 0x7F))
    digest = hashlib.sha256()
    count = 0
    for path in sorted((ROOT / "src").rglob("*")):
        if not path.is_file() or path.suffix not in {".ts", ".tsx", ".js", ".jsx", ".css", ".html", ".json", ".md"}:
            continue
        contents = path.read_bytes()
        text = contents.decode("utf-8")
        relative = path.relative_to(ROOT).as_posix()
        digest.update(relative.encode("utf-8") + b"\0" + contents + b"\0")
        codepoints.update(ord(character) for character in text if ord(character) >= 0x20)
        count += 1
    return codepoints, digest.hexdigest(), count


def rename_font(font: TTFont, spec: dict) -> None:
    """Give the modified fonts their own family and PostScript names."""
    family = spec["family"]
    postscript = family.replace(" ", "")
    replacements = {
        1: family,
        2: "Regular",
        3: f"{postscript};{COMMIT[:12]};subset",
        4: family,
        6: f"{postscript}-Regular",
        16: family,
        17: "Regular",
        25: postscript,
    }
    name_table = font["name"]
    for record in name_table.names:
        if record.nameID in replacements:
            value = replacements[record.nameID]
        else:
            value = record.toUnicode().replace(spec["upstream_name"], family)
            value = value.replace(spec["upstream_name"].replace(" ", ""), postscript)
        record.string = value.encode(record.getEncoding())
    for name_id, value in replacements.items():
        name_table.setName(value, name_id, 3, 1, 0x409)


def build_font(spec: dict, source_points: set[int]) -> dict:
    source = upstream_file(spec, spec["filename"])
    license_path = upstream_file(spec, "OFL.txt")
    metadata_path = upstream_file(spec, "METADATA.pb")
    metadata = metadata_path.read_text(encoding="utf-8")
    if not re.search(rf'commit: "{spec["source_commit"]}"', metadata):
        raise ValueError(f"Unexpected source commit in {metadata_path}")

    font = TTFont(source, recalcTimestamp=False)
    original_cmap = font.getBestCmap()
    requested = source_points | (gb2312_han() if spec["gb2312"] else set())
    available = requested & set(original_cmap)
    missing = sorted(requested - set(original_cmap))
    # Subsetting before range restriction avoids instancing the full CJK font.
    options = subset.Options()
    options.hinting = False
    options.layout_features = ["*"]
    options.name_IDs = ["*"]
    options.name_languages = ["*"]
    options.notdef_glyph = True
    options.notdef_outline = True
    options.recalc_timestamp = False
    subsetter = subset.Subsetter(options=options)
    subsetter.populate(unicodes=available)
    subsetter.subset(font)
    # Both upstream fonts have a light default. Explicitly rebase it to 400.
    instantiateVariableFont(font, {"wght": (400, 400, 700)}, inplace=True, optimize=True)
    rename_font(font, spec)
    font.flavor = "woff2"
    output = PUBLIC / spec["output"]
    font.save(output, reorderTables=True)
    font.close()

    # A reload checks the served file itself, its coverage and variable axis.
    with TTFont(output, recalcTimestamp=False) as built:
        cmap = built.getBestCmap()
        absent = available - set(cmap)
        if absent:
            raise ValueError(f"Subset unexpectedly lost {len(absent)} Unicode characters")
        axes = built["fvar"].axes
        if len(axes) != 1 or axes[0].axisTag != "wght" or (axes[0].minValue, axes[0].defaultValue, axes[0].maxValue) != (400, 400, 700):
            raise ValueError(f"Unexpected variable font axes in {output}")
        if built["name"].getDebugName(1) != spec["family"]:
            raise ValueError(f"Unexpected font family in {output}")
        glyph_count = len(built.getGlyphOrder())
    license_output = PUBLIC / f'{spec["output"].removesuffix(".woff2")}-OFL.txt'
    shutil.copyfile(license_path, license_output)
    return {
        "family": spec["family"],
        "output": output.relative_to(ROOT).as_posix(),
        "bytes": output.stat().st_size,
        "sha256": sha256(output),
        "unicode_count": len(available),
        "glyph_count": glyph_count,
        "gb2312_han_count": 6763 if spec["gb2312"] else 0,
        "weight_axis": {"min": 400, "default": 400, "max": 700},
        "missing_source_codepoints": [f"U+{point:04X}" for point in missing],
    }


def write_sources(builds: list[dict], digest: str, source_file_count: int) -> None:
    lines = [
        "# Zhuying local UI font sources",
        "",
        "The two locally hosted fonts are renamed, subset derivatives of the official Google Fonts Noto variable fonts. Both retain the SIL Open Font License 1.1. Original copyright and licensing records remain embedded; exact upstream OFL text is also served beside each font.",
        "",
        f"Google Fonts repository commit: `{COMMIT}`.",
        "",
        "## Rebuild",
        "",
        "```powershell",
        ".venv/Scripts/python.exe scripts/build_ui_fonts.py",
        "```",
        "",
        f"Requires `fonttools[woff]=={FONTTOOLS_VERSION}` and `brotli` (the project's `.venv` already provides them). Downloads are cached in `artifacts/ui-fonts/upstream/`; cached and downloaded bytes must match pinned SHA-256 values. WOFF2 generation uses the installed Brotli encoder, so byte-identical compression also requires the same Brotli version. No remote font request is needed at runtime.",
        "",
        f"This build scanned {source_file_count} UTF-8 text files in `src/` (aggregate source SHA-256 `{digest}`). Rebuild after adding UI text. Printable ASCII U+0020–U+007E is always included. All font-supported characters occurring in the scanned source, including Han, Chinese punctuation and symbols, are retained. Sans additionally includes all 6,763 GB 2312 Han characters. Both fonts retain a continuous `wght` axis from 400 through 700 with default 400. Glyph hints are removed; OpenType layout features and their dependent glyphs are retained.",
        "",
        "## Coverage and fallback",
        "",
        "These are subsets, not complete Unicode or full Noto CJK distributions. Serif is sized for current UI text, so user-entered names and newly introduced Chinese characters may require fallback. Sans covers the GB 2312 Han set plus current source text; uncommon Han outside that set, Japanese/Korean text, emoji and unsupported symbols can fall back to the system fonts in the CSS font stack. The source coverage manifest lists characters absent from upstream; these are intentionally left to fallback rather than replaced or fabricated. Font loading uses the site's `font-display: swap` policy.",
        "",
        "## Pinned upstream files",
        "",
    ]
    for spec, build in zip(SPECS, builds):
        lines += [
            f'### {spec["upstream_name"]} → {spec["family"]}',
            "",
            f'- Noto CJK source repository: [notofonts/noto-cjk](https://github.com/notofonts/noto-cjk/tree/{spec["source_commit"]}), source commit `{spec["source_commit"]}` (recorded in Google Fonts `METADATA.pb`).',
        ]
        for name, checksum in spec["hashes"].items():
            url = f'{BASE_URL}/{spec["directory"]}/{quote(name)}'
            lines += [f'- [{name}]({url}), SHA-256 `{checksum}`.']
        lines += [
            f'- Output: `{build["output"]}`, {build["bytes"]:,} bytes ({build["bytes"] / 1024 / 1024:.3f} MiB), {build["unicode_count"]:,} mapped codepoints, {build["glyph_count"]:,} glyphs. SHA-256 `{build["sha256"]}`.',
            "",
        ]
    lines += ["Build details and missing-source codepoints are in `manifest.json`.", ""]
    (ARTIFACTS / "SOURCES.md").write_text("\n".join(lines), encoding="utf-8")
    manifest = {
        "google_fonts_commit": COMMIT,
        "fonttools_version": fontTools.__version__,
        "brotli_version": __import__("brotli").__version__,
        "source_text_sha256": digest,
        "source_file_count": source_file_count,
        "fonts": builds,
    }
    (ARTIFACTS / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    shutil.copyfile(ARTIFACTS / "SOURCES.md", PUBLIC / "SOURCES.md")
    shutil.copyfile(ARTIFACTS / "manifest.json", PUBLIC / "manifest.json")


def main() -> None:
    if fontTools.__version__ != FONTTOOLS_VERSION:
        raise RuntimeError(f"Use fonttools=={FONTTOOLS_VERSION}; found {fontTools.__version__}")
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    PUBLIC.mkdir(parents=True, exist_ok=True)
    source_points, digest, source_file_count = source_characters()
    builds = []
    for spec in SPECS:
        build = build_font(spec, source_points)
        builds.append(build)
        print(f'{build["output"]}: {build["bytes"]:,} bytes, {build["unicode_count"]:,} codepoints; variable weight 400–700', flush=True)
    write_sources(builds, digest, source_file_count)
    print("Wrote artifacts/ui-fonts/SOURCES.md and manifest.json", flush=True)


if __name__ == "__main__":
    main()
