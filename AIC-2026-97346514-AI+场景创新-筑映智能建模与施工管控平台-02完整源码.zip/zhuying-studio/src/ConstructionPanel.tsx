import { Camera, ChevronRight, Images, CalendarDays, Trash2, ShieldCheck, ArrowRight } from 'lucide-react';
import { WORK_TYPES, activeWorkTypes, confirmedProgress, stageLabel } from './progress.mjs';
import type { Evidence, Room, Task, WorkType } from './types';
import './construction.css';

interface Props {
  room: Room;
  observedRoom: Room;
  date: string;
  today: string;
  demo: boolean;
  onTask: (type: WorkType, patch: Partial<Task>) => void;
  onAdd: () => void;
  onView: (evidence: Evidence) => void;
  onDelete: (id: string) => void;
  onReturnToday: () => void;
  onIssues?: () => void;
}

export function photoCount(evidence: Evidence) { return evidence.photos?.length ?? 1; }
export function evidenceSource(evidence: Evidence) { return evidence.source.startsWith('qwen/') ? 'AI 建议 · 人工确认' : '人工巡检'; }

export default function ConstructionPanel({ room, observedRoom, date, today, demo, onTask, onAdd, onView, onDelete, onReturnToday, onIssues }: Props) {
  const summary = confirmedProgress(observedRoom);
  const active = activeWorkTypes(room);
  const historical = date < today;
  const records = (room.evidence ?? []).filter(e => e.date <= date).map((e,index)=>({e,index})).sort((a,b)=>b.e.date.localeCompare(a.e.date)||b.index-a.index).map(({e})=>e);
  const range = summary.percent === null ? '待核对' : summary.upperPercent === summary.percent ? `${Math.round(summary.percent)}%` : `${Math.round(summary.percent)}–${Math.round(summary.upperPercent??100)}%`;
  return <div className="construction-panel">
    <section className="construction-overview" aria-label="施工核对概况">
      <div className="construction-eyebrow"><ShieldCheck size={14}/>{historical ? `${date} 的照片记录回放` : demo ? '示例施工记录' : '施工核对概况'}</div>
      <div className="construction-completion"><strong>{summary.completed}<span> / {summary.total}</span></strong><span>项工序可见完成</span></div>
      <div className="construction-coverage"><span>状态已核对</span><strong>{summary.known} / {summary.total} 项</strong></div>
      <div className="construction-coverage-track" role="progressbar" aria-label="工序状态核对覆盖率" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(summary.coverage*100)}><i style={{transform:`scaleX(${summary.coverage})`}}/></div>
      <details className="construction-index"><summary>查看阶段指数区间<ChevronRight size={13}/></summary><strong>{range}</strong><p>按启用工序等权计算；未知项保留不确定区间。此数值不代表实际工程量，外观完成也不等于验收通过。</p></details>
      {historical&&<p className="construction-history-note">状态来自截至该日的已确认照片。计划仍显示当前设置；没有照片的工序标为待核对。</p>}
      {historical&&<button className="construction-return" onClick={onReturnToday}>返回今天继续记录<ArrowRight size={12}/></button>}
      {onIssues&&<button className="construction-return" onClick={onIssues}>发现问题？进入整改中心<ArrowRight size={13}/></button>}
    </section>
    <section className="construction-section">
      <div className="construction-section-heading"><h3>工序与计划</h3><span>{active.length} 项启用</span></div>
      <p className="construction-section-note">启用本房间需要跟踪的工序，再填写计划完成日期。</p>
      <p className="construction-history-note">状态由已确认巡检更新：添加照片，核对后保存。{historical?'当前正在回放历史；请在时间线返回今天，再修改工序与计划。':'未拍到或无法判断的部分，请保留为待复核。'}</p>
      <div className="construction-tasks">{WORK_TYPES.map(meta=>{
        const enabled = active.includes(meta.id);
        const task = room.tasks[meta.id];
        const stage = observedRoom.tasks[meta.id]?.stage ?? 'unknown';
        return <div key={meta.id} className={`construction-task ${enabled?'enabled':''}`}>
          <div className="construction-task-top"><label><input type="checkbox" aria-label={`跟踪${meta.label}`} checked={enabled} disabled={historical} onChange={e=>onTask(meta.id,{enabled:e.target.checked})}/><span>{meta.label}</span></label><span className={`construction-stage ${stage}`}>{enabled?stageLabel(stage):'未启用'}</span></div>
          {enabled&&<label className="construction-due"><CalendarDays size={12}/><span>计划完成</span><input aria-label={`${meta.label}计划完成日期`} type="date" value={task?.dueDate??''} disabled={historical} onChange={e=>onTask(meta.id,{dueDate:e.target.value,plannedStage:e.target.value?'complete':'unknown'})}/></label>}
        </div>;
      })}</div>
      {active.length===0&&<p className="construction-history-note">先启用一项工序，再添加巡检。</p>}
    </section>
    <section className="construction-section">
      <div className="construction-section-heading"><h3>现场巡检</h3><button className="construction-add" onClick={onAdd}><Camera size={13}/>添加巡检</button></div>
      <p className="construction-section-note">同次巡检可保存多角度照片，并对照此前记录。</p>
      {records.length ? <div className="inspection-records">{records.map(e=>{
        const photos=e.photos??[{id:e.id,image:e.image,viewpoint:'历史照片'}];
        return <article className="inspection-record" key={e.id}>
          <div className="inspection-record-heading"><strong>{e.date}</strong><span className={`construction-stage ${e.stage}`}>{stageLabel(e.stage)}</span></div>
          <div className="inspection-record-meta"><span>{WORK_TYPES.find(w=>w.id===e.workType)?.label}</span><span>{photoCount(e)} 张照片</span></div>
          <button className="inspection-record-images" onClick={()=>onView(e)} aria-label={`查看${e.date}${WORK_TYPES.find(w=>w.id===e.workType)?.label}巡检照片`}>{photos.slice(0,3).map(p=><img key={p.id} src={p.image} alt={`${p.viewpoint||'现场'}照片`}/>)}{photos.length>3&&<span>+{photos.length-3}</span>}</button>
          <p>{e.summary || '已确认现场工序状态。'}</p>
          {e.comparison&&<button className="inspection-record-comparison" onClick={()=>onView(e)}><Images size={13}/><span>对照 {e.comparison.previousDate}</span><ArrowRight size={12}/></button>}
          <footer><span>{evidenceSource(e)}</span><button onClick={()=>onView(e)} aria-label={`打开${e.date}巡检详情`}>详情<ChevronRight size={12}/></button><button aria-label={`删除${e.date}${WORK_TYPES.find(w=>w.id===e.workType)?.label}巡检记录`} title="删除记录后，施工状态按剩余证据重新计算" onClick={()=>onDelete(e.id)}><Trash2 size={12}/></button></footer>
        </article>;
      })}</div> : <button className="construction-empty" onClick={onAdd}><Camera size={23}/><strong>为这个空间留下现场证据</strong><span>全景、门口、窗侧，多角度记录同一工序</span></button>}
    </section>
  </div>;
}
