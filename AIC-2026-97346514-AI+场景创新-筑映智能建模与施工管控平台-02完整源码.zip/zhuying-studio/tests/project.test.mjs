import test from 'node:test';
import assert from 'node:assert/strict';
import { validateProject } from '../src/project.mjs';
const valid=()=>({id:'p1',name:'测试',width:6,depth:5,height:2.8,source:'manual',warnings:[],walls:[{id:'w1',start:[0,0],end:[6,0],thickness:.2}],openings:[],rooms:[{id:'r1',name:'客厅',polygon:[[0,0],[6,0],[6,5],[0,5]],area:30,material:'wood',progress:0,tasks:{floor:{stage:'unknown',plannedStage:'unknown',dueDate:''},wall:{stage:'unknown',plannedStage:'unknown',dueDate:''}}}]});
test('完整项目允许恢复，缺失tasks不会进入应用状态',()=>{assert.equal(validateProject(valid()).rooms.length,1);const m=valid();delete m.rooms[0].tasks;assert.throws(()=>validateProject(m));});
test('几何字段必须有限且为数字，墙不能零长度',()=>{for(const val of [NaN,Infinity,'6',null,-1]){const m=valid();m.width=val;assert.throws(()=>validateProject(m));}const m=valid();m.walls[0].end=[0,0];assert.throws(()=>validateProject(m));});
test('未知工序合法，但任意枚举和重复构件ID不合法',()=>{let m=valid();m.rooms[0].tasks.floor.stage='guessed';assert.throws(()=>validateProject(m));m=valid();m.walls.push({...m.walls[0]});assert.throws(()=>validateProject(m));});
test('门窗必须关联已有墙且不能超出墙长或层高',()=>{let m=valid();m.openings=[{id:'d1',wallId:'w1',type:'door',offset:1,width:1,height:2.1}];assert.equal(validateProject(m).openings.length,1);m.openings[0].wallId='missing';assert.throws(()=>validateProject(m));m=valid();m.openings=[{id:'w2',wallId:'w1',type:'window',offset:5.5,width:1,height:2,sill:1}];assert.throws(()=>validateProject(m));});
test('旧项目无design合法，合法装修设计可完整往返',()=>{
  const m=valid();assert.strictEqual(validateProject(m),m);
  m.rooms[0].design={floorFinish:'terrazzo',wallColor:'#F4F0E8',wallFinish:'paint',floorDirection:90};
  assert.deepEqual(validateProject(JSON.parse(JSON.stringify(m))),m);
});
test('optional design存在时必须完整且各枚举、颜色、方向合法',()=>{
  const good={floorFinish:'oak',wallColor:'#f4f0e8',wallFinish:'paint',floorDirection:0};
  for(const bad of [null,[],{}, {...good,floorFinish:'carpet'}, {...good,wallColor:'red'},
    {...good,wallColor:'#fff'}, {...good,wallColor:'#00000000'}, {...good,wallFinish:'paper'},
    {...good,floorDirection:45}, {...good,floorDirection:'90'}]) {
    const m=valid();m.rooms[0].design=bad;assert.throws(()=>validateProject(m));
  }
  for(const finish of ['oak','walnut','light_tile','gray_stone','terrazzo','concrete']) {
    const m=valid();m.rooms[0].design={...good,floorFinish:finish};assert.doesNotThrow(()=>validateProject(m));
  }
});
test('旧门窗无design兼容，门窗完整设计在项目导出导入后保留',()=>{
  const m=valid();m.openings=[{id:'door',wallId:'w1',type:'door',offset:1,width:1,height:2.1}];
  assert.doesNotThrow(()=>validateProject(m));
  m.openings[0].design={color:'#c9b99b',style:'panel',openAngle:30,hinge:'end',swing:-1,glassTint:'smoke'};
  assert.deepEqual(validateProject(JSON.parse(JSON.stringify(m))),m);
});
test('门窗设计样式、角度及门窗重叠在导入边界被阻止',()=>{
  const good={color:'#c9b99b',style:'panel',openAngle:0,hinge:'start',swing:1,glassTint:'clear'};
  for(const bad of [null,{}, {...good,color:'red'},{...good,style:'fixed'},{...good,openAngle:101},
    {...good,hinge:'left'},{...good,swing:0},{...good,glassTint:'opaque'}]) {
    const m=valid();m.openings=[{id:'d1',wallId:'w1',type:'door',offset:1,width:1,height:2.1,design:bad}];
    assert.throws(()=>validateProject(m));
  }
  const m=valid();m.openings=[{id:'d1',wallId:'w1',type:'door',offset:1,width:1,height:2.1},
    {id:'d2',wallId:'w1',type:'door',offset:1.5,width:1,height:2.1}];
  assert.throws(()=>validateProject(m));
  m.openings[1]={id:'high',wallId:'w1',type:'window',offset:1,width:1,height:.5,sill:2.1};
  assert.doesNotThrow(()=>validateProject(m));
});
test('导入开口不能超出单独较矮墙高',()=>{
  const m=valid();m.walls[0].height=1.5;
  m.openings=[{id:'w2',wallId:'w1',type:'window',offset:1,width:1,height:1.2,sill:.5}];
  assert.throws(()=>validateProject(m));
});

const image = 'data:image/png;base64,AAAA';
const record = (id='e1', date='2026-10-04', extra={}) => ({ id, date, image, workType:'floor', stage:'complete',
  summary:'已现场确认', confirmed:true, source:'manual', ...extra });
const photos = () => [{ id:'p1', image, viewpoint:'门口向内' }, { id:'p2', image:'data:image/jpeg;base64,aA==', viewpoint:'窗边向内' }];

test('六工序、多角度记录及AI建议审计字段允许完整项目往返', () => {
  const m = valid(), r = m.rooms[0];
  for (const type of ['electrical','waterproof','masonry','carpentry']) r.tasks[type] = { stage:'in_progress', plannedStage:'complete', dueDate:'2026-10-08', enabled:true, note:'现场验收' };
  r.tasks.wall.enabled = false;
  r.evidence = [record('first','2026-10-02'), record('next','2026-10-04', {
    photos:photos(), aiStage:'in_progress', observations:[{ photoIndex:0, summary:'门口区域已铺设' },{ photoIndex:1, summary:'窗边已铺设' }],
    comparison:{ previousEvidenceId:'first', previousDate:'2026-10-02', summary:'现场范围扩大', change:'advanced', source:'qwen' },
  })];
  const original = structuredClone(m);
  assert.strictEqual(validateProject(m), m);
  assert.deepEqual(m, original);
  assert.deepEqual(validateProject(JSON.parse(JSON.stringify(m))), m);
  for (const type of ['electrical','waterproof','masonry','carpentry','floor','wall']) {
    const single = valid(); single.rooms[0].evidence = [record('trade','2026-10-04',{workType:type})];
    assert.doesNotThrow(() => validateProject(single));
  }
});

test('工序激活值、计划日期及未知工序在项目边界校验', () => {
  for (const bad of [null, {}, {stage:'complete',plannedStage:'complete',dueDate:'2026-02-30'},
    {stage:'complete',plannedStage:'complete',dueDate:'2026-10-04',enabled:'true'}]) {
    const m = valid(); m.rooms[0].tasks.electrical = bad; assert.throws(() => validateProject(m));
  }
  const m=valid();m.rooms[0].tasks.demolition={stage:'unknown',plannedStage:'unknown',dueDate:''};
  assert.throws(()=>validateProject(m));
});

test('巡检日期、重复ID、人工状态和来源元数据不能静默接受坏数据', () => {
  for (const bad of [{date:'2026-02-30'},{date:''},{date:'2026-1-04'},{source:''},{source:'   '},{source:{}},
    {source:'x'.repeat(161)},{workType:'demo'},{aiStage:'guessed'},{confirmed:'yes'},{summary:{}},
    {image:'https://example.com/photo.jpg'},{image:'data:image/svg+xml;base64,AAAA'},{image:'data:image/png;base64,@@@@'},{image:'data:image/png;base64,A'}]) {
    const m=valid();m.rooms[0].evidence=[record('bad','2026-10-04',bad)];assert.throws(()=>validateProject(m));
  }
  const m=valid();m.rooms[0].evidence=[record(),record()];assert.throws(()=>validateProject(m));
});

test('多照片必须1至6张、ID唯一、视角明确且旧主图等于首图', () => {
  for (const badPhotos of [null,[],[null],[{id:'p',image,viewpoint:''}],[{id:'p',image:'bad',viewpoint:'门口'}],
    [photos()[0],photos()[0]], Array.from({length:7},(_,i)=>({...photos()[0],id:`p${i}`}))]) {
    const m=valid();m.rooms[0].evidence=[record('bad','2026-10-04',{photos:badPhotos})];assert.throws(()=>validateProject(m));
  }
  const m=valid();m.rooms[0].evidence=[record('bad','2026-10-04',{photos:photos(),image:'data:image/png;base64,aA=='})];
  assert.throws(()=>validateProject(m));
});

test('多角度观察索引必须引用本轮照片，不能越界、重复或类型错误', () => {
  for (const observations of [[{photoIndex:-1,summary:'坏索引'}],[{photoIndex:2,summary:'坏索引'}],
    [{photoIndex:'0',summary:'坏索引'}],[{photoIndex:.5,summary:'坏索引'}],
    [{photoIndex:0,summary:'一次'},{photoIndex:0,summary:'重复'}],[{photoIndex:0,summary:{}}],null]) {
    const m=valid();m.rooms[0].evidence=[record('bad','2026-10-04',{photos:photos(),observations})];
    assert.throws(()=>validateProject(m));
  }
  const legacy=valid();legacy.rooms[0].evidence=[record('legacy','2026-10-04',{observations:[{photoIndex:0,summary:'主图判断'}]})];
  assert.doesNotThrow(()=>validateProject(legacy));
});

test('历史对比必须引用同工序较早确认记录，日期吻合并阻止自引用或环引用', () => {
  const comparison={previousEvidenceId:'first',previousDate:'2026-10-02',summary:'进度推进',change:'advanced',source:'qwen'};
  for (const bad of [{previousEvidenceId:'missing'},{previousEvidenceId:'next'},{previousDate:'2026-10-01'},
    {previousDate:'2026-02-30'},{change:'done'},{source:''},{summary:{}}]) {
    const m=valid();m.rooms[0].evidence=[record('first','2026-10-02'),record('next','2026-10-04',{comparison:{...comparison,...bad}})];
    assert.throws(()=>validateProject(m));
  }
  for (const first of [record('first','2026-10-02',{workType:'wall'}),record('first','2026-10-02',{confirmed:false}),record('first','2026-10-05')]) {
    const m=valid();m.rooms[0].evidence=[first,record('next','2026-10-04',{comparison:{...comparison,previousDate:first.date}})];
    assert.throws(()=>validateProject(m));
  }
  const mutual=valid();mutual.rooms[0].evidence=[record('first','2026-10-04',{comparison:{...comparison,previousEvidenceId:'next',previousDate:'2026-10-04'}}),
    record('next','2026-10-04',{comparison:{...comparison,previousDate:'2026-10-04'}})];
  assert.throws(()=>validateProject(mutual));
  const sameDay=valid();sameDay.rooms[0].evidence=[record('first','2026-10-04'),record('next','2026-10-04',{comparison:{...comparison,previousDate:'2026-10-04'}})];
  assert.doesNotThrow(()=>validateProject(sameDay));
});

test('一轮巡检按解码照片总量限制30MB，不重复计数兼容首图', () => {
  const large='data:image/png;base64,'+'A'.repeat(Math.ceil(11*1024*1024/3)*4);
  const m=valid();m.rooms[0].evidence=[record('large','2026-10-04',{image:large,photos:Array.from({length:3},(_,i)=>({id:`large${i}`,image:large,viewpoint:'门口'}))})];
  assert.throws(()=>validateProject(m));
  m.rooms[0].evidence[0].photos.pop();
  assert.doesNotThrow(()=>validateProject(m));
});
