"""Run from the repository root: python -m uvicorn backend.app:app --port 8000."""

import os
import json

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from starlette.concurrency import run_in_threadpool

from backend.algorithm import (MAX_IMAGE_BYTES, MAX_INSPECTION_FILES, MAX_INSPECTION_TOTAL_BYTES,
                               InspectionSizeError, ModelServiceError, PlanError, analyze_inspection, analyze_photo)
from backend.design_assistant import AssistantInputError, MAX_CHAT_BODY_BYTES, design_chat
from backend.neural_plan import recognition_status, recognize_floor_plan
from backend.ai_plan import assist_floor_plan
from backend.project_library import router as project_library_router
from backend.facade_demo import router as facade_demo_router

app = FastAPI(title="筑映 · 本地视觉与几何服务", version="0.1.0")
app.include_router(project_library_router)
app.include_router(facade_demo_router)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["GET", "POST", "PUT"], allow_headers=["Content-Type"])


async def _image_data(file):
    try:
        image_bytes = await file.read(MAX_IMAGE_BYTES + 1)
    finally:
        await file.close()
    if len(image_bytes) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="图片超过 10 MB 上限，请压缩后上传。")
    return image_bytes


@app.get("/api/health")
def health():
    return {"status": "ok", "algorithm": "hybrid-floorplan-v2", "planRecognition": recognition_status(),
            "visionConfigured": bool(os.environ.get("QWEN_API_KEY", "").strip()),
            "designConfigured": bool(os.environ.get("QWEN_API_KEY", "").strip())}


@app.post("/api/parse-plan")
async def parse_plan(file: UploadFile = File(...), real_width: float = Form(12.0), height: float = Form(2.8),
                     engine: str = Form('auto'), ai_assist: bool = Form(False), ai_mode: str | None = Form(None),
                     design_style: str = Form('warm')):
    image_bytes = await _image_data(file)
    mode = ai_mode if ai_mode is not None else ('assist' if ai_assist else 'local')
    if mode not in {'local', 'assist', 'rebuild'} or design_style not in {'warm', 'minimal', 'natural', 'industrial'}:
        raise HTTPException(status_code=422, detail='AI 识别模式或装修风格无效。')
    try:
        try:
            baseline = await run_in_threadpool(recognize_floor_plan, image_bytes, real_width, height, engine)
        except PlanError as exc:
            # Input validation/explicit engine errors cannot be bypassed by AI.
            if (mode != 'rebuild' or engine not in {'auto', 'classic', 'neural'}
                    or not 1 <= real_width <= 100 or not 2 <= height <= 6):
                raise
            return await run_in_threadpool(assist_floor_plan, image_bytes, None, real_width, height, mode, design_style, str(exc))
        if mode == 'local':
            return baseline
        return await run_in_threadpool(assist_floor_plan, image_bytes, baseline, real_width, height, mode, design_style)
    except PlanError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/analyze-photo")
async def photo_observation(file: UploadFile = File(...), room_name: str = Form(...), work_type: str = Form(...)):
    image_bytes = await _image_data(file)
    try:
        return await run_in_threadpool(analyze_photo, image_bytes, room_name, work_type)
    except PlanError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ModelServiceError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/api/design-chat")
async def design_conversation(request: Request):
    if request.headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/json":
        raise HTTPException(status_code=415, detail="设计对话须使用application/json。")
    chunks, size = [], 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > MAX_CHAT_BODY_BYTES:
            raise HTTPException(status_code=413, detail="设计对话超过64KB，请减少历史消息或补充说明。")
        chunks.append(chunk)
    try:
        payload = json.loads(b"".join(chunks))
    except (ValueError, UnicodeDecodeError, RecursionError) as exc:
        raise HTTPException(status_code=422, detail="设计对话JSON无效，请检查请求格式。") from exc
    try:
        return await run_in_threadpool(design_chat, payload)
    except AssistantInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ModelServiceError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/api/analyze-inspection")
async def inspection_observation(files: list[UploadFile] = File(...), room_name: str = Form(...),
                                 work_type: str = Form(...), date: str = Form(...),
                                 previous_files: list[UploadFile] | None = File(None),
                                 previous_date: str | None = Form(None), previous_stage: str | None = Form(None)):
    previous_files = previous_files or []
    uploads = files + previous_files
    current_data, previous_data, total = [], [], 0
    try:
        if not 1 <= len(files) <= MAX_INSPECTION_FILES or len(previous_files) > MAX_INSPECTION_FILES:
            raise HTTPException(status_code=422, detail="本次巡检须1至6张，前次巡检最多6张。")
        for group, target in ((files, current_data), (previous_files, previous_data)):
            for upload in group:
                data = await upload.read(MAX_IMAGE_BYTES + 1)
                if len(data) > MAX_IMAGE_BYTES:
                    raise HTTPException(status_code=413, detail="单张巡检照片超过10MB，请压缩后上传。")
                total += len(data)
                if total > MAX_INSPECTION_TOTAL_BYTES:
                    raise HTTPException(status_code=413, detail="本次及前次巡检照片合计超过30MB，请减少或压缩照片。")
                target.append(data)
    finally:
        for upload in uploads:
            await upload.close()
    try:
        return await run_in_threadpool(analyze_inspection, current_data, room_name, work_type, date,
                                      previous_data, previous_date, previous_stage)
    except InspectionSizeError as exc:
        raise HTTPException(status_code=413, detail=str(exc)) from exc
    except PlanError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ModelServiceError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
