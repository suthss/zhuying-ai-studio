"""Validate editable project metadata without normalizing or changing the payload."""

import base64
import binascii
import math
import re
from datetime import date, datetime
from decimal import Decimal

from fastapi import HTTPException

MAX_PHOTO_BYTES = 10 * 1024 * 1024
MAX_EVENT_PHOTO_BYTES = 30 * 1024 * 1024
IMAGE = re.compile(r"^data:image/(?:png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$")
PUBLIC_CASE = re.compile(r"^/renovation-case/[A-Za-z0-9_-]+\.(?:jpg|png|webp)$")
TIMESTAMP = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})")
WORK_TYPES = frozenset(("electrical", "waterproof", "masonry", "carpentry", "floor", "wall"))
ISSUE_STATES = frozenset(("open", "in_progress", "review", "closed"))
TRANSITIONS = {"begin": ("open", "in_progress"), "submit": ("in_progress", "review"),
               "close": ("review", "closed"), "return": ("review", "in_progress"),
               "reopen": ("closed", "in_progress")}
MISSING = object()


def _invalid(message):
    raise HTTPException(422, detail=message)


def _text(value, maximum=160, empty=False):
    # Frontend string limits count UTF-16 code units.
    return (isinstance(value, str) and len(value.encode("utf-16-le", errors="surrogatepass")) // 2 <= maximum
            and (empty or bool(value.strip())))


def _number(value, low, high, exclusive_low=False):
    try:
        return (type(value) in (int, float) and math.isfinite(value) and value <= high
                and (value > low if exclusive_low else value >= low))
    except OverflowError:
        return False


def _choice(value, choices):
    return isinstance(value, str) and value in choices


def _date(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return False
    try:
        return date.fromisoformat(value).isoformat() == value
    except ValueError:
        return False


def _timestamp(value):
    if not isinstance(value, str) or not TIMESTAMP.fullmatch(value):
        return False
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
        return True
    except ValueError:
        return False


def _rows(value, maximum, minimum=0):
    return (isinstance(value, list) and minimum <= len(value) <= maximum
            and all(isinstance(row, dict) and _text(row.get("id")) for row in value)
            and len({row["id"] for row in value}) == len(value))


def _point(value, maximum):
    return isinstance(value, list) and len(value) == 2 and all(_number(item, 0, maximum) for item in value)


def _photo_bytes(image):
    # Bound the encoded string before running the regex or allocating decoded bytes.
    if not isinstance(image, str) or len(image) > 32 + 4 * ((MAX_PHOTO_BYTES + 2) // 3):
        _invalid("单张问题照片不能超过 10 MB，且须为 PNG、JPEG 或 WebP 内嵌图片。")
    match = IMAGE.fullmatch(image)
    if not match or len(match[1]) % 4:
        _invalid("问题照片编码无效，请选择 PNG、JPEG 或 WebP 照片。")
    try:
        size = len(base64.b64decode(match[1], validate=True))
    except (ValueError, binascii.Error):
        _invalid("问题照片 Base64 编码无效。")
    if size > MAX_PHOTO_BYTES:
        _invalid("单张问题照片不能超过 10 MB。")
    return size


def _validate_photos(photos):
    if not _rows(photos, 6):
        _invalid("每次须保存最多六张编号不重复的问题照片。")
    total = 0
    for photo in photos:
        if (not _text(photo.get("caption"), 500, empty=True)
                or not _choice(photo.get("source"), ("upload", "inspection", "public_case"))
                or "captureDate" not in photo
                or (photo["captureDate"] is not None and not _date(photo["captureDate"]))):
            _invalid("问题照片说明、来源或拍摄日期无效。")
        if photo["source"] == "public_case":
            if not isinstance(photo.get("image"), str) or not PUBLIC_CASE.fullmatch(photo["image"]):
                _invalid("公开案例照片须使用 /renovation-case/ 下有效的 JPG、PNG 或 WebP 路径。")
        else:
            total += _photo_bytes(photo.get("image"))
        if "point" in photo and not _point(photo["point"], 1):
            _invalid("问题照片标记须为画面内的有效坐标。")
    if total > MAX_EVENT_PHOTO_BYTES:
        _invalid("单次问题记录的照片总量不能超过 30 MB。")


def _validate_issue_tracker(raw):
    if (not isinstance(raw, dict) or not _number(raw.get("version"), 1, 1)
            or not _rows(raw.get("issues"), 200)):
        _invalid("整改任务须为 version 1，且最多包含 200 项编号不重复的任务。")
    for issue in raw["issues"]:
        if (not _text(issue.get("roomId")) or not _text(issue.get("title"))
                or not _text(issue.get("description"), 3000, empty=True)
                or not _text(issue.get("location"), 500, empty=True) or not _text(issue.get("assignee"))
                or not _date(issue.get("dueDate")) or not _date(issue.get("createdDate"))
                or not _choice(issue.get("workType"), WORK_TYPES)
                or not _choice(issue.get("status"), ISSUE_STATES)
                or not _choice(issue.get("mode"), ("actual", "demonstration"))
                or ("orphaned" in issue and type(issue["orphaned"]) is not bool)):
            _invalid("整改任务的房间、说明、责任人、日期、工序或状态无效。")
        if issue["dueDate"] < issue["createdDate"]:
            _invalid("整改期限不得早于问题发现日期。")
        if not _rows(issue.get("events"), 100, 1):
            _invalid("每项问题须保留 1–100 条编号不重复的处理记录。")
        previous_date, status = issue["createdDate"], None
        for index, event in enumerate(issue["events"]):
            if (not _date(event.get("date")) or not _timestamp(event.get("at"))
                    or not _text(event.get("actor")) or not _text(event.get("note"), 3000, empty=True)
                    or ("confirmed" in event and type(event["confirmed"]) is not bool)):
                _invalid("问题处理记录的日期、时间、记录人、说明或确认状态无效。")
            if event["date"] < previous_date:
                _invalid("问题处理记录日期不能倒退。")
            previous_date = event["date"]
            _validate_photos(event.get("photos"))
            action, next_status = event.get("action"), event.get("status")
            if index == 0:
                if action != "create" or next_status != "open" or event["date"] != issue["createdDate"]:
                    _invalid("问题的首条记录须在发现日期创建待处理任务。")
            elif action in ("comment", "update"):
                if next_status != status:
                    _invalid("补充或更新记录不能改变问题处理状态。")
            else:
                transition = TRANSITIONS.get(action) if isinstance(action, str) else None
                if not transition or transition != (status, next_status):
                    _invalid("问题状态转换无效，须按处理和复核流程记录。")
                if action in ("submit", "close", "return", "reopen") and not event["note"].strip():
                    _invalid("提交、复核或重开问题必须填写说明。")
                if action == "submit" and not event["photos"]:
                    _invalid("提交复核必须附上整改照片。")
                if action == "close" and event.get("confirmed") is not True:
                    _invalid("关闭问题须经人工确认。")
            status = next_status
        if issue["status"] != status:
            _invalid("问题当前状态与最后一条处理记录不一致。")


def _exact_keys(value, keys):
    return isinstance(value, dict) and set(value) == set(keys)


def _decimal(value, maximum):
    if not _number(value, 0, maximum):
        return False
    return Decimal(str(value)).as_tuple().exponent >= -2


def _price(value):
    return value is None or _decimal(value, 10_000_000)


def _validate_budget(raw):
    if (not _exact_keys(raw, ("version", "selectedQuoteId", "quotes"))
            or not _number(raw.get("version"), 1, 1) or not _text(raw.get("selectedQuoteId"))
            or not _rows(raw.get("quotes"), 2, 1)):
        _invalid("材料预算须为 version 1，包含 1–2 套报价和有效的当前方案。")
    for quote in raw["quotes"]:
        if (not _exact_keys(quote, ("id", "name", "rooms", "furniture")) or not _text(quote.get("name"))
                or not isinstance(quote.get("rooms"), dict) or len(quote["rooms"]) > 200
                or not isinstance(quote.get("furniture"), dict) or len(quote["furniture"]) > 600):
            _invalid("材料报价的名称或条目格式无效。")
        for room_id, row in quote["rooms"].items():
            if (not _text(room_id) or not _exact_keys(row, ("floorUnitPrice", "floorWastePercent", "wallUnitPrice"))
                    or not _price(row.get("floorUnitPrice", MISSING)) or not _price(row.get("wallUnitPrice", MISSING))
                    or not _decimal(row.get("floorWastePercent"), 100)):
                _invalid("材料单价须留空或为不超过 10000000 元的两位小数，损耗率须为 0–100%。")
        if any(not _text(item_id) or not _price(price) for item_id, price in quote["furniture"].items()):
            _invalid("家具报价须留空或为不超过 10000000 元的非负两位小数。")
    if raw["selectedQuoteId"] not in {quote["id"] for quote in raw["quotes"]}:
        _invalid("当前材料报价方案不存在。")


def _validate_measurements(raw, model):
    if (not _rows(raw, 1000) or not isinstance(model, dict) or not isinstance(model.get("walls"), list)):
        _invalid("实测记录须为最多 1000 条编号不重复的记录，并关联有效项目。")
    for record in raw:
        if (not _text(record.get("wallId")) or not _number(record.get("lengthMeters"), 0, 200, exclusive_low=True)
                or not _date(record.get("date")) or not _text(record.get("source"), 500)
                or not _text(record.get("note"), 2000, empty=True) or type(record.get("confirmed")) is not bool):
            _invalid("实测记录的墙段、长度、日期、来源、备注或人工确认状态无效。")
        if "wallSnapshot" in record:
            snapshot = record["wallSnapshot"]
            if (not isinstance(snapshot, dict) or not _point(snapshot.get("start"), 100)
                    or not _point(snapshot.get("end"), 100) or math.dist(snapshot["start"], snapshot["end"]) < .01):
                _invalid("实测记录保存时的墙段端点快照无效。")


def validate_practical_meta(meta, model):
    """Validate known metadata; deleted-room/wall/quote references remain valid history."""
    if not isinstance(meta, dict):
        _invalid("模型附加信息须为 JSON 对象。")
    if "issueTracker" in meta:
        _validate_issue_tracker(meta["issueTracker"])
    if "materialBudget" in meta:
        _validate_budget(meta["materialBudget"])
    if "measurements" in meta:
        _validate_measurements(meta["measurements"], model)
    if "layoutReviewPending" in meta and type(meta["layoutReviewPending"]) is not bool:
        _invalid("家具布局待复核标记须为布尔值。")
    return meta
