﻿param([switch]$RestartBackend)

$ErrorActionPreference = 'Stop'
$studioRoot = $PSScriptRoot
$studioPython = Join-Path $studioRoot '.venv\Scripts\python.exe'
$studioVite = Join-Path $studioRoot 'node_modules\vite\bin\vite.js'
if (!(Test-Path -LiteralPath $studioPython) -or !(Test-Path -LiteralPath $studioVite)) {
    throw '请先按 README 安装 Python 与 npm 依赖。'
}
$studioLogs = Join-Path $studioRoot 'artifacts'
New-Item -ItemType Directory -Path $studioLogs -Force | Out-Null
$studioApiReady = $false
$studioUiReady = $false
$studioUiPort = $null
try { $studioHealth = Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/health' -TimeoutSec 2; $studioApiReady = $studioHealth.algorithm -eq 'hybrid-floorplan-v2' } catch {}
$studioListeners = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalPort)
if ($RestartBackend -and $studioApiReady) {
    # Verify the listener and its Python launcher belong to this checkout before stopping either.
    $studioBackendIds = @()
    $studioOwners = @(Get-NetTCPConnection -State Listen -LocalPort 8000 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
    if ($studioOwners.Count -eq 0) { throw '后端状态已变化，请重新运行启动命令。' }
    foreach ($studioOwner in $studioOwners) {
        $studioChain = @()
        $studioCurrentId = $studioOwner
        $studioOwned = $false
        for ($studioDepth = 0; $studioDepth -lt 8; $studioDepth++) {
            $studioProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $studioCurrentId"
            if (!$studioProcess -or $studioProcess.CommandLine -notmatch '(?:^|\s)-m\s+uvicorn\s+backend\.app:app(?:\s|$)') { break }
            $studioChain += [int]$studioProcess.ProcessId
            if ([StringComparer]::OrdinalIgnoreCase.Equals($studioProcess.ExecutablePath, $studioPython)) {
                $studioOwned = $true
                break
            }
            $studioCurrentId = [int]$studioProcess.ParentProcessId
        }
        if (!$studioOwned) { throw '无法确认8000端口的后端属于当前项目，未停止任何服务。请在原启动终端按Ctrl+C后重试。' }
        $studioBackendIds += $studioChain
    }
    foreach ($studioBackendId in ($studioBackendIds | Select-Object -Unique)) {
        if (Get-Process -Id $studioBackendId -ErrorAction SilentlyContinue) {
            try { Stop-Process -Id $studioBackendId -ErrorAction Stop }
            catch { if (Get-Process -Id $studioBackendId -ErrorAction SilentlyContinue) { throw } }
        }
    }
    $studioReleaseDeadline = (Get-Date).AddSeconds(5)
    do {
        $studioPortBusy = @(Get-NetTCPConnection -State Listen -LocalPort 8000 -ErrorAction SilentlyContinue).Count -gt 0
        if (!$studioPortBusy) { break }
        Start-Sleep -Milliseconds 100
    } while ((Get-Date) -lt $studioReleaseDeadline)
    if ($studioPortBusy) { throw '8000端口尚未释放，请稍后重试。' }
    $studioApiReady = $false
    $studioListeners = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty LocalPort)
    Write-Host '已停止当前项目旧后端，准备重新加载 backend/.env。'
}
$studioFreeUiPort = $null
foreach ($studioCandidate in 5173..5183) {
    if ($studioListeners -notcontains $studioCandidate) {
        if ($null -eq $studioFreeUiPort) { $studioFreeUiPort = $studioCandidate }
        continue
    }
    try {
        $studioPage = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$studioCandidate" -TimeoutSec 2
        $studioMarkup = $studioPage.Content
        # Windows PowerShell 5.1 can misdecode Vite HTML without an HTTP charset.
        if ($studioPage.RawContentStream) { $studioMarkup = [Text.Encoding]::UTF8.GetString($studioPage.RawContentStream.ToArray()) }
        if ($studioMarkup -match '<title>筑映 · 三维装修工作台</title>') {
            $studioUiReady = $true; $studioUiPort = $studioCandidate; break
        }
    } catch {}
}
if (!$studioUiReady) { $studioUiPort = $studioFreeUiPort }
if ($null -eq $studioUiPort) { throw '5173–5183 端口均被占用，请释放一个端口后重试。' }
if (!$studioApiReady) {
    if ($studioListeners -contains 8000) { throw '8000 端口已有其他服务。请先检查该服务，再启动筑映算法后端。' }
    $studioArgs = @('-m', 'uvicorn', 'backend.app:app', '--host', '127.0.0.1', '--port', '8000')
    if (Test-Path -LiteralPath (Join-Path $studioRoot 'backend\.env')) { $studioArgs += @('--env-file', 'backend/.env') }
    Start-Process -FilePath $studioPython -ArgumentList $studioArgs -WorkingDirectory $studioRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $studioLogs 'api.log') -RedirectStandardError (Join-Path $studioLogs 'api-error.log') | Out-Null
}
if (!$studioUiReady) {
    $studioNode = (Get-Command node.exe).Source
    Start-Process -FilePath $studioNode -ArgumentList @('"' + $studioVite + '"', '--host', '127.0.0.1', '--port', "$studioUiPort") -WorkingDirectory $studioRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $studioLogs 'ui.log') -RedirectStandardError (Join-Path $studioLogs 'ui-error.log') | Out-Null
}
Write-Host "筑映工作台：http://127.0.0.1:$studioUiPort"
Write-Host '服务启动需要数秒；异常时查看 artifacts 下的日志。'
