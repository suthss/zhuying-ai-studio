# 筑映：智能建模与施工管控平台

筑境智研队的算法竞赛研究原型。平台将户型识别、可编辑三维住宅、居住需求问答和按房间管理的施工证据关联起来。普通照片用于施工可见状态观察，不自动恢复精密几何。AI 建议经结构校验与人工确认后采用。

## 主要能力

- 户型图导入、用户尺度标定、OpenCV / CubiCasa5K 本地识别、可选千问视觉辅助或自主重建。
- 四步设计问答、13 类参数化家具与本地布局检查，地板、墙面、门窗编辑和房间固定视点 360° 环视。
- 六类工序的多角度巡检与前后照片对比，人工确认、未知状态区间、计划提示和整改状态历史。
- SQLite 多模型项目库、浏览器 IndexedDB 草稿、材料估算与比价、项目 JSON / 三维 GLB / CSV / 施工周报导出。
- 内嵌真实公开室内翻修照片和六期 IITU 外立面影像。案例中的几何、任务、人员与计划为演练配置。

## 本地运行

建议使用 Node.js 22.12 或更新的受支持版本、Python 3.12。先从仓库根目录安装依赖：

```powershell
npm.cmd ci
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend/requirements-dev.txt
.\start.ps1
```

打开终端输出的工作台地址。启动脚本仅绑定本机回环地址，通常使用前端 5173 和后端 8000；前端会寻找空闲端口。数据库和日志在运行时建立，本发布副本不含个人数据库、真实密钥或历史运行日志。

也可在两个终端分别启动：

```powershell
.\.venv\Scripts\python.exe -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
```

```powershell
npm.cmd run dev
```

没有配置千问或安装神经模型时，仍可使用基础本地识别、编辑与人工巡检。新导入户型没有真实施工进度，需要用户补充证据与计划。

### 可选：本地神经识别

**模型权重未包含在源码包中。** 上游权重为 208,651,193 字节，未核得独立的不受限再分发授权。本项目不代为托管或再分发，由使用者查阅上游条款后自行下载：

```powershell
.\.venv\Scripts\python.exe -m pip install -r backend/requirements-recognition.txt
.\.venv\Scripts\python.exe scripts/download_plan_model.py
```

下载脚本使用上游官方链接，并验证文件长度及 SHA-256：

```text
dd20b4e1bf1d670f2125107b079df06958b1ccd36e49a464ab739aeb00b8e7a2
```

目标文件为 `models/cubicasa5k/model_best_val_loss_var.pkl`。校验用于复现文件完整性，不等于商业或再分发授权。CPU / CUDA 依赖应按实际设备选择，详见 [第三方声明](docs/THIRD_PARTY_NOTICES.md)。

### 可选：千问 API

将 `backend/.env.example` **复制**为本机 `backend/.env`，在后端填写自己的密钥；样例中的密钥为空。模型名、服务地址及计费权限以使用者的服务平台为准。不要将真实密钥写入前端、提交到仓库或发送到公开讨论中。

配置后重启后端：

```powershell
powershell -ExecutionPolicy Bypass -File .\start.ps1 -RestartBackend
```

户型 AI 重建、需求对话和用户明确触发的照片分析会向已配置服务发送相应输入并产生用量。密钥仅由后端读取。操作步骤见 [API 配置说明](docs/api-configuration.md)。

## 测试与复现

```powershell
npm.cmd test
.\.venv\Scripts\python.exe -m unittest discover -s tests -p 'test_*.py' -v
npm.cmd run build
```

十张自绘户型用于固定回归对照，两张公开图纸仅用于运行观察，不代表真实户型的总体准确率。神经识别评估需要另行下载上游权重。上游 AI 响应在工程回归中采用模拟，不能用测试通过数替代视觉准确率或现场成效。

```powershell
.\.venv\Scripts\python.exe scripts/evaluate_plan_recognition.py --parser backend.neural_plan:recognize_floor_plan --output artifacts/recognition-local.json --save-models artifacts/recognition-models
```

## 源码结构

| 路径 | 内容 |
| --- | --- |
| `src/` | React / TypeScript 界面、Three.js 建模、布局及业务纯函数 |
| `backend/` | FastAPI、识别与矢量化、AI 接口适配、SQLite 项目库 |
| `scripts/` | 权重下载、数据抽帧、字体构建、评估和本地验证工具 |
| `tests/` | 自动测试、自绘控制图和保留许可的公开测试图片 |
| `public/` | 本地字体、品牌标记、公开案例影像及来源元数据 |
| `docs/` | 算法、使用流程、来源、已记录的验证和限制 |

完整使用说明见 [项目指南](docs/PROJECT_GUIDE.md)，算法见 [ALGORITHM.md](backend/ALGORITHM.md)，发布内容与扫描结果见 [发布审计](docs/RELEASE_AUDIT.md)。历史工作区产物和未打包的试验记录路径只作开发记录，不影响应用的安装运行。

## 使用边界与许可

当前版本面向单层住宅原型研究，不是精密测绘、结构设计、全自动施工验收或已验证的延期预测系统。进度为启用工序的等权阶段区间，保留未知项，不代表工程量、成本完成率或质量验收率。材料估算依赖用户价格及现场核对。

当前后端默认仅适合本地使用。公开部署前应补齐身份鉴权、HTTPS、配额与速率限制、持久化备份，并核对第三方代码、数据和权重的适用授权。

这是**包含多种许可材料的源码副本**，未为原创部分另行选择统一开源许可证，第三方内容不因收录而更换许可。CubiCasa 网络代码为 CC BY-NC 4.0，原始训练数据 Zenodo 记录为 CC BY-NC-SA 4.0；两张上游公开测试图保留 GPL-3.0，施工案例照片为 CC BY 4.0，字体为 SIL OFL 1.1。详见 [NOTICE](NOTICE.md) 和 [第三方声明](docs/THIRD_PARTY_NOTICES.md)。
