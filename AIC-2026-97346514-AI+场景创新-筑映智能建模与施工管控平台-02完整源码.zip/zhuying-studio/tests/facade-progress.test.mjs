import test from 'node:test';
import assert from 'node:assert/strict';
import {validateFacadeSample,summarizeFacade,planAtDate,evaluateFacade,createFacadeReport} from '../src/facade-progress.mjs';

function observation(id,date,statuses) {
  return {id,date,dateLabel:date,dateSource:'演示时间轴',image:`/facade-demo/${id}.webp`,sourceFile:'source-video.mp4',frameSeconds:10,
    stage:'partial',summary:'可见安装单元人工判读',regions:statuses.map((status,index)=>({id:`unit-${index}`,label:`单元${index}`,
      polygon:[[.05+index*.2,.1],[.15+index*.2,.1],[.15+index*.2,.3],[.05+index*.2,.3]],status,evidence:status==='unknown'?'遮挡，无法确认完整安装':'完整可见，按该帧人工标定'}))};
}
function sample() {
  return {schemaVersion:1,id:'facade-sample',title:'外立面时序样例',description:'固定四个可见单元',
    dataset:{title:'公开施工视频',url:'https://example.com/dataset',creator:'公开数据作者',license:'CC BY 4.0',licenseUrl:'https://creativecommons.org/licenses/by/4.0/'},
    datesAreCaptureDates:false,observations:[observation('first','2026-10-01',['not_installed','not_installed','not_installed','not_installed']),
      observation('middle','2026-10-03',['installed','not_installed','not_installed','not_installed']),
      observation('last','2026-10-05',['installed','installed','unknown','not_installed'])],
    plan:{simulated:true,label:'用户设置的模拟计划',startDate:'2026-10-01',endDate:'2026-10-09',targetPercent:100,inspectionGapDays:7},
    annotation:{method:'manual',scope:'同一组固定可见立面单元',label:'各帧独立人工判读，非真实工程量真值'}};
}

test('验证返回独立且稳定排序的样例，不修改原输入',()=>{
  const raw=sample();raw.observations.reverse();const before=structuredClone(raw),validated=validateFacadeSample(raw);
  assert.deepEqual(raw,before);assert.deepEqual(validated.observations.map(o=>o.id),['first','middle','last']);
  validated.observations[0].regions[0].status='unknown';assert.equal(raw.observations.at(-1).regions[0].status,'not_installed');
});
test('未知单元保留安装率上下界，覆盖率为0到100百分数',()=>{
  const summary=summarizeFacade(sample().observations.at(-1));
  assert.deepEqual(summary,{total:4,installed:2,notInstalled:1,unknown:1,coverage:75,lower:50,upper:75});
  assert.deepEqual(summarizeFacade(observation('all-unknown','2026-10-01',['unknown','unknown'])),
    {total:2,installed:0,notInstalled:0,unknown:2,coverage:0,lower:0,upper:100});
});
test('只把完整安装的固定单元计入下限，不用画面阶段推断百分比',()=>{
  const value=observation('raw','2026-10-01',['installed','not_installed']);value.stage='raw';
  assert.equal(summarizeFacade(value).lower,50);
});
test('各期固定标定单元一致且顺序可调整，不能更换或缩小分母',()=>{
  const raw=sample();raw.observations[1].regions.reverse();assert.equal(validateFacadeSample(raw).observations.length,3);
  for(const change of [o=>o.regions.pop(),o=>o.regions[0].id='new-unit']) {
    const invalid=sample();change(invalid.observations[1]);assert.throws(()=>validateFacadeSample(invalid),/相同固定标定单元/);
  }
});
test('重复观测编号和同一期重复单元编号明确拒绝',()=>{
  const a=sample();a.observations[1].id=a.observations[0].id;assert.throws(()=>validateFacadeSample(a),/观测编号不能重复/);
  const b=sample();b.observations[0].regions[1].id=b.observations[0].regions[0].id;assert.throws(()=>validateFacadeSample(b),/单元编号不能重复/);
});
test('同日期允许多帧，最新输入帧获胜，不把重复日算作额外速度样本',()=>{
  const raw=sample();raw.observations=[observation('a','2026-10-03',['installed','not_installed']),observation('b','2026-10-03',['installed','installed'])];
  const result=evaluateFacade(raw,'2026-10-03');assert.equal(result.observation.id,'b');assert.equal(result.actual.lower,100);assert.equal(result.scenario,null);
  raw.observations.reverse();assert.equal(evaluateFacade(raw,'2026-10-03').observation.id,'a');
});
test('截至日采用最新历史证据，未来观测不影响比例、速度或报告',()=>{
  const raw=sample(),result=evaluateFacade(raw,'2026-10-03');
  assert.equal(result.observation.id,'middle');assert.equal(result.actual.lower,25);
  const report=createFacadeReport(raw,'2026-10-03');assert.deepEqual(report.observations.map(o=>o.id),['first','middle']);
  raw.observations.at(-1).regions.forEach(r=>r.status='installed');
  assert.deepEqual(evaluateFacade(raw,'2026-10-03'),result);
  assert.equal(JSON.stringify(report).includes('2026-10-05'),false);
});
test('早于首观测日显示实际未知，并保留模拟计划值',()=>{
  const result=evaluateFacade(sample(),'2026-09-30');
  assert.equal(result.observation,null);assert.equal(result.actual,null);assert.equal(result.gap,null);assert.equal(result.staleDays,null);assert.equal(result.scenario,null);
  assert.equal(result.planned,0);assert.deepEqual(result.alerts.map(a=>a.kind),['missing_evidence']);
  assert.deepEqual(createFacadeReport(sample(),'2026-09-30').observations,[]);
});
test('模拟计划按日期线性累计，并在开始之前和结束之后截断',()=>{
  const plan=sample().plan;
  for(const [date,percent] of [['2026-09-30',0],['2026-10-01',0],['2026-10-03',25],['2026-10-05',50],['2026-10-09',100],['2026-10-20',100]]) assert.equal(planAtDate(plan,date),percent);
  assert.equal(planAtDate({...plan,targetPercent:80},'2026-10-05'),40);
  assert.equal(planAtDate({...plan,targetPercent:0},'2026-10-05'),0);
});
test('闰年计划计算按UTC日历天数，无本地时区偏移',()=>{
  const plan={...sample().plan,startDate:'2024-02-28',endDate:'2024-03-01'};
  assert.equal(planAtDate(plan,'2024-02-29'),50);
});
test('用户完整计划覆盖仅用于该次计算，不改样例原计划',()=>{
  const raw=sample(),before=structuredClone(raw),override={...raw.plan,endDate:'2026-10-05',targetPercent:80};
  const result=evaluateFacade(raw,'2026-10-03',override);assert.equal(result.planned,40);assert.equal(result.gap,-15);
  assert.deepEqual(raw,before);assert.deepEqual(createFacadeReport(raw,'2026-10-03',override).plan,override);
});
test('模拟偏差使用下限百分点，未知单元并不伪造100%实际进度',()=>{
  const result=evaluateFacade(sample(),'2026-10-07');assert.equal(result.planned,75);assert.equal(result.actual.lower,50);assert.equal(result.gap,-25);
  assert.deepEqual(result.alerts.map(a=>a.kind),['deviation','uncertain']);assert.match(result.alerts[0].message,/不能认定真实施工延期/);
});
test('超过巡检间隔才触发证据过期，与模拟偏差是不同告警',()=>{
  const raw=sample();raw.observations=[observation('first','2026-10-01',['installed','installed'])];
  assert.equal(evaluateFacade(raw,'2026-10-08').alerts.some(a=>a.kind==='stale'),false);
  const result=evaluateFacade(raw,'2026-10-09');assert.equal(result.staleDays,8);assert.deepEqual(result.alerts.map(a=>a.kind),['stale']);
  raw.observations[0].regions.forEach(r=>r.status='not_installed');
  assert.deepEqual(evaluateFacade(raw,'2026-10-09').alerts.map(a=>a.kind),['deviation','stale']);
});
test('完全核对的不同日期正增量可提供明确标注的情景估计',()=>{
  const raw=sample(),result=evaluateFacade(raw,'2026-10-03');
  assert.equal(result.scenario.rate,12.5);assert.equal(result.scenario.days,6);assert.equal(result.scenario.date,'2026-10-09');
  assert.match(result.scenario.label,/仅作情景估计/);assert.match(result.scenario.label,/不是实际工期预测/);
  raw.datesAreCaptureDates=true;assert.match(evaluateFacade(raw,'2026-10-03').scenario.label,/不是经过验证/);
});
test('观测不足、下降、零速度和已达目标不外推',()=>{
  const raw=sample();raw.observations=[observation('a','2026-10-01',['installed','installed','not_installed','not_installed'])];
  assert.equal(evaluateFacade(raw,'2026-10-01').scenario,null);
  for(const statuses of [['installed','not_installed','not_installed','not_installed'],['installed','installed','not_installed','not_installed'],['installed','installed','installed','installed']]) {
    raw.observations[1]=observation('b','2026-10-03',statuses);assert.equal(evaluateFacade(raw,'2026-10-03').scenario,null);
  }
});
test('当前有未知或证据过期时不把新增可见性当施工速度',()=>{
  assert.equal(evaluateFacade(sample(),'2026-10-05').scenario,null);
  const raw=sample();raw.observations=raw.observations.slice(0,2);
  assert.equal(evaluateFacade(raw,'2026-10-20').scenario,null);
  raw.observations[0].regions[0].status='unknown';assert.equal(evaluateFacade(raw,'2026-10-03').scenario,null);
});
test('情景目标日期若已早于截至日，不以过期估算冒充未来预测',()=>{
  const raw=sample();raw.observations=raw.observations.slice(0,2);
  raw.observations[1].regions[1].status='installed';raw.plan.targetPercent=60;
  assert.equal(evaluateFacade(raw,'2026-10-03').scenario.date,'2026-10-04');
  assert.equal(evaluateFacade(raw,'2026-10-05').scenario,null);
});
test('报告保留来源、人工标注、模拟计划、局限和截至证据，且与源数据独立',()=>{
  const raw=sample(),report=createFacadeReport(raw,'2026-10-05');
  assert.equal(report.reportType,'visible_facade_monitoring_demo');assert.deepEqual(report.dataset,raw.dataset);assert.equal(report.annotation.method,'manual');
  assert.equal(report.plan.simulated,true);assert.equal(report.datesAreCaptureDates,false);assert.ok(report.limitations.some(l=>l.includes('不表示整体建筑')));
  assert.ok(report.limitations.some(l=>l.includes('演示时间轴')));assert.deepEqual(report.evaluation,evaluateFacade(raw,'2026-10-05'));
  assert.doesNotThrow(()=>JSON.stringify(report));report.observations[0].regions[0].status='installed';assert.equal(raw.observations[0].regions[0].status,'not_installed');
});
test('日历非法日期、时间戳和空截至日期明确拒绝',()=>{
  for(const date of ['2026-02-29','2026-02-30','2026-13-01','2026-00-10','2026-10-00','2026-1-1','0000-01-01','2026-10-01T00:00:00Z','',null]) {
    const raw=sample();raw.observations[0].date=date;assert.throws(()=>validateFacadeSample(raw),/日期/);
    assert.throws(()=>evaluateFacade(sample(),date),/日期/);assert.throws(()=>planAtDate(sample().plan,date),/日期/);
  }
});
test('非法模拟计划、倒置/同日日期、目标与间隔无效都拒绝',()=>{
  for(const changes of [{simulated:false},{startDate:'2026-10-09'},{endDate:'2026-09-30'},{targetPercent:101},{targetPercent:-1},{targetPercent:NaN},
    {targetPercent:true},{inspectionGapDays:0},{inspectionGapDays:1.5},{inspectionGapDays:Infinity},{label:''}]) {
    const raw=sample();raw.plan={...raw.plan,...changes};assert.throws(()=>validateFacadeSample(raw));assert.throws(()=>evaluateFacade(sample(),'2026-10-05',raw.plan));
  }
});
test('非法结构、阶段、许可链接、影像路径与抽帧位置防御验证',()=>{
  for(const mutate of [r=>r.schemaVersion=2,r=>r.observations=[],r=>r.datesAreCaptureDates='false',r=>r.annotation.method='ai',r=>r.dataset.url='javascript:alert(1)',
    r=>r.dataset.licenseUrl='https://user:password@example.com',r=>r.observations[0].image='/facade-demo/../private',r=>r.observations[0].stage='complete',
    r=>r.observations[0].frameSeconds=-1,r=>r.observations[0].frameSeconds=NaN,r=>r.observations[0].dateSource='',r=>r.observations[0].summary='']) {
    const raw=sample();mutate(raw);assert.throws(()=>validateFacadeSample(raw));
  }
  for(const raw of [null,[],{}]) assert.throws(()=>validateFacadeSample(raw));
});
test('非法单元状态、坐标越界、自交和退化轮廓明确拒绝',()=>{
  for(const mutate of [r=>r.status='complete',r=>r.evidence='',r=>r.polygon[0][0]=-1,r=>r.polygon[0][1]=NaN,r=>r.polygon[0][0]=true,
    r=>r.polygon=[[0,0],[1,1],[1,0],[0,1]],r=>r.polygon=[[0,0],[.2,.2],[.4,.4]],r=>r.polygon=[[0,0],[1,0],[1,0],[0,1]]]) {
    const raw=sample();mutate(raw.observations[0].regions[0]);assert.throws(()=>validateFacadeSample(raw));
  }
});
