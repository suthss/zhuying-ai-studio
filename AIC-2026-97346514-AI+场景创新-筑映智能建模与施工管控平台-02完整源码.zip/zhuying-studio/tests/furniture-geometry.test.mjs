import test from 'node:test';
import assert from 'node:assert/strict';
import { viewer, withCanvas } from './helpers/viewer-module.mjs';
import { createDesignBrief, generateFurnishedModel } from '../src/furnishing.mjs';
const { THREE, createFurniture, buildHouse, disposeTree, DEMO_MODEL } = viewer;

test('13类真实家具的装饰网格均位于布局算法预留的外包尺寸内', () => {
  const kinds = ['sofa', 'coffee_table', 'tv_console', 'bed_double', 'bed_single', 'wardrobe', 'desk', 'chair', 'dining_table', 'kitchen_counter', 'sink_cabinet', 'toilet', 'shoe_cabinet'];
  for (const kind of kinds) {
    const item = { id: `test-${kind}`, roomId: 'room', kind, position: [8, 7], size: [1.6, 1.3, 1.2], rotation: .7, color: '#c6a47a' };
    const group = withCanvas(() => createFurniture(item));
    try {
      group.position.set(0, 0, 0); group.rotation.set(0, 0, 0); group.updateMatrixWorld(true);
      const bounds = new THREE.Box3().setFromObject(group);
      assert.ok(bounds.min.x >= -.8 - 1e-5 && bounds.max.x <= .8 + 1e-5, `${kind}: width overflow`);
      assert.ok(bounds.min.z >= -.6 - 1e-5 && bounds.max.z <= .6 + 1e-5, `${kind}: depth overflow`);
      assert.ok(bounds.min.y >= -1e-5 && bounds.max.y <= 1.3 + 1e-5, `${kind}: height overflow`);
      let meshes = 0;
      group.traverse(object => {
        if (!(object instanceof THREE.Mesh)) return;
        meshes++;
        assert.equal(object.userData.roomId, 'room');
        assert.equal(object.userData.furnitureId, item.id);
        assert.equal(object.userData.furnitureKind, kind);
      });
      assert.ok(meshes > 1, `${kind} should have detailed geometry`);
    } finally { disposeTree(group); }
  }
});

test('导入户型家具使用实际家具编号，空方案不会回退到示例家具', () => {
  const imported = structuredClone(DEMO_MODEL);
  imported.source = 'opencv';
  const result = generateFurnishedModel(imported, createDesignBrief(imported));
  assert.ok(result.model.furniture.length > 0);
  for (const furniture of [result.model.furniture, []]) {
    const model = { ...result.model, furniture };
    const { group } = withCanvas(() => buildHouse(model, 'material', false, true));
    try {
      const rendered = new Set();
      group.traverse(object => { if (object.userData.furnitureId) rendered.add(object.userData.furnitureId); });
      assert.deepEqual([...rendered].sort(), furniture.map(f => f.id).sort());
      assert.equal(group.getObjectByName('客厅 · 电视柜'), undefined);
    } finally { disposeTree(group); }
  }
});

test('真实柜门、抽屉与电视正面朝向布局的 +Z，水龙头留在后侧', () => {
  const kinds = ['wardrobe', 'shoe_cabinet', 'kitchen_counter', 'sink_cabinet', 'tv_console', 'desk'];
  for (const kind of kinds) {
    const item = { id: `front-${kind}`, roomId: 'room', kind, position: [8, 7], size: [1.6, 1.3, 1.2], rotation: Math.PI / 2, color: '#c6a47a' };
    const group = withCanvas(() => createFurniture(item));
    try {
      group.updateMatrixWorld(true);
      const named = label => group.children.filter(mesh => mesh.name === `${item.id} · ${label}`);
      // The layout rotates local +Z into the room; inspect the actual mesh visible from that direction.
      const frontHit = mesh => {
        const origin = group.localToWorld(new THREE.Vector3(mesh.position.x, mesh.position.y, item.size[2] * 2));
        const direction = new THREE.Vector3(0, 0, -1).applyQuaternion(group.quaternion);
        return new THREE.Raycaster(origin, direction).intersectObject(group, true)[0]?.object;
      };
      if (kind === 'desk') {
        const seams = named('抽屉缝');
        assert.equal(seams.length, 3);
        for (const seam of seams) {
          assert.ok(seam.position.z > 0, 'drawer seams must face the room');
          assert.equal(frontHit(seam), seam, 'the drawer front must be visible rather than hidden by its cabinet');
        }
      } else {
        const doors = named('柜门'), handles = named('嵌入式拉手');
        assert.ok(doors.length > 0);
        assert.equal(handles.length, doors.length);
        for (let i = 0; i < doors.length; i++) {
          assert.ok(doors[i].position.z > 0, `${kind}: cabinet doors must face the room`);
          assert.ok(handles[i].position.z > doors[i].position.z, `${kind}: handles must be in front of the doors`);
          assert.equal(frontHit(doors[i]), doors[i], `${kind}: the cabinet front must be visible from the room`);
        }
      }
      if (kind === 'tv_console') {
        const [screen] = named('屏幕');
        assert.ok(screen);
        assert.equal(frontHit(screen), screen, 'the screen must be visible ahead of the television frame');
      }
      if (kind === 'sink_cabinet') {
        const [tap] = named('龙头'), [spout] = named('出水口');
        assert.ok(tap.position.z < 0 && spout.position.z < 0, 'the faucet must stay behind the basin');
        assert.ok(spout.position.z > tap.position.z, 'the spout must extend from the rear toward the basin');
      }
    } finally { disposeTree(group); }
  }
});

test('按户型生成的客厅包含可见电视与薄地毯，软装不会阻挡房间交互', () => {
  const model=structuredClone(DEMO_MODEL);model.source='opencv';
  const result=generateFurnishedModel(model,createDesignBrief(model));
  const tv=result.model.furniture.find(item=>item.kind==='tv_console');
  assert.ok(tv);
  const {group}=withCanvas(()=>buildHouse(result.model,'material',true,true));
  try {
    assert.ok(group.getObjectByName(`${tv.id} · 屏幕`),'real generated furniture must include the screen');
    const rugs=[];
    group.traverse(object=>{if(object.userData.decoration==='rug')rugs.push(object);});
    assert.ok(rugs.length>0,'safely fitting rooms should have woven rugs');
    for(const rug of rugs) {
      assert.equal(rug.userData.ignorePick,true);
      assert.equal(rug.userData.kind,'floor');
      assert.equal(rug.userData.furnitureId,undefined);
      assert.ok(result.model.rooms.some(room=>room.id===rug.userData.roomId));
      rug.geometry.computeBoundingBox();
      assert.ok(rug.geometry.boundingBox.max.y-rug.geometry.boundingBox.min.y<.02);
    }
  } finally {disposeTree(group);}
});

test('茶几书册位于台面上，床头缝线在软包表面且均不超出预留包络', () => {
  const table={id:'books',roomId:'room',kind:'coffee_table',position:[0,0],size:[1.05,.42,.58],rotation:0,color:'#b79770'};
  const group=withCanvas(()=>createFurniture(table));
  try {
    const top=group.getObjectByName('books · 圆角台面'),book=group.getObjectByName('books · 桌面书册');
    assert.ok(top&&book);group.updateMatrixWorld(true);
    const topBounds=new THREE.Box3().setFromObject(top),bookBounds=new THREE.Box3().setFromObject(book);
    assert.ok(bookBounds.min.y>=topBounds.max.y-1e-5,'book cannot be hidden inside the tabletop');
    assert.ok(bookBounds.max.y>topBounds.max.y+.005);
  }finally {disposeTree(group);}
  const bed=withCanvas(()=>createFurniture({...table,id:'bed',kind:'bed_double',size:[1.55,.72,2]}));
  try {
    const seam=bed.getObjectByName('bed · 床头缝线'),head=bed.getObjectByName('bed · 软包床头');
    assert.ok(seam&&head);
    assert.ok(seam.position.z>head.position.z,'stitching must face the room');
  }finally {disposeTree(bed);}
});
