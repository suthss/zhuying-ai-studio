"""Explicit live check against the configured AI using a public fixture.

This makes up to two provider requests. It never writes the project database,
prints credentials, or includes request images in the diagnostic trace.
"""
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
from backend.neural_plan import recognize_floor_plan
from backend.ai_plan import assist_floor_plan


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    load_dotenv(ROOT / "backend/.env")
    target = ROOT / "artifacts"
    target.mkdir(exist_ok=True)
    os.environ["AI_PLAN_DEBUG_TRACE_PATH"] = str(target / "ai-scene-labels-trace.json")
    image = (ROOT / "tests/fixtures/plan-recognition/public-smoke/floorplan-to-blender-example.png").read_bytes()
    baseline = recognize_floor_plan(image, 12, 2.8, "auto")
    result = assist_floor_plan(image, baseline, 12, 2.8, "rebuild", "natural")
    (target / "ai-rebuild-verified.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    review = result["meta"]["aiReview"]
    print(json.dumps({**{key: review.get(key) for key in ("status", "geometryRebuilt", "source", "durationSeconds", "repairCount", "summary", "issues")},
                      "counts": {key: len(result[key]) for key in ("rooms", "walls", "openings")}}, ensure_ascii=False))
