import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { HouseModel } from '../types';

/** A local light rig. The transparent canvas lets the product's stage show through. */
export function createStudio(renderer: THREE.WebGLRenderer, scene: THREE.Scene) {
  const environment = new RoomEnvironment();
  const generator = new THREE.PMREMGenerator(renderer);
  let environmentMap: THREE.WebGLRenderTarget | null = null;
  try {
    // Keep the blur kernel within PMREM's 20-sample limit at its default resolution.
    environmentMap = generator.fromScene(environment, 0.035);
    scene.environment = environmentMap.texture;
  } catch {
    // Environment reflections are optional on resource-limited WebGL devices;
    // the direct studio lighting below remains a complete rendering fallback.
    scene.environment = null;
  } finally {
    environment.dispose();
    generator.dispose();
  }
  scene.environmentIntensity = 0.32;

  const ambient = new THREE.HemisphereLight('#ffffff', '#d0c9ba', 1.8);
  const key = new THREE.DirectionalLight('#fff9ef', 2.65);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.normalBias = 0.025;
  key.shadow.bias = -0.00035;
  key.shadow.radius = 4;
  const fill = new THREE.DirectionalLight('#f7f4eb', 0.9);
  const rim = new THREE.DirectionalLight('#ffffff', 0.65);
  scene.add(ambient, key, key.target, fill, rim);

  // Only the actual model casts onto this plane; it is outside the exported
  // house and outside all room picking/collision queries.
  const groundMaterial = new THREE.ShadowMaterial({ color: '#514c41', opacity: 0.17 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), groundMaterial);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.31;
  ground.receiveShadow = true;
  ground.userData.ignorePick = true;
  scene.add(ground);

  return {
    setTheme(theme: 'light' | 'dark') {
      const dark = theme === 'dark';
      // The architectural stage is transparent rather than a fogged world:
      // product background changes remain visible, and authored wall colours
      // are never darkened to emulate a dark theme.
      scene.background = null;
      scene.fog = null;
      renderer.setClearColor(dark ? '#1d201b' : '#ebe8df', 0);
      renderer.toneMappingExposure = dark ? 1.09 : 1.06;
      scene.environmentIntensity = dark ? 0.36 : 0.32;
      ambient.color.set(dark ? '#f5f2e8' : '#ffffff');
      ambient.groundColor.set(dark ? '#c7c4b5' : '#d0c9ba');
      groundMaterial.color.set(dark ? '#0e100b' : '#514c41');
      groundMaterial.opacity = dark ? 0.35 : 0.17;
    },
    frame(model: HouseModel) {
      const span = Math.max(model.width, model.depth, 4);
      key.position.set(-span * 0.8, span * 1.6, span * 0.65);
      fill.position.set(span, span * 0.6, -span);
      rim.position.set(-span * 0.6, span * 0.9, -span * 0.85);
      const half = span * 0.9 + 3;
      Object.assign(key.shadow.camera, { left: -half, right: half, top: half, bottom: -half, near: 0.1, far: span * 5 });
      key.shadow.camera.updateProjectionMatrix();
      ground.scale.set(span * 8, span * 8, 1);
    },
    dispose() {
      scene.environment = null;
      environmentMap?.dispose();
      key.shadow.dispose();
    },
  };
}

/** Fit both axes of the actual bounding volume to a deliberate stage coverage. */
export function fitStageCamera(camera: THREE.PerspectiveCamera, bounds: THREE.Box3, target: THREE.Vector3, aspect: number, coverage = 0.82) {
  camera.aspect = aspect;
  const direction = new THREE.Vector3(0.9, 1.08, 1.2).normalize();
  const right = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 1, 0), direction).normalize();
  const up = new THREE.Vector3().crossVectors(direction, right).normalize();
  const tanVertical = Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2);
  const tanHorizontal = tanVertical * aspect;
  let distance = 0;
  for (const x of [bounds.min.x, bounds.max.x]) for (const y of [bounds.min.y, bounds.max.y]) for (const z of [bounds.min.z, bounds.max.z]) {
    const offset = new THREE.Vector3(x, y, z).sub(target);
    distance = Math.max(distance, offset.dot(direction) + Math.abs(offset.dot(right)) / (tanHorizontal * coverage), offset.dot(direction) + Math.abs(offset.dot(up)) / (tanVertical * coverage));
  }
  // Centre the projected volume, rather than its ground origin. Perspective
  // otherwise pushes a deep plan toward the bottom and leaves empty sky.
  const points: THREE.Vector3[] = [];
  for (const x of [bounds.min.x, bounds.max.x]) for (const y of [bounds.min.y, bounds.max.y]) for (const z of [bounds.min.z, bounds.max.z]) points.push(new THREE.Vector3(x,y,z));
  const base = target.clone();
  let horizontal = 0, vertical = 0;
  for (let pass = 0; pass < 12; pass++) {
    target.copy(base).addScaledVector(right,horizontal).addScaledVector(up,vertical);
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const point of points) {
      const offset = point.clone().sub(target), depth = distance - offset.dot(direction);
      const x = offset.dot(right)/(depth*tanHorizontal), y = offset.dot(up)/(depth*tanVertical);
      minX = Math.min(minX,x);maxX = Math.max(maxX,x);minY = Math.min(minY,y);maxY = Math.max(maxY,y);
    }
    horizontal += ((minX+maxX)/2)*distance*tanHorizontal;
    vertical += ((minY+maxY)/2-.04)*distance*tanVertical;
    // Both axes must fit, including portrait mobile canvases. A small upward
    // bias leaves space for the actual room actions below the house.
    const projectedCoverage = Math.max((maxX-minX)/2,(maxY-minY)/2);
    distance *= THREE.MathUtils.clamp(projectedCoverage/coverage,.92,1.08);
  }
  target.copy(base).addScaledVector(right,horizontal).addScaledVector(up,vertical);
  camera.position.copy(target).addScaledVector(direction, distance);
  camera.far = Math.max(300, distance * 3);
  camera.lookAt(target);
  camera.updateProjectionMatrix();
}
