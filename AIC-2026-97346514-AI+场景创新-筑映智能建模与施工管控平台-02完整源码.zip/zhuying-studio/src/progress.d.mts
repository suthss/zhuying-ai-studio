import type { Evidence, Room, Stage, Task, WorkType } from './types';

export interface ProgressSummary {
  /** Equal-weight task stage lower bound across all active trades, not measured quantities. */
  percent: number | null;
  /** Unknown trades contribute their maximum stage; null only when no trades are active. */
  upperPercent: number | null;
  coverage: number;
  completed: number;
  known: number;
  unknown: number;
  total: number;
}

export interface RoomAlert {
  workType: WorkType;
  title: string;
  kind: 'delayed' | 'missing_evidence';
}

export function stageLabel(stage: Stage): string;
export const WORK_TYPES: readonly Readonly<{ id: WorkType; label: string; shortLabel: string; description: string }>[];
export function activeWorkTypes(room: Room): WorkType[];
export function confirmedProgress(room: Room, asOfDate?: string): ProgressSummary;
export function validCalendarDate(value: unknown): boolean;
/** Both dates must use YYYY-MM-DD. The due day itself is not overdue. */
export function isDelayed(task: Task, asOfDate: string): boolean;
export function getRoomAlerts(room: Room, asOfDate: string): RoomAlert[];
export function latestEvidence(evidence: Evidence[] | undefined, workType: WorkType, asOfDate?: string): Evidence | undefined;
export function roomAtDate(room: Room, date: string): Room;
export function validateEvidenceRecords(evidence: Evidence[]): Evidence[];
export function applyInspection(room: Room, evidence: Evidence): Room;
export function removeInspection(room: Room, id: string): Room;
