import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './style.css';
import './studio-theme.css';
import './premium-theme.css';
createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
