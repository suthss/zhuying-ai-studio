export type FacadeStatus = 'installed' | 'not_installed' | 'unknown';
export interface FacadeRegion { id:string; label:string; polygon:[number,number][]; status:FacadeStatus; evidence:string }
export interface FacadeObservation {
  id:string; date:string; dateLabel:string; dateSource:string; image:string; sourceFile:string; frameSeconds:number;
  stage:'raw'|'partial'; summary:string; regions:FacadeRegion[];
}
export interface FacadePlan { simulated:true; label:string; startDate:string; endDate:string; targetPercent:number; inspectionGapDays:number }
export interface FacadeSample {
  schemaVersion:1; id:string; title:string; description:string;
  dataset:{title:string;url:string;creator:string;license:string;licenseUrl:string};
  datesAreCaptureDates:boolean; observations:FacadeObservation[]; plan:FacadePlan;
  annotation:{method:'manual';scope:string;label:string};
}
export interface FacadeSummary { total:number; installed:number; notInstalled:number; unknown:number; coverage:number; lower:number; upper:number }
export interface FacadeEvaluation {
  observation:FacadeObservation|null; actual:FacadeSummary|null; planned:number;
  /** Confirmed lower bound minus simulated target, in percentage points. */
  gap:number|null; staleDays:number|null;
  alerts:{kind:'missing_evidence'|'deviation'|'stale'|'uncertain';message:string}[];
  scenario:{date:string;days:number;rate:number;label:string}|null;
}
export interface FacadeReport {
  schemaVersion:1; reportType:'visible_facade_monitoring_demo'; sampleId:string; title:string; asOf:string;
  metric:{label:string;unit:'percent';denominator:string;unknownPolicy:string};
  dataset:FacadeSample['dataset'];datesAreCaptureDates:boolean;annotation:FacadeSample['annotation'];plan:FacadePlan;
  limitations:string[];observations:FacadeObservation[];evaluation:FacadeEvaluation;
}
export function validateFacadeSample(raw:unknown):FacadeSample;
export function summarizeFacade(observation:FacadeObservation):FacadeSummary;
export function planAtDate(plan:FacadePlan,date:string):number;
export function evaluateFacade(sample:FacadeSample,asOf:string,planOverride?:FacadePlan):FacadeEvaluation;
export function createFacadeReport(sample:FacadeSample,asOf:string,planOverride?:FacadePlan):FacadeReport;
