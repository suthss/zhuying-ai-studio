import * as THREE from 'three';
import type { HouseModel, Point } from '../types';

export const INTERIOR_EYE_HEIGHT = 1.55;
const BODY_RADIUS = .18;

function inside(polygon: Point[], x: number, z: number) {
  let result = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const a = polygon[i], b = polygon[j];
    if ((a[1] > z) !== (b[1] > z) && x < (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]) + a[0]) result = !result;
  }
  return result;
}

function edgeClearance(polygon: Point[], x: number, z: number) {
  return Math.min(...polygon.map((a, index) => {
    const b = polygon[(index + 1) % polygon.length];
    const dx = b[0] - a[0], dz = b[1] - a[1], squared = dx * dx + dz * dz;
    const t = squared > 0 ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (z - a[1]) * dz) / squared)) : 0;
    return Math.hypot(x - a[0] - dx * t, z - a[1] - dz * t);
  }));
}

function physical(object: THREE.Object3D) {
  for (let ancestor: THREE.Object3D | null = object; ancestor; ancestor = ancestor.parent) {
    if (!ancestor.visible || ancestor.userData.ignorePick) return false;
  }
  return object instanceof THREE.Mesh;
}

/** Find floor space using physical furniture footprints, never place eyes in a bed. */
export function findInteriorStandingPoint(model: HouseModel, roomId: string, house: THREE.Group, preferred?: THREE.Vector3): THREE.Vector3 | null {
  const room = model.rooms.find(item => item.id === roomId);
  if (!room || room.polygon.length < 3 || model.height <= INTERIOR_EYE_HEIGHT + .08) return null;
  house.updateMatrixWorld(true);
  const obstacles: THREE.Box3[] = [];
  const floors: THREE.Object3D[] = [];
  house.traverse(object => {
    if (!(object instanceof THREE.Mesh) || !physical(object)) return;
    const data = object.userData;
    if (data.kind === 'floor' || (object.geometry instanceof THREE.ShapeGeometry && data.roomId === roomId)) {
      if (data.roomId === roomId) floors.push(object);
      return;
    }
    if (data.roomId && data.roomId !== roomId && !data.wallId && !data.openingId) return;
    if (data.kind === 'ceiling') return;
    const bounds = new THREE.Box3().setFromObject(object);
    // Rugs and floor trim below the ankles do not block standing. Furniture,
    // door leaves and walls through the body/eye height do block it.
    if (bounds.min.y < INTERIOR_EYE_HEIGHT + .1 && bounds.max.y > .1) obstacles.push(bounds);
  });
  const centerX = room.polygon.reduce((sum, p) => sum + p[0], 0) / room.polygon.length;
  const centerZ = room.polygon.reduce((sum, p) => sum + p[1], 0) / room.polygon.length;
  const minX = Math.min(...room.polygon.map(p => p[0])), maxX = Math.max(...room.polygon.map(p => p[0]));
  const minZ = Math.min(...room.polygon.map(p => p[1])), maxZ = Math.max(...room.polygon.map(p => p[1]));
  const candidates: Point[] = [];
  if (preferred) candidates.push([preferred.x + model.width / 2, preferred.z + model.depth / 2]);
  candidates.push([centerX, centerZ]);
  for (let i = 1; i <= 15; i++) for (let j = 1; j <= 15; j++) candidates.push([minX + (maxX - minX) * i / 16, minZ + (maxZ - minZ) * j / 16]);
  const raycaster = new THREE.Raycaster();
  const down = new THREE.Vector3(0, -1, 0);
  let best: THREE.Vector3 | null = null, bestScore = -Infinity;
  for (let index = 0; index < candidates.length; index++) {
    const [x, z] = candidates[index];
    const edgeDistance = edgeClearance(room.polygon, x, z);
    if (!inside(room.polygon, x, z) || edgeDistance < BODY_RADIUS + .05) continue;
    const worldX = x - model.width / 2, worldZ = z - model.depth / 2;
    if (obstacles.some(box => worldX > box.min.x - BODY_RADIUS && worldX < box.max.x + BODY_RADIUS && worldZ > box.min.z - BODY_RADIUS && worldZ < box.max.z + BODY_RADIUS)) continue;
    raycaster.set(new THREE.Vector3(worldX, .25, worldZ), down);
    raycaster.far = .5;
    const floor = raycaster.intersectObjects(floors, false)[0];
    if (!floor || floor.point.y > .1 || floor.point.y < -.05) continue;
    const position = new THREE.Vector3(worldX, INTERIOR_EYE_HEIGHT, worldZ);
    if (preferred && index === 0) return position;
    const furnitureDistance = Math.min(...obstacles.map(box => Math.hypot(Math.max(box.min.x - worldX, 0, worldX - box.max.x), Math.max(box.min.z - worldZ, 0, worldZ - box.max.z))), edgeDistance);
    const score = Math.min(edgeDistance, furnitureDistance) - Math.hypot(x - centerX, z - centerZ) * .08;
    if (score > bestScore) { bestScore = score; best = position; }
  }
  return best;
}

export function applyInteriorAngles(camera: THREE.PerspectiveCamera, yaw: number, pitch: number) {
  camera.rotation.set(THREE.MathUtils.clamp(pitch, -Math.PI * 4 / 9, Math.PI * 4 / 9), yaw, 0, 'YXZ');
}
