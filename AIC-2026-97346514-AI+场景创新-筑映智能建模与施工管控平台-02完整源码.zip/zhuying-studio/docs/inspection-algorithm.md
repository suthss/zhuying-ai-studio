# 多角度施工巡检与前后对比

## 算法用途

用户在施工监控中选择同一房间、同一工序的1～6张当前现场照片，可另选此前巡检日期下的0～6张真实照片。用户点击分析后，后端将两组图片与日期、工序一次送入已配置的千问视觉模型。接口只返回待复核的照片观察和可见差异，不直接修改项目施工状态。

这是基于视觉语言模型的联合证据描述，当前没有经过施工照片标注集验证的工序分类器，也没有可报告的识别准确率。多角度输入能提供更多可见证据，但不保证覆盖完整或判断正确。

## 输入与处理

`POST /api/analyze-inspection` 接收 multipart 表单：

| 字段 | 约束 |
|---|---|
| `files` | 当前照片1～6张，同名字段重复上传 |
| `room_name` | 非空，不超过80字符 |
| `work_type` | `electrical`水电安装、`waterproof`防水、`masonry`泥瓦、`carpentry`木工、`floor`地面、`wall`墙面 |
| `date` | 必填、严格有效的`YYYY-MM-DD` |
| `previous_files` | 前次照片0～6张，只传用户选择的真实照片 |
| `previous_date` | 可选有效日期，不得晚于`date` |
| `previous_stage` | 可选`not_started`、`in_progress`、`complete`或`unknown`；仅作为人工记录上下文 |

每张原文件不超过10 MiB，两组合计不超过30 MiB；只支持PNG/JPEG/WebP，任意边不超过12000像素，单张不超过2000万像素。两组所有图片均先成功解码；空图、坏图或非法元数据会在任何云端调用前被拒绝。解码图片及时关闭，配置模型时逐张缩至最长边1600像素并编码为JPEG。

云端请求中的顺序为：整体元数据 → 前次图0、1… → 当前图0、1…；每张图之前都有明确的`group`、`date`及组内`photoIndex`。服务只在收到用户触发的接口请求时进行分析，不定时巡检、不自动上传整个项目图片。密钥仅来自后端`QWEN_API_KEY`，视觉模型来自`QWEN_MODEL`，默认`qwen-vl-plus`；URL复用现有阿里云官方HTTPS白名单。

多图内容格式根据[阿里云千问视觉模型OpenAI兼容接口文档](https://help.aliyun.com/zh/model-studio/qwen-vl-compatible-with-openai)实现。一次HTTP请求包含所有已选照片，等待上限45秒；不同配置模型的上下文和图片额度仍可能导致提供方拒绝，此时返回明确错误，不拆成隐藏的多次付费调用。

## 输出与复核

```json
{
  "stage": "unknown",
  "summary": "待复核的当前工序可见证据与局限",
  "source": "manual_review",
  "needsReview": true,
  "observations": [
    {"photoIndex": 0, "summary": "当前第1张照片的证据说明"}
  ],
  "comparison": {
    "summary": "前后可见差异与局限",
    "change": "uncertain"
  }
}
```

`observations`只对应当前组，索引从0开始；每张恰有一项，完整、唯一、合法，后端按索引排序。`comparison`只在提供了真实前次照片时存在。仅传前次日期或状态不会产生图像对比。

模型须输出完整JSON，并通过工序阶段枚举、各段非空文本与2000字上限、索引完整性、对比字段及四类变化值的校验。多余来源或`needsReview`字段不会被模型覆盖：模型结果中的额外字段会被拒绝，成功结果由服务设置`source: qwen/<实际模型名>`和`needsReview: true`。

未配置密钥时，两组图片仍经输入校验，但不执行模型识别：`stage: unknown`、`source: manual_review`，逐图说明明确要求人工复核；有前次照片时`change: uncertain`。云端鉴权、网络及结构化输出失败返回502，不静默退回假识别成功。

前次日期缺省或两次巡检在同一天时，日期粒度无法证明先后顺序，即使模型给出`advanced`也会将变化归为`uncertain`，只保留可见差异说明。日期相同的对比仍允许查看，但不能当成已确认的时间进展。

## 证据边界

提示词要求遮挡、局部覆盖、视角无法对应或图像冲突时输出`unknown`/`uncertain`。`complete`只表示照片支持的可见外观完成，不能替代整间房确认、隐蔽工程验收或质量检测。模型的语义判断仍可能违反提示或误判，结构校验不能验证照片内容，因此所有成功结果必须人工复核后才能成为确认状态。

水电与防水只能观察可见管线、涂层或作业迹象；不判断线路功能、埋管质量、闭水试验、真实尺寸、精确工程量、准确完成百分比或规范合规。模型不推断或更改三维几何。未知状态是证据不足，并不等于未施工。

原有`POST /api/analyze-photo`仍保留单图`file`、`room_name`、`work_type: floor/wall`及`{stage, summary, source, needsReview}`返回，供旧版调用兼容。

## 回归验证

```powershell
.\.venv\Scripts\python.exe -m pip install -r backend/requirements-dev.txt
.\.venv\Scripts\python.exe -m pytest tests -q
```

新增测试使用真实有效的PNG输入及模拟云端HTTP响应，核对单次请求、前后图组顺序及颜色内容、日期与工序元数据、完整逐图索引、无密钥诚实路径、比较日期局限、错误状态、损坏图片、数量和大小限制、旧单图兼容性。测试不读取或打印密钥，不发起真实付费推理；模拟响应只证明边界和契约，不证明千问实际识别效果。
