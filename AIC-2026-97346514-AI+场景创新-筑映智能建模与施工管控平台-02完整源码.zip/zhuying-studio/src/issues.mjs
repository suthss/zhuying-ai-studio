import { WORK_TYPES, validCalendarDate } from './progress.mjs';

export const ISSUE_STATES = { open: '待处理', in_progress: '处理中', review: '待复核', closed: '已关闭' };
const record = v => !!v && typeof v === 'object' && !Array.isArray(v);
const fail = message => { throw new Error(message); };
const text = (v, name, max = 2000, empty = false) => {
  if (typeof v !== 'string' || v.length > max || (!empty && !v.trim())) fail(`${name}格式无效。`);
  return v;
};
const id = v => text(v, '编号', 160);
const day = (v, label) => { if (!validCalendarDate(v)) fail(`${label}须为有效日期。`); return v; };
const states = new Set(Object.keys(ISSUE_STATES));
const workTypes = new Set(WORK_TYPES.map(v => v.id));
const nextState = { begin: ['open','in_progress'], submit: ['in_progress','review'], close: ['review','closed'], return: ['review','in_progress'], reopen: ['closed','in_progress'] };
const validTimestamp = value => {
  if (typeof value !== 'string') return false;
  const match = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?(Z|[+-](\d{2}):(\d{2}))$/.exec(value);
  return !!match && validCalendarDate(match[1]) && +match[2] < 24 && +match[3] < 60 && +match[4] < 60 && (match[5] === 'Z' || (+match[6] < 24 && +match[7] < 60));
};

export function validateIssuePhotos(raw) {
  if (!Array.isArray(raw) || raw.length > 6) fail('每次最多保存六张问题照片。');
  const seen = new Set(); let bytes = 0;
  return raw.map(photo => {
    if (!record(photo)) fail('问题照片格式无效。');
    id(photo.id); if (seen.has(photo.id)) fail('照片编号不能重复。'); seen.add(photo.id);
    text(photo.caption, '照片说明', 500, true);
    if (!['upload','inspection','public_case'].includes(photo.source)) fail('照片来源无效。');
    if (photo.source === 'public_case') {
      if (!/^\/renovation-case\/[a-zA-Z0-9_-]+\.(?:webp|jpg|png)$/.test(photo.image)) fail('公开案例照片路径无效。');
    } else {
      if (typeof photo.image !== 'string') fail('照片编码无效。');
      const match = /^data:image\/(?:jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(photo.image);
      if (!match || match[1].length % 4) fail('请选择有效的 PNG、JPEG 或 WebP 照片。');
      const size = match[1].length * .75 - (match[1].endsWith('==') ? 2 : match[1].endsWith('=') ? 1 : 0);
      if (size > 10 * 1024 * 1024) fail('单张问题照片不能超过 10 MB。'); bytes += size;
    }
    if (photo.captureDate !== null) day(photo.captureDate, '照片日期');
    if (photo.point !== undefined && (!Array.isArray(photo.point) || photo.point.length !== 2 || photo.point.some(v => typeof v !== 'number' || !Number.isFinite(v) || v < 0 || v > 1))) fail('照片标记须位于画面内。');
    return { id: photo.id, image: photo.image, caption: photo.caption, source: photo.source, captureDate: photo.captureDate, ...(photo.point ? {point:[...photo.point]} : {}) };
  }).map(photo => { if (bytes > 30 * 1024 * 1024) fail('本次照片总量不能超过 30 MB。'); return photo; });
}

export function validateIssueTracker(raw, model) {
  if (raw === undefined) return { version: 1, issues: [] };
  if (!record(raw) || raw.version !== 1 || !Array.isArray(raw.issues) || raw.issues.length > 200) fail('整改任务格式无效，最多保存200项。');
  const seen = new Set();
  const issues = raw.issues.map(issue => {
    if (!record(issue)) fail('整改任务格式无效。');
    id(issue.id); if (seen.has(issue.id)) fail('整改任务编号重复。'); seen.add(issue.id);
    id(issue.roomId); text(issue.title,'问题名称',160); text(issue.description,'问题说明',3000,true);
    text(issue.location,'位置说明',500,true); text(issue.assignee,'责任人',160); day(issue.dueDate,'整改期限'); day(issue.createdDate,'发现日期');
    if (issue.dueDate < issue.createdDate || !workTypes.has(issue.workType) || !states.has(issue.status) || !['actual','demonstration'].includes(issue.mode) || (issue.orphaned !== undefined && typeof issue.orphaned !== 'boolean')) fail('整改期限、工序、状态或数据类型无效。');
    if (!Array.isArray(issue.events) || !issue.events.length || issue.events.length > 100) fail('问题需保留1至100条处理记录。');
    const eventIds = new Set(); let status = null; let previous = issue.createdDate;
    const events = issue.events.map((event, index) => {
      if (!record(event)) fail('处理记录格式无效。'); id(event.id);
      if (eventIds.has(event.id)) fail('处理记录编号重复。'); eventIds.add(event.id);
      day(event.date,'处理日期'); if (event.date < previous) fail('处理记录日期不能倒退。'); previous = event.date;
      text(event.actor,'记录人',160); text(event.note,'处理说明',3000,true);
      if (!validTimestamp(event.at) || (event.confirmed !== undefined && typeof event.confirmed !== 'boolean')) fail('记录时间或确认状态无效。');
      const photos = validateIssuePhotos(event.photos);
      if (index === 0) { if (event.action !== 'create' || event.status !== 'open' || event.date !== issue.createdDate) fail('问题须从待处理开始。'); }
      else if (['comment','update'].includes(event.action)) { if (event.status !== status) fail('补充记录不能改变处理状态。'); }
      else {
        const transition = nextState[event.action];
        if (!transition || transition[0] !== status || transition[1] !== event.status) fail('问题处理流程无效。');
        if (['submit','close','return','reopen'].includes(event.action) && !event.note.trim()) fail('提交或复核必须填写说明。');
        if (event.action === 'submit' && !photos.length) fail('提交复核需要整改照片。');
        if (event.action === 'close' && event.confirmed !== true) fail('关闭问题需要人工确认。');
      }
      status = event.status;
      return {...event,photos};
    });
    if (issue.status !== status) fail('问题状态与处理记录不一致。');
    return {...issue,events,orphaned:!!model && !model.rooms.some(room => room.id === issue.roomId)};
  });
  return {version:1,issues};
}

export function createIssue(model, input, context) {
  const tracker = validateIssueTracker(model.meta?.issueTracker,model);
  const issue = {id:context.id,roomId:input.roomId,title:input.title.trim(),description:input.description.trim(),location:input.location.trim(),
    workType:input.workType,assignee:input.assignee.trim(),dueDate:input.dueDate,createdDate:context.date,status:'open',
    mode: model.meta?.demoData === true || model.source === 'demo' ? 'demonstration' : 'actual',
    events:[{id:context.eventId,action:'create',status:'open',date:context.date,at:context.at,actor:context.actor.trim(),note:input.description.trim(),photos:input.photos??[]}]};
  if (!model.rooms.some(room => room.id === issue.roomId)) fail('请选择当前项目中的房间。');
  if (tracker.issues.length >= 200) fail('已达到200项问题上限，请备份项目。');
  return validateIssueTracker({version:1,issues:[...tracker.issues,issue]},model);
}

export function transitionIssue(model, issueId, action, input, context) {
  const tracker = validateIssueTracker(model.meta?.issueTracker,model);
  const issue = tracker.issues.find(item => item.id === issueId); if (!issue) fail('找不到这项问题。');
  const status = ['comment','update'].includes(action) ? issue.status : nextState[action]?.[1];
  if (!status) fail('处理动作无效。');
  const event = {id:context.eventId,action,status,date:context.date,at:context.at,actor:input.actor.trim(),note:input.note.trim(),photos:input.photos??[],...(action==='close'?{confirmed:input.confirmed===true}:{})};
  const updated = {...issue,status,events:[...issue.events,event]};
  return validateIssueTracker({...tracker,issues:tracker.issues.map(item => item.id === issueId ? updated : item)},model);
}

export function issueSummary(model, asOf) {
  day(asOf,'统计日期'); const tracker=validateIssueTracker(model.meta?.issueTracker,model);
  const issues=tracker.issues.map(issue=>{const events=issue.events.filter(event=>event.date<=asOf);return events.length?{...issue,status:events.at(-1).status,events}:null;}).filter(Boolean);
  return {issues,total:issues.length,open:issues.filter(i=>i.status==='open').length,inProgress:issues.filter(i=>i.status==='in_progress').length,
    review:issues.filter(i=>i.status==='review').length,closed:issues.filter(i=>i.status==='closed').length,overdue:issues.filter(i=>i.status!=='closed'&&i.dueDate<asOf).length};
}

export function createWeeklyReport(model,startDate,endDate) {
  day(startDate,'周报开始日期'); day(endDate,'周报结束日期'); if(startDate>endDate)fail('周报结束日期须不早于开始日期。');
  const summary=issueSummary(model,endDate);
  const activities=summary.issues.flatMap(issue=>issue.events.filter(event=>event.date>=startDate).map(event=>({issueId:issue.id,title:issue.title,roomId:issue.roomId,mode:issue.mode,...event}))).sort((a,b)=>b.date.localeCompare(a.date));
  const inspections=model.rooms.flatMap(room=>(room.evidence??[]).filter(e=>e.confirmed&&e.date>=startDate&&e.date<=endDate).map(e=>({roomId:room.id,roomName:room.name,id:e.id,date:e.date,workType:e.workType,stage:e.stage,summary:e.summary,photoCount:e.photos?.length??1})));
  return {schemaVersion:1,type:'zhuying_owner_weekly_report',projectId:model.id,projectName:model.name,startDate,endDate,
    demonstration:model.source==='demo'||model.meta?.demoData===true,summary:{total:summary.total,open:summary.open,inProgress:summary.inProgress,review:summary.review,closed:summary.closed,overdue:summary.overdue},
    issues:summary.issues,activities,inspections,limits:['整改关闭仅表示人工复核该问题，不自动更新工序完成状态或质量验收结论。','周报仅采用截至结束日期已记录的证据；缺少现场证据的部分保持待核对。']};
}

export function weeklyMarkdown(report,roomNames={}) {
  const safe=value=>String(value??'').replace(/[\r\n]+/g,' ').replace(/[|<>]/g,' ');
  return [`# ${safe(report.projectName)} · 业主周报`,`${report.startDate} — ${report.endDate}`,report.demonstration?'**公开影像案例／模拟任务演练，不是真实项目管理记录。**':'',
    `截至期末：待处理 ${report.summary.open}；处理中 ${report.summary.inProgress}；待复核 ${report.summary.review}；已关闭 ${report.summary.closed}；逾期未关闭 ${report.summary.overdue}。`,
    '## 本周处理',...report.activities.flatMap(e=>[`- ${e.date} · ${safe(roomNames[e.roomId]??e.roomId)} · ${safe(e.title)} · ${ISSUE_STATES[e.status]} · ${safe(e.actor)}：${safe(e.note)}（${e.photos.length}张照片）`,...e.photos.map(p=>`  - 照片：${safe(p.caption)} · 拍摄日期 ${p.captureDate??'未知'}${p.source==='public_case'?' · 公开原始影像':''}`)]),
    '## 待跟进',...report.issues.filter(i=>i.status!=='closed').map(i=>`- ${safe(i.title)} · ${safe(i.assignee)} · 期限 ${i.dueDate} · ${ISSUE_STATES[i.status]}`),
    '## 已确认巡检',...report.inspections.map(e=>`- ${e.date} · ${safe(e.roomName)} · ${safe(WORK_TYPES.find(w=>w.id===e.workType)?.label)} · ${safe(e.summary)}（${e.photoCount}张照片）`),
    '## 数据说明',...report.limits.map(text=>`- ${text}`)].filter(Boolean).join('\n\n');
}
