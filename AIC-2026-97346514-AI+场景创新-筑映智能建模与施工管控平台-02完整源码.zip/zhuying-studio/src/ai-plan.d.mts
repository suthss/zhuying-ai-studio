import type { DesignBrief, FurnitureKind, HouseModel, RoomUse } from './types';
export interface AIPlanReview {
  status: 'applied' | 'reviewed' | 'unavailable' | 'failed'; mode: 'local' | 'assist' | 'rebuild';
  source: string; summary: string; geometryRebuilt: boolean;
  changes: {kind: string; targetId: string; reason: string}[];
  issues: {targetId: string; severity: string; message: string}[];
  roomSuggestions: {roomId: string; name: string; use: RoomUse; confidence: number | null; evidence: string; applied: boolean}[];
  layoutSuggestions: {roomId: string; placement: string; items?: FurnitureKind[]}[];
  originalCounts: Partial<Record<'rooms'|'walls'|'doors'|'windows', number>>;
}
export function getAIPlanReview(model: HouseModel): AIPlanReview | null;
export function createAIPlanBrief(model: HouseModel, style?: DesignBrief['style']): DesignBrief;
