/** Visual design choices are independent of observed construction state. */
export const FLOOR_FINISHES = Object.freeze([
  { id: 'oak', label: '自然橡木', description: '温润木纹，适合卧室与客厅', color: '#c6a374' },
  { id: 'walnut', label: '深色胡桃木', description: '深色木纹，营造沉稳空间', color: '#896246' },
  { id: 'light_tile', label: '浅色瓷砖', description: '浅色大砖，明亮清爽', color: '#e4e4dc' },
  { id: 'gray_stone', label: '灰色石材', description: '细腻石纹，中性灰阶', color: '#a5aaa5' },
  { id: 'terrazzo', label: '细粒水磨石', description: '细粒拼色，柔和质感', color: '#d6cfc0' },
  { id: 'concrete', label: '施工基层', description: '无饰面纹理的混凝土基层', color: '#b9bbb5' },
].map(Object.freeze));

export const WALL_COLORS = Object.freeze([
  { id: 'warm_white', label: '暖白', color: '#f4f0e8' },
  { id: 'ivory', label: '米杏', color: '#e8e0d0' },
  { id: 'sage', label: '鼠尾草', color: '#c2d0bd' },
  { id: 'mist_blue', label: '雾蓝', color: '#bfccd4' },
  { id: 'clay', label: '陶土', color: '#d7b8a4' },
  { id: 'graphite', label: '石墨', color: '#596260' },
].map(Object.freeze));

const finishIds = new Set(FLOOR_FINISHES.map(finish => finish.id));
const designKeys = new Set(['floorFinish', 'wallColor', 'wallFinish', 'floorDirection']);
const legacyFinishes = { wood: 'oak', tile: 'light_tile', stone: 'gray_stone', concrete: 'concrete' };

export function isRoomDesign(value) {
  return !!value && typeof value === 'object' && !Array.isArray(value)
    && finishIds.has(value.floorFinish)
    && typeof value.wallColor === 'string' && /^#[0-9a-f]{6}$/i.test(value.wallColor)
    && (value.wallFinish === 'paint' || value.wallFinish === 'plaster')
    && (value.floorDirection === 0 || value.floorDirection === 90);
}

function checkedDesign(value) {
  if (!isRoomDesign(value)) throw new Error('装修设计无效：请使用支持的材质、六位十六进制墙色及 0°/90° 方向。');
  // Copy only the four supported design fields; callers cannot mutate stored data.
  return { floorFinish: value.floorFinish, wallColor: value.wallColor,
           wallFinish: value.wallFinish, floorDirection: value.floorDirection };
}

export function resolveRoomDesign(room) {
  if (room.design !== undefined) return checkedDesign(room.design);
  const material = typeof room.material === 'string' ? room.material.toLowerCase() : '';
  return { floorFinish: legacyFinishes[material] ?? 'oak', wallColor: '#f4f0e8',
           wallFinish: 'paint', floorDirection: 0 };
}

function requireRoom(model, roomId) {
  const room = model.rooms.find(item => item.id === roomId);
  if (!room) throw new Error('找不到待编辑的房间，请重新选择空间。');
  return room;
}

export function updateRoomDesign(model, roomId, patch) {
  const room = requireRoom(model, roomId);
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)
      || Object.keys(patch).some(key => !designKeys.has(key))) {
    throw new Error('设计修改只能包含地面材质、墙面颜色、墙面饰面与地板方向。');
  }
  const design = checkedDesign({ ...resolveRoomDesign(room), ...patch });
  return { ...model, rooms: model.rooms.map(item => item.id === roomId ? { ...item, design } : item) };
}

export function resetRoomDesign(model, roomId) {
  requireRoom(model, roomId);
  return { ...model, rooms: model.rooms.map(item => {
    if (item.id !== roomId) return item;
    const next = { ...item };
    delete next.design;
    return next;
  }) };
}

export function preserveRoomDesign(previous, next) {
  const designs = new Map(previous.rooms.filter(room => room.design !== undefined)
    .map(room => [room.id, checkedDesign(room.design)]));
  return { ...next, rooms: next.rooms.map(room => designs.has(room.id)
    ? { ...room, design: { ...designs.get(room.id) } } : room) };
}
