import { useMemo, useRef, useState } from 'react';
import { ArrowRight, Camera, Check, CheckCircle2, MapPin, Plus, Trash2 } from 'lucide-react';
import { createIssue, ISSUE_STATES, issueSummary, transitionIssue, validateIssuePhotos } from './issues.mjs';
import type { Issue, IssueAction, IssuePhoto } from './issues.mjs';
import { WORK_TYPES } from './progress.mjs';
import type { HouseModel, WorkType } from './types';
import { casePhotos } from './RenovationCase';
import { localToday } from './calendar';
const context=()=>({id:crypto.randomUUID(),eventId:crypto.randomUUID(),date:localToday(),at:new Date().toISOString()});

async function prepareIssuePhoto(file:File):Promise<IssuePhoto> {
  if (!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>10*1024*1024) throw new Error('请选择不超过10 MB的PNG、JPG或WebP照片。');
  const bitmap=await createImageBitmap(file);
  try {
    if(bitmap.width*bitmap.height>60_000_000)throw new Error('照片分辨率过大，请先缩小。');
    const scale=Math.min(1,1600/Math.max(bitmap.width,bitmap.height)),canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));
    const drawing=canvas.getContext('2d');if(!drawing)throw new Error('浏览器暂时不能处理照片。');
    drawing.fillStyle='#fff';drawing.fillRect(0,0,canvas.width,canvas.height);drawing.drawImage(bitmap,0,0,canvas.width,canvas.height);
    const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error('照片压缩失败。')),'image/jpeg',.86));
    const image=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('照片读取失败。'));reader.readAsDataURL(blob);});
    return{id:crypto.randomUUID(),image,caption:file.name,source:'upload',captureDate:null};
  } finally {bitmap.close();}
}

export function IssuePhotos({photos,onChange,readOnly=false}:{photos:IssuePhoto[];onChange?:(next:IssuePhoto[])=>void;readOnly?:boolean}) {
  return <div className="issue-photos">{photos.map((photo,index)=><figure key={photo.id}>
    <button type="button" className="issue-photo-mark" disabled={readOnly} aria-label={readOnly?photo.caption:`标记第${index+1}张照片的问题位置`} onClick={event=>{const bounds=event.currentTarget.getBoundingClientRect();const point:[number,number]=[Math.max(0,Math.min(1,(event.clientX-bounds.left)/bounds.width)),Math.max(0,Math.min(1,(event.clientY-bounds.top)/bounds.height))];onChange?.(photos.map(p=>p.id===photo.id?{...p,point}:p));}} onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();onChange?.(photos.map(p=>p.id===photo.id?{...p,point:[.5,.5]}:p));}}}>
      <img src={photo.image} alt={photo.caption||`问题证据${index+1}`} loading="lazy"/>{photo.point&&<span className="issue-pin" style={{left:`${photo.point[0]*100}%`,top:`${photo.point[1]*100}%`}}><MapPin size={18}/></span>}
    </button><figcaption><span>{photo.source==='public_case'?'公开原始影像':photo.source==='inspection'?'巡检证据':'补拍照片'} · {photo.captureDate??'日期未知'}</span>{!readOnly&&<button type="button" aria-label={`移除第${index+1}张问题照片`} onClick={()=>onChange?.(photos.filter(p=>p.id!==photo.id))}><Trash2 size={14}/></button>}</figcaption>
    {!readOnly&&photo.source==='upload'&&<label>照片日期<input type="date" value={photo.captureDate??''} max={localToday()} onChange={e=>onChange?.(photos.map(p=>p.id===photo.id?{...p,captureDate:e.target.value||null}:p))}/></label>}
  </figure>)}</div>;
}

export default function IssuePanel({model,onChange,onLocate,initialRoomId}:{model:HouseModel;onChange:(next:HouseModel)=>void;onLocate:(roomId:string)=>void;initialRoomId?:string}) {
  const summary=useMemo(()=>issueSummary(model,localToday()),[model]);
  const [selected,setSelected]=useState(summary.issues[0]?.id??'');
  const issue=summary.issues.find(i=>i.id===selected);
  const [creating,setCreating]=useState(false),[filter,setFilter]=useState('active'),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const [title,setTitle]=useState(''),[roomId,setRoomId]=useState(initialRoomId??model.rooms[0].id),[workType,setWorkType]=useState<WorkType>('wall');
  const [location,setLocation]=useState(''),[description,setDescription]=useState(''),[assignee,setAssignee]=useState(''),[dueDate,setDueDate]=useState(localToday());
  const [actor,setActor]=useState(''),[note,setNote]=useState(''),[confirmed,setConfirmed]=useState(false),[photos,setPhotos]=useState<IssuePhoto[]>([]),[busy,setBusy]=useState(false);
  const [evidenceId,setEvidenceId]=useState('');const file=useRef<HTMLInputElement>(null);const uploading=useRef(false);
  const [publicPhotoId,setPublicPhotoId]=useState('');
  const activeRoom=model.rooms.find(r=>r.id===(creating?roomId:issue?.roomId));
  const evidence=activeRoom?.evidence??[];
  const publicPhotos=casePhotos(model).filter(p=>p.roomId===activeRoom?.id);
  const rows=summary.issues.filter(i=>filter==='all'||filter==='active'&&i.status!=='closed'||filter==='review'&&i.status==='review'||filter==='overdue'&&i.status!=='closed'&&i.dueDate<localToday());
  const persist=(tracker:ReturnType<typeof createIssue>)=>onChange({...model,meta:{...model.meta,issueTracker:tracker}});
  const resetAction=()=>{setPhotos([]);setNote('');setActor('');setConfirmed(false);setEvidenceId('');setPublicPhotoId('');setError('');};
  async function addPhotos(files:File[]) {
    if(uploading.current)return;uploading.current=true;setBusy(true);setError('');
    try{if(photos.length+files.length>6||files.reduce((sum,f)=>sum+f.size,0)>30*1024*1024)throw new Error('一次最多六张，原始文件合计不超过30 MB。');const next:IssuePhoto[]=[];for(const f of files)next.push(await prepareIssuePhoto(f));setPhotos(validateIssuePhotos([...photos,...next]));}
    catch(e){setError(e instanceof Error?e.message:'照片处理失败。');}finally{uploading.current=false;setBusy(false);if(file.current)file.current.value='';}
  }
  function useEvidence() {
    const record=evidence.find(e=>e.id===evidenceId);if(!record)return;
    try{const next=(record.photos??[{id:record.id,image:record.image,viewpoint:'巡检照片'}]).map(p=>({id:crypto.randomUUID(),image:p.image,caption:p.viewpoint,source:'inspection' as const,captureDate:record.date}));setPhotos(validateIssuePhotos([...photos,...next]));setEvidenceId('');setError('');}catch(e){setError(e instanceof Error?e.message:'照片无效。');}
  }
  function saveNew(event:React.FormEvent) {
    event.preventDefault();setError('');
    try{const c=context();const tracker=createIssue(model,{roomId,title,workType,location,description,assignee,dueDate,photos},{...c,actor});persist(tracker);setSelected(c.id);setCreating(false);setFilter('all');setTitle('');setDescription('');setLocation('');setAssignee('');resetAction();setNotice('问题已记录，接下来开始处理并提交整改照片。');}
    catch(e){setError(e instanceof Error?e.message:'保存失败。');}
  }
  function act(action:Exclude<IssueAction,'create'|'update'>) {
    if(!issue)return;setError('');
    try{const c=context();persist(transitionIssue(model,issue.id,action,{actor,note:action==='begin'&&!note.trim()?'开始处理':note,photos,confirmed},c));if(action==='close')setFilter('all');resetAction();setNotice(action==='close'?'已保存人工复核结果；施工工序状态仍以巡检为准。':action==='return'?'已退回，保留整改证据并继续处理。':'处理记录已保存。');}
    catch(e){setError(e instanceof Error?e.message:'处理失败。');}
  }
  const renderCapture=()=> <div className="issue-capture">
    <input ref={file} type="file" accept="image/png,image/jpeg,image/webp" multiple hidden onChange={e=>void addPhotos(Array.from(e.target.files??[]))}/>
    <button type="button" className="tools-button" disabled={busy} onClick={()=>file.current?.click()}><Camera size={16}/>{busy?'正在处理照片…':'拍照或上传证据'}</button>
    {publicPhotos.length>0&&<div className="issue-evidence-picker"><label>引用公开案例影像<select value={publicPhotoId} onChange={e=>setPublicPhotoId(e.target.value)}><option value="">选择同房间的原始影像</option>{publicPhotos.map(p=><option key={p.id} value={p.id}>{p.caption}</option>)}</select></label><button type="button" className="tools-button" disabled={!publicPhotoId||busy} onClick={()=>{try{const p=publicPhotos.find(p=>p.id===publicPhotoId);if(p){setPhotos(validateIssuePhotos([...photos,{...p,id:crypto.randomUUID()}]));setPublicPhotoId('');setError('');}}catch(e){setError(e instanceof Error?e.message:'影像引用失败。');}}}>加入公开影像</button></div>}
    {evidence.length>0&&<div className="issue-evidence-picker"><label>引用已有巡检<select value={evidenceId} onChange={e=>setEvidenceId(e.target.value)}><option value="">选择一条巡检</option>{evidence.map(e=><option key={e.id} value={e.id}>{e.date} · {WORK_TYPES.find(w=>w.id===e.workType)?.label}</option>)}</select></label><button type="button" className="tools-button" disabled={!evidenceId||busy} onClick={useEvidence}>加入照片</button></div>}
    {!!photos.length&&<><p className="tools-muted">点击照片标记问题位置；照片日期可单独核对。</p><IssuePhotos photos={photos} readOnly={busy} onChange={setPhotos}/></>}
  </div>;
  return <section className="tools-section" aria-label="整改中心">
    <div className="tools-section-heading"><div><h2>把现场问题，处理到位。</h2><p>发现、处理、补拍、复核，每一步留下依据。</p></div><button className="tools-button primary" disabled={busy} onClick={()=>{setCreating(true);resetAction();setSelected('');}}><Plus size={16}/>新建问题</button></div>
    <div className="issue-summary" aria-label="问题概况"><span><strong>{summary.open+summary.inProgress}</strong>待处理／处理中</span><span><strong>{summary.review}</strong>待复核</span><span><strong>{summary.overdue}</strong>逾期未关闭</span><span><strong>{summary.closed}</strong>已关闭</span></div>
    <div className="issue-layout"><aside className="issue-list"><label>查看任务<select value={filter} onChange={e=>setFilter(e.target.value)}><option value="active">未关闭</option><option value="review">待复核</option><option value="overdue">逾期未关闭</option><option value="all">全部问题</option></select></label>{rows.map(item=><button key={item.id} disabled={busy} className={`issue-row ${item.id===selected&&!creating?'selected':''}`} onClick={()=>{setSelected(item.id);setCreating(false);resetAction();setNotice('');}}><span className="issue-row-state">{ISSUE_STATES[item.status]}{item.mode==='demonstration'?' · 演练':''}</span><strong>{item.title}</strong><span>{model.rooms.find(r=>r.id===item.roomId)?.name??'历史房间'} · {item.assignee}</span><small>期限 {item.dueDate}</small></button>)}{!rows.length&&<p className="tools-empty">{summary.total?'暂无符合筛选条件的问题，可切换全部查看历史。':'这里还没有问题，可从巡检证据创建第一项。'}</p>}</aside>
    <div className="issue-detail">{creating?<form onSubmit={saveNew}>
      <h3>记录一个问题</h3><div className="tools-field-grid"><label>问题名称<input required maxLength={160} value={title} onChange={e=>setTitle(e.target.value)} placeholder="例如：窗侧墙面需要补充核对"/></label><label>关联房间<select disabled={busy} value={roomId} onChange={e=>{setRoomId(e.target.value);setPhotos([]);setEvidenceId('');setPublicPhotoId('');}}>{model.rooms.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></label><label>工序<select value={workType} onChange={e=>setWorkType(e.target.value as WorkType)}>{WORK_TYPES.map(w=><option key={w.id} value={w.id}>{w.label}</option>)}</select></label><label>具体位置<input maxLength={500} value={location} onChange={e=>setLocation(e.target.value)} placeholder="窗侧、门口或墙面位置"/></label><label>责任人<input required maxLength={160} value={assignee} onChange={e=>setAssignee(e.target.value)} placeholder="填写负责人姓名或岗位"/></label><label>处理期限<input required type="date" min={localToday()} value={dueDate} onChange={e=>setDueDate(e.target.value)}/></label></div><label>问题说明<textarea maxLength={3000} value={description} onChange={e=>setDescription(e.target.value)}/></label><label>记录人<input required maxLength={160} value={actor} onChange={e=>setActor(e.target.value)}/></label>{renderCapture()}<div className="tools-actions"><button className="tools-button primary" disabled={busy} type="submit">保存问题<ArrowRight size={16}/></button><button className="tools-button" type="button" disabled={busy} onClick={()=>setCreating(false)}>取消</button></div>
    </form>:issue?<><div className="issue-detail-header"><span className="tools-tag">{ISSUE_STATES[issue.status]}{issue.mode==='demonstration'?' · 模拟任务':''}</span><h3>{issue.title}</h3><p>{activeRoom?.name??'关联房间已移除'} · {issue.location||'未填写具体位置'} · {WORK_TYPES.find(w=>w.id===issue.workType)?.label}</p><p>负责人 {issue.assignee} · 期限 {issue.dueDate}</p>{issue.description&&<p>{issue.description}</p>}<button className="tools-text-button" disabled={!activeRoom} onClick={()=>onLocate(issue.roomId)}><MapPin size={15}/>在模型中定位</button></div>
      <ol className="issue-history">{issue.events.map(event=><li key={event.id}><div><span>{event.date}</span><strong>{ISSUE_STATES[event.status]}</strong><span>{event.actor}</span></div>{event.note&&<p>{event.note}</p>}<IssuePhotos photos={event.photos} readOnly/>{event.action==='close'&&<span className="issue-confirmed"><CheckCircle2 size={14}/>已保存人工复核</span>}</li>)}</ol>
      <div className="issue-action-form"><h4>{issue.status==='review'?'复核这次处理':issue.status==='closed'?'补充记录或重新开启':'提交处理进展'}</h4><label>{issue.status==='review'?'复核人':'记录人'}<input maxLength={160} value={actor} onChange={e=>setActor(e.target.value)} placeholder="填写实际操作人；演练可填写示例岗位"/></label><label>处理／复核说明<textarea maxLength={3000} value={note} onChange={e=>setNote(e.target.value)} placeholder="说明本次完成了什么，或仍有哪些问题"/></label>{renderCapture()}{issue.status==='review'&&<label className="issue-check"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/>我已核对提交的证据，确认这项问题已解决</label>}<div className="tools-actions">
        {issue.status==='open'&&<button className="tools-button primary" disabled={busy} onClick={()=>act('begin')}>开始处理<ArrowRight size={16}/></button>}
        {issue.status==='in_progress'&&<button className="tools-button primary" disabled={busy} onClick={()=>act('submit')}>提交整改照片<ArrowRight size={16}/></button>}
        {issue.status==='review'&&<><button className="tools-button primary" disabled={busy||!confirmed} onClick={()=>act('close')}><Check size={16}/>确认关闭</button><button className="tools-button" disabled={busy} onClick={()=>act('return')}>退回继续处理</button></>}
        {issue.status==='closed'&&<button className="tools-button" disabled={busy} onClick={()=>act('reopen')}>重新开启问题</button>}
        <button className="tools-button" disabled={busy||!note.trim()} onClick={()=>act('comment')}>保存补充记录</button>
      </div><p className="tools-muted">整改任务与工序进度分别保存；关闭问题不代表质量验收通过。</p></div>
    </>:<div className="tools-empty"><CheckCircle2 size={28}/><h3>每个问题都有一个去向。</h3><p>选择左侧任务，或新建问题开始处理。手机可直接拍照补充证据。</p></div>}{error&&<p className="tools-error" role="alert">{error}</p>}{notice&&<p className="tools-notice" role="status">{notice}</p>}</div></div>
  </section>;
}
