"""AI-assisted import contracts. All provider calls are mocked, no keys loaded."""
import copy
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
import urllib.error
from unittest.mock import patch

from fastapi.testclient import TestClient
from PIL import Image, ImageDraw

from backend import ai_plan
from backend.algorithm import ModelServiceError, PlanError
from backend.app import app
from backend.project_library import validate_model


def image_bytes():
    image = Image.new("RGB", (1000, 800), "white")
    ImageDraw.Draw(image).rectangle((10, 10, 990, 790), outline="black", width=10)
    buffer = io.BytesIO()
    image.save(buffer, "PNG")
    return buffer.getvalue()


def geometry():
    return {"coordinateSystem": "metres", "depth": 8,
            "walls": [{"id": "north", "start": [0, 0], "end": [10, 0], "thickness": .2},
                      {"id": "east", "start": [10, 0], "end": [10, 8], "thickness": .2},
                      {"id": "south", "start": [10, 8], "end": [0, 8], "thickness": .2},
                      {"id": "west", "start": [0, 8], "end": [0, 0], "thickness": .2},
                      {"id": "partition", "start": [5, 0], "end": [5, 8], "thickness": .15}],
            "rooms": [{"id": "new-living", "name": "客餐厅", "use": "living", "polygon": [[0, 0], [5, 0], [5, 8], [0, 8]]},
                      {"id": "new-bedroom", "name": "主卧", "use": "bedroom", "polygon": [[5, 0], [10, 0], [10, 8], [5, 8]]}],
            "openings": [{"id": "bedroom-door", "wallId": "partition", "type": "door", "offset": 5.5, "width": .9, "height": 2.1, "sill": 0},
                         {"id": "living-window", "wallId": "north", "type": "window", "offset": 1, "width": 2, "height": 1.2, "sill": .85}]}


def baseline():
    raw = geometry()
    raw["walls"] = raw["walls"][:4]
    raw["rooms"] = [{"id": "old-room", "name": "区域 01", "use": "empty", "polygon": [[0, 0], [10, 0], [10, 8], [0, 8]]}]
    raw["openings"] = []
    model, _ = ai_plan._candidate(raw, None, Image.open(io.BytesIO(image_bytes())), 10, 2.8)
    model["id"], model["name"], model["warnings"] = "original-model", "原本户型", ["原识别需要核对"]
    model["meta"] = {"engine": "classic", "algorithm": "orthogonal-morphology-v1"}
    return model


def response(raw_geometry=None):
    return {"summary": "根据原图房间标签修复客餐厅与主卧分隔，门窗保持原位置。", "issues": [], "roomSuggestions": [],
            "layoutSuggestions": [{"roomId": "new-bedroom", "placement": "床头沿实墙，侧面预留通路。", "items": ["bed_double", "wardrobe"]}],
            "geometry": geometry() if raw_geometry is None else raw_geometry}


def grid_geometry():
    return {"coordinateSystem": "metres", "depth": 8, "grid": {
        "x": [0, 2, 6, 10], "y": [0, 3, 8], "rooms": [
            {"id": "bed", "name": "卧室", "use": "bedroom", "cells": [[1, 0]], "wallGroup": "bed"},
            {"id": "bath", "name": "卫生间", "use": "bathroom", "cells": [[2, 0]], "wallGroup": "bath"},
            {"id": "balcony", "name": "阳台", "use": "empty", "cells": [[0, 1]], "wallGroup": "balcony"},
            {"id": "living", "name": "客厅", "use": "living", "cells": [[1, 1]], "wallGroup": "open"},
            {"id": "kitchen", "name": "厨房", "use": "kitchen", "cells": [[2, 1]], "wallGroup": "open"}],
        "openings": [{"id": "bed-door", "type": "door", "center": [4, 3], "orientation": "horizontal", "width": .9, "height": 2.1, "sill": 0}]}}


def provider_response(value):
    return io.BytesIO(json.dumps({"choices": [{"message": {"content": json.dumps(value, ensure_ascii=False)}}]}, ensure_ascii=False).encode())


class AIPlanTests(unittest.TestCase):
    def setUp(self):
        self.environment = patch.dict(os.environ, {"QWEN_API_KEY": "mock-test-key", "QWEN_MODEL": "qwen3.8-flash",
                                                  "QWEN_BASE_URL": "https://maas.qianwenaiapi.com/compatible-mode/v1"}, clear=True)
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def run_ai(self, value=None, mode="rebuild", model=None):
        with patch.object(ai_plan, "_provider", return_value=(response() if value is None else value, "qwen/mock")) as provider:
            result = ai_plan.assist_floor_plan(image_bytes(), baseline() if model is None else model, 10, 2.8, mode)
        return result, provider

    def test_ai_rebuild_replaces_reference_with_new_rooms_walls_and_openings(self):
        original = baseline()
        before = copy.deepcopy(original)
        result, provider = self.run_ai(model=original)
        provider.assert_called_once()
        self.assertEqual(original, before)
        self.assertEqual(result["id"], original["id"])
        self.assertEqual(result["source"], "opencv")
        self.assertEqual([room["id"] for room in result["rooms"]], ["new-living", "new-bedroom"])
        self.assertEqual(len(result["walls"]), 5)
        self.assertEqual(len(result["openings"]), 2)
        self.assertEqual(result["width"], 10)
        self.assertEqual(result["height"], 2.8)
        review = result["meta"]["aiReview"]
        self.assertEqual(review["status"], "applied")
        self.assertTrue(review["geometryRebuilt"])
        self.assertEqual(review["originalCounts"], {"rooms": 1, "walls": 4, "doors": 0, "windows": 0})
        self.assertEqual(review["model"], "mock")
        self.assertEqual(review["repairCount"], 0)
        self.assertEqual(review["changes"][0]["after"], {"rooms": 2, "walls": 5, "openings": 2})
        self.assertEqual(result["meta"]["recognition"]["doors"], 1)
        self.assertEqual(result["meta"]["engine"], "ai")
        self.assertEqual(review["roomSuggestions"][1]["use"], "bedroom")
        self.assertEqual(review["layoutSuggestions"][0]["items"], ["bed_double", "wardrobe"])
        for room in result["rooms"]:
            self.assertAlmostEqual(room["area"], 40)
            self.assertEqual(room["progress"], 0)
            self.assertEqual(room["evidence"], [])
            self.assertTrue(all(task["stage"] == "unknown" for task in room["tasks"].values()))
        validate_model(result)
        json.dumps(result, allow_nan=False)

    def test_rebuild_sends_original_and_semantic_reference_without_erroneous_coordinates(self):
        with patch("urllib.request.urlopen", return_value=provider_response(response())) as urlopen:
            result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild", "natural")
        request = urlopen.call_args.args[0]
        self.assertEqual(request.full_url, "https://maas.qianwenaiapi.com/compatible-mode/v1/chat/completions")
        self.assertEqual(urlopen.call_args.kwargs["timeout"], 90)
        payload = json.loads(request.data)
        self.assertEqual(payload["model"], "qwen3.8-flash")
        self.assertTrue(payload["enable_thinking"])
        self.assertEqual(payload["thinking_budget"], 4096)
        self.assertFalse(payload["preserve_thinking"])
        self.assertNotIn("response_format", payload)
        content = payload["messages"][1]["content"]
        self.assertEqual(sum(item["type"] == "image_url" for item in content), 1)
        self.assertTrue(all(item["image_url"]["url"].startswith("data:image/jpeg;base64,") for item in content if item["type"] == "image_url"))
        details = json.loads(content[0]["text"])
        self.assertEqual(details["designStyle"], "natural")
        self.assertEqual(details["reference"]["rooms"][0]["id"], "old-room")
        self.assertNotIn("polygon", details["reference"]["rooms"][0])
        self.assertNotIn("walls", details["reference"])
        self.assertNotIn("depthReference", details)
        self.assertEqual(details["preferredGeometry"], "grid.labels")
        self.assertEqual(result["meta"]["aiReview"]["source"], "qwen/qwen3.8-flash")

    def test_assist_keeps_numbered_reference_diagram_and_coordinates_for_existing_room_review(self):
        value = {"summary": "核对已有区域", "roomSuggestions": [], "issues": [], "layoutSuggestions": []}
        with patch("urllib.request.urlopen", return_value=provider_response(value)) as urlopen:
            result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "assist")
        payload = json.loads(urlopen.call_args.args[0].data)
        content = payload["messages"][1]["content"]
        self.assertEqual(sum(item["type"] == "image_url" for item in content), 2)
        details = json.loads(content[0]["text"])
        self.assertIn("polygon", details["reference"]["rooms"][0])
        self.assertEqual(result["meta"]["aiReview"]["status"], "reviewed")
        self.assertFalse(payload["enable_thinking"])
        self.assertEqual(payload["response_format"], {"type": "json_object"})

    def test_rebuild_thinking_can_be_disabled_without_changing_other_ai_functions(self):
        with patch.dict(os.environ, {"QWEN_PLAN_THINKING": "false"}), patch("urllib.request.urlopen", return_value=provider_response(response())) as urlopen:
            result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
        payload = json.loads(urlopen.call_args.args[0].data)
        self.assertFalse(payload["enable_thinking"])
        self.assertEqual(payload["response_format"], {"type": "json_object"})
        self.assertNotIn("thinking_budget", payload)
        self.assertEqual(urlopen.call_args.kwargs["timeout"], 70)
        self.assertTrue(result["meta"]["aiReview"]["geometryRebuilt"])

    def test_thinking_final_answer_with_one_fenced_json_is_parsed_and_still_geometry_checked(self):
        content = '已完成空间推理，最终结构如下。\n```json\n' + json.dumps(response(), ensure_ascii=False) + '\n```'
        envelope = io.BytesIO(json.dumps({"choices": [{"message": {"content": content}}]}).encode())
        with patch("urllib.request.urlopen", return_value=envelope):
            result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
        self.assertTrue(result["meta"]["aiReview"]["geometryRebuilt"])

    def test_ambiguous_fenced_json_and_truncated_answers_are_rejected(self):
        for content in ('```json\n{}\n```\n```json\n{}\n```', '```json\n{"geometry":'):
            with self.subTest(content=content), patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps({"choices": [{"message": {"content": content}}]}).encode())):
                result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
            self.assertEqual(result["meta"]["aiReview"]["status"], "failed")

    def test_clear_plan_aspect_rejects_stretched_geometry_but_not_dense_photos(self):
        image = Image.open(io.BytesIO(image_bytes()))
        self.assertAlmostEqual(ai_plan._structural_depth_hint(image, 10), 8, delta=.1)
        stretched = geometry()
        stretched["depth"] = 12
        with self.assertRaisesRegex(ai_plan.CandidateError, "宽深比例"):
            ai_plan._candidate(stretched, baseline(), image, 10, 2.8)
        self.assertIsNone(ai_plan._structural_depth_hint(Image.new('RGB', (1000, 800), '#555555'), 10))

    def test_structural_aspect_ignores_separate_annotation_blob(self):
        image = Image.new('RGB', (1000, 800), 'white')
        draw = ImageDraw.Draw(image)
        draw.rectangle((150, 150, 850, 650), outline='black', width=10)
        draw.rectangle((10, 10, 30, 50), fill='black')
        self.assertAlmostEqual(ai_plan._structural_depth_hint(image, 10), 10 * 501 / 701, delta=.01)

    def test_repair_once_only_for_candidate_geometry_validation_error(self):
        invalid = response()
        invalid["geometry"]["openings"][0]["offset"] = 8
        with patch.object(ai_plan, "_provider", side_effect=[(invalid, "qwen/mock"), (response(), "qwen/mock")]) as provider:
            result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
        self.assertEqual(provider.call_count, 2)
        repair = provider.call_args.kwargs["repair"]
        self.assertIn("门窗", repair["validationError"])
        self.assertEqual(repair["candidate"], invalid["geometry"])
        self.assertEqual(result["meta"]["aiReview"]["repairCount"], 1)
        self.assertTrue(result["meta"]["aiReview"]["geometryRebuilt"])

    def test_repeated_invalid_geometry_preserves_complete_reference_and_explains_failure(self):
        invalid = response()
        invalid["geometry"]["rooms"][0]["polygon"] = [[0, 0], [5, 8], [5, 0], [0, 8]]
        original = baseline()
        result, provider = self.run_ai(invalid, model=original)
        self.assertEqual(provider.call_count, 2)
        for key in ("rooms", "walls", "openings", "id", "width", "height", "depth", "name"):
            self.assertEqual(result[key], original[key])
        self.assertEqual(result["meta"]["aiReview"]["status"], "failed")
        self.assertFalse(result["meta"]["aiReview"]["geometryRebuilt"])
        self.assertIn("未采用", result["warnings"][0])

    def test_no_key_preserves_reference_without_network_and_marks_unavailable(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(ai_plan, "_provider") as provider:
            result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
        provider.assert_not_called()
        self.assertEqual(result["meta"]["aiReview"]["status"], "unavailable")
        self.assertEqual(len(result["rooms"]), 1)

    def test_local_mode_never_uploads_or_mutates_model(self):
        original = baseline()
        with patch.object(ai_plan, "_provider") as provider:
            result = ai_plan.assist_floor_plan(image_bytes(), original, 10, 2.8, "local")
        self.assertIs(result, original)
        self.assertNotIn("aiReview", result["meta"])
        provider.assert_not_called()

    def test_assist_applies_image_grounded_names_and_leaves_geometry_fixed(self):
        value = {"summary": "原图区域标签为客厅。", "roomSuggestions": [{"roomId": "old-room", "name": "客厅", "use": "living", "confidence": .92, "evidence": "原图可见客厅文字与沙发符号。"}], "issues": [], "layoutSuggestions": []}
        result, provider = self.run_ai(value, mode="assist")
        provider.assert_called_once()
        self.assertEqual(result["rooms"][0]["name"], "客厅")
        self.assertEqual(result["rooms"][0]["polygon"], baseline()["rooms"][0]["polygon"])
        self.assertEqual(result["walls"], baseline()["walls"])
        self.assertEqual(result["openings"], [])
        self.assertFalse(result["meta"]["aiReview"]["geometryRebuilt"])

    def test_uncertain_room_use_is_review_suggestion_not_forced_mutation(self):
        value = {"summary": "文字无法辨认。", "roomSuggestions": [{"roomId": "old-room", "name": "卧室", "use": "bedroom", "confidence": .5, "evidence": "仅轮廓，无法区分用途。"}], "issues": [], "layoutSuggestions": []}
        result, _ = self.run_ai(value, mode="assist")
        self.assertEqual(result["rooms"][0]["name"], "区域 01")
        self.assertEqual(result["meta"]["aiReview"]["status"], "reviewed")
        self.assertFalse(result["meta"]["aiReview"]["roomSuggestions"][0]["applied"])

    def test_provider_failures_do_not_retry_or_hide_local_result(self):
        for code in (401, 403, 429, 500):
            with self.subTest(code=code), patch("urllib.request.urlopen", side_effect=urllib.error.HTTPError("https://provider", code, "failure", {}, None)) as network:
                result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
            self.assertEqual(network.call_count, 1)
            self.assertEqual(result["meta"]["aiReview"]["status"], "failed")
            self.assertEqual(len(result["rooms"]), 1)
        with patch.object(ai_plan, "_provider", side_effect=ModelServiceError("连接超时")) as provider:
            result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
        provider.assert_called_once()
        self.assertIn("连接超时", result["warnings"][0])

    def test_invalid_supplemental_suggestions_never_allow_untrusted_ids_or_items(self):
        for field in ({"roomId": "ghost", "placement": "沿墙", "items": []},
                      {"roomId": "new-bedroom", "placement": "沿墙", "items": ["wall_demolition"]},
                      {"roomId": [], "placement": "沿墙", "items": []}):
            value = response()
            value["layoutSuggestions"] = [field]
            with self.subTest(field=field):
                result, provider = self.run_ai(value)
                self.assertEqual(result["meta"]["aiReview"]["status"], "failed")
                self.assertEqual(provider.call_count, 1)

    def test_baseline_less_rebuild_is_validated_and_does_not_invent_success_if_failed(self):
        with patch.object(ai_plan, "_provider", return_value=(response(), "qwen/mock")):
            result = ai_plan.assist_floor_plan(image_bytes(), None, 10, 2.8, "rebuild", baseline_error="墙未闭合")
        self.assertEqual(len(result["rooms"]), 2)
        self.assertIsNone(result["meta"]["aiReview"]["originalCounts"])
        self.assertIn("墙未闭合", result["meta"]["aiReview"]["issues"][0]["message"])
        with patch.object(ai_plan, "_provider", side_effect=ModelServiceError("网络失败")):
            with self.assertRaisesRegex(PlanError, "墙未闭合.*AI 重建也未完成"):
                ai_plan.assist_floor_plan(image_bytes(), None, 10, 2.8, "rebuild", baseline_error="墙未闭合")
        with patch.dict(os.environ, {}, clear=True), self.assertRaisesRegex(PlanError, "未配置视觉密钥"):
            ai_plan.assist_floor_plan(image_bytes(), None, 10, 2.8, "rebuild", baseline_error="墙未闭合")

    def test_rejects_structural_hallucinations_beyond_basic_library_validator(self):
        mutations = []
        raw = geometry(); raw["rooms"][1]["polygon"] = copy.deepcopy(raw["rooms"][0]["polygon"]); mutations.append(("overlap", raw))
        raw = geometry(); raw["rooms"][0]["polygon"] = [[.8, .8], [4.2, .8], [4.2, 7.2], [.8, 7.2]]; mutations.append(("floating", raw))
        raw = geometry(); raw["rooms"] = [{"id": "full", "name": "客厅", "use": "living", "polygon": [[0, 0], [10, 0], [10, 8], [0, 8]]}]; mutations.append(("across_partition", raw))
        raw = geometry(); raw["walls"].append({"id": "island", "start": [1, 1], "end": [2, 1], "thickness": .1}); mutations.append(("isolated", raw))
        raw = geometry(); raw["walls"].append({**raw["walls"][0], "id": "duplicate"}); mutations.append(("duplicate_wall", raw))
        raw = geometry(); raw["openings"].append({**raw["openings"][0], "id": "overlap-opening"}); mutations.append(("opening_overlap", raw))
        raw = geometry(); raw["openings"][0]["wallId"] = "nonexistent"; mutations.append(("missing_wall", raw))
        raw = geometry(); raw["openings"][0]["sill"] = .1; mutations.append(("door_sill", raw))
        raw = geometry(); raw["openings"][1]["sill"] = 2; mutations.append(("window_above_wall", raw))
        raw = geometry(); raw["rooms"][1]["id"] = raw["rooms"][0]["id"]; mutations.append(("duplicate_room", raw))
        raw = geometry(); raw["depth"] = 80; mutations.append(("depth_ratio", raw))
        raw = geometry(); raw["rooms"][0]["polygon"][0] = [-.1, 0]; mutations.append(("outside_bounds", raw))
        raw = geometry(); raw["walls"][0]["thickness"] = float("nan"); mutations.append(("nonfinite", raw))
        raw = geometry(); raw["walls"][0]["thickness"] = 10 ** 350; mutations.append(("enormous_number", raw))
        raw = geometry(); raw["openings"][0]["type"] = []; mutations.append(("unhashable_enum", raw))
        image = Image.open(io.BytesIO(image_bytes()))
        for name, raw in mutations:
            with self.subTest(name=name), self.assertRaises(ai_plan.CandidateError):
                ai_plan._candidate(raw, baseline(), image, 10, 2.8)

    def test_concave_disjoint_rooms_pass_despite_overlapping_bounding_boxes(self):
        raw = geometry()
        raw["walls"] = raw["walls"][:4] + [{"id": "bend-v", "start": [5, 0], "end": [5, 4], "thickness": .15},
                                         {"id": "bend-h", "start": [5, 4], "end": [10, 4], "thickness": .15}]
        raw["rooms"][0]["polygon"] = [[0, 0], [5, 0], [5, 4], [10, 4], [10, 8], [0, 8]]
        raw["rooms"][1]["polygon"] = [[5, 0], [10, 0], [10, 4], [5, 4]]
        raw["openings"] = []
        model, _ = ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)
        self.assertEqual([room["area"] for room in model["rooms"]], [60, 20])

    def test_only_redundant_closure_and_forward_collinear_points_are_normalised(self):
        raw = geometry()
        raw["rooms"][0]["polygon"] = [[0, 0], [2, 0], [5, 0], [5, 0], [5, 8], [0, 8], [0, 0]]
        raw["rooms"][1]["polygon"] = list(reversed(raw["rooms"][1]["polygon"]))
        model, _ = ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)
        self.assertEqual(model["rooms"][0]["polygon"], [[0, 0], [5, 0], [5, 8], [0, 8]])
        self.assertEqual(model["rooms"][0]["area"], 40)
        raw["rooms"][0]["polygon"] = [[0, 0], [5, 0], [4, 0], [5, 8], [0, 8]]
        with self.assertRaisesRegex(ai_plan.CandidateError, "自交"):
            ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)

    def test_declared_width_must_match_actual_wall_span(self):
        raw = geometry()
        raw["openings"] = []
        for wall in raw["walls"]:
            wall["start"][0] *= .5
            wall["end"][0] *= .5
        for room in raw["rooms"]:
            for point in room["polygon"]:
                point[0] *= .5
        with self.assertRaisesRegex(ai_plan.CandidateError, "外轮廓宽度未覆盖"):
            ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)

    def test_original_pixel_calibration_is_provenance_not_rebuilt_geometry_scale(self):
        original = baseline()
        original["meta"].update(metresPerPixel=.025, boundsPixels=[10, 20, 410, 340], processedPixels=[500, 400], scaleBasis="outer_wall_centrelines")
        result, _ = self.run_ai(model=original)
        self.assertNotIn("metresPerPixel", result["meta"])
        self.assertNotIn("boundsPixels", result["meta"])
        self.assertEqual(result["meta"]["baselineRecognition"]["metresPerPixel"], .025)
        self.assertEqual(result["meta"]["scaleBasis"], "user_outer_wall_width_ai_depth")

    def test_debug_trace_is_explicit_local_only_without_request_image_or_key(self):
        with tempfile.TemporaryDirectory() as directory:
            trace_path = Path(directory) / "trace.json"
            with patch.dict(os.environ, {"AI_PLAN_DEBUG_TRACE_PATH": str(trace_path)}):
                result, _ = self.run_ai()
            self.assertEqual(result["meta"]["aiReview"]["status"], "applied")
            text = trace_path.read_text(encoding="utf-8")
            trace = json.loads(text)
            self.assertEqual(len(trace["attempts"]), 1)
            self.assertEqual(trace["attempts"][0]["geometry"], geometry())
            self.assertNotIn("image_url", text)
            self.assertNotIn("mock-test-key", text)
            self.assertNotIn("messages", text)
            trace_path.unlink()
            with patch.dict(os.environ, {"AI_PLAN_DEBUG_TRACE_PATH": ""}):
                self.run_ai()
            self.assertFalse(trace_path.exists())

    def test_rectangle_union_builds_simple_concave_room_without_choosing_vertex_order(self):
        raw = geometry()
        raw["walls"] = raw["walls"][:4] + [{"id": "bend-v", "start": [5, 0], "end": [5, 4], "thickness": .15},
                                         {"id": "bend-h", "start": [5, 4], "end": [10, 4], "thickness": .15}]
        raw["rooms"][0].pop("polygon")
        raw["rooms"][0]["rectangles"] = [[0, 0, 5, 4], [0, 4, 10, 8]]
        raw["rooms"][1]["polygon"] = [[5, 0], [10, 0], [10, 4], [5, 4]]
        raw["openings"] = []
        model, _ = ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)
        self.assertEqual(model["rooms"][0]["area"], 60)
        self.assertEqual(len(model["rooms"][0]["polygon"]), 6)

    def test_rectangle_union_rejects_holes_disconnected_components_and_corner_touch(self):
        cases = [[[0, 0, 2, 2], [4, 4, 6, 6]],
                 [[0, 0, 2, 2], [2, 2, 4, 4]],
                 [[0, 0, 2, 8], [2, 0, 8, 2], [6, 2, 8, 8], [2, 6, 6, 8]]]
        for rectangles in cases:
            with self.subTest(rectangles=rectangles), self.assertRaises(ai_plan.CandidateError):
                ai_plan._rectangle_ring(rectangles, 10, 8)

    def test_same_group_open_zones_share_virtual_boundaries_without_invented_walls(self):
        raw = geometry()
        raw["walls"] = raw["walls"][:4]
        raw["openings"] = []
        for room in raw["rooms"]:
            room.update(boundaryType="open_zone", wallGroup="common-area")
        model, _ = ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)
        self.assertEqual(len(model["walls"]), 4)
        self.assertEqual(len(model["rooms"]), 2)
        self.assertEqual(model["rooms"][0]["boundaryType"], "open_zone")
        self.assertEqual(model["rooms"][1]["wallGroup"], "common-area")
        raw["rooms"][1]["wallGroup"] = "other-group"
        with self.assertRaisesRegex(ai_plan.CandidateError, "悬空边界"):
            ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)

    def test_open_zones_still_cannot_leave_exterior_gaps_cross_walls_or_overlap(self):
        raw = geometry()
        for room in raw["rooms"]:
            room.update(boundaryType="open_zone", wallGroup="common-area")
        raw["openings"] = []
        raw["rooms"][0]["polygon"][1][0] = 6
        raw["rooms"][0]["polygon"][2][0] = 6
        with self.assertRaises(ai_plan.CandidateError):
            ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)
        raw["walls"] = raw["walls"][:4]
        raw["rooms"][0]["polygon"] = [[.8, .8], [5, .8], [5, 7.2], [.8, 7.2]]
        with self.assertRaisesRegex(ai_plan.CandidateError, "悬空边界"):
            ai_plan._candidate(raw, baseline(), Image.open(io.BytesIO(image_bytes())), 10, 2.8)

    def test_grid_adapter_rebuilds_rooms_and_consistent_walls_from_one_scene_graph(self):
        value = response(grid_geometry())
        value["layoutSuggestions"] = [{"roomId": "bed", "placement": "床头靠外侧实体墙。", "items": ["bed_double", "wardrobe"]}]
        result, provider = self.run_ai(value)
        provider.assert_called_once()
        review = result["meta"]["aiReview"]
        self.assertTrue(review["geometryRebuilt"])
        self.assertEqual(len(result["rooms"]), 5)
        self.assertEqual(len(result["walls"]), 9)
        self.assertEqual(len(result["openings"]), 1)
        self.assertEqual([room["id"] for room in result["rooms"] if room.get("boundaryType") == "open_zone"], ["living", "kitchen"])
        # Source balcony starts at x=0; the inset main roof starts at x=2.
        balcony = next(room for room in result["rooms"] if room["id"] == "balcony")
        bed = next(room for room in result["rooms"] if room["id"] == "bed")
        self.assertEqual(min(point[0] for point in balcony["polygon"]), 0)
        self.assertEqual(min(point[0] for point in bed["polygon"]), 2)
        self.assertFalse(any(wall["start"][0] == wall["end"][0] == 6 and wall["end"][1] > 3 for wall in result["walls"]))
        validate_model(result)

    def test_invalid_grid_is_repairable_without_exposing_a_partial_model(self):
        value = response(grid_geometry())
        value["layoutSuggestions"] = []
        value["geometry"]["grid"]["rooms"][0]["cells"] = [[0, 0], [2, 1]]
        result, provider = self.run_ai(value)
        self.assertEqual(provider.call_count, 2)
        self.assertEqual(result["meta"]["aiReview"]["status"], "failed")
        self.assertEqual(len(result["rooms"]), 1)
        self.assertIn("场景网格无效", result["warnings"][0])

    def test_malformed_provider_json_rejected_without_retry(self):
        for raw in ({"choices": []}, {"choices": [{"message": {"content": "[1,2]"}}]}, {"choices": [{"message": {"content": '{"summary":NaN}'}}]}):
            with self.subTest(raw=raw), patch("urllib.request.urlopen", return_value=io.BytesIO(json.dumps(raw).encode())) as network:
                result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
            self.assertEqual(network.call_count, 1)
            self.assertEqual(result["meta"]["aiReview"]["status"], "failed")

    def test_invalid_provider_base_does_not_send_key_to_other_domains(self):
        with patch.dict(os.environ, {"QWEN_BASE_URL": "https://untrusted.example/v1"}), patch("urllib.request.urlopen") as network:
            result = ai_plan.assist_floor_plan(image_bytes(), baseline(), 10, 2.8, "rebuild")
        network.assert_not_called()
        self.assertEqual(result["meta"]["aiReview"]["status"], "failed")


class AIPlanApiTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def upload(self, data):
        return self.client.post("/api/parse-plan", files={"file": ("plan.png", image_bytes(), "image/png")}, data=data)

    def test_default_local_remains_backward_compatible_and_ai_flag_selects_assist(self):
        original = baseline()
        for data, expected in (({}, "local"), ({"ai_assist": "true"}, "assist"), ({"ai_assist": "true", "ai_mode": "local"}, "local"),
                               ({"ai_mode": "rebuild", "design_style": "natural"}, "rebuild")):
            with self.subTest(data=data), patch("backend.app.recognize_floor_plan", return_value=original) as local, patch("backend.app.assist_floor_plan", return_value=original) as assistant:
                result = self.upload(data)
            self.assertEqual(result.status_code, 200, result.text)
            local.assert_called_once_with(image_bytes(), 12., 2.8, "auto")
            if expected == "local":
                assistant.assert_not_called()
            else:
                self.assertEqual(assistant.call_args.args[4], expected)
                self.assertEqual(assistant.call_args.args[5], data.get("design_style", "warm"))

    def test_unknown_mode_style_and_invalid_dimensions_are_422_without_ai(self):
        for data in ({"ai_mode": "unbounded"}, {"design_style": "magic"}, {"ai_mode": "rebuild", "real_width": "nan"},
                     {"ai_mode": "rebuild", "height": "20"}, {"ai_mode": "rebuild", "engine": "unknown"}):
            with self.subTest(data=data), patch("backend.app.assist_floor_plan") as assistant:
                result = self.upload(data)
            self.assertEqual(result.status_code, 422, result.text)
            assistant.assert_not_called()

    def test_rebuild_can_rescue_failed_local_geometry_but_other_modes_preserve_422(self):
        for mode in ("local", "assist", "rebuild"):
            with self.subTest(mode=mode), patch("backend.app.recognize_floor_plan", side_effect=PlanError("墙体不封闭")), patch("backend.app.assist_floor_plan", return_value=baseline()) as assistant:
                result = self.upload({"ai_mode": mode})
            self.assertEqual(result.status_code, 200 if mode == "rebuild" else 422, result.text)
            if mode == "rebuild":
                self.assertIsNone(assistant.call_args.args[1])
                self.assertEqual(assistant.call_args.args[6], "墙体不封闭")
            else:
                assistant.assert_not_called()


if __name__ == "__main__":
    unittest.main()
