import test from 'node:test';
import assert from 'node:assert/strict';
import { viewer } from './helpers/viewer-module.mjs';
const { THREE, fitStageCamera } = viewer;

test('横屏、手机及狭长户型完整入镜，且模型保持画面中心与可读尺寸', () => {
  for (const [width,depth] of [[12,9],[12,17.2],[3,25],[25,3],[2,2]]) {
    for (const aspect of [712/395,320/550,2.8,.35]) {
      const bounds = new THREE.Box3(new THREE.Vector3(-width/2-.42,-.35,-depth/2-.42),new THREE.Vector3(width/2+.42,2.8,depth/2+.42));
      const target = new THREE.Vector3(0,.28,0);
      const camera = new THREE.PerspectiveCamera(36,aspect,.05,300);
      fitStageCamera(camera,bounds,target,aspect);
      camera.updateMatrixWorld();
      const projected = [];
      for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z]) projected.push(new THREE.Vector3(x,y,z).project(camera));
      const xs=projected.map(p=>p.x),ys=projected.map(p=>p.y);
      const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
      assert.ok(projected.every(p=>Math.abs(p.x)<.94&&Math.abs(p.y)<.94&&p.z>-1&&p.z<1),`裁切: ${width}×${depth}, aspect ${aspect}`);
      assert.ok(Math.abs((minX+maxX)/2)<.04&&Math.abs((minY+maxY)/2-.04)<.04,'画面中心偏离');
      const span=Math.max((maxX-minX)/2,(maxY-minY)/2);
      assert.ok(span>.76&&span<.87,`模型过小或过大: ${span}`);
    }
  }
});
