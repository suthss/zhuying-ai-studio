import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { ArrowLeft, Move, Rotate3D } from 'lucide-react';
import { buildHouse, disposeTree, roomCenter } from './viewer/buildHouse';
import { applyInteriorAngles, findInteriorStandingPoint } from './viewer/interior';
import { createStudio, fitStageCamera } from './viewer/studio';
import { confirmedProgress } from './progress.mjs';
import type { HouseModel, ViewerProps } from './types';

interface ExteriorView {
  modelId: string; width: number; depth: number; height: number;
  perspective: THREE.PerspectiveCamera; top: THREE.OrthographicCamera;
  mode: ViewerProps['cameraMode']; target: THREE.Vector3; focusedRoom: string | null;
  minDistance: number; maxDistance: number;
}

interface World {
  scene: THREE.Scene;
  renderer: THREE.WebGLRenderer;
  perspective: THREE.PerspectiveCamera;
  top: THREE.OrthographicCamera;
  camera: THREE.PerspectiveCamera | THREE.OrthographicCamera;
  controls: OrbitControls;
  house: THREE.Group | null;
  selections: Map<string, THREE.Group>;
  hovers: Map<string, THREE.Group>;
  hoveredRoom: string | null;
  focusedRoom: string | null;
  labelPositions: Map<string, THREE.Vector3>;
  size: [number, number];
  interior: { roomId: string; yaw: number; pitch: number } | null;
  exteriorView: ExteriorView | null;
  interiorLight: THREE.PointLight;
  studio: ReturnType<typeof createStudio>;
  reducedMotion: boolean;
  dirty: boolean;
  fadeStarted: number | null;
  motion: { from: THREE.PerspectiveCamera | THREE.OrthographicCamera; to: THREE.PerspectiveCamera | THREE.OrthographicCamera; fromTarget: THREE.Vector3; toTarget: THREE.Vector3; started: number; minDistance: number } | null;
}

function snapshotCamera(world: World) {
  return { camera: world.camera, copy: world.camera.clone(), target: world.controls.target.clone() };
}

function stopCameraMotion(world: World) {
  if (world.motion) world.controls.minDistance = world.motion.minDistance;
  world.motion = null;
  world.controls.enableDamping = !world.reducedMotion;
}

function fadeView(world: World) {
  if (world.reducedMotion || document.hidden) return;
  world.fadeStarted = performance.now();
  world.renderer.domElement.style.opacity = '0';
}

function easeCamera(world: World, previous: ReturnType<typeof snapshotCamera>) {
  world.dirty = true;
  stopCameraMotion(world);
  if (world.reducedMotion || document.hidden) return;
  if (previous.camera !== world.camera) { fadeView(world); return; }
  const minDistance = world.controls.minDistance;
  world.motion = { from: previous.copy, to: world.camera.clone(), fromTarget: previous.target, toTarget: world.controls.target.clone(), started: performance.now(), minDistance };
  world.camera.copy(previous.copy);
  world.controls.target.copy(previous.target);
  world.controls.minDistance = 0;
  world.controls.enableDamping = false;
}

function advanceCamera(world: World, now: number) {
  const motion = world.motion;
  if (motion) {
    world.dirty = true;
    const raw = THREE.MathUtils.clamp((now - motion.started) / 540, 0, 1);
    const amount = raw * raw * (3 - 2 * raw);
    world.camera.position.lerpVectors(motion.from.position, motion.to.position, amount);
    world.controls.target.lerpVectors(motion.fromTarget, motion.toTarget, amount);
    world.camera.zoom = THREE.MathUtils.lerp(motion.from.zoom, motion.to.zoom, amount);
    world.camera.far = Math.max(motion.from.far, motion.to.far);
    if (world.camera instanceof THREE.OrthographicCamera && motion.from instanceof THREE.OrthographicCamera && motion.to instanceof THREE.OrthographicCamera) {
      for (const key of ['left', 'right', 'top', 'bottom'] as const) world.camera[key] = THREE.MathUtils.lerp(motion.from[key], motion.to[key], amount);
    }
    world.camera.updateProjectionMatrix();
    if (raw === 1) { world.camera.copy(motion.to); world.controls.target.copy(motion.toTarget); stopCameraMotion(world); }
  }
  if (world.fadeStarted !== null) {
    const opacity = THREE.MathUtils.clamp((now - world.fadeStarted) / 220, 0, 1);
    world.renderer.domElement.style.opacity = String(opacity);
    if (opacity === 1) world.fadeStarted = null;
  }
}

function saveExteriorView(world: World, model: HouseModel, mode: ViewerProps['cameraMode']) {
  stopCameraMotion(world);
  world.controls.enableDamping = false;
  world.controls.update();
  world.exteriorView = { modelId: model.id, width: model.width, depth: model.depth, height: model.height, perspective: world.perspective.clone(), top: world.top.clone(), mode, target: world.controls.target.clone(), focusedRoom: world.focusedRoom, minDistance: world.controls.minDistance, maxDistance: world.controls.maxDistance };
}

function restoreExteriorView(world: World, model: HouseModel, mode: ViewerProps['cameraMode']) {
  const saved = world.exteriorView;
  world.interior = null;
  world.interiorLight.visible = false;
  world.controls.enabled = true;
  world.controls.enableDamping = !world.reducedMotion;
  if (saved && saved.modelId === model.id && saved.width === model.width && saved.depth === model.depth && saved.height === model.height && saved.mode === mode) {
    world.perspective.copy(saved.perspective);
    world.perspective.aspect = world.size[0] / world.size[1];
    world.perspective.updateProjectionMatrix();
    world.top.copy(saved.top);
    const half = (world.top.top - world.top.bottom) / 2;
    world.top.left = -half * world.size[0] / world.size[1]; world.top.right = -world.top.left;
    world.top.updateProjectionMatrix();
    world.camera = mode === 'top' ? world.top : world.perspective;
    world.controls.object = world.camera;
    world.controls.target.copy(saved.target);
    world.controls.enableRotate = mode !== 'top';
    world.controls.minDistance = saved.minDistance; world.controls.maxDistance = saved.maxDistance;
    world.focusedRoom = saved.focusedRoom;
    world.controls.update();
  } else {
    world.perspective.fov = 36;
    frameHouse(world, model, mode);
    world.focusedRoom = null;
  }
  world.exteriorView = null;
  fadeView(world);
}

function frameHouse(world: World, model: HouseModel, mode: ViewerProps['cameraMode']) {
  stopCameraMotion(world);
  world.dirty = true;
  const [width, height] = world.size;
  const aspect = width / Math.max(height, 1);
  const longest = Math.max(model.width, model.depth);
  world.perspective.aspect = aspect;
  const center = new THREE.Vector3(0, .28, 0);
  const bounds = new THREE.Box3(new THREE.Vector3(-model.width / 2 - .42, -.35, -model.depth / 2 - .42), new THREE.Vector3(model.width / 2 + .42, model.height, model.depth / 2 + .42));
  fitStageCamera(world.perspective, bounds, center, aspect);
  const half = Math.max((model.depth / 2 + .45) / .8, (model.width / 2 + .45) / (aspect * .8));
  world.top.left = -half * aspect;
  world.top.right = half * aspect;
  world.top.top = half;
  world.top.bottom = -half;
  world.top.position.set(0, longest * 2.5, 0.001);
  world.top.zoom = 1;
  world.top.up.set(0, 0, -1);
  world.top.lookAt(0, 0, 0);
  world.top.updateProjectionMatrix();
  world.camera = mode === 'top' ? world.top : world.perspective;
  world.controls.object = world.camera;
  world.controls.enableRotate = mode !== 'top';
  world.controls.target.copy(mode==='top'?new THREE.Vector3():center);
  world.controls.minDistance = longest * 0.35;
  world.controls.maxDistance = longest * 4;
  world.controls.minZoom = 0.45;
  world.controls.maxZoom = 4;
  world.controls.update();
}

function focusRoom(world: World, model: HouseModel, id: string, mode: ViewerProps['cameraMode'], cutaway: boolean) {
  stopCameraMotion(world);
  world.dirty = true;
  const room = model.rooms.find(item => item.id === id);
  if (!room || !room.polygon.length) return;
  const xs = room.polygon.map(point => point[0] - model.width / 2), zs = room.polygon.map(point => point[1] - model.depth / 2);
  const minX = Math.min(...xs) - 0.45, maxX = Math.max(...xs) + 0.45;
  const minZ = Math.min(...zs) - 0.45, maxZ = Math.max(...zs) + 0.45;
  const center = new THREE.Vector3((minX + maxX) / 2, cutaway ? 0.35 : model.height * 0.3, (minZ + maxZ) / 2);
  const aspect = world.size[0] / world.size[1];
  const direction = new THREE.Vector3(0.88, 0.9, 1).normalize();
  const right = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 1, 0), direction).normalize();
  const up = new THREE.Vector3().crossVectors(direction, right).normalize();
  const tanVertical = Math.tan(THREE.MathUtils.degToRad(world.perspective.fov) / 2);
  let distance = 0;
  for (const x of [minX, maxX]) for (const z of [minZ, maxZ]) for (const y of [0, cutaway ? 1.25 : model.height]) {
    const offset = new THREE.Vector3(x, y, z).sub(center);
    const depth = offset.dot(direction);
    distance = Math.max(distance, depth + Math.abs(offset.dot(right)) / (tanVertical * aspect), depth + Math.abs(offset.dot(up)) / tanVertical);
  }
  world.perspective.position.copy(center).addScaledVector(direction, distance * 1.15);
  world.perspective.lookAt(center); world.perspective.updateProjectionMatrix();
  const half = Math.max((maxZ - minZ) * 0.57, (maxX - minX) * 0.57 / aspect);
  world.top.left = -half * aspect; world.top.right = half * aspect;
  world.top.top = half; world.top.bottom = -half; world.top.zoom = 1;
  const topCenter = center.clone(); topCenter.y = 0;
  world.top.position.copy(topCenter).add(new THREE.Vector3(0, Math.max(model.width, model.depth) * 2.5, 0.001));
  world.top.up.set(0, 0, -1); world.top.lookAt(topCenter); world.top.updateProjectionMatrix();
  world.camera = mode === 'top' ? world.top : world.perspective;
  world.controls.object = world.camera; world.controls.enableRotate = mode !== 'top';
  world.controls.target.copy(mode === 'top' ? topCenter : center);
  world.controls.minDistance = Math.max(1.5, Math.min(maxX - minX, maxZ - minZ) * 0.45);
  world.controls.maxDistance = Math.max(model.width, model.depth) * 4;
  world.controls.update(); world.focusedRoom = id;
}

function pickAllowed(object: THREE.Object3D) {
  for (let item: THREE.Object3D | null = object; item; item = item.parent) {
    if (!item.visible || item.userData.ignorePick) return false;
  }
  return object instanceof THREE.Mesh;
}

function roomFromHit(hit: THREE.Intersection, cameraPosition: THREE.Vector3): string | null {
  const data = hit.object.userData;
  if (typeof data.roomId === 'string' && !data.openingId) return data.roomId;
  const boxMesh = hit.object instanceof THREE.Mesh && hit.object.geometry instanceof THREE.BoxGeometry;
  const face = boxMesh && hit.faceIndex != null ? Math.floor(hit.faceIndex / 2) : hit.face?.materialIndex ?? -1;
  // Only the two designed faces of a multi-material wall have a stable side.
  // Neutral caps, jambs and rotated door leaves belong to the viewer-facing room.
  const designedWallSide = hit.object instanceof THREE.Mesh && Array.isArray(hit.object.material) && (face === 4 || face === 5);
  const faceRoom = designedWallSide ? data.faceRooms?.[face] : null;
  if (typeof faceRoom === 'string') return faceRoom;
  if (data.wallPlane && data.wallRooms) {
    const plane = data.wallPlane;
    const side = (cameraPosition.x - plane.x) * plane.nx + (cameraPosition.z - plane.z) * plane.nz;
    return (side >= 0 ? data.wallRooms.positive ?? data.wallRooms.negative : data.wallRooms.negative ?? data.wallRooms.positive) ?? null;
  }
  return null;
}

export default function HouseViewer(props: ViewerProps) {
  const host = useRef<HTMLDivElement>(null);
  const labels = useRef<HTMLDivElement>(null);
  const world = useRef<World | null>(null);
  const latest = useRef(props);
  latest.current = props;
  const [failure, setFailure] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [interiorNotice, setInteriorNotice] = useState<string | null>(null);
  const lastFocusKey = useRef(0);
  const lastFrame = useRef<{ id: string; width: number; depth: number; reset: number } | null>(null);

  useEffect(() => {
    const element = host.current;
    if (!element) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: false });
    } catch {
      setFailure('当前浏览器无法启动 3D 渲染，请开启硬件加速或更换浏览器。');
      return;
    }
    const scene = new THREE.Scene();
    renderer.setClearColor('#e9ede7', 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.06;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = false;
    renderer.shadowMap.needsUpdate = true;
    renderer.domElement.setAttribute('aria-label', '可旋转与点选的房屋三维模型');
    renderer.domElement.tabIndex = 0;
    renderer.domElement.style.touchAction = 'none';
    element.prepend(renderer.domElement);
    const perspective = new THREE.PerspectiveCamera(36, 1, 0.05, 300);
    const top = new THREE.OrthographicCamera(-10, 10, 10, -10, 0.05, 300);
    const controls = new OrbitControls(perspective, renderer.domElement);
    const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
    controls.enableDamping = !motionPreference.matches;
    controls.dampingFactor = 0.07;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.screenSpacePanning = true;
    controls.mouseButtons = { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
    const interiorLight = new THREE.PointLight('#ffe8c9', 14, 16, 2);
    interiorLight.visible = false; scene.add(interiorLight);
    const studio = createStudio(renderer, scene);
    studio.frame(latest.current.model);
    studio.setTheme(latest.current.theme ?? 'light');
    const state: World = {
      scene, renderer, perspective, top, camera: perspective, controls, house: null,
      selections: new Map(), hovers: new Map(), hoveredRoom: null, focusedRoom: null, labelPositions: new Map(), size: [1, 1],
      interior: null, exteriorView: null, interiorLight, studio,
      reducedMotion: motionPreference.matches, dirty: true, motion: null, fadeStarted: null,
    };
    world.current = state;
    const resize = () => {
      const box = element.getBoundingClientRect();
      state.size = [Math.max(box.width, 1), Math.max(box.height, 1)];
      renderer.setSize(state.size[0], state.size[1]);
      if (state.interior || latest.current.interiorRoom) {
        state.perspective.aspect = state.size[0] / state.size[1];
        state.perspective.updateProjectionMatrix();
        state.dirty = true;
        return;
      }
      const focus = state.focusedRoom;
      frameHouse(state, latest.current.model, latest.current.cameraMode);
      if (focus) focusRoom(state, latest.current.model, focus, latest.current.cameraMode, latest.current.cutaway);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(element);
    resize();
    // A viewer mounted directly into room mode still needs a valid exterior
    // camera to restore, rather than the PerspectiveCamera's default origin.
    if (latest.current.interiorRoom) frameHouse(state, latest.current.model, latest.current.cameraMode);
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let pointerStart: [number, number] | null = null;
    let pointerLast: [number, number] | null = null;
    let dragged = false;
    let multiPointer = false;
    const activePointers = new Set<number>();
    type PickResult = { roomId: string | null; openingId: string | null; enterable: boolean };
    const successfulClicks: { roomId: string; x: number; y: number; time: number; enterable: boolean }[] = [];
    const pick = (event: MouseEvent): PickResult | null => {
      if (!state.house) return null;
      const box = renderer.domElement.getBoundingClientRect();
      pointer.set(((event.clientX - box.left) / box.width) * 2 - 1, -((event.clientY - box.top) / box.height) * 2 + 1);
      raycaster.setFromCamera(pointer, state.camera);
      // The first visible physical surface blocks the ray, including walls.
      // Selection guides and metre markers never participate in picking.
      const hit = raycaster.intersectObjects(state.house.children, true).find(item => pickAllowed(item.object));
      if (!hit) return null;
      let openingId: string | null = null;
      let kind: string | null = null;
      for (let object: THREE.Object3D | null = hit.object; object; object = object.parent) {
        openingId ??= typeof object.userData.openingId === 'string' ? object.userData.openingId : null;
        kind ??= typeof object.userData.kind === 'string' ? object.userData.kind : null;
      }
      const roomId = roomFromHit(hit, raycaster.ray.origin);
      const floor = hit.object instanceof THREE.Mesh && hit.object.geometry instanceof THREE.ShapeGeometry && !!hit.object.userData.roomId;
      return { roomId, openingId, enterable: kind === 'floor' || kind === 'furniture' || floor };
    };
    const hover = (roomId: string | null) => {
      if (state.hoveredRoom !== roomId) state.dirty = true;
      state.hoveredRoom = roomId;
      state.hovers.forEach((outline, id) => { outline.visible = !state.interior && id === roomId && id !== latest.current.selectedRoom; });
      renderer.domElement.style.cursor = !state.interior && roomId ? 'pointer' : 'grab';
    };
    const down = (event: PointerEvent) => {
      stopCameraMotion(state);
      activePointers.add(event.pointerId);
      if (activePointers.size > 1) { dragged = true; multiPointer = true; successfulClicks.length = 0; return; }
      pointerStart = [event.clientX, event.clientY]; pointerLast = [...pointerStart];
      dragged = event.button !== 0; multiPointer = false;
      if (state.interior && event.button === 0) renderer.domElement.setPointerCapture(event.pointerId);
    };
    const move = (event: PointerEvent) => {
      if (pointerStart && Math.hypot(event.clientX - pointerStart[0], event.clientY - pointerStart[1]) > 5) dragged = true;
      if (state.interior && activePointers.has(event.pointerId) && activePointers.size === 1 && !multiPointer && pointerLast) {
        state.interior.yaw -= (event.clientX - pointerLast[0]) * .004;
        state.interior.pitch = THREE.MathUtils.clamp(state.interior.pitch - (event.clientY - pointerLast[1]) * .004, -Math.PI * 4 / 9, Math.PI * 4 / 9);
        applyInteriorAngles(state.perspective, state.interior.yaw, state.interior.pitch);
        state.dirty = true;
        pointerLast = [event.clientX, event.clientY];
      }
      if (activePointers.size) { hover(null); renderer.domElement.style.cursor = 'grabbing'; return; }
      hover(pick(event)?.roomId ?? null);
    };
    const up = (event: PointerEvent) => {
      activePointers.delete(event.pointerId);
      const isClick = pointerStart && !dragged && !multiPointer && event.button === 0 && Math.hypot(event.clientX - pointerStart[0], event.clientY - pointerStart[1]) <= 5;
      if (!activePointers.size) { pointerStart = null; pointerLast = null; }
      if (isClick) {
        const result = pick(event);
        if (result) {
          if (result.roomId) latest.current.onSelectRoom(result.roomId);
          if (result.openingId) latest.current.onSelectOpening(result.openingId);
          if (result.roomId && !state.interior) {
            successfulClicks.push({ roomId: result.roomId, x: event.clientX, y: event.clientY, time: performance.now(), enterable: result.enterable });
            if (successfulClicks.length > 2) successfulClicks.shift();
          }
        }
      } else successfulClicks.length = 0;
      hover(pick(event)?.roomId ?? null);
    };
    const doubleClick = (event: MouseEvent) => {
      if (state.interior || latest.current.interiorRoom || successfulClicks.length !== 2) return;
      const [a, b] = successfulClicks;
      if (!a.enterable || !b.enterable || a.roomId !== b.roomId || b.time - a.time > 550 || performance.now() - b.time > 150 || Math.hypot(a.x - b.x, a.y - b.y) > 10) return;
      successfulClicks.length = 0;
      event.preventDefault(); latest.current.onSelectRoom(b.roomId); latest.current.onEnterRoom(b.roomId);
    };
    const cancel = () => { pointerStart = null; pointerLast = null; dragged = true; multiPointer = false; activePointers.clear(); successfulClicks.length = 0; hover(null); };
    const lostCapture = (event: PointerEvent) => { if (event.buttons !== 0 && activePointers.has(event.pointerId)) cancel(); };
    const escape = (event: KeyboardEvent) => {
      if (event.defaultPrevented || !state.interior || element.closest('[inert]')) return;
      if (event.key === 'Escape') { event.preventDefault(); latest.current.onExitRoom(); return; }
      if (document.activeElement !== renderer.domElement || !event.key.startsWith('Arrow')) return;
      const turn = Math.PI / 30;
      if (event.key === 'ArrowLeft') state.interior.yaw += turn;
      else if (event.key === 'ArrowRight') state.interior.yaw -= turn;
      else if (event.key === 'ArrowUp') state.interior.pitch += turn;
      else if (event.key === 'ArrowDown') state.interior.pitch -= turn;
      else return;
      event.preventDefault();
      state.interior.pitch = THREE.MathUtils.clamp(state.interior.pitch, -Math.PI * 4 / 9, Math.PI * 4 / 9);
      applyInteriorAngles(state.perspective, state.interior.yaw, state.interior.pitch);
      state.dirty = true;
    };
    let frame = 0;
    const visibility = () => {
      if (document.hidden) { cancel(); cancelAnimationFrame(frame); frame = 0; }
      else if (frame === 0) { state.dirty = true; frame = requestAnimationFrame(animate); }
    };
    const motionChanged = () => {
      state.reducedMotion = motionPreference.matches;
      if (state.reducedMotion) {
        const motion = state.motion;
        if (motion) { state.camera.copy(motion.to); state.controls.target.copy(motion.toTarget); }
        stopCameraMotion(state);
        state.fadeStarted = null;
        renderer.domElement.style.opacity = '1';
      }
      controls.enableDamping = !state.reducedMotion;
      state.dirty = true;
    };
    const controlStart = () => stopCameraMotion(state);
    const wheel = (event: WheelEvent) => { if (state.interior) event.preventDefault(); };
    const lost = (event: Event) => {
      event.preventDefault();
      setFailure('3D 渲染连接已中断，请刷新页面重新加载模型。');
    };
    renderer.domElement.addEventListener('pointerdown', down);
    renderer.domElement.addEventListener('pointerup', up);
    renderer.domElement.addEventListener('pointermove', move);
    renderer.domElement.addEventListener('pointerleave', cancel);
    renderer.domElement.addEventListener('pointercancel', cancel);
    renderer.domElement.addEventListener('lostpointercapture', lostCapture);
    renderer.domElement.addEventListener('dblclick', doubleClick);
    renderer.domElement.addEventListener('wheel', wheel, { passive: false });
    renderer.domElement.addEventListener('webglcontextlost', lost);
    window.addEventListener('keydown', escape);
    window.addEventListener('blur', cancel);
    document.addEventListener('visibilitychange', visibility);
    motionPreference.addEventListener('change', motionChanged);
    controls.addEventListener('start', controlStart);
    const projection = new THREE.Vector3();
    const animate = () => {
      frame = document.hidden ? 0 : requestAnimationFrame(animate);
      advanceCamera(state, performance.now());
      const changed = !state.interior && controls.enabled ? controls.update() : false;
      if (!state.dirty && !changed && !state.motion) return;
      renderer.render(scene, state.camera);
      state.dirty = false;
      labels.current?.querySelectorAll<HTMLElement>('[data-room-label]').forEach(label => {
        const position = state.labelPositions.get(label.dataset.roomLabel!);
        if (!position) return;
        projection.copy(position).project(state.camera);
        const x = (projection.x + 1) * state.size[0] / 2;
        const y = (1 - projection.y) * state.size[1] / 2;
        label.style.left = `${x}px`;
        label.style.top = `${y}px`;
        const narrow = state.size[0] < 500;
        const allowed = !latest.current.interiorRoom && latest.current.showLabels && (!narrow || label.dataset.roomLabel === latest.current.selectedRoom);
        label.style.visibility = allowed && projection.z < 1 && projection.z > -1 && x > 24 && x < state.size[0] - 24 && y > 24 && y < state.size[1] - 24 ? 'visible' : 'hidden';
      });
    };
    animate();
    const exportModel = async () => {
      if (!state.house) return;
      setExporting(true);
      let temporaryHouse: THREE.Group | null = null;
      try {
        // UI selection contours and measurement sprites are not building parts.
        if (latest.current.interiorRoom) temporaryHouse = buildHouse(latest.current.model, latest.current.viewMode, latest.current.cutaway, latest.current.showFurniture, null).group;
        const exportRoot = (temporaryHouse ?? state.house).clone(true);
        const guides: THREE.Object3D[] = [];
        exportRoot.traverse(object => { if (object.userData.ignorePick) guides.push(object); });
        guides.forEach(object => object.removeFromParent());
        const exported = await new GLTFExporter().parseAsync(exportRoot, { binary: true, onlyVisible: true });
        if (!(exported instanceof ArrayBuffer) || exported.byteLength === 0) throw new Error('未生成有效的 GLB 数据');
        const blob = new Blob([exported], { type: 'model/gltf-binary' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${latest.current.model.name || '筑映模型'}.glb`;
        link.click();
        window.dispatchEvent(new CustomEvent('zhuying:export-complete', { detail: { bytes: blob.size } }));
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      } catch (error) {
        const message = error instanceof Error ? error.message : '请重试';
        setFailure(`模型导出失败：${message}`);
        window.dispatchEvent(new CustomEvent('zhuying:export-complete', { detail: { bytes: 0, error: message } }));
      } finally {
        if (temporaryHouse) disposeTree(temporaryHouse);
        setExporting(false);
      }
    };
    window.addEventListener('zhuying:export-glb', exportModel);
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      window.removeEventListener('zhuying:export-glb', exportModel);
      renderer.domElement.removeEventListener('pointerdown', down);
      renderer.domElement.removeEventListener('pointerup', up);
      renderer.domElement.removeEventListener('pointermove', move);
      renderer.domElement.removeEventListener('pointerleave', cancel);
      renderer.domElement.removeEventListener('pointercancel', cancel);
      renderer.domElement.removeEventListener('lostpointercapture', lostCapture);
      renderer.domElement.removeEventListener('dblclick', doubleClick);
      renderer.domElement.removeEventListener('wheel', wheel);
      renderer.domElement.removeEventListener('webglcontextlost', lost);
      window.removeEventListener('keydown', escape);
      window.removeEventListener('blur', cancel);
      document.removeEventListener('visibilitychange', visibility);
      motionPreference.removeEventListener('change', motionChanged);
      controls.removeEventListener('start', controlStart);
      controls.dispose();
      studio.dispose();
      disposeTree(scene);
      renderer.dispose();
      renderer.domElement.remove();
      world.current = null;
    };
  }, []);

  useEffect(() => {
    const state = world.current;
    if (!state) return;
    state.studio.setTheme(props.theme ?? 'light');
    state.dirty = true;
    if (state.interior) state.scene.background = new THREE.Color('#f1eee5');
    if (document.hidden) state.renderer.render(state.scene, state.camera);
  }, [props.theme]);

  useEffect(() => {
    const state = world.current;
    if (!state) return;
    if (state.house) {
      state.scene.remove(state.house);
      disposeTree(state.house);
    }
    const result = buildHouse(props.model, props.viewMode, props.interiorRoom ? false : props.cutaway, props.showFurniture, props.interiorRoom);
    state.house = result.group;
    state.selections = result.selections;
    state.hovers = result.hovers;
    state.scene.add(result.group);
    state.studio.frame(props.model);
    state.renderer.shadowMap.needsUpdate = true;
    state.dirty = true;
    state.labelPositions.clear();
    props.model.rooms.forEach(room => {
      const center = roomCenter(room.polygon);
      state.labelPositions.set(room.id, new THREE.Vector3(center[0] - props.model.width / 2, 0.2, center[1] - props.model.depth / 2));
    });
    state.selections.forEach((outline, id) => { outline.visible = !props.interiorRoom && id === latest.current.selectedRoom; });
    if (props.interiorRoom) state.house.traverse(object => { if (object.userData.ignorePick) object.visible = false; });
    if (document.hidden) state.renderer.render(state.scene, state.camera);
  }, [props.model, props.viewMode, props.cutaway, props.showFurniture, props.interiorRoom]);

  useEffect(() => {
    const state = world.current;
    if (!state || !state.house) return;
    if (!props.interiorRoom) {
      if (state.interior || state.exteriorView) restoreExteriorView(state, props.model, props.cameraMode);
      state.scene.background = null;
      state.renderer.domElement.setAttribute('aria-label', '可旋转与点选的房屋三维模型');
      state.dirty = true;
      return;
    }
    if (!state.exteriorView) saveExteriorView(state, props.model, props.cameraMode);
    const sameRoom = state.interior?.roomId === props.interiorRoom;
    const standingPoint = findInteriorStandingPoint(props.model, props.interiorRoom, state.house, sameRoom ? state.perspective.position : undefined);
    if (!standingPoint) {
      setInteriorNotice('这个房间没有足够的可站立空间或层高，请先校正结构或调整家具。');
      latest.current.onExitRoom();
      return;
    }
    setInteriorNotice(null);
    const room = props.model.rooms.find(item => item.id === props.interiorRoom)!;
    if (!sameRoom) {
      const center = roomCenter(room.polygon);
      const dx = center[0] - props.model.width / 2 - standingPoint.x, dz = center[1] - props.model.depth / 2 - standingPoint.z;
      state.interior = { roomId: room.id, yaw: Math.hypot(dx, dz) > .4 ? Math.atan2(-dx, -dz) : 0, pitch: -.06 };
      fadeView(state);
    }
    state.camera = state.perspective;
    state.controls.enabled = false;
    state.controls.object = state.perspective;
    state.perspective.position.copy(standingPoint);
    state.perspective.fov = 65;
    state.perspective.near = .035;
    state.perspective.aspect = state.size[0] / state.size[1];
    state.perspective.updateProjectionMatrix();
    applyInteriorAngles(state.perspective, state.interior!.yaw, state.interior!.pitch);
    const center = roomCenter(room.polygon);
    state.interiorLight.position.set(center[0] - props.model.width / 2, Math.min(props.model.height - .22, 2.4), center[1] - props.model.depth / 2);
    state.interiorLight.visible = true;
    state.scene.background = new THREE.Color('#f1eee5');
    state.renderer.domElement.setAttribute('aria-label', `${room.name}实时三维室内环视，拖动或方向键改变视线，Escape返回整屋`);
    state.renderer.domElement.focus({preventScroll:true});
    state.selections.forEach(outline => { outline.visible = false; });
    state.hovers.forEach(outline => { outline.visible = false; });
    state.dirty = true;
    if (document.hidden) state.renderer.render(state.scene, state.camera);
  }, [props.interiorRoom, props.model, props.showFurniture, props.viewMode]);

  useEffect(() => {
    const state = world.current;
    if (!state) return;
    if (props.interiorRoom) return;
    const previous = lastFrame.current;
    const reset = !previous || previous.id !== props.model.id || previous.width !== props.model.width || previous.depth !== props.model.depth || previous.reset !== props.resetKey;
    const focus = reset ? null : state.focusedRoom;
    const before = snapshotCamera(state);
    frameHouse(state, props.model, props.cameraMode);
    state.focusedRoom = null;
    if (focus) focusRoom(state, props.model, focus, props.cameraMode, props.cutaway);
    if (previous) easeCamera(state, before);
    lastFrame.current = { id: props.model.id, width: props.model.width, depth: props.model.depth, reset: props.resetKey };
    if (document.hidden) state.renderer.render(state.scene, state.camera);
  }, [props.model.id, props.model.width, props.model.depth, props.cameraMode, props.resetKey]);

  useEffect(() => {
    if (lastFocusKey.current === props.focusKey) return;
    lastFocusKey.current = props.focusKey;
    if (world.current && props.selectedRoom && !props.interiorRoom) {
      const state = world.current, before = snapshotCamera(state);
      focusRoom(state, props.model, props.selectedRoom, props.cameraMode, props.cutaway);
      easeCamera(state, before);
      if (document.hidden) state.renderer.render(state.scene, state.camera);
    }
  }, [props.focusKey]);

  useEffect(() => {
    world.current?.selections.forEach((outline, id) => { outline.visible = !props.interiorRoom && id === props.selectedRoom; });
    world.current?.hovers.forEach((outline, id) => { outline.visible = !props.interiorRoom && id === world.current?.hoveredRoom && id !== props.selectedRoom; });
    if (world.current) world.current.dirty = true;
  }, [props.selectedRoom, props.interiorRoom]);

  useEffect(() => { if (world.current) world.current.dirty = true; }, [props.showLabels]);

  return <div ref={host} className="house-viewer" data-interior-room={props.interiorRoom ?? undefined} data-selected-opening={props.selectedOpening ?? undefined} style={{ position: 'relative', width: '100%', height: '100%', minHeight: 280, overflow: 'hidden', background: 'transparent' }}>
    <style>{`
      .house-viewer canvas { display:block; width:100%; height:100%; outline:none; }
      .house-room-label { position:absolute; transform:translate(-50%,-50%); pointer-events:auto; padding:6px 10px; border:1px solid rgba(255,255,255,.85); border-radius:7px; background:rgba(255,255,255,.83); color:#42514a; box-shadow:0 2px 10px #26392b12; font-family:inherit; font-size:11px; line-height:1.25; font-weight:500; white-space:nowrap; cursor:pointer; backdrop-filter:blur(5px); transition:background .15s,border-color .15s; }
      .house-room-label:hover { background:#fff; border-color:#708d7f; }
      .house-room-label.is-selected { color:#1b5947; background:#f5fff9e8; border-color:#699f83; box-shadow:0 2px 12px #25503c20; }
      .house-room-label strong { display:block; font-size:11px; font-weight:600; line-height:1.35; }
      .house-room-label small { display:block; color:#79877e; font-size:9px; margin-top:2px; letter-spacing:.3px; }
      .house-viewer-failure { position:absolute; z-index:5; inset:0; display:grid; place-items:center; padding:32px; background:#e8ece7ee; color:#49594e; text-align:center; font-size:13px; }
      .house-interior-hud { position:absolute; top:max(15px,env(safe-area-inset-top)); left:max(15px,env(safe-area-inset-left)); right:max(15px,env(safe-area-inset-right)); display:flex; justify-content:space-between; align-items:flex-start; gap:12px; pointer-events:none; z-index:3; }
      .house-interior-caption { background:#fffef1eb; border:1px solid #d9dfd2; border-radius:10px; padding:11px 14px; backdrop-filter:blur(7px); box-shadow:0 4px 20px #33473412; color:#354c3b; max-width:calc(100% - 130px); }
      .house-interior-caption strong { display:flex; gap:7px; align-items:center; font-size:13px; font-weight:650; overflow-wrap:anywhere; }
      .house-interior-caption span { margin-top:6px; display:flex; align-items:center; gap:6px; font-size:10px; color:#71816a; }
      .house-interior-exit { pointer-events:auto; display:flex; align-items:center; justify-content:center; gap:7px; min-height:44px; padding:0 13px; border:1px solid #cad6ca; border-radius:9px; background:#ffffffed; color:#365d45; font:inherit; font-size:12px; cursor:pointer; backdrop-filter:blur(7px); flex-shrink:0; }
      .house-interior-exit:hover { background:#f4fcf5; border-color:#6c9377; }
      .house-interior-exit:focus-visible { outline:2px solid #367b52; outline-offset:3px; }
      .house-interior-notice { position:absolute; left:15px; right:15px; bottom:20px; color:#765e35; background:#fff8e8ef; border:1px solid #e6d8b8; border-radius:8px; padding:10px 14px; font-size:12px; z-index:3; }
      @media(max-width:500px) { .house-interior-hud { left:10px; right:10px; top:10px; gap:8px; } .house-interior-caption { padding:9px 10px; max-width:calc(100% - 110px); } .house-interior-caption strong { font-size:12px; } .house-interior-caption span { font-size:9px; } .house-interior-exit { padding:0 10px; font-size:11px; } }
    `}</style>
    <div ref={labels} style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity: props.showLabels && !props.interiorRoom ? 1 : 0, visibility: props.showLabels && !props.interiorRoom ? 'visible' : 'hidden' }}>
      {props.model.rooms.map(room => <button key={room.id} data-room-label={room.id} className={`house-room-label ${props.selectedRoom === room.id ? 'is-selected' : ''}`} onClick={() => props.onSelectRoom(room.id)} onDoubleClick={() => { if (!latest.current.interiorRoom) { props.onSelectRoom(room.id); props.onEnterRoom(room.id); } }} aria-pressed={props.selectedRoom === room.id} aria-label={`选择三维空间${room.name}`} title="双击进入房间，也可在装修面板中点击进入房间">
        <strong>{room.name}</strong>
        <small>{props.viewMode === 'progress' ? (confirmedProgress(room).known === 0 ? '待核对' : `${confirmedProgress(room).completed}/${confirmedProgress(room).total} 项可见完成`) : `${room.area.toFixed(1)} m²`}</small>
      </button>)}
    </div>
    {props.interiorRoom && <div className="house-interior-hud"><div className="house-interior-caption" role="status"><strong><Rotate3D size={16} />{props.model.rooms.find(room => room.id === props.interiorRoom)?.name ?? '室内'} · 实时 3D 环视</strong><span><Move size={12} />拖动 / 方向键环视 · ESC 返回</span></div><button className="house-interior-exit" onClick={props.onExitRoom} aria-label="退出房间，返回整屋"><ArrowLeft size={16} />返回整屋</button></div>}
    {interiorNotice && <div className="house-interior-notice" role="status">{interiorNotice}</div>}
    {failure && <div className="house-viewer-failure" role="alert">{failure}</div>}
    {exporting && <div style={{ position: 'absolute', right: 16, bottom: 16, padding: '9px 13px', borderRadius: 8, background: '#ffffffee', fontSize: 12, color: '#3b5449' }} role="status">正在导出三维模型…</div>}
  </div>;
}
