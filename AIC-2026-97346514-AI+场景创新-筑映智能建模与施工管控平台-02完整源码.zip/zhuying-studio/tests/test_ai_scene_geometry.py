"""Exact topology tests for AI grid expansion; no provider calls or API keys."""
import copy
import math
import unittest

from backend.ai_scene_geometry import expand_scene_grid


def scene(xs=None, ys=None, rooms=None, openings=None):
    xs = [0, 4, 8] if xs is None else xs
    ys = [0, 4, 8] if ys is None else ys
    rooms = [{"id": "living", "name": "客厅", "use": "living", "cells": [[0, 0], [1, 0], [0, 1], [1, 1]]}] if rooms is None else rooms
    return {"coordinateSystem": "metres", "depth": ys[-1],
            "grid": {"x": xs, "y": ys, "rooms": rooms, "openings": [] if openings is None else openings}}


def area(polygon):
    return abs(sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(polygon, polygon[1:] + polygon[:1])) / 2)


def opening(identifier="window", **changes):
    return {"id": identifier, "type": "window", "center": [4, 0], "orientation": "horizontal",
            "width": 2, "height": 1.2, "sill": .9, **changes}


class AISceneGeometryTests(unittest.TestCase):
    def expand(self, value):
        return expand_scene_grid(value, value["grid"]["x"][-1], 2.8)

    def test_rectangle_merges_grid_subdivisions_exactly_without_changing_input(self):
        raw = scene([0, 2.1234, 6.5678], [0, 1.2345, 4.9876])
        before = copy.deepcopy(raw)
        result = self.expand(raw)
        self.assertEqual(raw, before)
        self.assertEqual(result["coordinateSystem"], "metres")
        self.assertEqual(result["depth"], 4.9876)
        self.assertEqual(result["rooms"][0]["polygon"], [[0., 0.], [6.5678, 0.], [6.5678, 4.9876], [0., 4.9876]])
        self.assertAlmostEqual(area(result["rooms"][0]["polygon"]), 6.5678 * 4.9876)
        self.assertEqual(len(result["walls"]), 4)
        self.assertTrue(all(wall["thickness"] == .22 and wall["height"] == 2.8 for wall in result["walls"]))
        self.assertEqual(result["rooms"][0]["boundaryType"], "closed")
        self.assertEqual(result["openings"], [])

    def test_l_shaped_room_keeps_concavity_with_one_simple_ring(self):
        raw = scene([0, 2, 7], [0, 3, 8], [{"id": "l", "name": "L形客厅", "use": "living", "cells": [[0, 0], [1, 0], [0, 1]]}])
        result = self.expand(raw)
        self.assertEqual(result["rooms"][0]["polygon"], [[0., 0.], [7., 0.], [7., 3.], [2., 3.], [2., 8.], [0., 8.]])
        self.assertAlmostEqual(area(result["rooms"][0]["polygon"]), 31)
        self.assertEqual(len(result["walls"]), 6)

    def test_two_closed_rooms_share_one_partition(self):
        raw = scene(rooms=[{"id": "a", "name": "客厅", "use": "living", "cells": [[0, 0], [0, 1]]},
                           {"id": "b", "name": "卧室", "use": "bedroom", "cells": [[1, 0], [1, 1]]}])
        result = self.expand(raw)
        self.assertEqual(len(result["walls"]), 5)
        partition = [wall for wall in result["walls"] if wall["thickness"] == .18]
        self.assertEqual(len(partition), 1)
        self.assertEqual((partition[0]["start"], partition[0]["end"]), ([4., 0.], [4., 8.]))

    def test_open_living_kitchen_entry_keep_zones_without_inventing_partitions(self):
        raw = scene([0, 4, 8, 12], [0, 4, 8], [
            {"id": "living", "name": "客厅", "use": "living", "wallGroup": "public", "cells": [[0, 0], [1, 0]]},
            {"id": "kitchen", "name": "厨房", "use": "kitchen", "wallGroup": "public", "cells": [[0, 1]]},
            {"id": "entry", "name": "玄关", "use": "entry", "wallGroup": "public", "cells": [[1, 1]]},
            {"id": "bedroom", "name": "卧室", "use": "bedroom", "cells": [[2, 0], [2, 1]]}])
        result = self.expand(raw)
        self.assertEqual(len(result["walls"]), 5)
        self.assertEqual([room["boundaryType"] for room in result["rooms"]], ["open_zone"] * 3 + ["closed"])
        self.assertTrue(all(room["wallGroup"] == "public" for room in result["rooms"][:3]))
        self.assertEqual(sum(area(room["polygon"]) for room in result["rooms"]), 96)
        self.assertFalse(any(wall["start"][1] == wall["end"][1] == 4 for wall in result["walls"]))
        self.assertEqual([wall for wall in result["walls"] if wall["thickness"] == .18][0]["start"], [8., 0.])

    def test_left_balcony_projection_uses_nonnegative_global_origin(self):
        raw = scene([0, 1.2, 7, 12], [0, 3, 4.5, 9], [
            {"id": "balcony", "name": "阳台", "use": "empty", "cells": [[0, 1]]},
            {"id": "living", "name": "客厅", "use": "living", "cells": [[1, 0], [2, 0], [1, 1], [2, 1], [1, 2], [2, 2]]}])
        result = self.expand(raw)
        self.assertEqual(result["rooms"][0]["polygon"], [[0., 3.], [1.2, 3.], [1.2, 4.5], [0., 4.5]])
        self.assertTrue(all(min(point) >= 0 for wall in result["walls"] for point in (wall["start"], wall["end"])))
        self.assertAlmostEqual(sum(area(room["polygon"]) for room in result["rooms"]), 99)
        self.assertEqual(len(result["walls"]), 9)

    def test_stable_wall_ids_ignore_cell_and_room_order(self):
        raw = scene(rooms=[{"id": "a", "name": "客厅", "use": "living", "cells": [[0, 0], [0, 1]]},
                           {"id": "b", "name": "卧室", "use": "bedroom", "cells": [[1, 0], [1, 1]]}])
        reordered = copy.deepcopy(raw)
        reordered["grid"]["rooms"].reverse()
        for room in reordered["grid"]["rooms"]:
            room["cells"].reverse()
        self.assertEqual(self.expand(raw)["walls"], self.expand(reordered)["walls"])

    def test_opening_center_maps_to_merged_wall_with_exact_offset(self):
        result = self.expand(scene(openings=[opening()]))
        window = result["openings"][0]
        wall = next(wall for wall in result["walls"] if wall["id"] == window["wallId"])
        self.assertEqual((wall["start"], wall["end"]), ([0., 0.], [8., 0.]))
        self.assertEqual(window["offset"], 3)
        self.assertEqual(window["width"], 2)

    def test_vertical_door_maps_to_single_shared_partition(self):
        raw = scene(rooms=[{"id": "a", "name": "客厅", "use": "living", "cells": [[0, 0], [0, 1]]},
                           {"id": "b", "name": "卧室", "use": "bedroom", "cells": [[1, 0], [1, 1]]}],
                    openings=[opening("door", type="door", center=[4, 5.5], orientation="vertical", width=.9, height=2.1, sill=0)])
        result = self.expand(raw)
        door = result["openings"][0]
        self.assertAlmostEqual(door["offset"], 5.05)
        wall = next(wall for wall in result["walls"] if wall["id"] == door["wallId"])
        self.assertEqual(wall["thickness"], .18)

    def test_visible_center_noise_within_point_two_metres_is_projected(self):
        self.assertEqual(self.expand(scene(openings=[opening(center=[4, .2])]))["openings"][0]["offset"], 3)

    def test_reject_invalid_global_axes_and_dimension_contract(self):
        for axis, values in (("x", [1, 4, 8]), ("x", [0, 4, 4, 8]), ("x", [0, 4, 3, 8]),
                             ("x", [0, .001, 8]), ("x", [0, math.nan, 8]), ("y", [0, True, 8])):
            with self.subTest(axis=axis, values=values):
                raw = scene()
                raw["grid"][axis] = values
                with self.assertRaises(ValueError):
                    self.expand(raw)
        with self.assertRaisesRegex(ValueError, "声明尺寸"):
            expand_scene_grid(scene(), 10, 2.8)

    def test_reject_duplicate_out_of_bounds_noninteger_or_boolean_cells(self):
        for cells in ([[0, 0], [0, 0]], [[-1, 0]], [[2, 0]], [[0, 2]], [[0.0, 0]], [[False, 0]], [[0]], ["bad"]):
            with self.subTest(cells=cells):
                raw = scene()
                raw["grid"]["rooms"][0]["cells"] = cells
                with self.assertRaises(ValueError):
                    self.expand(raw)

    def test_reject_room_overlap(self):
        raw = scene()
        raw["grid"]["rooms"].append({"id": "bed", "name": "卧室", "use": "bedroom", "cells": [[0, 0]]})
        with self.assertRaisesRegex(ValueError, "重叠"):
            self.expand(raw)

    def test_reject_diagonal_room_and_building_connectivity(self):
        raw = scene()
        raw["grid"]["rooms"][0]["cells"] = [[0, 0], [1, 1]]
        with self.assertRaisesRegex(ValueError, "四邻连通"):
            self.expand(raw)
        raw["grid"]["rooms"] = [{"id": "a", "name": "客厅", "use": "living", "cells": [[0, 0]]},
                                 {"id": "b", "name": "卧室", "use": "bedroom", "cells": [[1, 1]]}]
        with self.assertRaisesRegex(ValueError, "整体不连通"):
            self.expand(raw)

    def test_reject_room_with_hole(self):
        cells = [[column, row] for column in range(3) for row in range(3) if (column, row) != (1, 1)]
        raw = scene([0, 1, 2, 3], [0, 1, 2, 3], [{"id": "ring", "name": "客厅", "use": "living", "cells": cells}])
        with self.assertRaisesRegex(ValueError, "孔洞"):
            self.expand(raw)

    def test_reject_disconnected_open_group(self):
        raw = scene([0, 4, 8, 12], [0, 8], [
            {"id": "a", "name": "客厅", "use": "living", "wallGroup": "public", "cells": [[0, 0]]},
            {"id": "b", "name": "卧室", "use": "bedroom", "cells": [[1, 0]]},
            {"id": "c", "name": "厨房", "use": "kitchen", "wallGroup": "public", "cells": [[2, 0]]}])
        with self.assertRaisesRegex(ValueError, "开放空间组"):
            self.expand(raw)

    def test_reject_declared_extent_not_reached(self):
        raw = scene()
        raw["grid"]["rooms"][0]["cells"] = [[0, 0], [0, 1]]
        with self.assertRaisesRegex(ValueError, "未覆盖"):
            self.expand(raw)

    def test_reject_unaligned_wrong_direction_overrun_or_tall_openings(self):
        invalid = [opening(center=[4, .201]), opening(center=[.9, 0]), opening(orientation="vertical"),
                   opening(sill=2), opening(height=3), opening(type="door"), opening(center=[-1, 0]),
                   opening(orientation=[]), opening(type=[]), opening(width=True)]
        for item in invalid:
            with self.subTest(item=item):
                with self.assertRaises(ValueError):
                    self.expand(scene(openings=[item]))

    def test_reject_opening_on_open_zone_boundary(self):
        raw = scene(rooms=[{"id": "a", "name": "客厅", "use": "living", "wallGroup": "public", "cells": [[0, 0], [0, 1]]},
                           {"id": "b", "name": "厨房", "use": "kitchen", "wallGroup": "public", "cells": [[1, 0], [1, 1]]}],
                    openings=[opening("door", type="door", center=[4, 4], orientation="vertical", width=.9, height=2.1, sill=0)])
        with self.assertRaisesRegex(ValueError, "实体墙"):
            self.expand(raw)

    def test_reject_duplicate_and_overlapping_openings(self):
        for items in ([opening(), opening()], [opening(), opening("second", center=[5, 0])]):
            with self.subTest(items=items):
                with self.assertRaises(ValueError):
                    self.expand(scene(openings=items))

    def test_optional_openings_never_invent_doors(self):
        raw = scene()
        del raw["grid"]["openings"]
        self.assertEqual(self.expand(raw)["openings"], [])

    def test_single_named_wall_group_still_forms_closed_room(self):
        raw = scene()
        raw["grid"]["rooms"][0]["wallGroup"] = "public"
        result = self.expand(raw)
        self.assertEqual(result["rooms"][0]["boundaryType"], "closed")
        self.assertEqual(len(result["walls"]), 4)

    def test_reject_malformed_and_nonfinite_contracts_cleanly(self):
        for raw in (None, [], {}, {"coordinateSystem": "pixels", "grid": {}}, {"coordinateSystem": "metres", "grid": [], "depth": 8}):
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):
                    expand_scene_grid(raw, 8, 2.8)
        with self.assertRaises(ValueError):
            expand_scene_grid(scene(), 10 ** 1000, 2.8)
        raw = scene()
        raw["grid"]["rooms"][0]["use"] = []
        with self.assertRaises(ValueError):
            self.expand(raw)

    def test_labels_matrix_produces_identical_geometry_to_existing_cells(self):
        raw = scene([0, 4, 8, 12], [0, 4, 8], [
            {"id": "living", "name": "客厅", "use": "living", "wallGroup": "public", "cells": [[0, 0], [1, 0]]},
            {"id": "kitchen", "name": "厨房", "use": "kitchen", "wallGroup": "public", "cells": [[0, 1]]},
            {"id": "entry", "name": "玄关", "use": "entry", "wallGroup": "public", "cells": [[1, 1]]},
            {"id": "bedroom", "name": "卧室", "use": "bedroom", "cells": [[2, 0], [2, 1]]}],
            [opening("bedroom-door", type="door", center=[8, 5], orientation="vertical", width=.9, height=2.1, sill=0)])
        matrix = copy.deepcopy(raw)
        for room in matrix["grid"]["rooms"]:
            del room["cells"]
        matrix["grid"]["labels"] = [["living", "living", "bedroom"], ["kitchen", "entry", "bedroom"]]
        before = copy.deepcopy(matrix)
        self.assertEqual(self.expand(matrix), self.expand(raw))
        self.assertEqual(matrix, before)

    def test_labels_null_preserves_l_shaped_exterior(self):
        raw = scene([0, 2, 7], [0, 3, 8], [{"id": "l", "name": "L形客厅", "use": "living"}])
        raw["grid"]["labels"] = [["l", "l"], ["l", None]]
        result = self.expand(raw)
        self.assertEqual(result["rooms"][0]["polygon"], [[0., 0.], [7., 0.], [7., 3.], [2., 3.], [2., 8.], [0., 8.]])
        self.assertEqual(len(result["walls"]), 6)

    def test_labels_reject_mixed_cells_even_when_empty(self):
        for cells in ([], [[0, 0]], None):
            raw = scene()
            raw["grid"]["rooms"][0]["cells"] = cells
            raw["grid"]["labels"] = [["living", "living"], ["living", "living"]]
            with self.subTest(cells=cells):
                with self.assertRaisesRegex(ValueError, "不可混用"):
                    self.expand(raw)

    def test_labels_reject_incomplete_transposed_or_ragged_matrix(self):
        invalid = (None, [], [["living"]], [["living", "living"]],
                   [["living", "living"], ["living"]],
                   [["living", "living", "living"], ["living", "living"]],
                   ["living", ["living", "living"]])
        for labels in invalid:
            raw = scene()
            del raw["grid"]["rooms"][0]["cells"]
            raw["grid"]["labels"] = labels
            with self.subTest(labels=labels):
                with self.assertRaisesRegex(ValueError, "labels"):
                    self.expand(raw)

    def test_labels_reject_unknown_id_nonstring_boolean_and_blank(self):
        for label in ("new-room", "", 1, True, [], {}):
            raw = scene()
            del raw["grid"]["rooms"][0]["cells"]
            raw["grid"]["labels"] = [["living", label], ["living", "living"]]
            with self.subTest(label=label):
                with self.assertRaisesRegex(ValueError, "已定义"):
                    self.expand(raw)

    def test_labels_require_each_declared_room_to_own_cells(self):
        raw = scene(rooms=[{"id": "living", "name": "客厅", "use": "living"},
                           {"id": "bedroom", "name": "卧室", "use": "bedroom"}])
        raw["grid"]["labels"] = [["living", "living"], ["living", "living"]]
        with self.assertRaisesRegex(ValueError, "bedroom.*1 至 1024"):
            self.expand(raw)

    def test_labels_do_not_weaken_hole_or_connectivity_validation(self):
        raw = scene([0, 1, 2, 3], [0, 1, 2, 3], [{"id": "l", "name": "客厅", "use": "living"}])
        raw["grid"]["labels"] = [["l", "l", "l"], ["l", None, "l"], ["l", "l", "l"]]
        with self.assertRaisesRegex(ValueError, "孔洞"):
            self.expand(raw)
        raw["grid"]["labels"] = [["l", None, None], [None, "l", None], [None, None, "l"]]
        with self.assertRaisesRegex(ValueError, "四邻连通"):
            self.expand(raw)

    def test_labels_reject_duplicate_room_ids_before_assigning(self):
        raw = scene(rooms=[{"id": "living", "name": "客厅", "use": "living"},
                           {"id": "living", "name": "厨房", "use": "kitchen"}])
        raw["grid"]["labels"] = [["living", "living"], ["living", "living"]]
        with self.assertRaisesRegex(ValueError, "重复"):
            self.expand(raw)

    def test_invalid_opening_reports_nearest_wall_endpoints_and_feasible_centers(self):
        raw = scene(rooms=[{"id": "a", "name": "客厅", "use": "living", "cells": [[0, 0], [0, 1]]},
                           {"id": "b", "name": "卧室", "use": "bedroom", "cells": [[1, 0], [1, 1]]}],
                    openings=[opening("bedroom-door", type="door", center=[4, 0], orientation="vertical", width=.9, height=2.1, sill=0)])
        before = copy.deepcopy(raw)
        with self.assertRaises(ValueError) as error:
            self.expand(raw)
        message = str(error.exception)
        self.assertIn("bedroom-door", message)
        self.assertIn("start=[4,0] end=[4,8]", message)
        self.assertIn("可用中心 y 范围=[0.45,7.55]，x=4", message)
        self.assertIn("不可越过墙端", message)
        self.assertEqual(raw, before)

    def test_opening_wall_hint_caps_at_three_nearest_candidates(self):
        raw = scene([0, 8], [0, 1, 2, 3, 4, 5],
                    [{"id": f"r{row}", "name": f"空间{row}", "use": "empty", "cells": [[0, row]]} for row in range(5)],
                    [opening(center=[0, 2.4])])
        with self.assertRaises(ValueError) as error:
            self.expand(raw)
        message = str(error.exception)
        self.assertEqual(message.count("可用中心 x 范围=[1,7]"), 3)
        self.assertIn("start=[0,2] end=[8,2]", message)
        self.assertIn("start=[0,3] end=[8,3]", message)
        self.assertIn("start=[0,1] end=[8,1]", message)
        self.assertNotIn("start=[0,0] end=[8,0]", message)
        self.assertNotIn("start=[0,5] end=[8,5]", message)

    def test_opening_wall_hint_marks_insufficient_wall_length(self):
        raw = scene([0, 1], [0, 1], [{"id": "l", "name": "房间", "use": "empty", "cells": [[0, 0]]}],
                    [opening(center=[.5, 0], width=2)])
        with self.assertRaisesRegex(ValueError, "墙长不足 2 米，没有可用中心范围"):
            self.expand(raw)

    def test_missing_vertical_dimensions_receive_editable_door_window_defaults(self):
        raw = scene(openings=[{"id": "door", "type": "door", "center": [2, 0], "orientation": "horizontal", "width": .9},
                              {"id": "window", "type": "window", "center": [5, 0], "orientation": "horizontal", "width": 2}])
        result = self.expand(raw)
        door, window = result["openings"]
        self.assertEqual((door["height"], door["sill"]), (2.1, 0.))
        self.assertEqual((window["height"], window["sill"]), (1.2, .85))

    def test_missing_vertical_defaults_fit_lower_user_ceiling(self):
        raw = scene(openings=[{"id": "door", "type": "door", "center": [2, 0], "orientation": "horizontal", "width": .9},
                              {"id": "window", "type": "window", "center": [5, 0], "orientation": "horizontal", "width": 2}])
        result = expand_scene_grid(raw, 8, 1.5)
        door, window = result["openings"]
        self.assertEqual((door["height"], door["sill"]), (1.5, 0.))
        self.assertEqual((window["height"], window["sill"]), (1.2, .3))
        result = expand_scene_grid(raw, 8, .8)
        self.assertTrue(all(item["height"] == .8 and item["sill"] == 0 for item in result["openings"]))

    def test_missing_sill_respects_explicit_window_height_without_changing_it(self):
        item = {"id": "window", "type": "window", "center": [4, 0], "orientation": "horizontal", "width": 2, "height": 2.4}
        result = self.expand(scene(openings=[item]))["openings"][0]
        self.assertEqual((result["height"], result["sill"]), (2.4, .4))

    def test_explicit_vertical_values_are_never_silently_defaulted(self):
        for changes in ({"height": None}, {"height": math.nan}, {"height": True}, {"height": 3},
                        {"height": .4}, {"sill": None}, {"sill": True}, {"sill": -.1}, {"sill": 2}):
            item = {"id": "window", "type": "window", "center": [4, 0], "orientation": "horizontal", "width": 2, **changes}
            with self.subTest(changes=changes):
                with self.assertRaises(ValueError):
                    self.expand(scene(openings=[item]))
        door = {"id": "door", "type": "door", "center": [4, 0], "orientation": "horizontal", "width": .9, "sill": .1}
        with self.assertRaisesRegex(ValueError, "门的 sill 必须为 0"):
            self.expand(scene(openings=[door]))

    def test_existing_explicit_vertical_dimensions_remain_unchanged(self):
        result = self.expand(scene(openings=[opening(height=1.5, sill=.7)]))["openings"][0]
        self.assertEqual((result["height"], result["sill"]), (1.5, .7))


if __name__ == "__main__":
    unittest.main()
