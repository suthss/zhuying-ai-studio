# 筑映 · 千问 API 配置教程

你已经有密钥，只需把它填入本机后端配置、重启后端，再分别验证设计问答与照片分析。密钥无需发到聊天里，也不要写进前端的 `VITE_` 变量。

本教程适用：千问平台「按量付费」API Key + OpenAI 兼容接口 + `qwen3.8-flash`。千问官方建议应用开发与 API 集成选择按量付费，见 [计费方式说明](https://platform.qianwenai.com/docs/resources/faq-billing)。不要混用「订阅 Token Plan」的密钥与本教程地址。

## 1. 打开项目目录

在 PowerShell 中运行：

```powershell
Set-Location -LiteralPath '<PROJECT_ROOT>'
```

后续命令均在这个目录运行。

## 2. 创建配置文件，填写密钥

以下命令只在 `backend\.env` 不存在时复制样例；已有配置会保留：

```powershell
if (!(Test-Path -LiteralPath 'backend\.env')) {
    Copy-Item -LiteralPath 'backend\.env.example' -Destination 'backend\.env'
}
notepad.exe backend\.env
```

在记事本中，把下面四行设为：

```dotenv
QWEN_API_KEY=这里替换成你自己的完整密钥
QWEN_CHAT_MODEL=qwen3.8-flash
QWEN_MODEL=qwen3.8-flash
QWEN_BASE_URL=https://maas.qianwenaiapi.com/compatible-mode/v1
```

将 `QWEN_API_KEY=` 后面的中文占位文字全部替换为实际密钥。其他三行直接照抄；每个变量仅保留一行。不要把密钥粘贴到 PowerShell 命令中。按 Ctrl+S 保存，确认文件名为 `.env`，而不是 `.env.txt`。文件中的 `PLAN_DEVICE`、`PLAN_INPUT_SIDE` 等本地户型识别配置可保留。

| 配置项 | 对应功能 |
|---|---|
| `QWEN_API_KEY` | 后端调用千问的凭证 |
| `QWEN_CHAT_MODEL` | 设计问答，整理用途、需求、风格与家具清单 |
| `QWEN_MODEL` | 户型图重建／用途核对、施工照片观察与前后照片对比 |
| `QWEN_PLAN_THINKING` | 可选，默认 `true`；千问 Flash 自主重建使用有上限的思考，设置 `false` 可加快请求 |
| `QWEN_BASE_URL` | OpenAI 兼容接口根地址，程序自动追加 `/chat/completions` |

你的截图显示 `https://maas.qianwenai.com/compatible-mode/v1`；当前 [官方首次调用示例](https://platform.qianwenai.com/docs/developer-guides/getting-started/first-api-call) 使用的是上面的 **`maas.qianwenaiapi.com`**，注意中间多了 `api`。本教程采用已核对的官方文档地址。本次本机不带密钥访问新地址得到 401，说明接口可达；截图地址在本次连接中发生 TLS 错误。这些连通结果不代表你的密钥已验证，也不证明截图地址在所有环境中不可用。

`qwen3.8-flash` 支持文本、图片理解与结构化输出，模型名与能力见 [官方模型说明](https://platform.qianwenai.com/docs/developer-guides/getting-started/latest-model)。当前项目的实际家具坐标仍由本地几何算法生成；普通施工照片不会自动恢复精确房屋几何。

## 3. 重启后端，让配置生效

修改 `.env` 后，**仅刷新网页不会加载新密钥**。已经运行的后端必须重启。

从项目目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\start.ps1 -RestartBackend
```

脚本会核验现有 8000 端口进程是否属于本工作区的筑映后端，匹配后重启并加载 `backend/.env`；如果属于其他程序，则拒绝自动停止它。已有筑映网页服务会复用。打开命令输出的工作台地址，当前工作区通常为 `http://127.0.0.1:5174`，端口以实际输出为准。

**普通运行 `start.ps1` 会复用已启动的后端；更新配置时必须带 `-RestartBackend`。** 只刷新网页或普通重新运行脚本不能让已运行后端读到新配置。

备用方法：如果后端在终端前台运行，先在该终端按 Ctrl+C 停止，再从项目目录运行：

```powershell
.\.venv\Scripts\python.exe -m uvicorn backend.app:app --env-file backend/.env --host 127.0.0.1 --port 8000
```

启动后保持这个终端运行，浏览器刷新工作台。不要在旧后端仍运行时重复执行上述启动命令，否则会提示 8000 端口被占用。

## 4. 确认配置已经加载

在浏览器打开：

`http://127.0.0.1:8000/api/health`

或在另一个 PowerShell 终端运行：

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1:8000/api/health' |
    Select-Object status, algorithm, visionConfigured, designConfigured
```

期望：`status` 为 `ok`，`algorithm` 为 `hybrid-floorplan-v2`，`visionConfigured` 与 `designConfigured` 都为 `True`。这两个字段只说明后端读到了非空密钥；**并没有向千问验证鉴权、模型权限或额度**。本地健康检查不调用云模型。

工作台中的问答标题应显示「千问密钥已配置」，添加巡检中应显示「千问视觉已配置」。刷新后仍显示本地模式时，先检查文件名与后端重启步骤。

## 5. 发一次设计问答，验证文字调用

1. 打开工作台，点击「问答设计」。
2. 输入一句明确需求，例如「主卧放一张双人床和书桌，客厅不要电视柜」，提交。
3. 收到「千问设计助手」的回复及「千问已更新你的需求」提示，核对房间用途与家具清单。若返回错误，按下一节排查。
4. 问答只修改需求草稿；完成四步并点击「生成我的家」，家具与材质方案才会应用到三维模型。

如需更严格地检查来源，按 F12 打开浏览器开发者工具，在 Network／网络面板查看 `/api/design-chat` 的响应：成功的云调用应为 `source: "qwen"`，本地规则为 `source: "local"`。不要公开分享包含私人需求或照片的完整请求记录。

## 6. 分析现场照片，验证视觉调用

1. 选择一个房间，切换「施工进度」，启用需要跟踪的工序。
2. 点击「添加巡检」，选择工序和有效日期，上传 1～6 张同房间、同工序的现场照片。填写全景、窗侧或细节等拍摄说明，有助于人工核对。
3. 点击「联合分析照片」。如果选择了更早的同工序巡检，则点击「联合分析与前后对比」。**只有点击分析按钮，选定照片才会发送至千问**。
4. 检查「AI 建议，待你确认」、逐张观察与可选的前后变化。证据不足时显示待复核属于正常结果，不能为了测试连通强行选完工。
5. 核对或修改可见施工状态，点击「确认巡检」保存。选择可见完工还需勾选覆盖核对。

开发者工具中 `/api/analyze-inspection` 成功响应的来源应为 `source: "qwen/qwen3.8-flash"`；`source: "manual_review"` 表示没有调用云视觉模型。AI 建议需人工确认后才更新施工记录；可见完工不等于质量验收通过。

设计问答和照片分析分别触发云 API 用量。账户额度、可用模型与账单以千问控制台为准。本次后续检测已通过运行中的后端进行两次真实调用，结果见文末；没有输出密钥。

## 常见问题

| 表现 | 原因与处理 |
|---|---|
| 两个 `Configured` 都为 `False` | 检查是否为 `backend\.env`、密钥是否为空、是否使用 `--env-file backend/.env` 启动并完成重启。 |
| 健康检查正常，问答提示鉴权失败 | 上游 401／403 被应用转为 502 并给出中文说明；核对完整密钥、所属计费模式、业务空间与模型权限。配置状态为 True 不能代替鉴权验证。 |
| 提示调用受限 | 上游 429 被应用转为 502；稍后重试，并在控制台检查额度、余额及调用限制。 |
| 提示模型返回 HTTP 404 或其他状态（如 503） | 应用显示具体上游状态并以 502 返回；404 时核对模型名与地址，服务端 503 时稍后重试。不要把这类失败当作 AI 已成功识别。 |
| 提示网络连接失败或超时 | 核对官方 HTTPS 地址与本机网络；问答／巡检请求最多 45 秒，户型重建单次最多 90 秒，可能另有一次几何修复。 |
| 提示不是有效需求 JSON／巡检 JSON | 请求抵达后结果未通过本地结构校验，可以重试或手动填写；没有静默伪造成功。 |
| 启动报 8000 端口占用／拒绝自动重启 | 旧后端仍运行，或进程不符合本工作区后端身份。优先使用上面的 `-RestartBackend`；若脚本拒绝，先确认服务归属，再在原终端停止筑映后端。不要任意结束其他项目的进程。 |
| 户型识别仍漏墙或分错房间 | 导入时选择「AI 自主重建」调用视觉模型重新规划；「AI 辅助校正」只核对用途。本地 CubiCasa5K／OpenCV 提供初始结构，AI 结果未通过校验会明确回退。需对照预览与实际尺度；详见 [AI 户型流程说明](ai-assisted-floorplan.md)。 |

如 PowerShell 会话已设置同名 `QWEN_*` 环境变量，它们可能优先于 `.env`。请在不含这些旧变量的新终端启动，或按自己的原配置来源修改；无需输出实际密钥排查。

## 本次验证边界（2026-10-05）

最初核对了官方地址、模型 ID、现有后端配置变量、健康检查字段与两类接口的来源标记，并完成不带密钥的接口连通检查。用户随后填入配置并请求检测，已完成下面的真实调用验证。检测直接请求运行中的本地后端，没有读取配置文件或输出密钥；没有用真实施工标注集证明模型准确率。

后端回归验证为 **111 项测试、108 项子测试全部通过**，覆盖新官方地址、单图／多图巡检、设计问答、JSON 参数与旧模型兼容。Windows PowerShell 启动脚本的 3 项模拟验证通过，覆盖本项目重启、其他项目拒绝停止、正常复用服务；本工作区也已实际重启后端，确认加载 `backend/.env` 并正常提供健康接口，前端继续使用 5174。

后续真实调用检测（2026-10-05）：健康检查的两项配置状态均为 `true`。设计问答返回 HTTP 200、`source: "qwen"`，约5.59秒；测试需求要求主卧增加书桌、客厅不要电视柜，返回清单正确包含卧室书桌和椅子，并移除客厅电视柜。照片分析返回 HTTP 200、`source: "qwen/qwen3.8-flash"`，约1.94秒；输入是96×96的合成空白图片，模型正确返回 `unknown`、`needsReview: true` 及无有效视觉证据的说明。此视觉检测验证鉴权、图片输入与结构化响应，不能据此判断真实施工识别准确率。测试未写入用户项目或巡检记录。脱敏结果保存在本地 `artifacts/api-live-check.json`。
