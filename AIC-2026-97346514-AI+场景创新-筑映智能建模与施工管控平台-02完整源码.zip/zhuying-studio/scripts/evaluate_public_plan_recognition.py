"""Run public raster smoke examples, saving models and diagnostic segmentation.

These examples have no annotated geometry or measured dimensions. Successful
parsing and visible overlays are operational checks, never accuracy metrics.
Only explicitly selected local parsers are called; no user images are uploaded.
"""
from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path
import sys
import time

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--parser', default='backend.neural_plan:recognize_floor_plan')
    cli.add_argument('--output', type=Path, required=True)
    cli.add_argument('--save-models', type=Path, required=True)
    cli.add_argument('--debug-masks', type=Path)
    args = cli.parse_args()
    module, separator, function = args.parser.partition(':')
    if not separator:
        cli.error('--parser must use module:function')
    parser = getattr(importlib.import_module(module), function)
    source_dir = ROOT / 'tests/fixtures/plan-recognition/public-smoke'
    provenance = json.loads((source_dir / 'sources.json').read_text(encoding='utf-8'))
    results = []
    args.save_models.mkdir(parents=True, exist_ok=True)
    for source in provenance['files']:
        image_bytes = (source_dir / source['file']).read_bytes()
        model_path = args.save_models / (Path(source['file']).stem + '.json')
        model_path.unlink(missing_ok=True)
        start = time.perf_counter()
        result = {'file': source['file'], 'assumedWidth': 12,
                  'note': 'Unlabelled smoke only; width is a preview assumption, not a survey measurement.'}
        try:
            model = parser(image_bytes, real_width=12, height=2.8)
            if isinstance(model, dict) and 'model' in model:
                model = model['model']
            result.update({'status': 'parsed', 'depth': model['depth'],
                           'rooms': len(model['rooms']), 'walls': len(model['walls']),
                           'openings': len(model.get('openings', [])),
                           'algorithm': model.get('meta', {}).get('algorithm'),
                           'engine': model.get('meta', {}).get('engine', 'unreported'),
                           'fallbackReason': model.get('meta', {}).get('fallbackReason'),
                           'warnings': model.get('warnings', [])})
            model_path.write_text(
                json.dumps(model, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        except Exception as error:
            result.update({'status': 'rejected', 'errorType': type(error).__name__, 'error': str(error)})
        result['latencySeconds'] = time.perf_counter() - start
        results.append(result)
        if args.debug_masks:
            from backend.neural_plan import segment_floor_plan
            args.debug_masks.mkdir(parents=True, exist_ok=True)
            segmented = segment_floor_plan(image_bytes)
            name = Path(source['file']).stem
            np.save(args.debug_masks / (name + '-labels.npy'), segmented['labels'])
            np.save(args.debug_masks / (name + '-rooms.npy'), segmented['roomLabels'])
            segmented['image'].save(args.debug_masks / (name + '-input.png'))
            colors = np.array([[255, 255, 255], [45, 62, 63], [245, 140, 55], [58, 154, 217]], dtype=np.uint8)
            cv2.imwrite(str(args.debug_masks / (name + '-structures.png')), colors[segmented['labels']][:, :, ::-1])
            (args.debug_masks / (name + '-meta.json')).write_text(
                json.dumps(segmented['meta'], ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False), flush=True)
    report = {'parser': args.parser, 'scope': 'Public example smoke only; no labelled accuracy benchmark',
              'sources': provenance, 'results': results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
