import type { HouseModel, Opening, OpeningDesign, OpeningStyle } from './types';

export interface OpeningStylePreset { readonly id: OpeningStyle; readonly label: string }
export const doorStyles: readonly OpeningStylePreset[];
export const windowStyles: readonly OpeningStylePreset[];
export function resolveOpeningDesign(opening: Opening): OpeningDesign;
export function isOpeningDesign(value: unknown, type: Opening['type']): value is OpeningDesign;
export function getOpeningErrors(model: HouseModel, opening: Opening): string[];
export function updateOpening(model: HouseModel, id: string, patch: Partial<Opening>): HouseModel;
export function getRoomOpenings(model: HouseModel, roomId: string): Opening[];
export interface DoorLeafPose {
  pivotX: number; pivotZ: number; rotation: number; leafWidth: number;
  centerX: number; centerZ: number;
}
export function doorLeafPose(opening: Opening): DoorLeafPose;
