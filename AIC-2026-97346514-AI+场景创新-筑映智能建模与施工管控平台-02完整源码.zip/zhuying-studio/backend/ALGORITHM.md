# 筑映 · 算法与服务说明

## 当前实现

户型图识别提供三种方式：`auto` 自动选择、`neural` 本地 CubiCasa5K 预训练网络、`classic` 原 OpenCV 规则方法。神经模型根据 PNG/JPEG/WebP 原图预测墙、房间类型及门窗，再转成项目可编辑的 `HouseModel`。输出为米制墙中心线、墙厚、房间多边形与面积、关联到父墙的门窗；尺度来自用户输入的外墙中心线总宽度，层高仍需用户提供。

普通室内照片用于施工证据。配置千问时，可辅助描述地面／墙面可见状态；无密钥时返回 `unknown` 和人工复核提示。户型识别与照片观察不推断工程完成情况，也不恢复真实相机位姿、摄影测量点云或 NeRF。

## 户型识别流程

1. **输入检查**：PNG/JPEG/WebP，原始文件不超过10 MB、总像素不超过2000万、任意边不超过12000像素；处理透明背景与 EXIF 方向。总宽度1～100米，层高2～6米。
2. **本地推理**：等比例缩小至最长边768像素（可配置512～1024），保留长宽比；右侧／底部补白至64的倍数，归一化为 `[-1, 1]`。44通道网络输出中使用12类房间和11类图标分割；裁掉补白后得到墙、门、窗和房间语义标签。本版未使用21个角点热图联合优化，也未启用四旋转平均。
3. **墙线矢量化**：对预测墙掩码细化、提取线段，估计线宽，合并共线墙段并校正近邻交点。只在有限距离或门窗预测有依据时连接断口；复杂斜墙、裂缝及细墙仍可能漏识别。
4. **门窗投影**：提取门窗语义连通区域，匹配有效父墙，计算墙起点偏移与开口宽度；范围、重叠及过小／过大开口经校验。不能可靠关联的预测会被跳过并提示人工添加，不能当成已确认构件。
5. **房间提取**：墙及可靠门窗形成分区屏障，结合室内类别排除外部区域；保留区域的简化多边形，支持凹形轮廓。房间类型取语义分割的区域候选，需在问答或结构编辑中确认。房间不是统一用外接矩形代替。
6. **尺度与初始化**：外墙中心线总宽度标定米／像素，进深由识别范围得到；门高、窗高、窗台高为可编辑初始值。施工任务与计划全部为 `unknown`、日期为空，`progress: 0` 仅表示尚无已确认完成项。

`auto` 在专用模型与基础线条方法之间选择适用结果：清晰封闭正交墙线图只有在墨迹几乎完全被连通墙线解释时才优先保留经典结果（覆盖率与连通墙占比均≥0.99），此选择记录为 `selectionReason: closed_orthogonal_structure`；不按文件名或期望房间数选择。其他图尝试神经分割。模型不可用或不能得到可用几何时，自动方式返回基础方法的实际解析结果，并在元数据中记录 `fallbackReason`。手动选择 `neural` 时，未就绪或失败会返回错误，不伪装成神经模型识别成功。`meta.engine`、`meta.algorithm`、识别构件数和警告可用于检查实际路径。

`classic` 保留原流程：最长边1800像素 → Otsu二值化 → 横竖形态学长线提取 → 共线合并 → 外墙中心线尺度标定 → 空白四连通域 → 多边形与净面积。它适合清晰封闭的正交线图，不自动识别门窗或房间用途。

## 安装专用模型

常规服务依赖见 `backend/requirements.txt`；专用识别另外需要 PyTorch。应使用适合本机的 CPU／CUDA 安装版本，不因安装识别模块自动安装 CUDA。以下命令安装可选依赖并下载上游官方 checkpoint（208,651,193 bytes，约209 MB）：

```powershell
.\.venv\Scripts\python.exe -m pip install -r backend/requirements-recognition.txt
.\.venv\Scripts\python.exe scripts/download_plan_model.py
```

默认权重位置 `models/cubicasa5k/model_best_val_loss_var.pkl` 由 Git 忽略。下载脚本验证文件大小及 SHA256，权重仅按张量／基本数据安全加载（`weights_only=True`），不会因加载失败打开任意 pickle 执行，也不会在用户上传请求中下载网络代码或权重。

| 环境变量 | 默认值 | 用途 |
|---|---|---|
| `PLAN_DEVICE` | `auto` | `auto` 有可用 CUDA 时使用 GPU，否则 CPU；也可指定 `cpu`／`cuda` |
| `PLAN_INPUT_SIDE` | `768` | 输入最长边，整数512～1024；512更省资源但可能漏细线 |
| `PLAN_MODEL_PATH` | 默认权重路径 | 指定已有本地 checkpoint |

配置后重启后端；可复制 `backend/.env.example` 为 `backend/.env`，用 `uvicorn --env-file backend/.env` 或 `start.ps1` 加载。本地模型不把用户户型图片发送到云端。CPU/GPU 耗时取决于图片和设备，第一次调用包括权重初始化。

网络代码与 checkpoint 来自 [CubiCasa/CubiCasa5k](https://github.com/CubiCasa/CubiCasa5k)，网络按44通道和当前环境适配。上游网络代码为 **CC BY-NC 4.0**，原始训练数据 Zenodo 记录为 **CC BY-NC-SA 4.0**，本项目将此识别路径限定于竞赛和非商业研究，保留署名、许可和修改记录。具体文件与权重来源见 [第三方声明](../docs/THIRD_PARTY_NOTICES.md)；本版不能宣称这些权重可任意商业使用。

## 支持范围与剩余限制

- 已有专用房间／墙／门窗分割，能处理部分带门洞、家具、尺寸线的原图；处理成功不证明图纸完整准确。
- 预训练模型源于 CubiCasa5K 图纸域。中国彩色营销图、手绘、透视照片、多个楼层拼图、模糊扫描、罕见墙符号可能与训练域不同，应先裁剪单层图纸并人工核对。
- 门窗可能漏检／误检，房间可能合并或产生小区域，厚墙和复杂交点可能被拆成多段。房间用途只是候选，分类概率不是准确率或置信保证。
- 本版矢量化独立实现；不是完整复现上游角点热图与多旋转后处理，也不直接输出施工图或建筑规范合规报告。
- 用户总宽度按**外墙中心线**定义，不能不换算就使用外墙面尺寸；墙厚、净面积来自栅格预测，仍有线宽、分割及像素量化误差。
- 图片没有独立测量基准时，不自动读尺寸文字恢复精确尺度。门高、窗高和层高不能从普通二维图可靠恢复。
- `public/demo-plan.png` 是自绘六区域规则图，证明接口闭环；不是外部精度数据。

## API

从项目根目录运行：

```powershell
.\.venv\Scripts\python.exe -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
```

| 接口 | 请求 | 返回 |
|---|---|---|
| `GET /api/health` | 无 | `status`, `algorithm: hybrid-floorplan-v2`, `planRecognition`, `visionConfigured`, `designConfigured` |
| `POST /api/parse-plan` | multipart `file`, `real_width`（默认12）, `height`（默认2.8）, `engine`（`auto`／`neural`／`classic`，默认`auto`） | 完整 `HouseModel`，含识别来源与待复核警告 |
| `POST /api/design-chat` | JSON：房间摘要、`brief`、`messages` | `{reply, brief, source, warnings}` |
| `POST /api/analyze-photo` | multipart `file`, `room_name`, `work_type`（`floor`／`wall`） | `{stage, summary, source, needsReview}` |
| `POST /api/analyze-inspection` | multipart `files`当前1～6张，`previous_files`前次0～6张，`room_name`、六类`work_type`、`date`及可选`previous_date`／`previous_stage` | 复核阶段、当前逐图`observations`及可选前后`comparison` |

输入无效和无法识别返回422；文件超过限制返回413；云模型鉴权、网络或输出异常返回502，不返回密钥或提供方正文。设计对话仅发送名称、面积、宽深、需求和文字，不发送户型图片；照片上传视觉服务由用户触发，建议经确认后才更新施工记录。

联合巡检两组照片合计最多30 MiB，单张10 MiB；日期必须有效，前次不得晚于当前。模型一次查看全部已选照片，逐图索引只对应当前组；无密钥明确返回人工复核，缺少前次日期或两次同日时对比变化为`uncertain`。完整契约、工序边界与验证记录见[多角度巡检算法说明](../docs/inspection-algorithm.md)。

## 千问与家具方案

后端读取 `QWEN_API_KEY`、`QWEN_CHAT_MODEL`、`QWEN_MODEL`、`QWEN_BASE_URL`。本项目的配置样例推荐两个模型均为 `qwen3.8-flash`，按量付费的 OpenAI 兼容地址为 `https://maas.qianwenaiapi.com/compatible-mode/v1`，见 [千问官方首次调用文档](https://platform.qianwenai.com/docs/developer-guides/getting-started/first-api-call)。允许此官方地址以及原阿里云北京、新加坡、美国共享域名；URL 必须匹配允许列表，不能填 Anthropic 地址、Token Plan 地址或额外追加 `/chat/completions`。未填写模型变量时，源代码仍兼容文本 `qwen-plus`、视觉 `qwen-vl-plus` 的旧默认值。密钥不能放到前端 `VITE_` 变量中。完整配置、重启与验证步骤见 [API 配置教程](../docs/api-configuration.md)。

文本模型将用户需求整理为经校验的 `DesignBrief`；无密钥时由本地规则返回相同契约并明确 `source: local`。实际家具坐标由本地几何约束算法产生，避让墙体、门口、开启区域和其他家具；放不下会提示并跳过，不直接执行大模型生成的未经校验坐标。

视觉图片压缩至最长边1600，以 JPEG Base64 传入 OpenAI 兼容接口；结构化结果经本地校验。网络等待45秒，失败不伪造成功。在线模型效果尚未通过真实密钥验证。

## 回归与模型验证

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -p 'test_*.py' -v
.\.venv\Scripts\python.exe scripts/evaluate_plan_recognition.py --parser backend.neural_plan:recognize_floor_plan --output artifacts/recognition-improved.json --save-models artifacts/recognition-models
.\.venv\Scripts\python.exe scripts/evaluate_public_plan_recognition.py --output artifacts/recognition-public-improved.json --save-models artifacts/recognition-public-models
```

自绘十图覆盖门洞、窗线、家具、尺寸线、缩小、微旋转与凹形空间。评估报告包含拒识数、房间 IoU、房间数、墙中心线容差 F1、门窗位置与宽度 F1、尺度误差及耗时，拒识样本按0计入主要平均值。控制样本用于回归，**不能作为真实户型泛化准确率**。两张公开示例只有出处／许可与解析运行记录，没有测量宽度或完整人工标注，因此不报告它们的识别准确率。

测试中的模拟云响应只验证接口边界，不验证大模型效果。真实预训练权重的本机推理记录与旧方法对比另存 `artifacts/recognition-*.json`；未来仍需经授权、按房屋划分的真实户型标注集评估模型的泛化与误差。

本次真实GPU／CPU运行、旧方法对比、剩余退化与24份前端模型校验见 [识别验证记录](../docs/plan-recognition-validation.md)。十张自绘图的默认自动方式解析10/10、目标房间平均IoU0.847；它们是受控回归样本，当前并非所有图都改善，例如无门洞彩色家具图仍会漏分区。
