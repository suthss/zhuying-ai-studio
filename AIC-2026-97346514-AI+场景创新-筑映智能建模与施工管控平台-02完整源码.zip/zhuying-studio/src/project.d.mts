import type { HouseModel } from './types';
export function validateProject(value: unknown): HouseModel;
