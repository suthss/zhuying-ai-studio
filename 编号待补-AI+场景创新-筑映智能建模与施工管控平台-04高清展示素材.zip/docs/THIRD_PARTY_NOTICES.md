# 第三方材料来源与许可

更新时间：2026-10-05。当前户型识别模块按竞赛研究版本使用第三方材料；本文件记录出处，不构成完整的商业授权保证。商业使用或分发前，应分别核对代码、权重、数据和其他资产的许可范围。

## CubiCasa5k 户型识别网络

- 项目：[CubiCasa/CubiCasa5k](https://github.com/CubiCasa/CubiCasa5k)。
- 核对版本：`c34440266665a11f4484eb06cd2e4b7d72ad76c1`。
- 网络代码来源：[floortrans/models/hg_furukawa_original.py](https://github.com/CubiCasa/CubiCasa5k/blob/c34440266665a11f4484eb06cd2e4b7d72ad76c1/floortrans/models/hg_furukawa_original.py)。
- 预处理与类别来源：[floortrans/loaders/svg_loader.py](https://github.com/CubiCasa/CubiCasa5k/blob/c34440266665a11f4484eb06cd2e4b7d72ad76c1/floortrans/loaders/svg_loader.py)、[samples.ipynb](https://github.com/CubiCasa/CubiCasa5k/blob/c34440266665a11f4484eb06cd2e4b7d72ad76c1/samples.ipynb)。
- 上游许可：[LICENSE](https://github.com/CubiCasa/CubiCasa5k/blob/c34440266665a11f4484eb06cd2e4b7d72ad76c1/LICENSE)，**Creative Commons Attribution-NonCommercial 4.0 International（CC BY-NC 4.0）**，Copyright (c) 2019。
- 完整许可条款：[CC BY-NC 4.0 legal code](https://creativecommons.org/licenses/by-nc/4.0/legalcode.en)。

本地文件对应：

| 本地路径 | 内容与来源 |
|---|---|
| `backend/vendor/cubicasa/hg_furukawa_original.py` | 上游 `Residual` 与完整户型网络 class；保留结构，删除未用的 `model_1427` 导入及 `init_weights()`，加入来源说明 |
| `backend/vendor/cubicasa/LICENSE.txt` | 保留上游许可说明 |
| `backend/neural_plan.py` | 本项目输入/输出适配、44 通道 checkpoint 加载、CPU/GPU 设备选择和识别流程；几何后处理为本项目独立实现 |
| `scripts/download_plan_model.py` | 使用固定官方链接的权重下载脚本 |
| `models/cubicasa5k/model_best_val_loss_var.pkl` | 仅在本地缓存的官方权重，大文件由 Git 忽略 |

本项目对上游网络的修改用于适配现有后端：移除被最终权重覆盖的姿态估计初始化与其额外文件依赖，直接实例化最终 44 通道网络。输入、输出和 checkpoint 适配器属于本项目工程代码；上游来源与许可仍需保留，不把被改动的第三方网络重新标为不受限的原创代码。

预训练权重为上游 README 链接的 `model_best_val_loss_var.pkl`，Google Drive 文件 ID：`1gRB7ez1e4H7a9Y09lLqRuna0luZO5VRK`。[官方权重页](https://drive.google.com/file/d/1gRB7ez1e4H7a9Y09lLqRuna0luZO5VRK/view)的文件大小经 HTTP 响应核对为 208,651,193 bytes。没有发现上游为该权重单独授予不受限商用许可，因此本项目按研究用途保守处理，不能因为可以下载就声明可任意商业分发。

本工作区已显式下载并按 `weights_only=True` 加载真实 checkpoint。本地下载文件 SHA256 为 `dd20b4e1bf1d670f2125107b079df06958b1ccd36e49a464ab739aeb00b8e7a2`，下载脚本固定验证此哈希与长度；哈希用于复现本次文件完整性，不表示另有商用授权。

上游网络代码的固定版本 LICENSE 为 CC BY-NC 4.0。训练数据 CubiCasa5k 采用独立许可：Zenodo 记录 DOI:10.5281/zenodo.2613548 的官方 API 元数据标为 CC BY-NC-SA 4.0（2026-10-17 核对）。本副本不包含训练数据或权重，不把仓库代码许可推广为所有关联材料的许可；使用者应分别查阅各自条款。

### 推荐引用

Kalervo, Ahti; Ylioinas, Juha; Häikiö, Markus; Karhu, Antti; Kannala, Juho. **CubiCasa5K: A Dataset and an Improved Multi-Task Model for Floorplan Image Analysis**. 2019. [arXiv:1904.01920](https://arxiv.org/abs/1904.01920), [DOI](https://doi.org/10.48550/arXiv.1904.01920)。

```bibtex
@misc{kalervo2019cubicasa5k,
  title={CubiCasa5K: A Dataset and an Improved Multi-Task Model for Floorplan Image Analysis},
  author={Ahti Kalervo and Juha Ylioinas and Markus H\"aiki\"o and Antti Karhu and Juho Kannala},
  year={2019},
  eprint={1904.01920},
  archivePrefix={arXiv},
  primaryClass={cs.CV},
  doi={10.48550/arXiv.1904.01920}
}
```

## 研究参考方案

[方案核查](plan-recognition-research.md)还比较了 Yytsi/floorplan-to-3d、Raster2Seq、rbg-research/Floor-Plan-Detection 和 DeepFloorplan。记录这些方案不表示已将其全部代码或模型纳入本项目。

Yytsi 与 Raster2Seq 的代码/模型卡标 MIT，但其 CubiCasa 训练数据仍有独立的 CC BY-NC-SA 4.0 条件。rbg 仓库虽然整体标 MIT，部分 Blender 工具包含来自 GPL 项目的材料；DeepFloorplan 为 GPL-3.0。不能把某个仓库顶层许可推广为所有关联数据、权重或内嵌文件的许可。

## 公开示例图的运行验证

`tests/fixtures/plan-recognition/public-smoke/` 包含 Grebtsew / FloorplanToBlender3d 仓库的两张公开示例 PNG，用于检查带家具、文字与门窗图纸的实际运行结果。具体固定 commit、原始 URL、文件哈希、署名及上游 GPL-3.0 许可保存在该目录的 `sources.json`、`README.md` 与 `LICENSE.upstream.txt`。这里只使用图像作本地 smoke test，没有复制其 Blender 建模或 GPL 算法实现；两图没有独立几何真值，不用于宣称准确率。

## IITU 外立面施工时序影像

`public/facade-demo/` 的 6 张真实 WebP 抽帧来自 **Arman Keresh (2026), IITU Multi-Temporal Building Floor-Count Dataset: 12-Month Fixed-Viewpoint Construction Sequence**，Mendeley Data，Version 1。[原始数据集](https://data.mendeley.com/datasets/ww7rt2rnk6/1)，[DOI: 10.17632/ww7rt2rnk6.1](https://doi.org/10.17632/ww7rt2rnk6.1)，许可为 **[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)**。

本次素材日期为 2025-06-25、2025-08-31、2025-09-06、2025-10-21、2025-11-05 和 2026-04-25。筑映从相应公开视频的 1.0 秒处选帧，将原始 1920×1080 画面等比例缩小至 1600×900 并进行 WebP 压缩，保留摄像机时间；发布图片没有裁剪或生成式修改。日期依据为画面摄像机时间与源文件名前 8 位，时区未声明。重新展示或分发时请保留作者、数据来源、许可链接和修改说明。

各图源文件、抽帧秒数、尺寸、SHA-256 与署名保存在 [sources.json](../public/facade-demo/sources.json)；选帧理由、页面阶段说明与实拍差异、构图变化及评估边界见 [数据来源说明](facade-data-sources.md)。该版本未提供官方施工阶段、幕墙安装率或真实施工计划标签，样例中的人工复核与模拟计划属于本项目制作。



## 本地中文字体与设计技能（2026-10-06）

Noto Sans SC / Noto Serif SC 字体来自 [Google Fonts 官方仓库](https://github.com/google/fonts/tree/9710da1eacb3be272583c3224dcb70f9da6eadbb/ofl)，采用 SIL Open Font License 1.1。项目进行了字符子集、400–700 字重范围和 WOFF2 格式转换，原许可保存在 `public/fonts/`；源路径、哈希及修改说明见 [字体记录](../public/fonts/SOURCES.md)。运行时不依赖 Google Fonts 在线服务。

用户请求安装并使用 [UI UX Pro Max](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill/tree/477bcb28c9812b385cb51a4605ddf30d7b2266e2) 与 [Impeccable](https://github.com/pbakaus/impeccable/tree/ece38d9904b8a619b3f77cab476eacad09c4fb11)。技能位于本机 Codex skills 目录，作为设计工作流使用；应用没有打包其运行器或整个技能库。各自许可保留在安装目录。

## 波鸿大学 IC 楼室内翻修影像

`public/renovation-case/` 的照片来自 Christian Koch、Markus König、Christopher Kropp 的 **Data for: Interior construction state recognition with 4D BIM registered image sequences**，Mendeley Data，Version 2，2017-11-09 发布。[原始数据集](https://data.mendeley.com/datasets/rskgn5f8y8/2)，[DOI](https://doi.org/10.17632/rskgn5f8y8.2)，许可 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)。

筑映从原视频抽取典型帧、裁去播放器字幕边缘并导出 JPEG，同时保留完整源帧和三个片头的日期／房间编号证据。保留原视频彩色标注，未进行生成式修改。5-169 房间两期拍摄日期为 2012-11-27 和 2012-12-20；2-169 的 2012-12-20 照片作为另一个房间的独立参考。源文件、哈希、抽帧时间、裁剪坐标及修改说明保存在 `public/renovation-case/data.json`，详见 [案例来源](renovation-case-sources.md)。分发素材应保留作者、来源、许可及修改说明。


## 2026-10-17 源码发布副本补充

本副本只包含源码、公开案例与复现材料，不含真实密钥、个人数据库、日志、依赖安装目录或208,651,193字节的权重。CubiCasa代码、训练数据与权重的许可范围分别记录，权重仅提供官方下载和校验，不再分发。完整CC许可副本见根目录licenses/，总发布范围见NOTICE.md。原创部分未另外选择统一开源许可证。
