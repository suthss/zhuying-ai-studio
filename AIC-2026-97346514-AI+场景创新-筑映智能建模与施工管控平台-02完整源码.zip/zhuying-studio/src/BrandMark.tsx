import { useId } from 'react'

type BrandMarkProps = {
  size?: number
  className?: string
  decorative?: boolean
}

/** Original ZhuYing identity: an open architectural section with a folded floor. */
export default function BrandMark({ size = 36, className, decorative = true }: BrandMarkProps) {
  const titleId = useId()

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 48 48"
      width={size}
      height={size}
      fill="none"
      className={className}
      aria-hidden={decorative ? true : undefined}
      aria-labelledby={decorative ? undefined : titleId}
      role={decorative ? undefined : 'img'}
      focusable="false"
    >
      {!decorative && <title id={titleId}>筑映，空间折页</title>}
      <path
        fill="currentColor"
        d="M7 13 24 3l17 10-7 4-10-6-10 6v14l10 6 10-6v-6l7-4v14L24 45 7 35V13Z"
      />
    </svg>
  )
}
