---
name: 筑映
description: 空间设计与施工观察工作台
colors:
  charcoal: "#252823"
  brass: "#916c3d"
  paper: "#fffdf8"
  stone: "#f5f2eb"
  canvas: "#ebe8df"
  muted: "#62645b"
  divider: "#d9d6cb"
  hover: "#eeeadf"
  selected: "#e9dfcd"
  dark-ink: "#efece2"
  dark-paper: "#292c26"
  dark-panel: "#232620"
  dark-canvas: "#1d201b"
  dark-accent: "#c7a879"
  dark-primary-ink: "#242820"
typography:
  display:
    fontFamily: "Zhuying Serif, Noto Serif SC, Songti SC, serif"
    fontSize: "30px"
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: "normal"
  body:
    fontFamily: "Zhuying Sans, Noto Sans SC, PingFang SC, Microsoft YaHei, sans-serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.55
    letterSpacing: "normal"
  code:
    fontFamily: "Consolas, monospace"
    fontSize: "13px"
    fontWeight: 400
    lineHeight: 1.7
    letterSpacing: "normal"
rounded:
  control: "6px"
  canvas: "9px"
  dialog: "12px"
spacing:
  tight: "8px"
  group: "14px"
  panel: "24px"
components:
  button-primary:
    backgroundColor: "{colors.charcoal}"
    textColor: "{colors.paper}"
    rounded: "{rounded.control}"
    height: "40px"
    padding: "9px 14px"
  button-primary-hover:
    backgroundColor: "{colors.brass}"
    textColor: "{colors.paper}"
  button-secondary:
    backgroundColor: "transparent"
    textColor: "{colors.charcoal}"
    rounded: "{rounded.control}"
    height: "40px"
    padding: "9px 14px"
  button-studio-action:
    backgroundColor: "transparent"
    textColor: "{colors.charcoal}"
    rounded: "{rounded.control}"
    height: "40px"
    padding: "9px 14px"
---

# Design System: 筑映

## Overview

**Creative North Star: "模型与施工影像主导的建筑工作台"**

模型与施工影像主导画面，编辑工具安静地围绕它们。暖石白背景、纸白面板、炭灰文字与少量黄铜选中态，形成建筑材料样册的质感。大标题使用宋体，控件使用清晰的黑体；不把控制界面做成装饰性展示页。

默认视图减去重复模式切换、指标卡和多层说明条。导航用图标加文字，当前空间、即时材质预览、巡检入口和保存动作保持可见；项目操作、设计与施工的区别、数据来源和同步说明采用渐进展开。

**Key Characteristics:**

- 模型与真实影像主导画面。
- 中文宋黑双字体本地托管。
- 就近渐进展开详情。

## Colors

浅色令白天查看模型、照片和材料更清晰。`src/premium-theme.css` 是工作台的最终主题层，位于已有组件 CSS 之后。深色是用户可切换的另一套表面，不修改用户选定的墙面与地板颜色。

黄铜用于选中、焦点及次要强调，炭灰用于主操作。施工状态继续使用语义颜色，未知与模拟值保留明确的文字标签；设计选择的颜色不代表真实施工状态。

“AI 设计”与“记录巡检”使用炭灰文字、黄铜描边，hover 才加入选中表面。深色主按钮以浅色正文作为背景、深色主按钮文字作为前景；主题只控制界面表面与控件，不覆盖用户选定的墙面和地板颜色。

## Typography

`public/fonts/zhuying-sans.woff2` 与 `zhuying-serif.woff2` 来自 Google Fonts 的 Noto Sans SC / Noto Serif SC；本地可变字重 400–700。Sans 包含常用中文及源码字符，Serif 包含源码字符，缺字回退到设备中文字体。来源、许可、哈希和可复现脚本见 [字体说明](public/fonts/SOURCES.md)。

主工作台标题通常 30px（1280px 及以下 29px，宽屏 34px），手机 25px；项目库标题 38px，手机 30px；施工观察室标题 42px，手机 30px。界面控件一般 12–14px，默认行高 1.55；详细说明 13–14px、行高 1.75–1.8；手机主要输入框 16px。实际日期、数量和尺寸采用等宽数字，不把等宽字体当装饰。报告 JSON 使用 Consolas 或系统等宽字体，作为代码内容。

## Layout

桌面为 76px 导航、资源目录、可伸缩模型舞台和空间编辑面板；页眉 76px。宽屏资源／编辑面板为 228／330px，常规为 202／302px，1280px 下为 184／282px。模型填满中间余下空间，设计视图让出施工时间线的位置给模型；施工模式的时间线默认折叠。

小于 1100px 使用侧栏抽屉，每次只打开一侧。650px 及以下导航为 58px、页眉为 68px。施工观察的移动入口保留在导航，JSON 备份可从空间目录的“项目操作”打开。低高度窗口允许内容滚动，不裁掉操作。

施工观察室的照片与核对面板采用两列，内容最大宽度 1504px；920px 及以下变为一列，620px 及以下采用手机排布。项目库桌面以三列项目预览为主，窄屏收为一列。

## Elevation & Depth

面板以表面色与分隔线组织，不叠加卡片阴影。模型本身保留工作室灯光、真实落影和本地反射。悬浮工具用轻微、有偏移的阴影，弹窗遮罩保护当前任务焦点。

## Shapes

输入与按钮 5–6px 圆角、模型舞台 9px、弹窗 12px。材质块保留真实纹理，墙面色样是可选颜色而非装饰。保留专属“空间折页”SVG，不引入另一套图标风格。

## Components

导航各按钮同时显示图标与文字，选中态用淡黄铜背景。材质、门窗、施工三个面板入口保留。帮助可从导航打开；首次使用沿用功能引导。

按钮与材质切换使用约 180ms 的颜色反馈，弹窗使用约 220ms 的有限过渡。背景不循环动画；镜头过渡仍可被拖动打断，减少动态效果时关闭过渡。

项目库、设计问答、导入、结构编辑及施工观察沿用同一字体与表面。来源说明折叠；AI 建议待确认、状态未知、计划模拟及错误恢复仍清楚可见。

项目库状态标签使用小圆角和文字表达“当前工作台”“含示例数据”等事实。项目条目外层无阴影，预览区域保留圆角；施工核对面板则用细分隔线、纸白表面与 10px 圆角包围步骤内容。

## Do's and Don'ts

- **Do** 用真实三维模型、施工照片及可操作的材料样本承担主视觉。
- **Do** 优先保留操作标签与当前状态；长说明放到相关的详情里。
- **Do** 保持键盘焦点、错误、加载、禁用、未保存与确认状态可读。
- **Don't** 把减少小字解释成删除来源、未知状态或人工确认。
- **Don't** 让设计调整自动更改施工事实，不把示例安装比例当整栋工程进度。

本次使用的技能：UI UX Pro Max 固定提交 `477bcb28c9812b385cb51a4605ddf30d7b2266e2`；Impeccable 固定提交 `ece38d9904b8a619b3f77cab476eacad09c4fb11`。前者用于中文字体、色彩与可用性参考，后者用于 Operate 布局、信息精简及最终质检。既有工程与功能沿革见 [原设计记录](docs/DESIGN.md)。
