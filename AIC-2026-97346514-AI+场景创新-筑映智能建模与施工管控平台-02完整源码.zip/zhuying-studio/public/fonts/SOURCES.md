# Zhuying local UI font sources

The two locally hosted fonts are renamed, subset derivatives of the official Google Fonts Noto variable fonts. Both retain the SIL Open Font License 1.1. Original copyright and licensing records remain embedded; exact upstream OFL text is also served beside each font.

Google Fonts repository commit: `9710da1eacb3be272583c3224dcb70f9da6eadbb`.

## Rebuild

```powershell
.venv/Scripts/python.exe scripts/build_ui_fonts.py
```

Requires `fonttools[woff]==4.60.1` and `brotli` (the project's `.venv` already provides them). Downloads are cached in `artifacts/ui-fonts/upstream/`; cached and downloaded bytes must match pinned SHA-256 values. WOFF2 generation uses the installed Brotli encoder, so byte-identical compression also requires the same Brotli version. No remote font request is needed at runtime.

This build scanned 49 UTF-8 text files in `src/` (aggregate source SHA-256 `54571ff3762b0402a74b674b84e8a817d8c49223f6fab6a038975ba6e385777b`). Rebuild after adding UI text. Printable ASCII U+0020–U+007E is always included. All font-supported characters occurring in the scanned source, including Han, Chinese punctuation and symbols, are retained. Sans additionally includes all 6,763 GB 2312 Han characters. Both fonts retain a continuous `wght` axis from 400 through 700 with default 400. Glyph hints are removed; OpenType layout features and their dependent glyphs are retained.

## Coverage and fallback

These are subsets, not complete Unicode or full Noto CJK distributions. Serif is sized for current UI text, so user-entered names and newly introduced Chinese characters may require fallback. Sans covers the GB 2312 Han set plus current source text; uncommon Han outside that set, Japanese/Korean text, emoji and unsupported symbols can fall back to the system fonts in the CSS font stack. The source coverage manifest lists characters absent from upstream; these are intentionally left to fallback rather than replaced or fabricated. Font loading uses the site's `font-display: swap` policy.

## Pinned upstream files

### Noto Sans SC → Zhuying Sans

- Noto CJK source repository: [notofonts/noto-cjk](https://github.com/notofonts/noto-cjk/tree/523d033d6cb47f4a80c58a35753646f5c3608a78), source commit `523d033d6cb47f4a80c58a35753646f5c3608a78` (recorded in Google Fonts `METADATA.pb`).
- [NotoSansSC[wght].ttf](https://raw.githubusercontent.com/google/fonts/9710da1eacb3be272583c3224dcb70f9da6eadbb/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf), SHA-256 `a3041811a78c361b1de50f953c805e0244951c21c5bd412f7232ef0d899af0da`.
- [OFL.txt](https://raw.githubusercontent.com/google/fonts/9710da1eacb3be272583c3224dcb70f9da6eadbb/ofl/notosanssc/OFL.txt), SHA-256 `1c05c68c34f9708415aada51f17e1b0092d2cea709bf4a94cd38114f9e73d7d9`.
- [METADATA.pb](https://raw.githubusercontent.com/google/fonts/9710da1eacb3be272583c3224dcb70f9da6eadbb/ofl/notosanssc/METADATA.pb), SHA-256 `c6c4bdb785793b2de1da177caeeffcd0c90d7680bdab2de8f88ab45007bc59bc`.
- Output: `public/fonts/zhuying-sans.woff2`, 1,806,268 bytes (1.723 MiB), 6,883 mapped codepoints, 7,315 glyphs. SHA-256 `b46496fec2e2df85c33cadf592b4d7fd060cf1c5dc654b35b8f61e20a08f6f45`.

### Noto Serif SC → Zhuying Serif

- Noto CJK source repository: [notofonts/noto-cjk](https://github.com/notofonts/noto-cjk/tree/985fa52c81c1d6692ccdd82bc3656e8fb932fd89), source commit `985fa52c81c1d6692ccdd82bc3656e8fb932fd89` (recorded in Google Fonts `METADATA.pb`).
- [NotoSerifSC[wght].ttf](https://raw.githubusercontent.com/google/fonts/9710da1eacb3be272583c3224dcb70f9da6eadbb/ofl/notoserifsc/NotoSerifSC%5Bwght%5D.ttf), SHA-256 `050080d9255a86808f2945bffac582b31ef32bc36411ce29563b4961670c66f9`.
- [OFL.txt](https://raw.githubusercontent.com/google/fonts/9710da1eacb3be272583c3224dcb70f9da6eadbb/ofl/notoserifsc/OFL.txt), SHA-256 `5e0da210fb04058a8c0087985d2d456b931c2579811a49655721d3cf0c36b6d6`.
- [METADATA.pb](https://raw.githubusercontent.com/google/fonts/9710da1eacb3be272583c3224dcb70f9da6eadbb/ofl/notoserifsc/METADATA.pb), SHA-256 `e0c253c6f850fc3ef6e7fc398361133dd55acc408c931822a3f69cfac08554c2`.
- Output: `public/fonts/zhuying-serif.woff2`, 338,224 bytes (0.323 MiB), 911 mapped codepoints, 1,335 glyphs. SHA-256 `54d0a2d54b99b48c2ee1bcadd9a601ab34c54dfb2ea505849b60659ecbcdadbd`.

Build details and missing-source codepoints are in `manifest.json`.
