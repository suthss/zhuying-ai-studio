import { isRoomDesign } from './design.mjs';
import { getOpeningErrors } from './openings.mjs';
import { getFurnitureErrors, getFurnitureSchemaErrors, validateDesignBrief } from './furnishing.mjs';
import { validateIssueTracker } from './issues.mjs';
import { validateBudgetConfig } from './budget.mjs';
import { validateMeasurements } from './layout-audit.mjs';
import { WORK_TYPES, validCalendarDate, validateEvidenceRecords } from './progress.mjs';

const stages = new Set(['unknown','not_started','in_progress','complete']);
const number = (v,lo,hi) => typeof v === 'number' && Number.isFinite(v) && v >= lo && v <= hi;
const text = v => typeof v === 'string' && v.length > 0 && v.length <= 160;
const point = p => Array.isArray(p) && p.length === 2 && p.every(v=>number(v,0,100));
const date = v => v === '' || validCalendarDate(v);
const fail = () => { throw new Error('项目格式或几何数据无效，请使用筑映导出的完整项目文件。'); };
const unique = rows => new Set(rows.map(r=>r.id)).size === rows.length;
export function validateProject(m) {
  if (!m || !text(m.id) || !text(m.name) || !number(m.width,.1,100) || !number(m.depth,.1,100) || !number(m.height,2,6) || !['demo','opencv','manual'].includes(m.source)) fail();
  if (!Array.isArray(m.walls) || !m.walls.length || m.walls.length>500 || !Array.isArray(m.rooms) || !m.rooms.length || m.rooms.length>100 || !Array.isArray(m.openings) || m.openings.length>500 || !Array.isArray(m.warnings) || m.warnings.length>100 || !m.warnings.every(v=>typeof v==='string')) fail();
  if (!unique(m.walls) || !unique(m.rooms) || !unique(m.openings)) fail();
  if (m.meta!==undefined && (!m.meta||typeof m.meta!=='object'||Array.isArray(m.meta))) fail();
  if (m.meta?.layoutReviewPending!==undefined && typeof m.meta.layoutReviewPending!=='boolean') fail();
  for (const w of m.walls) if(!text(w.id)||!point(w.start)||!point(w.end)||Math.hypot(w.end[0]-w.start[0],w.end[1]-w.start[1])<.01||!number(w.thickness,.02,2)||(w.height!==undefined&&!number(w.height,.1,m.height)))fail();
  for (const o of m.openings) {
    if(!text(o.id)||getOpeningErrors(m,o).length)fail();
  }
  for (const r of m.rooms) {
    if(!text(r.id)||!text(r.name)||!Array.isArray(r.polygon)||r.polygon.length<3||r.polygon.length>200||!r.polygon.every(point)||!number(r.area,.001,10000)||!text(r.material)||!number(r.progress,0,100))fail();
    if(r.design!==undefined&&!isRoomDesign(r.design))fail();
    if (!r.tasks || typeof r.tasks !== 'object' || Array.isArray(r.tasks) || !r.tasks.floor || !r.tasks.wall) fail();
    for (const type of Object.keys(r.tasks)) {
      const task=r.tasks[type];
      if (!WORK_TYPES.some(work=>work.id===type) || !task || typeof task!=='object' || Array.isArray(task) || !stages.has(task.stage)
        || !stages.has(task.plannedStage) || !date(task.dueDate) || (task.enabled!==undefined&&typeof task.enabled!=='boolean')
        || (task.note!==undefined&&(typeof task.note!=='string'||task.note.length>12000))) fail();
    }
    if(r.evidence!==undefined) {
      try { validateEvidenceRecords(r.evidence); } catch { fail(); }
    }
  }
  if(m.furniture!==undefined) {
    if(!Array.isArray(m.furniture)||m.furniture.length>300||m.furniture.some(item=>!item||typeof item!=='object')||!unique(m.furniture))fail();
    for(const item of m.furniture)if((m.meta?.layoutReviewPending===true?getFurnitureSchemaErrors(m,item):getFurnitureErrors(m,item)).length)fail();
  }
  if(m.designBrief!==undefined) {
    try {validateDesignBrief(m,m.designBrief);}catch {fail();}
  }
  if(m.meta?.issueTracker!==undefined)validateIssueTracker(m.meta.issueTracker,m);
  if(m.meta?.materialBudget!==undefined)validateBudgetConfig(m.meta.materialBudget,m);
  if(m.meta?.measurements!==undefined)validateMeasurements(m.meta.measurements,m);
  return m;
}
