import type { FloorFinish, HouseModel, Room, RoomDesign } from './types';

export interface FloorFinishPreset {
  readonly id: FloorFinish;
  readonly label: string;
  readonly description: string;
  readonly color: string;
}
export interface WallColorPreset {
  readonly id: string;
  readonly label: string;
  readonly color: string;
}

export const FLOOR_FINISHES: readonly FloorFinishPreset[];
export const WALL_COLORS: readonly WallColorPreset[];
export function isRoomDesign(value: unknown): value is RoomDesign;
export function resolveRoomDesign(room: Room): RoomDesign;
export function updateRoomDesign(model: HouseModel, roomId: string, patch: Partial<RoomDesign>): HouseModel;
export function resetRoomDesign(model: HouseModel, roomId: string): HouseModel;
export function preserveRoomDesign(previous: HouseModel, next: HouseModel): HouseModel;
