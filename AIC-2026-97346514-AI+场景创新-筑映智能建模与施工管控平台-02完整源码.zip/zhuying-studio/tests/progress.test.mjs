import test from 'node:test';
import assert from 'node:assert/strict';
import { WORK_TYPES, activeWorkTypes, stageLabel, confirmedProgress, isDelayed, getRoomAlerts, latestEvidence,
  roomAtDate, applyInspection, removeInspection, validateEvidenceRecords } from '../src/progress.mjs';

function task(stage, plannedStage = 'complete', dueDate = '2026-10-03') {
  return { stage, plannedStage, dueDate };
}

function room(floor, wall) {
  return {
    id: 'living', name: '客厅', polygon: [[0, 0], [4, 0], [4, 3], [0, 3]],
    area: 12, material: 'wood', progress: 99, tasks: { floor, wall },
  };
}

function summary(percent, upperPercent, known, completed, total = 2) {
  return { percent, upperPercent, coverage: total ? known / total : 0, completed, known, unknown: total - known, total };
}
const image = 'data:image/png;base64,AAAA';
function evidence(id, date, stage, workType = 'floor', extra = {}) {
  return { id, date, stage, workType, image, summary: '可见施工状态', confirmed: true, source: 'manual', ...extra };
}

test('施工阶段使用明确的中文名称', () => {
  assert.equal(stageLabel('not_started'), '未开始');
  assert.equal(stageLabel('in_progress'), '施工中');
  assert.equal(stageLabel('complete'), '已完成');
  assert.equal(stageLabel('unknown'), '待复核');
});

test('完整证据的进度由地面和墙面任务计算，不使用缓存进度', () => {
  assert.deepEqual(confirmedProgress(room(task('complete'), task('in_progress'))), summary(75, 75, 2, 1));
  assert.deepEqual(confirmedProgress(room(task('not_started'), task('not_started'))), summary(0, 0, 2, 0));
});

test('未知工序计入分母，给出阶段下上界及确认覆盖率', () => {
  assert.deepEqual(confirmedProgress(room(task('complete'), task('unknown'))), summary(50, 100, 1, 1));
  assert.deepEqual(confirmedProgress(room(task('unknown'), task('in_progress'))), summary(25, 75, 1, 0));
  assert.deepEqual(confirmedProgress(room(task('unknown'), task('unknown'))), summary(null, 100, 0, 0));
});

test('人工修改任一任务后，进度立即随真实状态重新计算', () => {
  const current = room(task('not_started'), task('not_started'));
  current.tasks.floor.stage = 'in_progress';
  assert.deepEqual(confirmedProgress(current), summary(25, 25, 2, 0));
  current.tasks.wall.stage = 'complete';
  assert.deepEqual(confirmedProgress(current), summary(75, 75, 2, 1));
  current.tasks.floor.stage = 'complete';
  assert.deepEqual(confirmedProgress(current), summary(100, 100, 2, 2));
});

test('计划截止当天不报警，过期且落后于计划阶段才报警', () => {
  assert.equal(isDelayed(task('in_progress'), '2026-10-02'), false);
  assert.equal(isDelayed(task('in_progress'), '2026-10-03'), false);
  assert.equal(isDelayed(task('in_progress'), '2026-10-04'), true);
  assert.equal(isDelayed(task('complete'), '2026-10-04'), false);
  assert.equal(isDelayed(task('in_progress', 'in_progress'), '2026-10-04'), false);
  assert.equal(isDelayed(task('complete', 'in_progress'), '2026-10-04'), false);
  assert.equal(isDelayed(task('not_started', 'in_progress'), '2026-10-04'), true);
});

test('实际或计划状态未知以及无效日期不生成延期警报', () => {
  assert.equal(isDelayed(task('unknown'), '2026-10-04'), false);
  assert.equal(isDelayed(task('not_started', 'unknown'), '2026-10-04'), false);
  assert.equal(isDelayed(task('not_started', 'complete', ''), '2026-10-04'), false);
  assert.equal(isDelayed(task('not_started'), 'invalid-date'), false);
  assert.equal(isDelayed(task('not_started', 'complete', '2026-02-30'), '2026-10-04'), false);
});

test('跨月及跨年日期按日历顺序比较', () => {
  assert.equal(isDelayed(task('not_started', 'complete', '2026-09-30'), '2026-10-01'), true);
  assert.equal(isDelayed(task('not_started', 'complete', '2026-12-31'), '2027-01-01'), true);
});

test('两个工序单独生成警报，未知且过期改为待补充确认警报', () => {
  const current = room(task('not_started'), task('in_progress'));
  assert.deepEqual(getRoomAlerts(current, '2026-10-04'), [
    { workType: 'floor', title: '地面施工进度滞后', kind: 'delayed' },
    { workType: 'wall', title: '墙面施工进度滞后', kind: 'delayed' },
  ]);
  current.tasks.floor.stage = 'complete';
  assert.deepEqual(getRoomAlerts(current, '2026-10-04'), [
    { workType: 'wall', title: '墙面施工进度滞后', kind: 'delayed' },
  ]);
  current.tasks.wall.stage = 'unknown';
  assert.deepEqual(getRoomAlerts(current, '2026-10-04'), [
    { workType: 'wall', title: '墙面已过计划日期，待补充确认记录', kind: 'missing_evidence' },
  ]);
});
test('同日追加的确认记录覆盖旧状态，晚日期优先于录入顺序', () => {
  const records=[{id:'a',date:'2026-10-04',confirmed:true,workType:'floor',stage:'not_started'},{id:'b',date:'2026-10-04',confirmed:true,workType:'floor',stage:'complete'},{id:'old',date:'2026-10-03',confirmed:true,workType:'floor',stage:'in_progress'}];
  assert.equal(latestEvidence(records,'floor').id,'b');
  assert.equal(latestEvidence(records,'wall'),undefined);
  assert.equal(records[0].id,'a');
});

test('旧项目默认两个工序，可选工序仅有任务且未禁用时加入统计', () => {
  const current = room(task('complete'), task('unknown'));
  assert.deepEqual(activeWorkTypes(current), ['floor', 'wall']);
  current.tasks.electrical = task('complete');
  current.tasks.waterproof = { ...task('unknown'), enabled: false };
  assert.deepEqual(activeWorkTypes(current), ['electrical', 'floor', 'wall']);
  assert.deepEqual(confirmedProgress(current), summary(2 / 3 * 100, 100, 2, 2, 3));
  current.tasks.floor.enabled = false;
  current.tasks.wall.enabled = false;
  current.tasks.electrical.enabled = false;
  assert.deepEqual(confirmedProgress(current), summary(null, null, 0, 0, 0));
  assert.equal(WORK_TYPES.length, 6);
  assert.ok(WORK_TYPES.every(work => work.id && work.label && work.shortLabel && work.description));
});

test('六工序独立统计，禁用工序既不稀释进度也不报警', () => {
  const current = room(task('complete'), task('unknown'));
  current.tasks.electrical = task('complete');
  current.tasks.waterproof = task('in_progress');
  current.tasks.masonry = task('not_started');
  current.tasks.carpentry = { ...task('unknown'), enabled: false };
  assert.deepEqual(confirmedProgress(current), summary(50, 70, 4, 2, 5));
  assert.deepEqual(getRoomAlerts(current, '2026-10-04').map(alert => [alert.workType, alert.kind]), [
    ['waterproof', 'delayed'], ['masonry', 'delayed'], ['wall', 'missing_evidence'],
  ]);
});

test('日期回放只使用截止确认记录，保留计划、启用、几何和设计且不修改输入', () => {
  const current = room(task('complete'), task('complete'));
  current.tasks.electrical = { ...task('complete'), enabled: true, note: '原计划备注' };
  current.design = { floorFinish: 'oak', wallColor: '#f4f0e8', wallFinish: 'paint', floorDirection: 0 };
  current.evidence = [evidence('late', '2026-10-06', 'complete'), evidence('early', '2026-10-02', 'not_started'),
    evidence('first', '2026-10-04', 'in_progress'), evidence('last', '2026-10-04', 'complete'),
    evidence('suggested', '2026-10-04', 'complete', 'wall', { confirmed: false })];
  const original = structuredClone(current), historical = roomAtDate(current, '2026-10-04');
  assert.equal(historical.tasks.floor.stage, 'complete');
  assert.equal(historical.tasks.wall.stage, 'unknown');
  assert.equal(historical.tasks.electrical.stage, 'unknown');
  assert.deepEqual(historical.tasks.electrical, { ...current.tasks.electrical, stage: 'unknown' });
  assert.deepEqual(historical.design, current.design);
  assert.deepEqual(historical.polygon, current.polygon);
  assert.deepEqual(confirmedProgress(current, '2026-10-04'), summary(1 / 3 * 100, 100, 1, 1, 3));
  assert.deepEqual(confirmedProgress(current, '2026-10-01'), summary(null, 100, 0, 0, 3));
  historical.tasks.floor.dueDate = '2027-01-01'; historical.polygon[0][0] = 99;
  assert.deepEqual(current, original);
  assert.equal(latestEvidence(current.evidence, 'floor', '2026-10-04').id, 'last');
  assert.equal(latestEvidence(current.evidence, 'floor', '2026-10-01'), undefined);
});

test('回放和证据查询不会把无效日期当作最新事实', () => {
  const current = room(task('complete'), task('complete'));
  for (const invalid of ['2026-02-30', '2026-13-01', 'not-a-date', '2026-1-01', '']) {
    assert.throws(() => roomAtDate(current, invalid));
    assert.throws(() => confirmedProgress(current, invalid));
    assert.equal(latestEvidence([evidence('a', '2026-10-04', 'complete')], 'floor', invalid), undefined);
  }
  assert.equal(latestEvidence([evidence('invalid', '2026-02-30', 'complete'), evidence('valid', '2026-02-28', 'in_progress')], 'floor').id, 'valid');
});

test('追加早日期或未确认记录不覆盖较新确认状态，同日追加生效且不共享输入', () => {
  const original = room(task('unknown'), task('unknown'));
  const input = evidence('latest', '2026-10-05', 'complete', 'floor', { aiStage: 'in_progress' });
  let result = applyInspection(original, input);
  result = applyInspection(result, evidence('old', '2026-10-03', 'not_started'));
  result = applyInspection(result, evidence('draft', '2026-10-06', 'not_started', 'floor', { confirmed: false }));
  assert.equal(result.tasks.floor.stage, 'complete');
  assert.equal(result.evidence[0].aiStage, 'in_progress');
  const previous = structuredClone(result);
  const sameDay = applyInspection(result, evidence('corrected', '2026-10-05', 'in_progress'));
  assert.equal(sameDay.tasks.floor.stage, 'in_progress');
  assert.deepEqual(result, previous);
  input.summary = '外部修改';
  assert.equal(result.evidence[0].summary, '可见施工状态');
  assert.equal(original.tasks.floor.stage, 'unknown');
  assert.equal(original.evidence, undefined);
  assert.throws(() => applyInspection(result, evidence('latest', '2026-10-07', 'complete')));
});

test('首次额外工序巡检创建任务，计划默认未知，既有禁用和计划设置不被改写', () => {
  const original = room(task('unknown'), task('unknown'));
  const result = applyInspection(original, evidence('mep', '2026-10-05', 'complete', 'electrical'));
  assert.deepEqual(result.tasks.electrical, { stage: 'complete', plannedStage: 'unknown', dueDate: '', enabled: true });
  result.tasks.electrical.enabled = false;
  result.tasks.electrical.dueDate = '2026-10-10';
  const next = applyInspection(result, evidence('mep2', '2026-10-06', 'in_progress', 'electrical'));
  assert.equal(next.tasks.electrical.enabled, false);
  assert.equal(next.tasks.electrical.dueDate, '2026-10-10');
});

test('删除最新记录恢复更早确认状态，最后一条删除回待核对并清除依赖对比', () => {
  const current = room(task('complete'), task('complete'));
  current.evidence = [evidence('first', '2026-10-02', 'in_progress'), evidence('second', '2026-10-04', 'complete', 'floor', {
    comparison: { previousEvidenceId: 'first', previousDate: '2026-10-02', summary: '铺设推进', change: 'advanced', source: 'qwen' },
  })];
  const original = structuredClone(current);
  const removedLatest = removeInspection(current, 'second');
  assert.equal(removedLatest.tasks.floor.stage, 'in_progress');
  assert.equal(removedLatest.tasks.wall.stage, 'complete');
  const empty = removeInspection(removedLatest, 'first');
  assert.equal(empty.tasks.floor.stage, 'unknown');
  assert.deepEqual(confirmedProgress(empty), summary(50, 100, 1, 1));
  const deletedPrevious = removeInspection(current, 'first');
  assert.equal(deletedPrevious.evidence[0].comparison, undefined);
  assert.equal(deletedPrevious.tasks.floor.stage, 'complete');
  assert.doesNotThrow(() => validateEvidenceRecords(deletedPrevious.evidence));
  assert.deepEqual(current, original);
  const missing = removeInspection(current, 'missing');
  assert.deepEqual(missing, current);
  assert.notStrictEqual(missing, current);
});

test('未确认草稿的追加和删除保留旧项目人工状态，不启用不存在的工序', () => {
  const legacy = room(task('complete'), task('in_progress'));
  const original = structuredClone(legacy);
  const floorDraft = applyInspection(legacy, evidence('draft','2026-10-04','unknown','floor',{confirmed:false}));
  assert.equal(floorDraft.tasks.floor.stage, 'complete');
  assert.equal(floorDraft.progress, legacy.progress);
  const restored = removeInspection(floorDraft,'draft');
  assert.deepEqual(restored.tasks, legacy.tasks);
  const extraDraft = applyInspection(legacy,evidence('mep-draft','2026-10-04','complete','electrical',{confirmed:false}));
  assert.equal(extraDraft.tasks.electrical,undefined);
  assert.deepEqual(activeWorkTypes(extraDraft),['floor','wall']);
  assert.deepEqual(legacy,original);
});

test('追加、删除、回放均保留房间设计和全部计划，且结果不会共享可变嵌套对象', () => {
  const original = room({ ...task('unknown'), enabled:true, note:'地面计划' }, { ...task('complete'), enabled:false, note:'墙面计划' });
  original.tasks.waterproof = { ...task('in_progress','in_progress','2026-10-20'), enabled:true, note:'闭水试验后人工验收' };
  original.design = { floorFinish:'walnut', wallColor:'#f4f0e8', wallFinish:'plaster', floorDirection:90 };
  // The room transformer preserves auxiliary authored data, while actual
  // project-level furniture lives outside the room and is never modified here.
  original.authoredMetadata = { furnitureReferences:['bed-1'], custom:{value:'保留'} };
  const snapshot = structuredClone(original);
  const added = applyInspection(original,evidence('add','2026-10-04','in_progress'));
  for (const result of [added,removeInspection(added,'add'),roomAtDate(added,'2026-10-03')]) {
    assert.deepEqual(result.design,original.design);
    assert.deepEqual(result.polygon,original.polygon);
    assert.deepEqual(result.authoredMetadata,original.authoredMetadata);
    for (const type of ['floor','wall','waterproof']) {
      for (const key of ['plannedStage','dueDate','note','enabled']) assert.equal(result.tasks[type][key],original.tasks[type][key]);
    }
    result.design.wallColor='#ffffff';result.authoredMetadata.custom.value='外部修改';result.tasks.floor.note='外部修改';
  }
  assert.deepEqual(original,snapshot);
});

test('禁用全部工序后回放没有假百分比、没有警报，并保留真实证据', () => {
  const current = room({ ...task('complete'), enabled:false }, { ...task('complete'), enabled:false });
  current.evidence=[evidence('floor','2026-10-04','complete')];
  const historical=roomAtDate(current,'2026-10-04');
  assert.deepEqual(confirmedProgress(historical),summary(null,null,0,0,0));
  assert.deepEqual(getRoomAlerts(historical,'2026-10-05'),[]);
  assert.deepEqual(historical.evidence,current.evidence);
  assert.equal(historical.tasks.floor.stage,'complete');
  assert.equal(historical.tasks.wall.stage,'unknown');
});
