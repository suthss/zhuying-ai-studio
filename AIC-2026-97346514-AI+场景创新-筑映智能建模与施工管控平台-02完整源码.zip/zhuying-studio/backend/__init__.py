"""Local floor-plan geometry and construction evidence services."""
