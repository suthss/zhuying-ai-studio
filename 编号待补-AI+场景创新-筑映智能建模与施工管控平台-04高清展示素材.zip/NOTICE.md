# 来源、许可与发布范围

本副本为筑映平台的竞赛研究源码材料。原创源码与文档由其权利人保留权利，未另行选择覆盖全仓库的统一开源许可证。发布副本保留第三方内容的原署名、许可与修改记录，不把第三方代码、数据或权重宣称为完全原创，也不统一改标为 MIT。

| 材料 | 所在位置 | 许可及保留说明 |
| --- | --- | --- |
| CubiCasa5K 网络代码 | `backend/vendor/cubicasa/` | CubiCasa5k，Copyright (c) 2019，CC BY-NC 4.0。固定 commit `c34440266665a11f4484eb06cd2e4b7d72ad76c1`。移除未用初始化和额外导入，保留结构与出处。上游原说明见目录内 `LICENSE.txt`，完整条款见 `licenses/CC-BY-NC-4.0.txt`。 |
| CubiCasa5K 训练数据 | **未打包** | Zenodo DOI:10.5281/zenodo.2613548 的元数据许可为 CC BY-NC-SA 4.0，与代码许可分开记录。 |
| CubiCasa5K 预训练权重 | **未打包** | 上游公开下载不等于独立再分发或商业授权。仅提供上游下载脚本、文件长度和 SHA-256 校验。 |
| 两张公开户型图 | `tests/fixtures/plan-recognition/public-smoke/` | Grebtsew / FloorplanToBlender3d，COPYRIGHT 2021，上游 GPL-3.0。图片未修改，完整上游许可、固定版本与哈希随图保存。无独立几何真值，只作 smoke test。没有把上游 Blender 算法复制进生产代码。 |
| 室内翻修照片 | `public/renovation-case/` | Christian Koch、Markus König、Christopher Kropp (2017)，Mendeley Data V2，DOI:10.17632/rskgn5f8y8.2，CC BY 4.0。抽帧及裁切，保留原彩色标注、完整源帧和日期/房间证据。具体修改与哈希见 `data.json`。 |
| IITU 外立面照片 | `public/facade-demo/` | Arman Keresh (2026)，Mendeley Data V1，DOI:10.17632/ww7rt2rnk6.1，CC BY 4.0。由视频第1秒抽帧，等比例缩放及 WebP 压缩，保留摄像机时间。来源与哈希见 `sources.json`。观察单元为本项目人工划分，计划为模拟。 |
| Noto 衍生本地字体 | `public/fonts/` | SIL Open Font License 1.1，源字体经字符子集与 WOFF2 转换并重命名。完整 OFL、固定源版本、哈希和修改见该目录。 |

CC BY 4.0 完整条款位于 `licenses/CC-BY-4.0.txt`。CubiCasa 原始数据不在包中，仍保留其独立许可记录和 `licenses/CC-BY-NC-SA-4.0.txt` 供核对。依赖由 npm / pip 从上游安装，不随本副本重打包，应继续遵守每项依赖的许可证。

## 权重下载与校验

官方项目：https://github.com/CubiCasa/CubiCasa5k

官方权重页：https://drive.google.com/file/d/1gRB7ez1e4H7a9Y09lLqRuna0luZO5VRK/view

下载工具：`python scripts/download_plan_model.py`

文件：`models/cubicasa5k/model_best_val_loss_var.pkl`

长度：208,651,193 字节。

SHA-256：`dd20b4e1bf1d670f2125107b079df06958b1ccd36e49a464ab739aeb00b8e7a2`

使用者应自行取得上游文件并核对适用条款。本副本没有训练该基础模型，没有附带商业或不受限分发授权。

## 本副本不包含

真实 `backend/.env` 或其他密钥文件、SQLite 业务数据库、个人上传、模型权重、Git 历史、依赖安装目录、Python 环境、日志、缓存、构建输出、答辩或方案制作的中间文件。空密钥样例 `.env.example` 可以复制后在本地配置。

## 来源链接

- 网络代码许可：https://github.com/CubiCasa/CubiCasa5k/blob/c34440266665a11f4484eb06cd2e4b7d72ad76c1/LICENSE
- 训练数据：https://doi.org/10.5281/zenodo.2613548
- 公开测试图：https://github.com/Grebtsew/FloorplanToBlender3d/tree/2da4c9532e9866b025c67aee17f87ff7e0b8db98
- 室内案例：https://doi.org/10.17632/rskgn5f8y8.2
- 外立面案例：https://doi.org/10.17632/ww7rt2rnk6.1

来源及许可核对日期：2026-10-17。更详细的来源和改动见 `docs/THIRD_PARTY_NOTICES.md`。
