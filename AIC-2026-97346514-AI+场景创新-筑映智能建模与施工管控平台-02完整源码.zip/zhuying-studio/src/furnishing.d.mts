import type { DesignBrief, FurnitureItem, FurnitureKind, HouseModel, RoomUse } from './types';

/** Guesses only; the question form must let the user confirm every room use. */
export function createDesignBrief(model: HouseModel): DesignBrief;
export function getDefaultFurniture(use: RoomUse, needs?: string[]): FurnitureKind[];
export function validateDesignBrief(model: HouseModel, value: unknown): DesignBrief;
export function generateFurnishedModel(model: HouseModel, brief: DesignBrief): { model: HouseModel; warnings: string[] };
export function getFurnitureErrors(model: HouseModel, item: unknown): string[];
export function getFurnitureSchemaErrors(model: HouseModel, item: unknown): string[];
/** A boundary-checked, non-blocking rug rendered beneath the furniture. */
export function getRoomRug(model: HouseModel, roomId: string): { position: [number, number]; size: [number, number, number]; rotation: number; color: string } | null;
