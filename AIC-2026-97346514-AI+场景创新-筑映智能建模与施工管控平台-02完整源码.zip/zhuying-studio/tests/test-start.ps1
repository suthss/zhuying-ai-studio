﻿$ErrorActionPreference = 'Stop'
$studioTestPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'start.ps1'
$global:studioTestPython = Join-Path (Split-Path $PSScriptRoot -Parent) '.venv\Scripts\python.exe'
# Command mocks prevent this test from starting or stopping real processes.
function Invoke-RestMethod { param($Uri, $TimeoutSec) @{ algorithm = 'hybrid-floorplan-v2' } }
function Invoke-WebRequest {
    param([switch]$UseBasicParsing, $Uri, $TimeoutSec)
    if ($Uri -match ':5174$') {
        $studioMockHtml = [Text.Encoding]::UTF8.GetBytes('<title>筑映 · 三维装修工作台</title>')
        @{ Content = 'misdecoded HTML'; RawContentStream = [IO.MemoryStream]::new($studioMockHtml) }
    }
    else { @{ Content = '<title>Other app</title>' } }
}
function Get-NetTCPConnection {
    param($State, $LocalPort, $ErrorAction)
    if ($LocalPort -eq 8000) {
        if ($global:studioMockPortBusy) { [pscustomobject]@{LocalPort=8000; OwningProcess=62001} }
        return
    }
    if ($global:studioMockPortBusy) { [pscustomobject]@{LocalPort=8000; OwningProcess=62001} }
    if (!$global:studioMockFreeFirstPort) { [pscustomobject]@{LocalPort=5173; OwningProcess=61000} }
    [pscustomobject]@{LocalPort=5174; OwningProcess=61001}
}
function Get-CimInstance {
    param($ClassName, $Filter)
    if ($Filter -eq 'ProcessId = 62001') {
        [pscustomobject]@{ProcessId=62001; ParentProcessId=62000; ExecutablePath='C:\runtime\python.exe'; CommandLine='python.exe -m uvicorn backend.app:app --port 8000'}
    } elseif ($Filter -eq 'ProcessId = 62000') {
        $studioMockExecutable = if ($global:studioMockOwned) { $global:studioTestPython } else { 'C:\other-project\.venv\Scripts\python.exe' }
        [pscustomobject]@{ProcessId=62000; ParentProcessId=0; ExecutablePath=$studioMockExecutable; CommandLine='python.exe -m uvicorn backend.app:app --port 8000'}
    }
}
function Get-Process {
    param($Id, $ErrorAction)
    if ($global:studioMockStopped -notcontains $Id) { [pscustomobject]@{Id=$Id} }
}
function Stop-Process {
    param($Id, $ErrorAction)
    $global:studioMockStopped += $Id
    $global:studioMockPortBusy=$false
}
function Start-Process {
    param($FilePath, $ArgumentList, $WorkingDirectory, $WindowStyle, $RedirectStandardOutput, $RedirectStandardError)
    if ($WindowStyle -ne 'Hidden') { throw 'Background launch must be hidden' }
    $global:studioMockStarted += ,$ArgumentList
}
function Get-Command { param($Name) [pscustomobject]@{Source='C:\runtime\node.exe'} }

$global:studioMockOwned=$true; $global:studioMockPortBusy=$true
$global:studioMockStopped=@(); $global:studioMockStarted=@()
& $studioTestPath -RestartBackend
if (($studioMockStopped -join ',') -ne '62001,62000' -or $studioMockStarted.Count -ne 1 -or $studioMockStarted[0] -notcontains 'backend.app:app') { throw 'Owned restart failed' }
if ((Test-Path -LiteralPath (Join-Path (Split-Path $PSScriptRoot -Parent) 'backend/.env')) -and $studioMockStarted[0] -notcontains '--env-file') { throw 'Restart must load the configuration file' }
'PASS: restart stops only verified local backend and reuses frontend'

$global:studioMockOwned=$false; $global:studioMockPortBusy=$true
$global:studioMockStopped=@(); $global:studioMockStarted=@()
try { & $studioTestPath -RestartBackend; throw 'Unsafe restart was allowed' }
catch { if ($_.Exception.Message -notmatch '无法确认8000') { throw } }
if ($studioMockStopped.Count -or $studioMockStarted.Count) { throw 'Other-project service changed' }
'PASS: other-project backend refused without stopping any process'

$global:studioMockOwned=$true; $global:studioMockPortBusy=$true
$global:studioMockStopped=@(); $global:studioMockStarted=@()
& $studioTestPath
if ($studioMockStopped.Count -or $studioMockStarted.Count) { throw 'Default reuse changed running services' }
'PASS: ordinary start reuses existing backend and frontend'
$global:studioMockFreeFirstPort=$true
& $studioTestPath
if ($studioMockStarted.Count) { throw 'Free earlier port must not duplicate an existing frontend' }
'PASS: existing frontend is reused even when an earlier port is free'
