"""Download the official CubiCasa5K checkpoint, without executing its contents."""
from pathlib import Path
import hashlib
import json
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
URL = 'https://drive.usercontent.google.com/download?id=1gRB7ez1e4H7a9Y09lLqRuna0luZO5VRK&export=download&confirm=t'
EXPECTED_BYTES = 208_651_193
EXPECTED_SHA256 = 'dd20b4e1bf1d670f2125107b079df06958b1ccd36e49a464ab739aeb00b8e7a2'
DESTINATION = ROOT / 'models' / 'cubicasa5k' / 'model_best_val_loss_var.pkl'


def download():
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    if DESTINATION.is_file() and DESTINATION.stat().st_size == EXPECTED_BYTES:
        with DESTINATION.open('rb') as existing:
            existing_digest = hashlib.file_digest(existing, 'sha256').hexdigest()
        if existing_digest == EXPECTED_SHA256:
            print(f'Checkpoint verified: {DESTINATION}', flush=True)
            return
    temporary = DESTINATION.with_suffix('.part')
    digest = hashlib.sha256()
    total = 0
    with urllib.request.urlopen(URL, timeout=60) as response:
        if 'text/' in response.headers.get('Content-Type', ''):
            raise RuntimeError('Official download returned a text page rather than model weights.')
        with temporary.open('wb') as output:
            while chunk := response.read(1024 * 1024):
                total += len(chunk)
                if total > EXPECTED_BYTES:
                    raise RuntimeError('Checkpoint exceeds the expected official file size.')
                output.write(chunk)
                digest.update(chunk)
                if total // (25 * 1024 * 1024) != (total - len(chunk)) // (25 * 1024 * 1024):
                    print(f'Downloaded {total / 1024**2:.0f} / {EXPECTED_BYTES / 1024**2:.0f} MiB', flush=True)
    if total != EXPECTED_BYTES:
        raise RuntimeError(f'Incomplete checkpoint: {total} bytes. Run this script again.')
    if digest.hexdigest() != EXPECTED_SHA256:
        raise RuntimeError('Checkpoint hash differs from the verified official weights. Download was not installed.')
    temporary.replace(DESTINATION)
    metadata = {'source': URL, 'upstream': 'https://github.com/CubiCasa/CubiCasa5k',
                'upstream_code_license': 'CC BY-NC 4.0',
                'weight_redistribution_license': 'No separate unrestricted redistribution authorization verified; obtain from upstream and review terms.',
                'bytes': total, 'sha256': digest.hexdigest()}
    DESTINATION.with_suffix('.provenance.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    print(json.dumps(metadata, indent=2), flush=True)


if __name__ == '__main__':
    download()
