"""Contracts between a local raster model, metric geometry and the public API.

Inference and label vectorization are mocked here: these tests never fetch or
load pretrained weights. Mask geometry is tested in test_plan_vectorization.
The adapter must produce a project accepted by the actual frontend validator.
"""

import copy
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import pickle
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np
from PIL import Image

from backend.algorithm import PlanError
from backend import neural_plan
from backend.plan_vectorization import VectorizationError


ROOT = Path(__file__).resolve().parents[1]


def raster_bytes():
    buffer = io.BytesIO()
    Image.new('RGB', (320, 220), 'white').save(buffer, 'PNG')
    return buffer.getvalue()


def segmented_plan():
    return {'labels': np.zeros((220, 320), np.uint8),
            'roomLabels': np.zeros((220, 320), np.uint8),
            'image': Image.new('RGB', (320, 220)),
            'meta': {'device': 'cpu', 'inferenceSeconds': .1,
                     'sourcePixels': [1280, 880], 'processedPixels': [320, 220],
                     'meanClassProbability': .8, 'needsReview': True,
                     'sourceRepository': 'https://github.com/CubiCasa/CubiCasa5k'}}


def pixel_geometry():
    """Two measured rectangles separated by one wall with a door opening."""
    return {'bounds': [10, 20, 290, 200],
            'walls': [
                {'start': [10, 20], 'end': [290, 20], 'thickness': 7},
                {'start': [290, 20], 'end': [290, 200], 'thickness': 7},
                {'start': [10, 200], 'end': [290, 200], 'thickness': 7},
                {'start': [10, 20], 'end': [10, 200], 'thickness': 7},
                {'start': [160, 20], 'end': [160, 200], 'thickness': 7}],
            'openings': [{'wallIndex': 4, 'type': 'door', 'offset': 68, 'width': 32},
                         {'wallIndex': 0, 'type': 'window', 'offset': 40, 'width': 50}],
            'rooms': [{'polygon': [[14, 24], [156, 24], [156, 196], [14, 196]],
                       'area': 142 * 172, 'semantic': 4},
                      {'polygon': [[164, 24], [286, 24], [286, 196], [164, 196]],
                       'area': 122 * 172, 'semantic': 5}],
            'warnings': []}


def parse_mock_geometry(geometry=None, width=12, height=2.8):
    geometry = pixel_geometry() if geometry is None else geometry
    with patch.object(neural_plan, 'segment_floor_plan', return_value=segmented_plan()), \
            patch.object(neural_plan, 'vectorize_plan_labels', return_value=copy.deepcopy(geometry)):
        return neural_plan.parse_neural_floor_plan(b'mocked raster', width, height)


class MetricAdapterTests(unittest.TestCase):
    def test_import_has_metric_geometry_room_semantics_and_reviewable_unknown_progress(self):
        model = parse_mock_geometry(height=2.9)
        self.assertEqual(model['source'], 'opencv')
        self.assertEqual(model['meta']['engine'], 'neural')
        self.assertIn('cubicasa', model['meta']['algorithm'])
        self.assertTrue(model['meta']['geometryNeedsReview'])
        self.assertEqual(model['meta']['recognition']['sourcePixels'], [1280, 880])
        self.assertEqual(model['meta']['recognition']['processedPixels'], [320, 220])
        self.assertEqual(model['meta']['recognition']['doors'], 1)
        self.assertEqual(model['meta']['recognition']['windows'], 1)
        self.assertEqual(model['width'], 12)
        self.assertAlmostEqual(model['depth'], 12 * 180 / 280, places=4)
        self.assertEqual(model['height'], 2.9)
        self.assertEqual(model['walls'][0]['start'], [0, 0])
        self.assertEqual(model['walls'][0]['end'], [12, 0])
        self.assertTrue(model['rooms'][0]['name'].startswith('客厅'))
        self.assertTrue(model['rooms'][1]['name'].startswith('卧室'))
        for room in model['rooms']:
            self.assertEqual(room['progress'], 0)
            self.assertEqual(room['evidence'], [])
            for task in room['tasks'].values():
                self.assertEqual(task['stage'], 'unknown')
                self.assertEqual(task['plannedStage'], 'unknown')
                self.assertEqual(task['dueDate'], '')
        # This is an image-derived initial structure, not evidence of a
        # construction stage or of a fitted furniture scheme.
        self.assertNotIn('furniture', model)
        self.assertNotIn('designBrief', model)
        json.dumps(model, allow_nan=False)

    def test_scale_changes_lengths_and_area_consistently_without_changing_topology(self):
        small, large = parse_mock_geometry(width=6), parse_mock_geometry(width=12)
        self.assertEqual(len(small['walls']), len(large['walls']))
        self.assertEqual(len(small['rooms']), len(large['rooms']))
        self.assertEqual(len(small['openings']), len(large['openings']))
        self.assertAlmostEqual(large['depth'], 2 * small['depth'], delta=.0002)
        for first, second in zip(small['rooms'], large['rooms']):
            self.assertAlmostEqual(second['area'], 4 * first['area'], delta=.025)
        for first, second in zip(small['openings'], large['openings']):
            self.assertAlmostEqual(second['width'], 2 * first['width'], delta=.0002)
            self.assertAlmostEqual(second['offset'], 2 * first['offset'], delta=.0002)

    def test_metric_validation_rejects_bool_nonfinite_out_of_range_before_inference(self):
        with patch.object(neural_plan, 'segment_floor_plan') as inference:
            for width in (True, False, 0, .99, 100.01, float('nan'), float('inf'), '12', None):
                with self.subTest(width=width), self.assertRaises(PlanError):
                    neural_plan.parse_neural_floor_plan(b'mocked raster', width)
            for height in (True, False, 1.99, 6.01, float('nan'), float('-inf'), '2.8', None):
                with self.subTest(height=height), self.assertRaises(PlanError):
                    neural_plan.parse_neural_floor_plan(b'mocked raster', height=height)
        inference.assert_not_called()

    def test_vectorization_failure_is_a_reviewable_plan_error(self):
        with patch.object(neural_plan, 'segment_floor_plan', return_value=segmented_plan()), \
                patch.object(neural_plan, 'vectorize_plan_labels', side_effect=VectorizationError('墙体未封闭')):
            with self.assertRaisesRegex(PlanError, '未封闭'):
                neural_plan.parse_neural_floor_plan(b'mocked raster')

    def test_extreme_aspect_ratio_and_metric_short_wall_are_rejected(self):
        tall = pixel_geometry()
        tall['bounds'] = [10, 20, 11, 200]
        with self.assertRaisesRegex(PlanError, '长宽比'):
            parse_mock_geometry(tall)
        tiny = pixel_geometry()
        tiny['walls'].append({'start': [50, 50], 'end': [50.1, 50], 'thickness': 1})
        with self.assertRaisesRegex(PlanError, '墙段过短'):
            parse_mock_geometry(tiny)

    def test_too_small_and_outside_openings_are_skipped_with_warning(self):
        geometry = pixel_geometry()
        geometry['openings'] = [{'wallIndex': 0, 'type': 'door', 'offset': 5, 'width': 1},
                                {'wallIndex': 0, 'type': 'window', 'offset': 350, 'width': 50}]
        model = parse_mock_geometry(geometry)
        self.assertEqual(model['openings'], [])
        self.assertTrue(any('跳过' in warning for warning in model['warnings']))
        self.assertEqual(model['meta']['recognition']['doors'], 0)
        self.assertEqual(model['meta']['recognition']['windows'], 0)

    def test_low_ceiling_keeps_window_and_door_below_wall_top(self):
        model = parse_mock_geometry(height=2)
        for opening in model['openings']:
            top = opening.get('sill', 0) + opening['height']
            self.assertLessEqual(top, model['height'])
            self.assertGreaterEqual(opening.get('sill', 0), 0)
            self.assertGreaterEqual(opening['height'], .1)

    def test_small_but_valid_room_area_does_not_round_to_zero(self):
        geometry = pixel_geometry()
        geometry['rooms'].append({'polygon': [[14, 24], [27, 24], [27, 37], [14, 37]],
                                  'area': 169, 'semantic': 9})
        model = parse_mock_geometry(geometry, width=1)
        self.assertGreaterEqual(model['rooms'][-1]['area'], .001)
        self.assertAlmostEqual(model['rooms'][-1]['area'], 169 / 280 ** 2, delta=.0001)

    def test_four_decimal_openings_fit_rounded_slanted_wall_endpoints(self):
        geometry = pixel_geometry()
        geometry['walls'][4] = {'start': [10, 20], 'end': [130, 110], 'thickness': 7}
        # The opening ends exactly at the 150 px diagonal wall endpoint.
        geometry['openings'] = [{'wallIndex': 4, 'type': 'door', 'offset': 25.123, 'width': 124.877}]
        model = parse_mock_geometry(geometry)
        self.assertEqual(len(model['openings']), 1)
        opening = model['openings'][0]
        wall = next(row for row in model['walls'] if row['id'] == opening['wallId'])
        length = math.dist(wall['start'], wall['end'])
        self.assertLessEqual(opening['offset'] + opening['width'], length + 1e-5,
                             'independent rounding must not invalidate an otherwise valid imported house')

    def test_subpixel_overlapping_openings_do_not_survive_metric_conversion(self):
        geometry = pixel_geometry()
        # A 0.25 px overlap can pass the vectorizer's raster tolerance, but is
        # over a centimetre at this scale; the two default vertical spans also
        # overlap. The imported project must contain only nonconflicting holes.
        geometry['openings'] = [{'wallIndex': 0, 'type': 'window', 'offset': 40, 'width': 50},
                                {'wallIndex': 0, 'type': 'door', 'offset': 89.75, 'width': 25}]
        model = parse_mock_geometry(geometry)
        self.assertEqual(len(model['openings']), 1)
        self.assertTrue(any('重叠' in warning or '冲突' in warning for warning in model['warnings']))

    def test_warning_budget_is_compatible_with_saved_project_schema(self):
        geometry = pixel_geometry()
        geometry['warnings'] = [f'需核对墙段 {index}' for index in range(100)]
        model = parse_mock_geometry(geometry)
        self.assertLessEqual(len(model['warnings']), 100)
        self.assertTrue(any('神经模型' in warning for warning in model['warnings']))
        self.assertEqual(len(model['warnings']), len(set(model['warnings'])))

    @unittest.skipUnless(shutil.which('node'), 'frontend validator requires Node.js')
    def test_imported_model_is_accepted_by_the_actual_frontend_validator(self):
        model = parse_mock_geometry()
        script = "import{readFileSync}from'node:fs';import{validateProject}from'./src/project.mjs';validateProject(JSON.parse(readFileSync(0,'utf8')));"
        result = subprocess.run([shutil.which('node'), '--input-type=module', '-e', script],
                                input=json.dumps(model), text=True, capture_output=True, cwd=ROOT, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)


class EngineSelectionTests(unittest.TestCase):
    def classic_result(self):
        result = parse_mock_geometry()
        result['openings'] = []
        result['meta'] = {'algorithm': 'orthogonal-morphology-v1'}
        result['warnings'] = ['基础几何需核对']
        return result

    def test_auto_with_weak_line_evidence_returns_neural_result(self):
        expected = parse_mock_geometry()
        candidate = self.classic_result()
        candidate['meta']['classicStructure'] = {'inkCoverage': .5, 'connectedWallShare': .5}
        with patch.object(neural_plan, 'parse_neural_floor_plan', return_value=expected) as neural, \
                patch.object(neural_plan, 'parse_floor_plan', return_value=candidate) as classic:
            model = neural_plan.recognize_floor_plan(b'raster', 11, 2.9)
        self.assertIs(model, expected)
        neural.assert_called_once_with(b'raster', 11, 2.9)
        classic.assert_called_once_with(b'raster', 11, 2.9)

    def test_auto_preserves_clear_connected_orthogonal_geometry_without_neural_guessing(self):
        candidate = self.classic_result()
        candidate['meta']['classicStructure'] = {'inkCoverage': 1., 'connectedWallShare': 1.}
        with patch.object(neural_plan, 'parse_neural_floor_plan') as neural, \
                patch.object(neural_plan, 'parse_floor_plan', return_value=candidate):
            model = neural_plan.recognize_floor_plan(b'raster')
        neural.assert_not_called()
        self.assertEqual(model['meta']['engine'], 'classic')
        self.assertEqual(model['meta']['selectionReason'], 'closed_orthogonal_structure')
        self.assertNotIn('fallbackReason', model['meta'])
        self.assertTrue(any('连续闭合正交墙线' in warning for warning in model['warnings']))

    def test_auto_falls_back_after_model_failure_and_exposes_reason(self):
        reason = '神经墙体未形成房间'
        classic_result = self.classic_result()
        with patch.object(neural_plan, 'parse_neural_floor_plan', side_effect=PlanError(reason)), \
                patch.object(neural_plan, 'parse_floor_plan', return_value=classic_result) as classic:
            model = neural_plan.recognize_floor_plan(b'raster', engine='auto')
        classic.assert_called_once()
        self.assertEqual(model['meta']['engine'], 'classic')
        self.assertEqual(model['meta']['fallbackReason'], reason)
        self.assertEqual(model['meta']['recognition']['doors'], 0)
        self.assertTrue(model['meta']['recognition']['needsReview'])
        self.assertTrue(any(reason in warning and '基础线条' in warning for warning in model['warnings']))

    def test_explicit_neural_failure_never_silently_calls_classic(self):
        with patch.object(neural_plan, 'parse_neural_floor_plan', side_effect=PlanError('神经识别未就绪')), \
                patch.object(neural_plan, 'parse_floor_plan') as classic:
            with self.assertRaisesRegex(PlanError, '未就绪'):
                neural_plan.recognize_floor_plan(b'raster', engine='neural')
        classic.assert_not_called()

    def test_explicit_classic_skips_neural_even_when_weights_exist(self):
        classic_result = self.classic_result()
        with patch.object(neural_plan, 'parse_neural_floor_plan') as neural, \
                patch.object(neural_plan, 'parse_floor_plan', return_value=classic_result):
            model = neural_plan.recognize_floor_plan(b'raster', engine='classic')
        neural.assert_not_called()
        self.assertEqual(model['meta']['engine'], 'classic')
        self.assertNotIn('fallbackReason', model['meta'])

    def test_unknown_engine_is_rejected_before_any_recognition(self):
        with patch.object(neural_plan, 'parse_neural_floor_plan') as neural, \
                patch.object(neural_plan, 'parse_floor_plan') as classic:
            for engine in ('cloud', '', None):
                with self.subTest(engine=engine), self.assertRaises(PlanError):
                    neural_plan.recognize_floor_plan(b'raster', engine=engine)
        neural.assert_not_called()
        classic.assert_not_called()

    def test_boolean_metric_cannot_become_valid_by_falling_back_to_classic(self):
        # Validate the user input before choosing a runtime. A bool is not a
        # metre value even though Python treats it as an integer.
        with patch.object(neural_plan, 'parse_neural_floor_plan') as neural, \
                patch.object(neural_plan, 'parse_floor_plan') as classic:
            for engine in ('auto', 'classic', 'neural'):
                with self.subTest(engine=engine), self.assertRaises(PlanError):
                    neural_plan.recognize_floor_plan(b'raster', real_width=True, engine=engine)
        neural.assert_not_called()
        classic.assert_not_called()


class RuntimeReadinessTests(unittest.TestCase):
    def test_ready_status_requires_both_local_weights_and_runtime_without_downloading(self):
        with tempfile.TemporaryDirectory() as directory:
            weights = Path(directory) / 'local-model.pkl'
            env = {'PLAN_MODEL_PATH': str(weights)}
            with patch.dict(os.environ, env), patch('importlib.util.find_spec', return_value=object()):
                self.assertFalse(neural_plan.recognition_status()['available'])
                weights.write_bytes(b'fixture presence only')
                status = neural_plan.recognition_status()
                self.assertTrue(status['available'])
                self.assertTrue(status['weightsPresent'])
                self.assertTrue(status['runtimePresent'])
                self.assertTrue(status['requiresReview'])
                self.assertNotIn('path', status)
            with patch.dict(os.environ, env), patch('importlib.util.find_spec', return_value=None):
                self.assertFalse(neural_plan.recognition_status()['available'])

    def test_unavailable_runtime_raises_actionable_error_before_loading_network(self):
        with patch.object(neural_plan, 'recognition_status', return_value={'available': False}), \
                patch.object(neural_plan, '_load_network') as loader:
            with self.assertRaisesRegex(PlanError, '基础线条'):
                neural_plan.segment_floor_plan(raster_bytes())
        loader.assert_not_called()

    def test_input_side_setting_is_validated_before_inference(self):
        with patch.object(neural_plan, 'recognition_status', return_value={'available': True}), \
                patch.object(neural_plan, '_load_network') as loader:
            for side in ('garbage', '511', '1025', '768.5'):
                with self.subTest(side=side), patch.dict(os.environ, {'PLAN_INPUT_SIDE': side}), \
                        self.assertRaisesRegex(PlanError, '512'):
                    neural_plan.segment_floor_plan(raster_bytes())
        loader.assert_not_called()

    def test_corrupt_or_unsafe_checkpoint_is_reported_as_plan_error(self):
        # Mock torch itself to keep this test independent of both torch startup
        # and actual checkpoints; always require weights_only in the adapter.
        fake_torch = SimpleNamespace(cuda=SimpleNamespace(is_available=lambda: False),
                                     set_num_threads=Mock(), load=Mock())
        fake_vendor = SimpleNamespace(hg_furukawa_original=Mock())
        modules = {'torch': fake_torch,
                   'backend.vendor.cubicasa.hg_furukawa_original': fake_vendor}
        neural_plan._load_network.cache_clear()
        try:
            with patch.dict(sys.modules, modules):
                for error in (pickle.UnpicklingError('unsafe checkpoint'), EOFError('truncated checkpoint')):
                    fake_torch.load.side_effect = error
                    with self.subTest(error=type(error).__name__), self.assertRaisesRegex(PlanError, '权重'):
                        neural_plan._load_network('fixture-only.pkl', 'cpu')
                    self.assertTrue(fake_torch.load.call_args.kwargs['weights_only'])
                    fake_vendor.hg_furukawa_original.assert_not_called()
        finally:
            neural_plan._load_network.cache_clear()


@unittest.skipUnless(importlib.util.find_spec('fastapi') and importlib.util.find_spec('httpx')
                     and importlib.util.find_spec('multipart'), 'API test dependencies are not installed')
class RecognitionApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from backend.app import app
        cls.client = TestClient(app)

    def upload(self, data=None):
        return self.client.post('/api/parse-plan', files={'file': ('plan.png', raster_bytes(), 'image/png')},
                                data={} if data is None else data)

    def test_engine_form_defaults_to_auto_and_all_modes_are_forwarded(self):
        model = parse_mock_geometry()
        for data, engine, width, height in [({}, 'auto', 12., 2.8),
                                           ({'engine': 'auto'}, 'auto', 12., 2.8),
                                           ({'engine': 'classic', 'real_width': '9', 'height': '3'}, 'classic', 9., 3.),
                                           ({'engine': 'neural'}, 'neural', 12., 2.8)]:
            with self.subTest(engine=engine, data=data), \
                    patch('backend.app.recognize_floor_plan', return_value=model) as recognizer:
                response = self.upload(data)
            self.assertEqual(response.status_code, 200, response.text)
            recognizer.assert_called_once_with(raster_bytes(), width, height, engine)
            self.assertEqual(response.json()['source'], 'opencv')
            self.assertTrue(response.json()['meta']['geometryNeedsReview'])

    def test_explicit_neural_error_is_422_while_auto_exposes_classic_fallback(self):
        classic_result = EngineSelectionTests().classic_result()
        with patch.object(neural_plan, 'parse_neural_floor_plan', side_effect=PlanError('测试：权重不可用')), \
                patch.object(neural_plan, 'parse_floor_plan', return_value=classic_result) as classic:
            forced = self.upload({'engine': 'neural'})
            self.assertEqual(forced.status_code, 422)
            self.assertIn('权重不可用', forced.json()['detail'])
            classic.assert_not_called()
            automatic = self.upload({'engine': 'auto'})
            self.assertEqual(automatic.status_code, 200, automatic.text)
            classic.assert_called_once()
        result = automatic.json()
        self.assertEqual(result['meta']['engine'], 'classic')
        self.assertIn('权重不可用', result['meta']['fallbackReason'])
        self.assertTrue(any('基础线条' in warning for warning in result['warnings']))

    def test_invalid_engine_and_nonfinite_dimensions_reject_before_inference(self):
        with patch.object(neural_plan, 'parse_neural_floor_plan') as neural, \
                patch.object(neural_plan, 'parse_floor_plan') as classic:
            for data in ({'engine': 'external'}, {'real_width': 'nan'}, {'height': 'inf'},
                         {'real_width': 'true'}, {'real_width': '101'}, {'height': '1.9'}):
                with self.subTest(data=data):
                    response = self.upload(data)
                    self.assertEqual(response.status_code, 422, response.text)
        neural.assert_not_called()
        classic.assert_not_called()

    def test_health_reports_local_readiness_without_inference_or_secret(self):
        status = {'available': False, 'engine': 'cubicasa5k', 'weightsPresent': False,
                  'runtimePresent': True, 'requiresReview': True}
        with patch('backend.app.recognition_status', return_value=status), \
                patch.object(neural_plan, '_load_network') as loader, \
                patch.dict(os.environ, {'QWEN_API_KEY': 'unit-test-secret'}):
            response = self.client.get('/api/health')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['algorithm'], 'hybrid-floorplan-v2')
        self.assertEqual(response.json()['planRecognition'], status)
        self.assertTrue(response.json()['designConfigured'])
        self.assertNotIn('unit-test-secret', response.text)
        loader.assert_not_called()


if __name__ == '__main__':
    unittest.main()
